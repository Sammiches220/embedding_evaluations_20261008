# Embedding Feature Audit

A small Python project for testing **how faithfully a feature from a source population is represented by an embedding**, then comparing that geometry against **extrinsic predictions** of the same feature.

The package emphasizes **neighborhood purity** and **lift** because they are easy to connect to segmentation, targeting, retrieval, recommendation, risk, operations, and other business workflows.

## Core ideas

For item `i`, neighborhood purity at scale `k` is the fraction of its `k` nearest neighbors with the same label:

```text
purity_k(i) = matching neighbors / k
```

Purity is intuitive, but it is strongly affected by class prevalence. A label occupying 80% of the population will have high expected purity even in an uninformative embedding.

Lift corrects for this baseline:

```text
lift_k(i) = purity_k(i) / prevalence(label_i)
```

Interpretation:

- `lift = 1`: no enrichment over population prevalence.
- `lift > 1`: the embedding concentrates similar items locally.
- `lift < 1`: the local neighborhood is less homogeneous than prevalence would predict.

The project reports both **micro** metrics (each item contributes equally) and **macro** metrics (each label contributes equally). Macro metrics are especially useful when minority segments matter commercially.

## Included analyses

### Source-population characterization

For categorical features:

- label prevalence/counts
- largest-label share
- Shannon entropy
- normalized entropy
- number of labels
- missing share

For continuous features:

- mean/std
- quantiles
- range
- missing share

### Embedding representation

- purity curves across multiple neighborhood sizes `k`
- lift curves across `k`
- per-label purity/lift
- micro and macro aggregation
- permutation null distributions
- z-scores relative to the permutation null
- simple representation probes:
  - linear/logistic probe
  - k-nearest-neighbor probe
  - random-forest nonlinear probe

For continuous features:

- mean neighbor absolute difference
- local variance
- local/global variance ratio
- linear, k-NN, and random-forest regression probes

### Extrinsic prediction auditing

If you provide predictions aligned to the same rows:

- raw accuracy
- balanced accuracy
- macro F1
- Jensen-Shannon divergence between source and predicted label distributions
- change in largest-label share
- change in normalized entropy
- change in number of labels
- predicted-vs-true purity/lift curves
- purity/lift deltas and ratios across scale

This makes it possible to catch cases where a prediction system makes the representation appear artificially cleaner.

### Missingness / reconstruction experiments

The package deliberately hides increasing fractions of known labels and reconstructs them with a k-NN predictor. It performs both:

- **random missingness**
- **rare-first missingness**, which preferentially removes minority labels

It then measures prediction quality, distribution drift, and geometric distortion.

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Demo

Generate a synthetic dataset:

```bash
python examples/make_demo_data.py
```

Run the full categorical audit:

```bash
embedding-feature-audit \
  --embeddings examples/demo_data/embeddings.npy \
  --labels examples/demo_data/labels.npy \
  --predicted-labels examples/demo_data/predicted_labels.npy \
  --ks 5,10,25,50,100,250 \
  --permutations 30 \
  --missingness 0.1,0.25,0.5,0.75 \
  --out demo_audit
```

Output structure:

```text
demo_audit/
├── source_summary.json
├── prediction_accuracy.json
├── prediction_distribution_distortion.json
├── tables/
│   ├── label_prevalence.csv
│   ├── purity_lift_by_k.csv
│   ├── purity_lift_by_label.csv
│   ├── probe_results.csv
│   ├── permutation_null.csv
│   ├── purity_lift_with_null_zscores.csv
│   ├── predicted_purity_lift_by_k.csv
│   ├── predicted_purity_lift_by_label.csv
│   ├── prediction_geometric_distortion.csv
│   └── missingness_*.csv
└── plots/
    ├── observed_purity_curve.png
    ├── observed_lift_curve.png
    ├── predicted_purity_curve.png
    ├── predicted_lift_curve.png
    ├── per_label_lift.png
    ├── lift_vs_null.png
    ├── prediction_lift_distortion.png
    ├── probe_*.png
    └── missingness_*/
```

## Using your own data

The important assumption is **row alignment**:

```text
embeddings[i] <-> observed_label[i] <-> predicted_label[i]
```

The embedding must be a 2-D matrix `[N, D]`. Labels can be `.npy`, or a one-column CSV/TSV. For a multi-column table, pass `--label-column`.

Example:

```bash
embedding-feature-audit \
  --embeddings data/embeddings.npy \
  --labels data/features.parquet \
  --label-column artist_cluster \
  --predicted-labels data/features.parquet \
  --predicted-label-column predicted_artist_cluster \
  --out artist_audit
```

## Business-oriented interpretation of purity and lift

Suppose `enterprise` customers are 5% of the source population.

If an enterprise item's 50-nearest-neighbor neighborhood is 30% enterprise:

```text
purity = 0.30
lift = 0.30 / 0.05 = 6.0
```

That means enterprise customers occur **6× as often locally as their population baseline**. This is often more actionable than purity alone because it separates genuine concentration from effects caused by segment size.

A few useful readings:

- **high purity + high lift**: strong, locally coherent segment
- **high purity + lift near 1**: likely a very common segment; purity may be misleading
- **low purity + high lift**: rare segment that is still meaningfully enriched locally
- **macro lift >> micro lift**: minority labels are strongly structured even if dominant labels drive most observations
- **predicted lift > true lift**: prediction may be artificially sharpening the apparent segmentation
- **predicted lift < true lift**: prediction is washing out real structure

## Important warning about circularity

If the extrinsic predictor itself consumes the same embedding being audited, then geometric coherence of the predicted labels is **not independent evidence**. A model trained from `Z` to predict `Y` is naturally likely to produce predictions that look organized in `Z`.

Use the prediction-distortion outputs to describe what changed, but do not interpret increased lift as independent validation unless the predictor comes from genuinely separate information.

## Scaling notes

The current nearest-neighbor implementation uses scikit-learn `NearestNeighbors`. That is convenient and exact, but very large datasets may require approximate-nearest-neighbor infrastructure such as FAISS, HNSW, or a precomputed k-NN graph. The metric functions are intentionally separated so that neighbor retrieval can be swapped later.
