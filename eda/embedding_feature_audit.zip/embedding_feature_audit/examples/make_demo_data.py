from pathlib import Path
import numpy as np

rng = np.random.default_rng(7)
out = Path(__file__).resolve().parent / "demo_data"
out.mkdir(exist_ok=True)

n = 3000
labels = rng.choice(np.array(["enterprise", "midmarket", "smb", "other"]), size=n, p=[0.12, 0.23, 0.5, 0.15])
centers = {
    "enterprise": np.array([3.2, 0.0, 0.5, 0.0, 0.0, 0.0]),
    "midmarket": np.array([1.1, 1.7, 0.0, 0.0, 0.0, 0.0]),
    "smb": np.array([-1.0, 0.2, 0.0, 0.0, 0.0, 0.0]),
    "other": np.array([0.0, -2.5, 0.0, 0.0, 0.0, 0.0]),
}
z = np.vstack([centers[x] + rng.normal(0, 1.2, 6) for x in labels]).astype("float32")
# Add nuisance dimensions to make the probe nontrivial.
z = np.hstack([z, rng.normal(size=(n, 10)).astype("float32")])

# Extrinsic predictions: imperfect and biased toward the majority class.
pred = labels.copy()
flip = rng.random(n) < 0.18
pred[flip] = rng.choice(np.array(["enterprise", "midmarket", "smb", "other"]), size=flip.sum(), p=[0.08, 0.18, 0.66, 0.08])

np.save(out / "embeddings.npy", z)
np.save(out / "labels.npy", labels)
np.save(out / "predicted_labels.npy", pred)
print(out)
