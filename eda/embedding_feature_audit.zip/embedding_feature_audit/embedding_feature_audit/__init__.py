"""Embedding feature fidelity auditing tools."""

__version__ = "0.1.0"
