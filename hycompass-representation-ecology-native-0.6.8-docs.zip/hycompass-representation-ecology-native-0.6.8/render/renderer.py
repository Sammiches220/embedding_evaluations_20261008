################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass
from typing import Any

##### Internal Imports #####
from model.workspace.session import ViewData
from .camera import Camera
from .gl_utils import GL, UniformCache
from .layers.density import DensityLayer
from .layers.coverage_field import CoverageFieldLayer
from .layers.points import PointsLayer
from .layers.segmentation import SegmentationLayer
from .layers.selection import SelectionLayer
from .resources import GLResources


################################################################################
# CLASSES
################################################################################
@dataclass
class RenderState:
    timeline: float = 0.5
    coverage_field_timeline: float = 0.5
    point_size: float = 1.25
    show_active: bool = True
    show_future: bool = True
    show_outside: bool = True
    cluster_colors: bool = False
    cap_background: bool = False
    background_cap: int = 1_000_000

    show_density: bool = True
    density_opacity: float = 0.42
    density_threshold: float = 0.04
    contour_levels: int = 12

    show_coverage_field: bool = True
    coverage_field_opacity: float = 0.66
    coverage_field_threshold: float = 0.38
    show_coverage_field_boundary: bool = True

    show_segmentations: bool = True
    segmentation_fill: bool = False
    segmentation_fill_opacity: float = 0.12
    segmentation_boundary: bool = True
    segmentation_boundary_width: float = 1.0
    segmentation_labels: bool = False


class Renderer:
    """OpenGL orchestration for one lightweight ViewData composition."""

    def __init__(self, dataset: ViewData, camera: Camera) -> None:
        self.dataset = dataset
        self.camera = camera
        self.theme = dataset.theme

        self.initialized = False
        self.initialization_error: Exception | None = None
        self.initialized_layers: list[str] = []

        self.state = RenderState(
            show_density=bool(dataset.densities),
            show_coverage_field=dataset.coverage_field is not None,
            show_segmentations=bool(dataset.segmentations),
            coverage_field_threshold=float(dataset.spec.coverage_field_style.get("threshold", 0.38)),
        )
        self.resources = GLResources(dataset)
        self.uniforms = UniformCache()
        self.device_pixel_ratio = 1.0
        self.viewport_width = 1
        self.viewport_height = 1
        self.gl_renderer = "not initialized"
        self.gl_version = "not initialized"
        self.upload_ms = 0.0
        self.cpu_submit_ms = 0.0
        self.fps = 0.0
        self._swaps = deque(maxlen=120)

        self.density_layers = [DensityLayer(i) for i in range(len(dataset.densities))]
        self.coverage_field_layer = CoverageFieldLayer()
        self.segmentation_layers = [SegmentationLayer(i) for i in range(len(dataset.segmentations))]
        self.points_layer = PointsLayer()
        self.selection_layer = SelectionLayer()
        self.layers = [
            *self.density_layers,
            self.coverage_field_layer,
            *self.segmentation_layers,
            self.points_layer,
            self.selection_layer,
        ]

    def initialize(self) -> None:
        self.initialized = False
        self.intialization_error = None
        self.initialized_layers = []

        try:
            self.gl_renderer = (
                GL.glGetString(GL.GL_RENDERER) or b"?"
            ).decode(
                "utf-8",
                "replace"
            )

            self.gl_version = (
                GL.glGetString(GL.GL_VERSION) or b"?"
            ).decode(
                "utf-8",
                "replace"
            )

            print(
                "OpenGL initialization:",
                f"renderer={self.gl_renderer!r}",
                f"version={self.gl_version!r}",
            )

            for layer in self.layers:
                layer_name = type(layer).__name__

                print(
                    f"Initializing render layer: {layer_name}"
                )

                try:
                    layer.initialize(self)
                except Exception as exc:
                    print(
                        f"Failed to initialize render layer "
                        f"{layer_name}: "
                        f"{type(exc).__name__}: {exc}"
                    )
                    raise

                self.initialized_layers.append(layer_name)

                print(
                    f"Initialized render layer: {layer_name}"
                )

            print("Initializing shared OpenGL resources")

            started = time.perf_counter()

            self.resources.initialize()

            self.upload_ms = (time.perf_counter() - started) * 1000.0

            GL.glDisable(GL.GL_DEPTH_TEST)
            GL.glEnable(GL.GL_PROGRAM_POINT_SIZE)
            GL.glEnable(GL.GL_BLEND)
            GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)

            self.initialized = True

            print(
                "Renderer initialization completed:",
                ", ".join(self.initialized_layers),
            )

        except Exception as exc:
            self.initialization_error = exc
            print(
                "Renderer initialization failed after layers:",
                self.initialized_layers,
            )
            raise

    def resize(self, width: int, height: int, device_pixel_ratio: float) -> None:
        self.viewport_width = max(1, int(width))
        self.viewport_height = max(1, int(height))
        self.device_pixel_ratio = float(device_pixel_ratio)
        GL.glViewport(0, 0, max(1, int(width * device_pixel_ratio)), max(1, int(height * device_pixel_ratio)))

    def draw(self, width: int, height: int, device_pixel_ratio: float) -> None:
        if not self.initialized:
            return

        self.viewport_width = max(1, int(width))
        self.viewport_height = max(1, int(height))
        self.device_pixel_ratio = float(device_pixel_ratio)

        started = time.perf_counter()

        bg = self.theme.background

        GL.glClearColor(*bg)
        GL.glClear(GL.GL_COLOR_BUFFER_BIT)

        for layer in self.layers:
            layer.draw(self)

        GL.glUseProgram(0)

        self.cpu_submit_ms = (time.perf_counter() - started) * 1000.0

    def frame_swapped(self) -> None:
        now = time.perf_counter()
        self._swaps.append(now)
        if len(self._swaps) > 1:
            dt = self._swaps[-1] - self._swaps[0]
            self.fps = (len(self._swaps) - 1) / dt if dt > 0 else 0.0

    def set_view_uniforms(self, program: int) -> None:
        half_w, half_h = self.camera.half_size(self.viewport_width, self.viewport_height)
        GL.glUniform2f(self.uniforms.location(program, "uViewCenter"), float(self.camera.view_center[0]), float(self.camera.view_center[1]))
        GL.glUniform2f(self.uniforms.location(program, "uHalfSize"), half_w, half_h)

    def uniform1f(self, program: int, name: str, value: float) -> None:
        GL.glUniform1f(self.uniforms.location(program, name), float(value))

    def uniform1i(self, program: int, name: str, value: int) -> None:
        GL.glUniform1i(self.uniforms.location(program, name), int(value))

    def uniform3f(self, program: int, name: str, value) -> None:
        GL.glUniform3f(self.uniforms.location(program, name), *map(float, value[:3]))

    def uniform4f(self, program: int, name: str, value) -> None:
        GL.glUniform4f(self.uniforms.location(program, name), *map(float, value[:4]))

    def draw_quad(self, texture: int, target: int, unit: int = 0) -> None:
        GL.glActiveTexture(GL.GL_TEXTURE0 + unit)
        GL.glBindTexture(target, texture)
        GL.glBindVertexArray(self.resources.quad_vao)
        GL.glDrawArrays(GL.GL_TRIANGLE_STRIP, 0, 4)
        GL.glBindVertexArray(0)

    def keep_fraction(self) -> float:
        if not self.state.cap_background:
            return 1.0
        estimate = max(1.0, self.dataset.projected_count / max(self.camera.zoom * self.camera.zoom, 1e-6))
        return float(min(1.0, self.state.background_cap / estimate))

    def density_style(self, asset_id: str) -> dict[str, Any]:
        return self.dataset.spec.density_styles.get(asset_id, {})

    def segmentation_style(self, asset_id: str) -> dict[str, Any]:
        return self.dataset.spec.segmentation_styles.get(asset_id, {})

    def coverage_field_style(self) -> dict[str, Any]:
        return self.dataset.spec.coverage_field_style

    def overlay_style(self, name: str) -> dict[str, Any]:
        style = self.dataset.spec.overlay_style if isinstance(self.dataset.spec.overlay_style, dict) else {}
        value = style.get(name, {})
        return value if isinstance(value, dict) else {}


################################################################################
if __name__=="__main__":
    pass
