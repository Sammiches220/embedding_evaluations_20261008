################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

##### Internal Imports #####
from render.gl_utils import GL, make_program
from .base import RenderLayer


################################################################################
# CLASSES
################################################################################
class CoverageFieldLayer(RenderLayer):
    def initialize(self, renderer) -> None:
        self.program = make_program("quad.vert", "coverage_field.frag")

    def draw(self, renderer) -> None:
        binding = renderer.dataset.coverage_field
        if binding is None or not renderer.state.show_coverage_field:
            return
        style = renderer.coverage_field_style()
        if style.get("visible", True) is False:
            return
        s, p = renderer.state, self.program
        GL.glUseProgram(p)
        renderer.set_view_uniforms(p)
        renderer.uniform1i(p, "uFrames", 0)
        renderer.uniform1f(p, "uTimeline", s.coverage_field_timeline)
        renderer.uniform1f(p, "uFrameCount", float(binding.frames.shape[0]))
        renderer.uniform1f(p, "uThreshold", float(style.get("threshold", s.coverage_field_threshold)))
        renderer.uniform1f(p, "uOpacity", float(style.get("opacity", s.coverage_field_opacity)))
        mode = str(style.get("display_mode", "both"))
        renderer.uniform1i(p, "uShowFill", int(mode in {"both", "field", "fill", "heatmap"}))
        renderer.uniform1i(p, "uShowBoundary", int(style.get("boundary", s.show_coverage_field_boundary) and mode in {"both", "boundary"}))
        palette = renderer.theme.palette("coverage_field_palette")
        for i, color in enumerate(palette):
            renderer.uniform3f(p, f"uPalette{i}", color)
        renderer.uniform4f(p, "uBoundaryColor", style.get("boundary_color", [1, 1, 1, 0.92]))
        renderer.draw_quad(renderer.resources.coverage_field_texture, GL.GL_TEXTURE_2D_ARRAY)


################################################################################
if __name__=="__main__":
    pass
