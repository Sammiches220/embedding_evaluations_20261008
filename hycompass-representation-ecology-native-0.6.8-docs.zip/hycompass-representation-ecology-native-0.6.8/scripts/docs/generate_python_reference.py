"""Generate virtual Python reference pages from project docstrings.

The generator runs inside MkDocs through ``mkdocs-gen-files``. It discovers
importable top-level packages, mirrors their module hierarchy under
``reference/``, and builds a literate navigation tree. Only public top-level
symbols that actually have docstrings are selected for rendering; class members
are then filtered recursively by mkdocstrings.

Google-style parsing and presentation are handled by the existing mkdocstrings
configuration in ``mkdocs.yml``.
"""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Iterable

import mkdocs_gen_files
import pathspec


PROJECT_ROOT = Path(__file__).resolve().parents[2]
REFERENCE_ROOT = Path("reference")

# Set to None to disable .gitignore-based filtering.
GITIGNORE_PATH: Path | None = PROJECT_ROOT / ".gitignore"

# Explicit project-relative paths to exclude regardless of .gitignore rules.
#
# These may refer to files or directories. Excluding a directory also excludes
# everything beneath it.
EXCLUDED_PATHS = {
    Path(".git"),
    Path(".github"),
    Path(".idea"),
    Path(".mypy_cache"),
    Path(".pytest_cache"),
    Path(".ruff_cache"),
    Path(".venv"),
    Path("build"),
    Path("dist"),
    Path("docs_generated"),
    Path("docs_src"),
    Path("site"),
    Path("tests"),
    Path("venv"),
}


def _load_gitignore(path: Path | None) -> pathspec.PathSpec | None:
    """Load optional Git-style ignore rules.

    Args:
        path: Path to a gitignore-style file, or ``None`` to disable filtering.

    Returns:
        Parsed ignore rules, or ``None`` when disabled or absent in an export.

    Raises:
        RuntimeError: If the configured ignore file cannot be read.
    """
    if path is None:
        return None

    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except FileNotFoundError:
        # Source ZIPs need not contain repository metadata. Explicit exclusions
        # still keep generated docs, tests and environments out of the reference.
        return None
    except OSError as exc:
        raise RuntimeError(f"unable to read ignore file {path}: {exc}") from exc

    return pathspec.PathSpec.from_lines("gitwildmatch", lines)


def _is_explicitly_excluded(path: Path, root: Path) -> bool:
    """Return whether a path is covered by an explicit exclusion."""
    relative = path.relative_to(root)

    for excluded in EXCLUDED_PATHS:
        if relative == excluded or excluded in relative.parents:
            return True

    return False


def _is_gitignored(
    path: Path,
    *,
    root: Path,
    spec: pathspec.PathSpec | None,
) -> bool:
    """Return whether a project path is excluded by gitignore-style rules."""
    if spec is None:
        return False

    relative = path.relative_to(root).as_posix()

    # A trailing slash lets directory-only patterns behave correctly when
    # checking directories themselves.
    if path.is_dir():
        relative += "/"

    return spec.match_file(relative)


def _is_excluded(
    path: Path,
    *,
    root: Path,
    gitignore: pathspec.PathSpec | None,
) -> bool:
    """Return whether a path is excluded by explicit or gitignore rules."""
    return _is_explicitly_excluded(path, root) or _is_gitignored(
        path,
        root=root,
        spec=gitignore,
    )


def _public_package_roots(
    root: Path,
    gitignore: pathspec.PathSpec | None,
) -> list[Path]:
    """Return importable top-level package directories in deterministic order."""
    return sorted(
        (
            child
            for child in root.iterdir()
            if child.is_dir()
            and not _is_excluded(child, root=root, gitignore=gitignore)
            and not child.name.startswith((".", "_"))
            and (child / "__init__.py").is_file()
        ),
        key=lambda path: path.name.casefold(),
    )


def _has_docstring(node: ast.AST) -> bool:
    """Return whether an AST node has a non-empty docstring."""
    try:
        return bool(ast.get_docstring(node, clean=False))
    except TypeError:
        return False


def _class_has_documented_public_member(node: ast.ClassDef) -> bool:
    """Return whether a class contains a documented public child."""
    for child in node.body:
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if not child.name.startswith("_") and _has_docstring(child):
                return True
    return False


def _documented_attribute_names(body: list[ast.stmt]) -> dict[int, list[str]]:
    """Map assignment line numbers to public attributes with adjacent docstrings.

    Griffe recognizes the common pattern ``name = value`` followed immediately
    by a string literal as an attribute docstring. This helper lets the generated
    module member list preserve those attributes as well.
    """
    result: dict[int, list[str]] = {}

    for index, node in enumerate(body[:-1]):
        next_node = body[index + 1]

        if not (
            isinstance(next_node, ast.Expr)
            and isinstance(next_node.value, ast.Constant)
            and isinstance(next_node.value.value, str)
            and next_node.value.value.strip()
        ):
            continue

        names: list[str] = []

        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and not target.id.startswith("_"):
                    names.append(target.id)

        elif isinstance(node, ast.AnnAssign):
            target = node.target
            if isinstance(target, ast.Name) and not target.id.startswith("_"):
                names.append(target.id)

        if names:
            result[node.lineno] = names

    return result


def _documented_public_members(tree: ast.Module) -> list[str]:
    """Return documented public module members in source order."""
    attributes = _documented_attribute_names(tree.body)
    members: list[tuple[int, str]] = []

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if not node.name.startswith("_") and _has_docstring(node):
                members.append((node.lineno, node.name))

        elif isinstance(node, ast.ClassDef):
            if not node.name.startswith("_") and (
                _has_docstring(node) or _class_has_documented_public_member(node)
            ):
                members.append((node.lineno, node.name))

        elif node.lineno in attributes:
            members.extend(
                (node.lineno, name)
                for name in attributes[node.lineno]
            )

    members.sort(key=lambda item: item[0])
    return [name for _, name in members]


def _module_files(
    package_roots: Iterable[Path],
    *,
    root: Path,
    gitignore: pathspec.PathSpec | None,
) -> list[Path]:
    """Return public Python source files from all discovered packages."""
    files: list[Path] = []

    for package_root in package_roots:
        for path in package_root.rglob("*.py"):
            relative = path.relative_to(package_root)

            if _is_excluded(path, root=root, gitignore=gitignore):
                continue

            if path.name == "__main__.py":
                continue

            if any(part.startswith("_") for part in relative.parts[:-1]):
                continue

            if path.name.startswith("_") and path.name != "__init__.py":
                continue

            files.append(path)

    return sorted(files, key=lambda path: path.as_posix().casefold())


def _module_parts(path: Path, root: Path) -> tuple[str, ...]:
    """Convert a Python source path into importable dotted-path components."""
    relative = path.relative_to(root).with_suffix("")
    parts = relative.parts

    if parts[-1] == "__init__":
        parts = parts[:-1]

    return tuple(parts)


def _reference_path(parts: tuple[str, ...], is_package: bool) -> Path:
    """Return the virtual Markdown path for a module or package."""
    if is_package:
        return REFERENCE_ROOT.joinpath(*parts, "index.md")

    return REFERENCE_ROOT.joinpath(*parts).with_suffix(".md")


def _write_module_page(
    *,
    source_path: Path,
    root: Path,
    parts: tuple[str, ...],
    members: list[str],
    has_module_docstring: bool,
) -> Path:
    """Write one virtual mkdocstrings page and return its path."""
    is_package = source_path.name == "__init__.py"
    full_doc_path = _reference_path(parts, is_package)
    identifier = ".".join(parts)

    with mkdocs_gen_files.open(full_doc_path, "w") as output:
        print(f"# `{identifier}`", file=output)
        print(file=output)
        print(f"::: {identifier}", file=output)
        print("    options:", file=output)

        if members:
            print("      members:", file=output)

            for member in members:
                print(f"        - {member}", file=output)

        elif has_module_docstring:
            print("      members: false", file=output)

    mkdocs_gen_files.set_edit_path(
        full_doc_path,
        source_path.relative_to(root),
    )

    return full_doc_path


def main() -> None:
    """Generate Python reference pages and their nested navigation."""
    root = PROJECT_ROOT
    gitignore = _load_gitignore(GITIGNORE_PATH)
    packages = _public_package_roots(root, gitignore)

    nav = mkdocs_gen_files.Nav()
    nav["Overview"] = "index.md"

    for source_path in _module_files(
        packages,
        root=root,
        gitignore=gitignore,
    ):
        try:
            source = source_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(source_path))
        except (OSError, SyntaxError, UnicodeError) as exc:
            raise RuntimeError(
                f"unable to inspect {source_path}: {exc}"
            ) from exc

        parts = _module_parts(source_path, root)

        if not parts:
            continue

        has_module_docstring = _has_docstring(tree)
        members = _documented_public_members(tree)

        if not has_module_docstring and not members:
            continue

        full_doc_path = _write_module_page(
            source_path=source_path,
            root=root,
            parts=parts,
            members=members,
            has_module_docstring=has_module_docstring,
        )

        nav_path = full_doc_path.relative_to(REFERENCE_ROOT)
        nav[parts] = nav_path.as_posix()

    with mkdocs_gen_files.open(
        REFERENCE_ROOT / "SUMMARY.md",
        "w",
    ) as nav_file:
        nav_file.writelines(nav.build_literate_nav())


main()
