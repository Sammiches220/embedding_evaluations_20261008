"""Schemas for health/workspace endpoints."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from .base import ApiModel

################################################################################
# CLASSES
################################################################################
class HealthResponse(ApiModel):
    ok: bool = True
    version: str


class WorkspaceResponse(ApiModel):
    domains: list[str]
    projections: list[str]
    selections: list[str]
    timelines: list[str]
    clusterings: list[str]
    densities: list[str]
    segmentations: list[str]
    coverage_fields: list[str]
    saved_queries: list[str]
    themes: list[str]


################################################################################
if __name__=="__main__":
    pass
