"""Schemas for asset catalog and registration endpoints."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from typing import Any

from pydantic import Field, ConfigDict
from uvicorn import Config

##### Internal Imports #####
from .descriptions import DOMAIN
from .base import ApiModel
from .compat import FalsyEmptyString, LegacyBool, LegacyDict, LegacyInt, Stringified


################################################################################
# CLASSES
################################################################################
class AssetCatalogResponse(ApiModel):
    domains: dict[str, dict[str, Any]]
    projections: dict[str, dict[str, Any]]
    selections: dict[str, dict[str, Any]]
    timelines: dict[str, dict[str, Any]]
    clusterings: dict[str, dict[str, Any]]
    densities: dict[str, dict[str, Any]]
    segmentations: dict[str, dict[str, Any]]
    coverage_fields: dict[str, dict[str, Any]]
    themes: dict[str, dict[str, Any]]


class AssetRegistrationResponse(ApiModel):
    ok: bool = True
    asset: dict[str, Any]


class RegistrationBase(ApiModel):
    id: FalsyEmptyString = ""
    storage: Stringified = "copy"
    replace: LegacyBool = False
    metadata: LegacyDict = Field(default_factory=dict)
    chunk_size: LegacyInt

    def normalized_chunk_size(self) -> int:
        """Preserve the legacy ``max(1, int(chunk_size))`` behavior."""
        return max(1, int(self.chunk_size))


class DomainRegistrationRequest(RegistrationBase):
    embeddings_path: FalsyEmptyString = Field(description="Server-local path to embeddings file")
    item_ids_path: FalsyEmptyString = Field(description="Server-local path to item IDs file")
    version: LegacyInt = Field(description="Version of the domain")
    storage: Stringified = "reference"
    chunk_size: LegacyInt = 250_000


class ProjectionRegistrationRequest(RegistrationBase):
    domain: FalsyEmptyString = ""
    positions_path: FalsyEmptyString = ""
    selection: str | None = None
    x_order_path: str | None = None
    x_sorted_path: str | None = None
    build_spatial_index: LegacyBool = True
    world_bounds: Any | None = Field(
        default=None, 
        description="Projection world bounds in the format accepted by model.workspace.",
        examples=[[-4.2, 5.1, -3.0, 4.4]]
    )
    method: Stringified = "external"
    chunk_size: LegacyInt = 1_000_000


class ClusteringRegistrationRequest(RegistrationBase):
    domain: FalsyEmptyString = Field(description=DOMAIN)
    labels_path: FalsyEmptyString = ""
    projection: str | None = Field(
        default=None,
        description="Optional projection ID. Makes the clustering compatible only with that Projection."
    )
    selection: str | None = Field(
        default=None,
        description="Optional selection ID. Records the Selection scope used when computing it."
    )
    method: Stringified = "external"
    chunk_size: LegacyInt = 1_000_000


class DensityRegistrationRequest(RegistrationBase):
    projection: FalsyEmptyString = ""
    field_path: FalsyEmptyString = ""
    selection: str | None = None
    method: Stringified = "external"
    value_range: Stringified = "unit"
    chunk_size: LegacyInt = 4096


class SegmentationRegistrationRequest(RegistrationBase):
    projection: FalsyEmptyString = ""
    labels_path: FalsyEmptyString = ""
    stats_path: str | None = None
    density: str | None = Field(
        default=None,
        description="Optional density ID. Ensures compatibility -- both have the same `[H,W]` shape."
    )
    selection: str | None = None
    method: Stringified = "external"
    chunk_size: LegacyInt = 250_000


class CoverageFieldRegistrationRequest(RegistrationBase):
    projection: FalsyEmptyString = ""
    selection: FalsyEmptyString = ""
    frames_path: FalsyEmptyString = ""
    timeline: str | None = None
    timeline_start: float | None = None
    timeline_end: float | None = None
    method: Stringified = "external"
    value_range: Stringified = "unit"
    chunk_size: LegacyInt = 64

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "id": "favorites-coverage",
                    "projection": "external-umap",
                    "selection": "favorites",
                    "frames_path": "/shared/favorites_coverage.npy",
                    "method": "custom-coverage",
                    "storage": "copy",
                    "value_range": "unit"
                },
                {
                    "id": "favorites-history",
                    "projection": "external-umap",
                    "selection": "favorites",
                    "timeline": "archive-time",
                    "frames_path": "/shared/favorites_history.npy",
                    "timeline_start": 1640995200,
                    "timeline_end": 1767225599,
                    "method": "custom-temporal-coverage",
                    "storage": "copy",
                    "value_range": "unit",
                    "replace": False,
                    "metadata": {}
                }
            ]
        }
    )


class SelectionRegistrationRequest(RegistrationBase):
    domain: FalsyEmptyString = Field(description=DOMAIN)
    mask_path: FalsyEmptyString = ""
    source: str | None = None
    chunk_size: LegacyInt = 1_000_000


class TimelineRegistrationRequest(RegistrationBase):
    domain: FalsyEmptyString = Field(description=DOMAIN)
    timestamps_path: FalsyEmptyString = ""
    missing_value: LegacyInt = -1
    chunk_size: LegacyInt = 1_000_000


################################################################################
if __name__=="__main__":
    pass
