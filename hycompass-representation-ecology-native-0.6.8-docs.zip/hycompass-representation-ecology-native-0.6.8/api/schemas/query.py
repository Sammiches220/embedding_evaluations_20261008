"""Request/response schemas for querying points and fetching features."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from typing import Any

from pydantic import Field

##### Internal Imports #####
from .base import ApiModel
from .common import FeatureSelection, ItemSelector, JsonObject, PageInfo, RowsPage
from .context import ApiContext
from .compat import LegacyInt
from .descriptions import FEATURE_RECORDS_DESCRIPTION, POINT_QUERY_DESCRIPTION


################################################################################
# CLASSES
################################################################################
class QueryRequest(ApiContext):
    """Execute a point query in a live or ad-hoc context."""

    where: JsonObject | None = Field(
        default=None,
        description=POINT_QUERY_DESCRIPTION,
    )
    offset: LegacyInt = Field(default=0, description="Page offset; negative values are clamped to 0 for compatibility.")
    limit: LegacyInt = Field(default=1000, description="Requested page size; clamped to the inclusive range 1..10000.")

    def normalized_page(self) -> tuple[int, int]:
        """Return legacy-compatible clamped offset and limit."""
        return max(0, int(self.offset)), min(10_000, max(1, int(self.limit)))


class QueryResponse(RowsPage):
    """Paged query result."""


class ItemFeaturesRequest(ApiContext, ItemSelector, FeatureSelection):
    """Resolve rows or a query and return requested feature records."""

    where: JsonObject | None = Field(default=None, description=POINT_QUERY_DESCRIPTION)
    offset: LegacyInt = 0
    limit: LegacyInt = 1000

    def normalized_page(self) -> tuple[int, int]:
        """Return legacy-compatible clamped offset and limit."""
        return max(0, int(self.offset)), min(10_000, max(1, int(self.limit)))


class FeatureRecordEnvelope(ApiModel):
    """Envelope for dynamic feature records.

    Records themselves intentionally remain dictionaries because FeatureProvider
    can emit workspace-dependent feature keys and the current public wire format
    places them directly in each item record.
    """

    items: list[dict[str, Any]] = Field(description=FEATURE_RECORDS_DESCRIPTION)


class FeatureCatalogRequest(ApiContext):
    """Request the features/assets compatible with a context."""


class FeatureCatalogResponse(ApiModel):
    """Feature and asset identifiers compatible with a context."""

    domain: str
    projection: str
    timeline: str | None
    selections: list[str]
    clusterings: list[str]
    densities: list[str]
    segmentations: list[str]
    coverage_fields: list[str]
    builtins: list[str]


class QueryFeaturesRequest(QueryRequest, FeatureSelection):
    """Run a query and return dynamic feature records for the page."""


class QueryFeaturesResponse(PageInfo):
    """Paged dynamic feature response."""

    items: list[dict[str, Any]] = Field(description=FEATURE_RECORDS_DESCRIPTION)


################################################################################
if __name__=="__main__":
    pass
