"""Canonical correspondence and saved-map endpoints. Computation uses CLI/GUI worker."""
from typing import Literal
import numpy as np
from fastapi import APIRouter,Depends,HTTPException
from pydantic import BaseModel,Field,ConfigDict
from ..dependencies import get_session
from ecology.catalog import Catalog,clean
from ecology.store import Store
from ecology.instruments import plan
from ecology.comparison import compare

router=APIRouter(prefix='/ecology',tags=['Representation ecology'])

class CorrespondenceRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    source_domain:str
    target_domain:str
    rows:list[int]=Field(max_length=100000)

class DefineRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    title:str
    domain:str
    collection_rows:list[int]=Field(min_length=1,max_length=100000)
    settings:dict=Field(default_factory=dict)

class FeatureRequest(BaseModel):
    collection:str
    collection_rows:list[int]=Field(max_length=10000)
    features:list[str]=Field(max_length=16)

@router.get('/catalog')
def catalog(session=Depends(get_session)):
    c=Catalog(session.manifest.root)
    return c.raw

@router.post('/correspondence')
def correspondence(payload:CorrespondenceRequest,session=Depends(get_session)):
    c=Catalog(session.manifest.root)
    try:
        if c.raw['domains'][payload.source_domain]['collection']!=c.raw['domains'][payload.target_domain]['collection']:raise ValueError('Domains belong to different collections')
        canonical=c.to_collection(payload.source_domain,np.asarray(payload.rows,dtype=np.int64));present,rows=c.to_domain(payload.target_domain,canonical)
        ids=c.load(c.collection(c.raw['domains'][payload.source_domain]['collection'])['item_ids'])[present]
        return clean(dict(collection_rows=present,domain_rows=rows,item_ids=ids,missing=len(canonical)-len(present)))
    except (KeyError,ValueError) as exc:raise HTTPException(400,str(exc))

@router.post('/features')
def features(payload:FeatureRequest,session=Depends(get_session)):
    from ecology.catalog import rows_checked
    c=Catalog(session.manifest.root)
    try:
        rows=rows_checked(np.asarray(payload.collection_rows,np.int64),c.n(payload.collection));ids=c.load(c.collection(payload.collection)['item_ids'])[rows];columns={}
        for f in payload.features:
            if c.raw['features'][f]['collection']!=payload.collection:raise ValueError('Feature collection mismatch')
            v,known=c.feature(f,rows);columns[f]=[x.item() if k else None for x,k in zip(v,known)]
        return clean(dict(collection_rows=rows,item_ids=ids,columns=columns))
    except (KeyError,ValueError) as exc:raise HTTPException(400,str(exc))

@router.get('/maps')
def maps(session=Depends(get_session)):
    return Store(session.manifest.root).definitions()

@router.post('/maps')
def define(payload:DefineRequest,session=Depends(get_session)):
    try:return Store(session.manifest.root).create(payload.title,payload.domain,np.asarray(payload.collection_rows,np.int64),payload.settings)
    except (KeyError,ValueError) as exc:raise HTTPException(400,str(exc))

@router.get('/maps/{key}')
def status(key:str,session=Depends(get_session)):
    try:
        store=Store(session.manifest.root);return dict(definition=store.read(key),instruments=store.status(key),disk_bytes=store.disk_bytes(key))
    except (KeyError,ValueError,FileNotFoundError) as exc:raise HTTPException(400,str(exc))

@router.get('/maps/{key}/plan')
def estimate(key:str,instrument:str='geometry',session=Depends(get_session)):
    try:return plan(Store(session.manifest.root),key,[instrument])
    except (KeyError,ValueError,FileNotFoundError) as exc:raise HTTPException(400,str(exc))

@router.get('/compare')
def comparison(a:str,b:str,instrument:str='geometry',session=Depends(get_session)):
    try:return clean(compare(Store(session.manifest.root),a,b,instrument))
    except (KeyError,ValueError,FileNotFoundError) as exc:raise HTTPException(400,str(exc))

# Map lifecycle and bounded job/result/package services share the native backend.
from fastapi import Request
from fastapi.responses import FileResponse
from pathlib import Path
from functools import wraps
from ecology.jobs import get_jobs
from ecology.results import register_result,result_descriptors
from ecology.packages import export_package,import_package,attach_package

def service_errors(fn):
    @wraps(fn)
    def wrapped(*args,**kwargs):
        try:return fn(*args,**kwargs)
        except (ValueError,KeyError,OSError) as exc:
            raise HTTPException(409 if 'revision conflict' in str(exc).lower() else 400,str(exc)) from exc
    return wrapped

class RenameRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    title:str=Field(min_length=1,max_length=500)
    metadata_revision:str
    description:str|None=None
    tags:list[str]|None=None

class DuplicateRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    title:str=Field(min_length=1,max_length=500)

class JobRequest(BaseModel):
    continue_on_error:bool=False
    model_config=ConfigDict(extra='forbid')
    map_revision:str
    instruments:list[str]=Field(min_length=1,max_length=32)

class PackageRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    path:str
    profile:Literal['definition','viewing','embeddings','targets','full']='viewing'

class ImportRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    path:str
    destination:str
    max_bytes:int=Field(default=16*1024**3,ge=1,le=128*1024**3)

class ExternalRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    map_revision:str
    item_ids:list[int]|list[str]=Field(min_length=1,max_length=100000)
    predictions:list[float]|list[list[float]]=Field(min_length=1,max_length=100000)
    known:list[bool]|None=None
    target:str
    kind:Literal['numeric','boolean','category']
    scope:Literal['in_sample','held_out','external','unknown']
    provenance:str=Field(min_length=1,max_length=10000)
    metrics:dict[str,float]=Field(default_factory=dict)
    result_id:str|None=Field(default=None,pattern=r'^[A-Za-z0-9_-]{1,80}$')

@router.get('/maps/{key}/capabilities')
@service_errors
def capabilities(key:str,session=Depends(get_session)):
    return Store(session.manifest.root).capabilities(key)

@router.patch('/maps/{key}')
@service_errors
def rename_map(key:str,payload:RenameRequest,session=Depends(get_session)):
    return Store(session.manifest.root).rename(key,payload.title,payload.metadata_revision,payload.description,payload.tags)

@router.post('/maps/{key}/duplicate')
@service_errors
def duplicate_map(key:str,payload:DuplicateRequest,session=Depends(get_session)):
    return Store(session.manifest.root).duplicate(key,payload.title)

@router.get('/maps/{key}/deletion-preview')
@service_errors
def deletion_preview(key:str,session=Depends(get_session)):
    return Store(session.manifest.root).deletion_preview(key)

@router.delete('/maps/{key}')
@service_errors
def delete_map(key:str,session=Depends(get_session)):
    return Store(session.manifest.root).delete(key)

@router.delete('/maps/{key}/results')
@service_errors
def delete_results(key:str,session=Depends(get_session)):
    Store(session.manifest.root).delete_results(key);return dict(deleted=True)

@router.delete('/maps/{key}/results/{component}')
@service_errors
def delete_result(key:str,component:str,session=Depends(get_session)):
    Store(session.manifest.root).delete_artifact(key,component);return dict(deleted=True)

@router.post('/maps/{key}/jobs')
@service_errors
def submit_job(key:str,payload:JobRequest,request:Request,session=Depends(get_session)):
    jobs=get_jobs(session.manifest.root)
    runtime=getattr(request.app.state,'runtime',None)
    if runtime is not None and not getattr(jobs,'api_events_attached',False):
        jobs.listeners.append(lambda record:runtime.events.publish('map.job.changed',revision=runtime.workspace_revision,data=record));jobs.api_events_attached=True
    future=jobs.submit(key,payload.instruments,payload.map_revision,continue_on_error=payload.continue_on_error)
    return jobs.inspect(future.job_id)

@router.get('/jobs/{job_id}')
@service_errors
def job_status(job_id:str,session=Depends(get_session)):
    return get_jobs(session.manifest.root).inspect(job_id)

@router.post('/jobs/{job_id}/cancel')
@service_errors
def cancel_job(job_id:str,session=Depends(get_session)):
    return get_jobs(session.manifest.root).cancel_job(job_id)

@router.get('/maps/{key}/results')
@service_errors
def results(key:str,session=Depends(get_session)):
    return clean(result_descriptors(Store(session.manifest.root),key))

@router.post('/maps/{key}/results/external')
@service_errors
def external_result(key:str,payload:ExternalRequest,session=Depends(get_session)):
    return clean(register_result(Store(session.manifest.root),key,item_ids=np.asarray(payload.item_ids),predictions=np.asarray(payload.predictions),known=np.asarray(payload.known,dtype=bool) if payload.known is not None else None,target=payload.target,kind=payload.kind,scope=payload.scope,provenance=payload.provenance,metrics=payload.metrics,result_id=payload.result_id,expected_revision=payload.map_revision))

@router.get('/maps/{key}/results/{component}/arrays/{array}')
@service_errors
def result_array(key:str,component:str,array:str,signature:str,session=Depends(get_session)):
    store=Store(session.manifest.root)
    if component not in __import__('ecology.instruments',fromlist=['REGISTRY']).REGISTRY and not component.startswith('external_') and '--' not in component:raise ValueError('Unknown component')
    arrays,meta=store.artifact(key,component)
    if signature!=meta['result_signature']:raise ValueError('Result revision conflict')
    if array not in arrays:raise ValueError('Unknown result array')
    return FileResponse(store.artifact_path(key,component)/(array+'.npy'),media_type='application/octet-stream',filename=array+'.npy')

@router.post('/maps/{key}/export')
@service_errors
def export_map(key:str,payload:PackageRequest,session=Depends(get_session)):
    return export_package(Store(session.manifest.root),key,payload.path,payload.profile)

@router.post('/packages/import')
@service_errors
def install_package(payload:ImportRequest,session=Depends(get_session)):
    return import_package(payload.path,payload.destination,max_bytes=payload.max_bytes)

@router.post('/packages/attach')
@service_errors
def attach_layers(payload:PackageRequest,session=Depends(get_session)):
    return attach_package(payload.path,session.manifest.root)

class NavigationRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    selection:dict
    subset_rows:list[int]|None=Field(default=None,max_length=100000)

@router.post('/navigation/resolve')
def navigation_resolve(payload:NavigationRequest,session=Depends(get_session)):
    from ecology.navigation import Selection,resolve_saved
    from dataclasses import asdict
    try:return clean(asdict(resolve_saved(Store(session.manifest.root),Selection(**payload.selection),payload.subset_rows)))
    except (ValueError,KeyError,TypeError,OSError) as exc:raise HTTPException(400,str(exc))
