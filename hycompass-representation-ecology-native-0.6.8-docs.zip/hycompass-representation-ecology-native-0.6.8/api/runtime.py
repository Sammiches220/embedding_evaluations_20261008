################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib
import json
from queue import Empty, Full, Queue
from threading import RLock
from typing import Any
import uuid

import numpy as np

##### Internal Imports #####
from model.workspace import ViewSpec

##### Global Variables #####
EVENT_HISTORY_LIMIT = 4096
SUBSCRIBER_QUEUE_LIMIT = 512
SELECTION_DELTA_HISTORY = 128
SELECTION_DELTA_COMPARE_LIMIT = 200_000
SELECTION_DELTA_STORE_LIMIT = 10_000
INLINE_DELTA_LIMIT = 64


################################################################################
# FUNCTIONS
################################################################################
def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _query_hash(value: dict | None) -> str | None:
    if value is None:
        return None
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]


def _event_matches(event: dict[str, Any], *, types: set[str] | None, view: str | None, domain: str | None) -> bool:
    if view is not None and event.get("view") != view:
        return False
    if domain is not None and event.get("domain") != domain:
        return False
    if types:
        event_type = str(event.get("type") or "")
        matched = False
        for wanted in types:
            if wanted.endswith("*"):
                matched |= event_type.startswith(wanted[:-1])
            else:
                matched |= event_type == wanted
        if not matched:
            return False
    return True


################################################################################
# CLASSES
################################################################################
@dataclass
class EventSubscriber:
    token: str
    queue: Queue
    types: set[str] | None = None
    view: str | None = None
    domain: str | None = None


class EventHub:
    """Small in-process publish/subscribe hub used by the SSE endpoint.

    The hub stores only compact event metadata. Bulk rows/features always remain
    in normal REST endpoints. A bounded history supports Last-Event-ID replay;
    slow subscribers are never allowed to block the GUI/API threads.
    """

    def __init__(self, history_limit: int = EVENT_HISTORY_LIMIT) -> None:
        self._lock = RLock()
        self._next_id = 1
        self._history: deque[dict[str, Any]] = deque(maxlen=max(64, int(history_limit)))
        self._subscribers: dict[str, EventSubscriber] = {}

    @property
    def head(self) -> int:
        with self._lock:
            return self._next_id - 1

    def publish(
        self,
        event_type: str,
        *,
        revision: int,
        view: str | None = None,
        domain: str | None = None,
        projection: str | None = None,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        with self._lock:
            event = {
                "event_id": self._next_id,
                "type": str(event_type),
                "revision": int(revision),
                "time": _utc_now(),
                "view": view,
                "domain": domain,
                "projection": projection,
                "data": dict(data or {}),
            }
            self._next_id += 1
            self._history.append(event)
            subscribers = list(self._subscribers.values())

        for sub in subscribers:
            if not _event_matches(event, types=sub.types, view=sub.view, domain=sub.domain):
                continue
            try:
                sub.queue.put_nowait(event)
            except Full:
                # Never block the GUI/API producer. Collapse the subscriber to a
                # one-message resync instruction; the client can use /state and
                # revisioned snapshots to recover.
                try:
                    while True:
                        sub.queue.get_nowait()
                except Empty:
                    pass
                try:
                    sub.queue.put_nowait({
                        "event_id": event["event_id"],
                        "type": "stream.resync_required",
                        "revision": 0,
                        "time": event["time"],
                        "view": sub.view,
                        "domain": sub.domain,
                        "projection": None,
                        "data": {"reason": "subscriber_queue_overflow", "head_event_id": event["event_id"]},
                    })
                except Full:
                    pass
        return event

    def subscribe(
        self,
        *,
        since_event_id: int | None = None,
        types: set[str] | None = None,
        view: str | None = None,
        domain: str | None = None,
    ) -> tuple[EventSubscriber, list[dict[str, Any]], bool, int]:
        with self._lock:
            token = uuid.uuid4().hex
            sub = EventSubscriber(token, Queue(maxsize=SUBSCRIBER_QUEUE_LIMIT), types, view, domain)
            self._subscribers[token] = sub
            head = self._next_id - 1
            history = list(self._history)
            oldest = history[0]["event_id"] if history else self._next_id
            resync_required = bool(since_event_id is not None and since_event_id < oldest - 1)
            replay: list[dict[str, Any]] = []
            if since_event_id is not None and not resync_required:
                replay = [
                    event for event in history
                    if int(event["event_id"]) > int(since_event_id)
                    and _event_matches(event, types=types, view=view, domain=domain)
                ]
            return sub, replay, resync_required, head

    def unsubscribe(self, token: str) -> None:
        with self._lock:
            self._subscribers.pop(token, None)


@dataclass
class ResultSet:
    id: str
    rows: np.ndarray
    scores: list[float] | None = None
    labels: list[str] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SelectionDelta:
    from_revision: int
    to_revision: int
    available: bool
    added: np.ndarray | None = None
    removed: np.ndarray | None = None
    added_count: int | None = None
    removed_count: int | None = None


class RuntimeState:
    """Thread-safe runtime state shared between Qt, REST and SSE consumers."""

    _REVISION_KEYS = (
        "working_selection", "predicate", "visibility", "timeline", "highlights",
        "focus", "result_sets", "view",
    )

    def __init__(self) -> None:
        self.lock = RLock()
        self.events = EventHub()
        self.views: dict[str, ViewSpec] = {}
        self.working: dict[str, np.ndarray] = {}
        self.highlights: dict[str, np.ndarray] = {}
        self.visibility_queries: dict[str, dict | None] = {}
        self.visibility_counts: dict[str, int | None] = {}
        self.predicates: dict[str, dict] = {}
        self.predicate_sources: dict[str, dict[str, Any]] = {}
        self.timelines: dict[str, float] = {}
        self.focused_rows: dict[str, int | None] = {}
        self._timeline_emitted_revision: dict[str, int] = {}
        self.result_sets: dict[tuple[str, str], ResultSet] = {}
        self.actions: Queue[dict[str, Any]] = Queue()
        self._revisions: dict[str, dict[str, int]] = {}
        self._updated_at: dict[str, dict[str, str]] = {}
        self._selection_deltas: dict[str, deque[SelectionDelta]] = {}
        self.active_view: str | None = None
        self.active_view_revision = 0
        self.workspace_revision = 0

    # ---- revision / scope helpers -----------------------------------------
    def _ensure_view_state_locked(self, view_id: str) -> None:
        self.working.setdefault(view_id, np.empty(0, np.uint32))
        self.highlights.setdefault(view_id, np.empty(0, np.uint32))
        self.visibility_queries.setdefault(view_id, None)
        self.visibility_counts.setdefault(view_id, None)
        self.predicates.setdefault(view_id, {"op": "all"})
        self.predicate_sources.setdefault(view_id, {"source": "controls", "saved_query_id": None, "saved_query_name": None})
        self.timelines.setdefault(view_id, 0.5)
        self.focused_rows.setdefault(view_id, None)
        self._timeline_emitted_revision.setdefault(view_id, -1)
        self._revisions.setdefault(view_id, {key: 0 for key in self._REVISION_KEYS})
        self._updated_at.setdefault(view_id, {key: _utc_now() for key in self._REVISION_KEYS})
        self._selection_deltas.setdefault(view_id, deque(maxlen=SELECTION_DELTA_HISTORY))

    def _bump_locked(self, view_id: str, key: str) -> tuple[int, str]:
        self._ensure_view_state_locked(view_id)
        self._revisions[view_id][key] += 1
        now = _utc_now()
        self._updated_at[view_id][key] = now
        return self._revisions[view_id][key], now

    def _scope_locked(self, view_id: str) -> tuple[str | None, str | None]:
        spec = self.views.get(view_id)
        return (spec.domain, spec.projection) if spec is not None else (None, None)

    def _emit_view(self, event_type: str, view_id: str, revision: int, data: dict[str, Any] | None = None) -> dict[str, Any]:
        with self.lock:
            domain, projection = self._scope_locked(view_id)
        return self.events.publish(event_type, revision=revision, view=view_id, domain=domain, projection=projection, data=data)

    # ---- views / active tab ----------------------------------------------
    def register_view(self, spec: ViewSpec) -> None:
        with self.lock:
            previous = self.views.get(spec.id)
            self.views[spec.id] = spec
            self._ensure_view_state_locked(spec.id)
            if previous is None:
                revision, _ = self._bump_locked(spec.id, "view")
                event_type = "view.opened"
                data = {"title": spec.title}
            elif previous != spec:
                revision, _ = self._bump_locked(spec.id, "view")
                event_type = "view.reconfigured"
                data = {"title": spec.title}
            else:
                return
        self._emit_view(event_type, spec.id, revision, data)

    def unregister_view(self, view_id: str) -> None:
        with self.lock:
            spec = self.views.pop(view_id, None)
            if spec is None:
                return
            self._ensure_view_state_locked(view_id)
            revision, _ = self._bump_locked(view_id, "view")
            active_changed = self.active_view == view_id
            if active_changed:
                self.active_view = None
                self.active_view_revision += 1
                active_revision = self.active_view_revision
            else:
                active_revision = None
        self.events.publish(
            "view.closed", revision=revision, view=view_id, domain=spec.domain, projection=spec.projection,
            data={"title": spec.title},
        )
        if active_revision is not None:
            self.events.publish("active_view.changed", revision=active_revision, data={"active_view": None, "previous_view": view_id})

    def spec(self, view_id: str) -> ViewSpec:
        with self.lock:
            if view_id not in self.views:
                raise KeyError(view_id)
            return self.views[view_id]

    def set_active_view(self, view_id: str | None, *, cause: str = "tab") -> None:
        with self.lock:
            if view_id is not None and view_id not in self.views:
                return
            if self.active_view == view_id:
                return
            previous = self.active_view
            self.active_view = view_id
            self.active_view_revision += 1
            revision = self.active_view_revision
            spec = self.views.get(view_id) if view_id is not None else None
        self.events.publish(
            "active_view.changed", revision=revision,
            view=view_id,
            domain=spec.domain if spec else None,
            projection=spec.projection if spec else None,
            data={"active_view": view_id, "previous_view": previous, "cause": cause},
        )

    # ---- WorkingSelection -------------------------------------------------
    @staticmethod
    def _compute_selection_delta(old: np.ndarray, new: np.ndarray, from_revision: int, to_revision: int) -> SelectionDelta:
        if len(old) + len(new) > SELECTION_DELTA_COMPARE_LIMIT:
            return SelectionDelta(from_revision, to_revision, False)
        added = np.setdiff1d(new, old, assume_unique=False).astype(np.uint32, copy=False)
        removed = np.setdiff1d(old, new, assume_unique=False).astype(np.uint32, copy=False)
        if len(added) + len(removed) > SELECTION_DELTA_STORE_LIMIT:
            return SelectionDelta(from_revision, to_revision, False, added_count=int(len(added)), removed_count=int(len(removed)))
        return SelectionDelta(
            from_revision, to_revision, True,
            added=np.asarray(added, dtype=np.uint32).copy(),
            removed=np.asarray(removed, dtype=np.uint32).copy(),
            added_count=int(len(added)), removed_count=int(len(removed)),
        )

    def set_working(self, view_id: str, rows: np.ndarray, *, cause: str = "unknown") -> int:
        new = np.asarray(rows, dtype=np.uint32).copy()
        with self.lock:
            self._ensure_view_state_locked(view_id)
            old = self.working.get(view_id, np.empty(0, np.uint32))
            if np.array_equal(old, new):
                return self._revisions[view_id]["working_selection"]
            from_revision = self._revisions[view_id]["working_selection"]
            self.working[view_id] = new
            revision, _ = self._bump_locked(view_id, "working_selection")
            delta = self._compute_selection_delta(old, new, from_revision, revision)
            self._selection_deltas[view_id].append(delta)
            previous_count = int(len(old))
        delta_data: dict[str, Any] = {
            "available": bool(delta.available),
            "added_count": delta.added_count,
            "removed_count": delta.removed_count,
        }
        if delta.available and delta.added is not None and delta.removed is not None and len(delta.added) + len(delta.removed) <= INLINE_DELTA_LIMIT:
            delta_data["added_rows"] = [int(x) for x in delta.added]
            delta_data["removed_rows"] = [int(x) for x in delta.removed]
        self._emit_view(
            "working_selection.changed", view_id, revision,
            {
                "count": int(len(new)), "previous_count": previous_count, "cause": cause,
                "delta": delta_data,
            },
        )
        return revision

    def working_state(self, view_id: str) -> dict[str, Any]:
        with self.lock:
            self._ensure_view_state_locked(view_id)
            spec = self.views.get(view_id)
            return {
                "type": "working_selection",
                "view": view_id,
                "domain": spec.domain if spec else None,
                "projection": spec.projection if spec else None,
                "revision": self._revisions[view_id]["working_selection"],
                "count": int(len(self.working[view_id])),
                "updated_at": self._updated_at[view_id]["working_selection"],
                "head_event_id": self.events.head,
            }

    def working_delta(self, view_id: str, since_revision: int, *, max_items: int = 10_000) -> dict[str, Any]:
        with self.lock:
            self._ensure_view_state_locked(view_id)
            current = self._revisions[view_id]["working_selection"]
            count = int(len(self.working[view_id]))
            if since_revision == current:
                return {
                    "from_revision": current, "to_revision": current,
                    "snapshot_required": False, "count": count,
                    "added_rows": [], "removed_rows": [],
                }
            if since_revision < 0 or since_revision > current:
                return {"from_revision": since_revision, "to_revision": current, "snapshot_required": True, "count": count}
            history = list(self._selection_deltas[view_id])

        by_from = {d.from_revision: d for d in history}
        rev = int(since_revision)
        added: set[int] = set()
        removed: set[int] = set()
        while rev < current:
            delta = by_from.get(rev)
            if delta is None or delta.to_revision != rev + 1 or not delta.available or delta.added is None or delta.removed is None:
                return {"from_revision": since_revision, "to_revision": current, "snapshot_required": True, "count": count}
            for value in delta.added:
                item = int(value)
                if item in removed:
                    removed.remove(item)
                else:
                    added.add(item)
            for value in delta.removed:
                item = int(value)
                if item in added:
                    added.remove(item)
                else:
                    removed.add(item)
            if len(added) + len(removed) > max_items:
                return {"from_revision": since_revision, "to_revision": current, "snapshot_required": True, "count": count}
            rev = delta.to_revision
        return {
            "from_revision": since_revision, "to_revision": current,
            "snapshot_required": False, "count": count,
            "added_rows": sorted(added), "removed_rows": sorted(removed),
        }

    # ---- predicates / visibility -----------------------------------------
    def set_predicate(
        self, view_id: str, query: dict, *, source: str = "controls",
        saved_query_id: str | None = None, saved_query_name: str | None = None,
    ) -> int:
        normalized = dict(query or {"op": "all"})
        source_state = {"source": source, "saved_query_id": saved_query_id, "saved_query_name": saved_query_name}
        with self.lock:
            self._ensure_view_state_locked(view_id)
            if self.predicates.get(view_id) == normalized and self.predicate_sources.get(view_id) == source_state:
                return self._revisions[view_id]["predicate"]
            self.predicates[view_id] = normalized
            self.predicate_sources[view_id] = source_state
            revision, _ = self._bump_locked(view_id, "predicate")
        self._emit_view(
            "point_predicate.changed", view_id, revision,
            {**source_state, "query_hash": _query_hash(normalized)},
        )
        return revision

    def predicate_state(self, view_id: str) -> dict[str, Any]:
        with self.lock:
            self._ensure_view_state_locked(view_id)
            spec = self.views.get(view_id)
            query = dict(self.predicates[view_id])
            source = dict(self.predicate_sources[view_id])
            return {
                "type": "point_predicate", "view": view_id,
                "domain": spec.domain if spec else None,
                "projection": spec.projection if spec else None,
                "revision": self._revisions[view_id]["predicate"],
                "updated_at": self._updated_at[view_id]["predicate"],
                "query_hash": _query_hash(query), "query": query, **source,
            }

    def set_visibility(self, view_id: str, query: dict | None, *, visible_count: int | None = None, cause: str = "unknown") -> int:
        normalized = None if query is None else dict(query)
        with self.lock:
            self._ensure_view_state_locked(view_id)
            if self.visibility_queries.get(view_id) == normalized and self.visibility_counts.get(view_id) == visible_count:
                return self._revisions[view_id]["visibility"]
            self.visibility_queries[view_id] = normalized
            self.visibility_counts[view_id] = visible_count
            revision, _ = self._bump_locked(view_id, "visibility")
        self._emit_view(
            "visibility.changed", view_id, revision,
            {"enabled": normalized is not None, "visible_count": visible_count, "cause": cause, "query_hash": _query_hash(normalized)},
        )
        return revision

    # ---- timeline / highlights / focus / result sets ---------------------
    def set_timeline(self, view_id: str, value: float, *, emit_event: bool = False, cause: str = "timeline") -> int:
        value = float(np.clip(value, 0.0, 1.0))
        with self.lock:
            self._ensure_view_state_locked(view_id)
            changed = abs(self.timelines.get(view_id, 0.5) - value) > 1e-9
            self.timelines[view_id] = value
            if not changed:
                return self._revisions[view_id]["timeline"]
            revision, _ = self._bump_locked(view_id, "timeline")
        if emit_event:
            with self.lock:self._timeline_emitted_revision[view_id]=revision
            self._emit_view("timeline.changed", view_id, revision, {"progress": value, "cause": cause})
        return revision

    def emit_timeline(self, view_id: str, *, cause: str = "timeline") -> None:
        with self.lock:
            self._ensure_view_state_locked(view_id)
            revision = self._revisions[view_id]["timeline"]
            if self._timeline_emitted_revision.get(view_id,-1)==revision:
                return
            self._timeline_emitted_revision[view_id]=revision
            value = self.timelines[view_id]
        self._emit_view("timeline.changed", view_id, revision, {"progress": float(value), "cause": cause})

    def set_highlights(self, view_id: str, rows: np.ndarray, *, cause: str = "unknown") -> int:
        new = np.asarray(rows, dtype=np.uint32).copy()
        with self.lock:
            self._ensure_view_state_locked(view_id)
            old = self.highlights.get(view_id, np.empty(0, np.uint32))
            if np.array_equal(old, new):
                return self._revisions[view_id]["highlights"]
            self.highlights[view_id] = new
            revision, _ = self._bump_locked(view_id, "highlights")
        self._emit_view("highlights.changed", view_id, revision, {"count": int(len(new)), "cause": cause})
        return revision

    def set_focus(self, view_id: str, row: int | None, *, cause: str = "api") -> int:
        row_value = None if row is None else int(row)
        with self.lock:
            self._ensure_view_state_locked(view_id)
            if self.focused_rows.get(view_id) == row_value:
                return self._revisions[view_id]["focus"]
            self.focused_rows[view_id] = row_value
            revision, _ = self._bump_locked(view_id, "focus")
        self._emit_view("focus.changed", view_id, revision, {"row": row_value, "cause": cause})
        return revision

    def set_result_set(self, view_id: str, result_set: ResultSet, *, cause: str = "api") -> int:
        with self.lock:
            self._ensure_view_state_locked(view_id)
            self.result_sets[(view_id, result_set.id)] = result_set
            revision, _ = self._bump_locked(view_id, "result_sets")
        self._emit_view(
            "result_set.changed", view_id, revision,
            {"result_set": result_set.id, "count": int(len(result_set.rows)), "cause": cause},
        )
        return revision

    # ---- workspace/catalog -----------------------------------------------
    def workspace_changed(
        self, event_type: str, data: dict[str, Any] | None = None, *,
        domain: str | None = None, projection: str | None = None,
    ) -> int:
        with self.lock:
            self.workspace_revision += 1
            revision = self.workspace_revision
        self.events.publish(event_type, revision=revision, domain=domain, projection=projection, data=data or {})
        return revision

    # ---- cheap state snapshots -------------------------------------------
    def view_state(self, view_id: str) -> dict[str, Any]:
        with self.lock:
            self._ensure_view_state_locked(view_id)
            spec = self.views.get(view_id)
            if spec is None:
                raise KeyError(view_id)
            revisions = dict(self._revisions[view_id])
            return {
                "view": view_id, "domain": spec.domain, "projection": spec.projection,
                "title": spec.title,
                "active": self.active_view == view_id,
                "revisions": revisions,
                "counts": {
                    "working_selection": int(len(self.working[view_id])),
                    "highlights": int(len(self.highlights[view_id])),
                    "visible": self.visibility_counts.get(view_id),
                },
                "timeline_progress": float(self.timelines[view_id]),
                "predicate_source": dict(self.predicate_sources[view_id]),
                "predicate_query_hash": _query_hash(self.predicates[view_id]),
                "visibility_query_hash": _query_hash(self.visibility_queries[view_id]),
                "focused_row": self.focused_rows.get(view_id),
                "head_event_id": self.events.head,
            }

    def global_state(self) -> dict[str, Any]:
        with self.lock:
            active = self.active_view
            spec = self.views.get(active) if active else None
            return {
                "version": "0.7.0",
                "head_event_id": self.events.head,
                "workspace_revision": self.workspace_revision,
                "active_view_revision": self.active_view_revision,
                "active_view": None if spec is None else {
                    "view": spec.id, "title": spec.title, "domain": spec.domain, "projection": spec.projection,
                },
                "runtime_view_count": len(self.views),
            }

    # ---- GUI action bridge ------------------------------------------------
    def enqueue(self, action: str, view_id: str, **payload) -> None:
        self.actions.put({"action": action, "view_id": view_id, **payload})


################################################################################
if __name__=="__main__":
    pass
