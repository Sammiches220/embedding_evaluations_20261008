# HyCompass: maps and representation ecology — 0.6.8

A native Qt/OpenGL population browser with persistent analytical maps, bounded modular analysis, fixed group-held-out reconstruction, coordinated metric navigation and portable evidence packages.

```bash
python -m pip install -r requirements.txt
python main.py --workspace demo_workspace --map shared-base
```

The fresh demo includes two partially overlapping embeddings, canonical identities, typed targets, saved maps, geometry, reconstruction, frozen-reference evaluation and linked population views.

- [Illustrated representation ecology guide](docs_src/guides/representation_ecology/index.md) — also in generated **Guides → Representation Ecology**
- [Group visualizations, checklists and audit feedback](docs_merge/RELEASE_NOTES_0.6.1.md)
- [Metric navigation and scoped source audits](docs_merge/METRIC_NAVIGATION.md)
- [0.6.0 implementation and validation](docs_merge/RELEASE_NOTES_0.6.0.md)
- [Compact resource toolbar](docs_merge/RELEASE_NOTES_0.5.2.md)
- [Screen resource controls and complexity estimates](docs_merge/RELEASE_NOTES_0.5.1.md)
- [Map manager, packages, CLI and REST workflows](docs_merge/MAP_WORKFLOWS.md)
- [Implementation status and validation](docs_merge/IMPLEMENTATION.md)
- [Population viewer documentation](README_POPULATION.md)
- [Generated REST contract](docs_merge/openapi.json)

This project uses workspace format 4, ecology catalog 2 and the map/coverage-field contracts directly. Create fresh workspaces; older schemas and flags are not supported. The demo is generated under the current contracts rather than converted.

The existing numerical analysis methods and compact spectra/geometry interface are retained. The population remains independently available. Detail rendering uses bounded CPU meshes; original population rendering uses OpenGL. Large-corpus throughput, VRAM behavior and platform-specific desktop rendering require representative hardware measurements.

```bash
QT_QPA_PLATFORM=offscreen OPENBLAS_NUM_THREADS=1 python -m pytest
```
