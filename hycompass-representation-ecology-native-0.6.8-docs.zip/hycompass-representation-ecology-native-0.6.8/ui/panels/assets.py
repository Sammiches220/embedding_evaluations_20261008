################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from dataclasses import replace

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QFormLayout,
    QGroupBox,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QVBoxLayout,
)

##### Internal Imports #####
from model.workspace import ViewSpec, WorkspaceManifest


################################################################################
# CLASSES
################################################################################
class AssetBindingsPanel(QGroupBox):
    applyRequested = Signal(object)

    def __init__(self, manifest: WorkspaceManifest, spec: ViewSpec, parent=None) -> None:
        super().__init__("View composition", parent)
        self.manifest = manifest
        self.spec = spec
        root = QVBoxLayout(self)
        form = QFormLayout()
        self.domain = QComboBox()
        self.projection = QComboBox()
        self.selection = QComboBox()
        self.timeline = QComboBox()
        self.clustering = QComboBox()
        self.coverage_field = QComboBox()
        self.theme = QComboBox()
        for label, widget in (
            ("Domain", self.domain),
            ("Projection", self.projection),
            ("Primary selection", self.selection),
            ("Timeline", self.timeline),
            ("Point color", self.clustering),
            ("CoverageField field", self.coverage_field),
            ("Theme", self.theme),
        ):
            form.addRow(label, widget)
        root.addLayout(form)

        self.densities = QListWidget()
        self.densities.setMaximumHeight(90)
        self.segmentations = QListWidget()
        self.segmentations.setMaximumHeight(110)
        root.addWidget(self.densities)
        root.addWidget(self.segmentations)
        self.apply_btn = QPushButton("Apply composition")
        root.addWidget(self.apply_btn)

        self.domain.currentIndexChanged.connect(self._domain_changed)
        self.projection.currentIndexChanged.connect(self._projection_changed)
        self.timeline.currentIndexChanged.connect(self._timeline_changed)
        self.apply_btn.clicked.connect(self._emit_apply)
        self._populate_initial()
        self._set_combo(self.theme, [("default-dark", None)] + [(t.id, t.id) for t in self.manifest.themes.values()], self.spec.theme)

    @staticmethod
    def _set_combo(combo: QComboBox, items: list[tuple[str, object]], current) -> None:
        combo.blockSignals(True)
        combo.clear()
        current_index = 0
        for i, (label, data) in enumerate(items):
            combo.addItem(label, data)
            if data == current:
                current_index = i
        combo.setCurrentIndex(current_index)
        combo.blockSignals(False)

    def _populate_initial(self) -> None:
        domains = [(d.id, d.id) for d in self.manifest.domains.values()]
        self._set_combo(self.domain, domains, self.spec.domain)
        self._populate_for_domain(self.spec.domain, self.spec.projection)

    def _populate_for_domain(self, domain_id: str, projection_id: str | None = None) -> None:
        projections = [p for p in self.manifest.projections.values() if p.domain == domain_id]
        if not projections:
            self._set_combo(self.projection, [], None)
            return
        if projection_id not in {p.id for p in projections}:
            projection_id = projections[0].id
        self._set_combo(self.projection, [(p.id, p.id) for p in projections], projection_id)
        self._populate_for_projection(domain_id, projection_id)

    def _populate_for_projection(self, domain_id: str, projection_id: str) -> None:
        selection_items = [("(all domain)", None)] + [
            (s.id, s.id) for s in self.manifest.compatible_selections(domain_id) if s.kind != "all"
        ]
        self._set_combo(self.selection, selection_items, self.spec.selection)
        timeline_items = [("(none)", None)] + [
            (t.id, t.id) for t in self.manifest.compatible_timelines(domain_id)
        ]
        self._set_combo(self.timeline, timeline_items, self.spec.timeline)
        clustering_items = [("(none)", None)] + [
            (c.id, c.id) for c in self.manifest.compatible_clusterings(domain_id, projection_id)
        ]
        self._set_combo(self.clustering, clustering_items, self.spec.clustering)
        self._populate_coverage_field(projection_id, self.timeline.currentData())
        self._set_check_list(
            self.densities,
            "Density layers",
            [d.id for d in self.manifest.compatible_densities(projection_id)],
            set(self.spec.densities),
        )
        self._set_check_list(
            self.segmentations,
            "Segmentation layers",
            [s.id for s in self.manifest.compatible_segmentations(projection_id)],
            set(self.spec.segmentations),
        )

    def _populate_coverage_field(self, projection_id: str, timeline_id: str | None) -> None:
        items = [("(none)", None)] + [
            (e.id, e.id)
            for e in self.manifest.compatible_coverage_fields(projection_id, timeline_id)
        ]
        current = self.spec.coverage_field
        if current not in {data for _, data in items}:
            current = None
        self._set_combo(self.coverage_field, items, current)

    @staticmethod
    def _set_check_list(widget: QListWidget, title: str, ids: list[str], checked: set[str]) -> None:
        widget.clear()
        widget.setToolTip(title + ": multiple compatible assets may be stacked")
        for asset_id in ids:
            item = QListWidgetItem(asset_id)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Checked if asset_id in checked else Qt.CheckState.Unchecked)
            widget.addItem(item)

    @staticmethod
    def _checked_ids(widget: QListWidget) -> list[str]:
        return [
            widget.item(i).text()
            for i in range(widget.count())
            if widget.item(i).checkState() == Qt.CheckState.Checked
        ]

    def _domain_changed(self) -> None:
        domain_id = self.domain.currentData()
        if domain_id:
            self._populate_for_domain(domain_id)

    def _projection_changed(self) -> None:
        domain_id = self.domain.currentData()
        projection_id = self.projection.currentData()
        if domain_id and projection_id:
            self._populate_for_projection(domain_id, projection_id)

    def _timeline_changed(self) -> None:
        projection_id = self.projection.currentData()
        if projection_id:
            self._populate_coverage_field(projection_id, self.timeline.currentData())

    def _emit_apply(self) -> None:
        domain_id = self.domain.currentData()
        projection_id = self.projection.currentData()
        if not domain_id or not projection_id:
            return
        spec = replace(
            self.spec,
            domain=domain_id,
            projection=projection_id,
            selection=self.selection.currentData(),
            timeline=self.timeline.currentData(),
            clustering=self.clustering.currentData(),
            densities=self._checked_ids(self.densities),
            segmentations=self._checked_ids(self.segmentations),
            coverage_field=self.coverage_field.currentData(),
            theme=self.theme.currentData(),
            playback_start=None,
            playback_end=None,
        )
        self.applyRequested.emit(spec)


################################################################################
if __name__=="__main__":
    pass
