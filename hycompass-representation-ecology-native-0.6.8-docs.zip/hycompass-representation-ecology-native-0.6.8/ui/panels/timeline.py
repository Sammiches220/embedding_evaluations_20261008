################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QGroupBox, QHBoxLayout, QLabel, QPushButton, QSlider, QVBoxLayout


################################################################################
# CLASSES
################################################################################
class TimelinePanel(QGroupBox):
    def __init__(self, parent=None) -> None:
        super().__init__("Timeline", parent)
        layout = QVBoxLayout(self)
        self.time_label = QLabel()
        self.time_label.setWordWrap(True)
        layout.addWidget(self.time_label)
        self.timeline = QSlider(Qt.Orientation.Horizontal)
        self.timeline.setRange(0, 1000)
        self.timeline.setValue(500)
        layout.addWidget(self.timeline)
        row = QHBoxLayout()
        self.back_btn = QPushButton("◀")
        self.play_btn = QPushButton("▶ Play")
        self.play_btn.setCheckable(True)
        self.forward_btn = QPushButton("▶")
        row.addWidget(self.back_btn)
        row.addWidget(self.play_btn, 1)
        row.addWidget(self.forward_btn)
        layout.addLayout(row)

    def configure(self, has_timeline: bool, timeline_id: str | None = None) -> None:
        for widget in (self.timeline, self.back_btn, self.play_btn, self.forward_btn):
            widget.setEnabled(has_timeline)
        if not has_timeline:
            self.time_label.setText("No timeline selected. Selections/coverage_field remain fully usable.")
        elif timeline_id:
            self.setTitle(f"Timeline — {timeline_id}")


################################################################################
if __name__=="__main__":
    pass
