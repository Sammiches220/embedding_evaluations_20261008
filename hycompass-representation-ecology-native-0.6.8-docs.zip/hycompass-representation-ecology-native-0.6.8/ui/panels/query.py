################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import numpy as np
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QGroupBox, QHBoxLayout, QLabel, QListWidget,
    QListWidgetItem, QPushButton, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
)

##### Internal Imports #####
from ui.dialogs.library import LibraryBrowserDialog, LibraryEntry, SaveLibraryItemDialog


################################################################################
# CLASSES
################################################################################
class PointQueryPanel(QGroupBox):
    """Convenience editor for the JSON PointQuery grammar.

    The editor intentionally exposes *compatible workspace assets*, not only the
    assets currently rendered in the View. Multiple clustering, segmentation,
    density and coverage_field assets can therefore participate in one predicate.
    """

    applySelectionRequested = Signal(object)
    applyVisibilityRequested = Signal(object)
    clearVisibilityRequested = Signal()
    saveQueryRequested = Signal(str, str, object)
    deleteQueryRequested = Signal(str)
    predicateChanged = Signal(object, str, object)

    def __init__(self, dataset, parent=None) -> None:
        super().__init__("Point predicates", parent)
        self.dataset = dataset
        self.manifest = dataset.session.manifest
        self.spec = dataset.spec
        self._loaded_expression: dict | None = None
        self._loaded_query_name: str | None = None
        self._loaded_query_id: str | None = None
        self._tree_guard = False
        root = QVBoxLayout(self)

        # Selection membership -------------------------------------------------
        self.selection_group = self._check_group("Selection membership")
        box = QVBoxLayout(self.selection_group)
        self.selection_mode = self._any_all_combo("Across selected memberships")
        self.selection_ids = QListWidget(); self.selection_ids.setMaximumHeight(120)
        for s in self.manifest.compatible_selections(self.spec.domain):
            if s.kind != "all": self._add_check_item(self.selection_ids, s.id, s.id)
        box.addWidget(self.selection_mode); box.addWidget(self.selection_ids); box.addLayout(self._check_buttons(self.selection_ids))
        root.addWidget(self.selection_group)

        # Multiple clustering assets ------------------------------------------
        self.cluster_group = self._check_group("Clusterings")
        box = QVBoxLayout(self.cluster_group)
        self.cluster_asset_mode = self._any_all_combo("Across enabled clustering assets")
        self.cluster_tree = QTreeWidget(); self.cluster_tree.setHeaderLabels(["Clustering / cluster ID", "Population"]); self.cluster_tree.setMaximumHeight(250)
        self._populate_cluster_tree()
        box.addWidget(self.cluster_asset_mode); box.addWidget(self.cluster_tree)
        box.addWidget(QLabel("Check one or more clustering assets, then any combination of IDs beneath each asset."))
        root.addWidget(self.cluster_group)

        # Multiple segmentation assets ----------------------------------------
        self.segment_group = self._check_group("Segmentations")
        box = QVBoxLayout(self.segment_group)
        self.segment_asset_mode = self._any_all_combo("Across enabled segmentation assets")
        self.segment_tree = QTreeWidget(); self.segment_tree.setHeaderLabels(["Segmentation / region", "Population"]); self.segment_tree.setMaximumHeight(260)
        self._populate_segment_tree()
        box.addWidget(self.segment_asset_mode); box.addWidget(self.segment_tree)
        box.addWidget(QLabel("Check regions from one or several segmentation assets. Each enabled asset may contribute multiple region IDs."))
        root.addWidget(self.segment_group)

        # Multiple density fields ---------------------------------------------
        self.density_group = self._check_group("Density fields")
        box = QVBoxLayout(self.density_group)
        self.density_asset_mode = self._any_all_combo("Across checked density assets")
        self.density_ids = QListWidget(); self.density_ids.setMaximumHeight(130)
        for d in self.manifest.compatible_densities(self.spec.projection): self._add_check_item(self.density_ids, f"{d.id}  [{d.method or 'unknown'}]", d.id)
        self.density_mode = QComboBox()
        for label,data in ((">= value","ge"),("<= value","le"),("top N%","top_pct"),("bottom N%","bottom_pct")): self.density_mode.addItem(label,data)
        self.density_value = QDoubleSpinBox(); self.density_value.setRange(0.0,1.0); self.density_value.setValue(0.5); self.density_value.setDecimals(3)
        box.addWidget(self.density_asset_mode); box.addWidget(self.density_ids); box.addLayout(self._check_buttons(self.density_ids)); box.addWidget(self.density_mode); box.addWidget(self.density_value)
        root.addWidget(self.density_group)

        # Multiple compatible coverage_field fields -----------------------------
        self.coverage_field_group = self._check_group("CoverageField fields")
        box = QVBoxLayout(self.coverage_field_group)
        self.coverage_field_asset_mode = self._any_all_combo("Across checked coverage_field assets")
        self.coverage_field_ids = QListWidget(); self.coverage_field_ids.setMaximumHeight(130)
        for e in self.manifest.compatible_coverage_fields(self.spec.projection, self.spec.timeline): self._add_check_item(self.coverage_field_ids, f"{e.id}  [{e.method or 'unknown'}]", e.id)
        self.coverage_field_mode = QComboBox()
        for label,data in (("inside boundary","inside"),("outside boundary","outside"),(">= value","ge"),("<= value","le")): self.coverage_field_mode.addItem(label,data)
        self.coverage_field_value = QDoubleSpinBox(); self.coverage_field_value.setRange(0.0,1.0); self.coverage_field_value.setValue(float(dataset.current_coverage_field_threshold)); self.coverage_field_value.setDecimals(3)
        box.addWidget(self.coverage_field_asset_mode); box.addWidget(self.coverage_field_ids); box.addLayout(self._check_buttons(self.coverage_field_ids)); box.addWidget(self.coverage_field_mode); box.addWidget(self.coverage_field_value)
        root.addWidget(self.coverage_field_group)

        self.timeline_group = self._check_group("Timeline state")
        box = QVBoxLayout(self.timeline_group)
        self.timeline_mode = QComboBox(); self.timeline_mode.addItem("Observed by current time","observed"); self.timeline_mode.addItem("Future / missing","future")
        box.addWidget(self.timeline_mode); root.addWidget(self.timeline_group)

        action_box = QGroupBox("Apply predicates")
        action_layout = QVBoxLayout(action_box)
        row = QHBoxLayout(); self.apply_selection=QPushButton("Select matches"); self.show_only=QPushButton("Show only matches"); self.hide_matches=QPushButton("Hide matches")
        row.addWidget(self.apply_selection); row.addWidget(self.show_only); row.addWidget(self.hide_matches); action_layout.addLayout(row)
        self.reset_visibility=QPushButton("Reset visibility"); action_layout.addWidget(self.reset_visibility)
        root.addWidget(action_box)

        saved_box = QGroupBox("Saved queries")
        saved_layout = QVBoxLayout(saved_box)
        self.source_status = QLabel("Predicate source: <b>Visible controls</b>"); self.source_status.setWordWrap(True)
        saved_layout.addWidget(self.source_status)
        row=QHBoxLayout(); self.load_saved=QPushButton("Load saved query…"); self.save_query=QPushButton("Save controls…"); self.delete_saved=QPushButton("Delete saved query…")
        row.addWidget(self.load_saved); row.addWidget(self.save_query); row.addWidget(self.delete_saved); saved_layout.addLayout(row)
        self.use_controls=QPushButton("Switch to visible predicate controls"); self.use_controls.setEnabled(False); saved_layout.addWidget(self.use_controls)
        root.addWidget(saved_box)

        self.status=QLabel("Unchecked predicate groups do not participate. Compatible assets need not currently be rendered in the View."); self.status.setWordWrap(True); root.addWidget(self.status)

        # Wiring ---------------------------------------------------------------
        self.density_mode.currentIndexChanged.connect(self._density_mode_changed)
        self.cluster_tree.itemChanged.connect(self._tree_changed)
        self.segment_tree.itemChanged.connect(self._tree_changed)
        self.apply_selection.clicked.connect(lambda:self.applySelectionRequested.emit(self.expression()))
        self.show_only.clicked.connect(lambda:self.applyVisibilityRequested.emit(self.expression()))
        self.hide_matches.clicked.connect(lambda:self.applyVisibilityRequested.emit({"op":"not","arg":self.expression()}))
        self.reset_visibility.clicked.connect(self.clearVisibilityRequested)
        self.save_query.clicked.connect(self._save_dialog); self.load_saved.clicked.connect(self._load_dialog); self.delete_saved.clicked.connect(self._delete_dialog); self.use_controls.clicked.connect(self._clear_loaded_expression)

        for group in (self.selection_group,self.cluster_group,self.segment_group,self.density_group,self.coverage_field_group,self.timeline_group): group.toggled.connect(self._controls_changed)
        for combo in (self.selection_mode,self.cluster_asset_mode,self.segment_asset_mode,self.density_asset_mode,self.density_mode,self.coverage_field_asset_mode,self.coverage_field_mode,self.timeline_mode): combo.currentIndexChanged.connect(self._controls_changed)
        for spin in (self.density_value,self.coverage_field_value): spin.valueChanged.connect(self._controls_changed)
        for lst in (self.selection_ids,self.density_ids,self.coverage_field_ids): lst.itemChanged.connect(lambda *_: self._controls_changed())
        self._configure_availability(); self._density_mode_changed()

    @staticmethod
    def _check_group(title: str) -> QGroupBox:
        g=QGroupBox(title); g.setCheckable(True); g.setChecked(False); return g

    @staticmethod
    def _any_all_combo(prefix: str) -> QComboBox:
        c=QComboBox(); c.addItem(f"{prefix}: match ALL", "all"); c.addItem(f"{prefix}: match ANY", "any"); return c

    @staticmethod
    def _add_check_item(widget: QListWidget, label: str, value) -> None:
        item=QListWidgetItem(str(label)); item.setData(Qt.ItemDataRole.UserRole,value); item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable); item.setCheckState(Qt.CheckState.Unchecked); widget.addItem(item)

    @staticmethod
    def _checked_values(widget: QListWidget) -> list:
        return [widget.item(i).data(Qt.ItemDataRole.UserRole) for i in range(widget.count()) if widget.item(i).checkState()==Qt.CheckState.Checked]

    @staticmethod
    def _check_buttons(widget: QListWidget) -> QHBoxLayout:
        row=QHBoxLayout(); all_btn=QPushButton("All"); none_btn=QPushButton("None")
        def set_all(state):
            for i in range(widget.count()): widget.item(i).setCheckState(state)
        all_btn.clicked.connect(lambda:set_all(Qt.CheckState.Checked)); none_btn.clicked.connect(lambda:set_all(Qt.CheckState.Unchecked)); row.addWidget(all_btn); row.addWidget(none_btn); row.addStretch(1); return row

    @staticmethod
    def _checkable_tree_item(label: str, value, *, population: int | None = None) -> QTreeWidgetItem:
        item=QTreeWidgetItem([str(label), "" if population is None else f"{int(population):,}"])
        item.setData(0,Qt.ItemDataRole.UserRole,value); item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable); item.setCheckState(0,Qt.CheckState.Unchecked); return item

    def _populate_cluster_tree(self) -> None:
        self.cluster_tree.clear()
        for spec in self.manifest.compatible_clusterings(self.spec.domain,self.spec.projection):
            labels=self.dataset.session.array(spec.labels); unique,counts=np.unique(labels,return_counts=True)
            root=self._checkable_tree_item(f"{spec.id}  [{spec.method or 'unknown'}]",spec.id); root.setExpanded(False)
            for value,count in zip(unique[:5000],counts[:5000]): root.addChild(self._checkable_tree_item(str(int(value)),int(value),population=int(count)))
            if len(unique)>5000: root.setToolTip(0,f"{len(unique):,} IDs exist; first 5,000 shown. REST queries can address any ID explicitly.")
            self.cluster_tree.addTopLevelItem(root)

    def _populate_segment_tree(self) -> None:
        self.segment_tree.clear()
        for spec in self.manifest.compatible_segmentations(self.spec.projection):
            stats=self.dataset.session.json_value(spec.stats)
            if isinstance(stats,dict): stats=stats.get("regions") or stats.get("stats") or []
            root=self._checkable_tree_item(f"{spec.id}  [{spec.method or 'unknown'}]",spec.id); root.setExpanded(False)
            for entry in sorted(list(stats or []),key=lambda x:int(x.get("id",0))):
                sid=int(entry.get("id",0)); name=str(entry.get("name") or entry.get("label") or f"Segment {sid}")
                root.addChild(self._checkable_tree_item(f"{sid}: {name}",sid,population=int(entry.get("population",0))))
            self.segment_tree.addTopLevelItem(root)

    def _tree_changed(self,item:QTreeWidgetItem,column:int) -> None:
        if self._tree_guard: return
        self._tree_guard=True
        try:
            parent=item.parent()
            if parent is None:
                # Checking an asset with no chosen IDs selects all visible IDs;
                # unchecking it disables the entire asset without altering IDs.
                if item.checkState(0)==Qt.CheckState.Checked and item.childCount() and not any(item.child(i).checkState(0)==Qt.CheckState.Checked for i in range(item.childCount())):
                    for i in range(item.childCount()): item.child(i).setCheckState(0,Qt.CheckState.Checked)
            elif item.checkState(0)==Qt.CheckState.Checked:
                parent.setCheckState(0,Qt.CheckState.Checked)
        finally:
            self._tree_guard=False
        self._controls_changed()

    @staticmethod
    def _tree_asset_leaves(tree:QTreeWidget, feature:str) -> list[dict]:
        leaves=[]
        for i in range(tree.topLevelItemCount()):
            root=tree.topLevelItem(i)
            if root.checkState(0)!=Qt.CheckState.Checked: continue
            values=[root.child(j).data(0,Qt.ItemDataRole.UserRole) for j in range(root.childCount()) if root.child(j).checkState(0)==Qt.CheckState.Checked]
            if values: leaves.append({"feature":feature,"asset":str(root.data(0,Qt.ItemDataRole.UserRole)),"cmp":"in","values":values})
        return leaves

    @staticmethod
    def _combine_leaves(leaves:list[dict],mode:str) -> dict | None:
        if not leaves:return None
        if len(leaves)==1:return leaves[0]
        return {"op":"or" if mode=="any" else "and","args":leaves}

    def _configure_availability(self) -> None:
        for group,available in (
            (self.selection_group,self.selection_ids.count()>0),
            (self.cluster_group,self.cluster_tree.topLevelItemCount()>0),
            (self.segment_group,self.segment_tree.topLevelItemCount()>0),
            (self.density_group,self.density_ids.count()>0),
            (self.coverage_field_group,self.coverage_field_ids.count()>0),
            (self.timeline_group,bool(self.spec.timeline)),
        ):
            group.setEnabled(bool(available)); group.setChecked(False)

    def _density_mode_changed(self,*_) -> None:
        percentile=self.density_mode.currentData() in {"top_pct","bottom_pct"}; self.density_value.blockSignals(True); old=float(self.density_value.value())
        if percentile:
            self.density_value.setRange(0.01,100.0); self.density_value.setDecimals(2); self.density_value.setSuffix(" %"); self.density_value.setValue(10.0 if old<=1.0 else old)
        else:
            self.density_value.setRange(0.0,1.0); self.density_value.setDecimals(3); self.density_value.setSuffix(""); self.density_value.setValue(0.5 if old>1.0 else old)
        self.density_value.blockSignals(False)

    def expression(self) -> dict:
        if self._loaded_expression is not None:return dict(self._loaded_expression)
        args:list[dict]=[{"feature":"projected","cmp":"finite"}]
        if self.selection_group.isChecked():
            leaves=[{"feature":"selection","asset":str(x),"cmp":"member"} for x in self._checked_values(self.selection_ids)]
            leaf=self._combine_leaves(leaves,str(self.selection_mode.currentData()));
            if leaf:args.append(leaf)
        if self.cluster_group.isChecked():
            leaf=self._combine_leaves(self._tree_asset_leaves(self.cluster_tree,"cluster"),str(self.cluster_asset_mode.currentData()));
            if leaf:args.append(leaf)
        if self.segment_group.isChecked():
            leaf=self._combine_leaves(self._tree_asset_leaves(self.segment_tree,"segmentation"),str(self.segment_asset_mode.currentData()));
            if leaf:args.append(leaf)
        if self.density_group.isChecked():
            leaves=[]; mode=self.density_mode.currentData(); value=float(self.density_value.value())
            for aid in self._checked_values(self.density_ids):
                leaf={"feature":"density","asset":str(aid)}
                if mode=="top_pct":leaf.update({"cmp":">=","percentile":max(0.0,100.0-value)})
                elif mode=="bottom_pct":leaf.update({"cmp":"<=","percentile":value})
                elif mode=="le":leaf.update({"cmp":"<=","value":value})
                else:leaf.update({"cmp":">=","value":value})
                leaves.append(leaf)
            leaf=self._combine_leaves(leaves,str(self.density_asset_mode.currentData()));
            if leaf:args.append(leaf)
        if self.coverage_field_group.isChecked():
            leaves=[]; mode=self.coverage_field_mode.currentData(); value=float(self.coverage_field_value.value())
            for aid in self._checked_values(self.coverage_field_ids):
                leaf={"feature":"coverage_field","asset":str(aid)}
                if mode in {"inside","outside"}:leaf.update({"cmp":mode,"threshold":value})
                elif mode=="le":leaf.update({"cmp":"<=","value":value})
                else:leaf.update({"cmp":">=","value":value})
                leaves.append(leaf)
            leaf=self._combine_leaves(leaves,str(self.coverage_field_asset_mode.currentData()));
            if leaf:args.append(leaf)
        if self.timeline_group.isChecked() and self.spec.timeline:args.append({"feature":"timeline","cmp":self.timeline_mode.currentData()})
        return {"op":"and","args":args}

    def _entries(self) -> list[LibraryEntry]:
        return [LibraryEntry(q.id,q.title or q.id,q.folder) for q in self.manifest.compatible_queries(self.spec.domain,self.spec.projection)]

    def _set_source_status(self) -> None:
        if self._loaded_expression is None:
            self.source_status.setText("Predicate source: <b>Visible controls</b>"); self.use_controls.setEnabled(False)
        else:
            self.source_status.setText(f"Predicate source: <b>Saved query — {self._loaded_query_name or 'loaded query'}</b><br>The visible controls are currently overridden."); self.use_controls.setEnabled(True)

    def _load_dialog(self) -> None:
        dlg=LibraryBrowserDialog(self._entries(),noun="query",allow_delete=False,parent=self)
        if dlg.exec() and dlg.selected_id:
            q=self.manifest.saved_queries[dlg.selected_id]
            self._loaded_expression=dict(q.query)
            self._loaded_query_id=q.id
            self._loaded_query_name=f"{q.folder + '/' if q.folder else ''}{q.title or q.id}"
            self._set_source_status()
            self.status.setText("Loaded Saved Query is active. Choose 'Switch to visible predicate controls' or edit any predicate control to stop using it.")
            self._emit_predicate_changed()

    def _clear_loaded_expression(self, *, emit: bool = True) -> None:
        self._loaded_expression=None
        self._loaded_query_id=None
        self._loaded_query_name=None
        self._set_source_status()
        self.status.setText("Using the visible predicate controls.")
        if emit:
            self._emit_predicate_changed()

    def _emit_predicate_changed(self) -> None:
        if self._loaded_expression is None:
            self.predicateChanged.emit(self.expression(), "controls", {"saved_query_id": None, "saved_query_name": None})
        else:
            self.predicateChanged.emit(
                self.expression(), "saved_query",
                {"saved_query_id": self._loaded_query_id, "saved_query_name": self._loaded_query_name},
            )

    def _controls_changed(self,*_) -> None:
        if self._loaded_expression is not None:
            self._clear_loaded_expression(emit=False)
        self._emit_predicate_changed()

    def _save_dialog(self) -> None:
        dlg=SaveLibraryItemDialog(noun="query",title="Query",folder="",parent=self)
        if dlg.exec():self.saveQueryRequested.emit(dlg.item_title,dlg.folder,self.expression())

    def _delete_dialog(self) -> None:
        dlg=LibraryBrowserDialog(self._entries(),noun="query",allow_delete=True,parent=self); dlg.exec()
        for qid in dlg.deleted_ids:self.deleteQueryRequested.emit(qid)
        if dlg.deleted_ids:self.status.setText(f"Deleted {len(dlg.deleted_ids)} saved quer{'y' if len(dlg.deleted_ids)==1 else 'ies'}.")


################################################################################
if __name__=="__main__":
    pass
