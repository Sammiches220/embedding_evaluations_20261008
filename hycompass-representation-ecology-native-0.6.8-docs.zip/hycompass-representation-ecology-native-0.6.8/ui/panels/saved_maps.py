"""Population sidebar and portable card dialogs."""
import base64

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor, QIcon, QImage, QPixmap
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMessageBox, QPushButton, QScrollArea, QSpinBox, QVBoxLayout, QWidget,
)

from ecology.cards import (
    MAX_FINDINGS, PRESETS, card_details, export_html, import_card, local_match, make_card,
    preset_rows, read_card, report_details, saved_evidence, write_card,
)
from ecology.footprints import footprints, matches_view
from ecology.store import Store


def footprint_outcome(future):
    if future is None:
        return None, "Location unavailable · open a compatible population view"
    try:
        return future.result(), ""
    except FileNotFoundError:
        return None, "Location unavailable · missing source asset"
    except (OSError, ValueError, KeyError) as exc:
        return None, str(exc)


class CardPreview(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.title = QLabel()
        title_font = self.title.font()
        title_font.setBold(True)
        title_font.setPointSizeF(max(11, title_font.pointSizeF() + 2))
        self.title.setFont(title_font)
        self.picture = QLabel()
        self.picture.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.picture.setStyleSheet("background:#0d1a23; border:1px solid #2b454d; border-radius:8px; padding:8px;")
        self.details = QLabel()
        for label in (self.title, self.details):
            label.setTextFormat(Qt.TextFormat.PlainText)
            label.setWordWrap(True)
            label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.title)
        layout.addWidget(self.picture)
        layout.addWidget(self.details)

    def scroll_area(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self)
        return scroll

    def show_card(self, card=None, message=""):
        self.title.setText(card["title"] if card else "")
        self.details.setText(card_details(card) if card else message)
        self.picture.clear()
        png = card["png"] if card else None
        if png:
            image = QPixmap.fromImage(QImage.fromData(base64.b64decode(png), "PNG"))
            self.picture.setPixmap(image.scaled(200, 170, Qt.AspectRatioMode.KeepAspectRatio,
                                                Qt.TransformationMode.SmoothTransformation))
        self.picture.setToolTip("Occupied member cells and the saved map’s coverage field.")
        self.picture.setVisible(bool(png))


class CardDialog(QDialog):
    def __init__(self, store, key, dataset, parent):
        super().__init__(parent)
        self.setWindowTitle("Portable map card")
        self.resize(540, 480)
        self.definition = store.read(key)
        if dataset is not None and not matches_view(self.definition, dataset):
            dataset = None
        self.footprint = None
        self.status = "Preparing footprint…" if dataset is not None else ""
        self.anchors = None
        self.card = None
        layout = QVBoxLayout(self)
        self.preview = CardPreview()
        layout.addWidget(self.preview.scroll_area(), stretch=1)
        self.preset = QComboBox()
        self.preset.addItems(PRESETS)
        self.preset.currentIndexChanged.connect(self.apply_preset)
        preset_bar = QHBoxLayout()
        preset_bar.addWidget(self.preset, 1)
        apply = QPushButton("Apply preset")
        apply.clicked.connect(lambda: self.apply_preset(self.preset.currentIndex()))
        preset_bar.addWidget(apply)
        layout.addLayout(preset_bar)
        self.result_filter = QComboBox()
        self.result_filter.addItem("All result families", "")
        self.result_filter.currentIndexChanged.connect(self.filter_findings)
        layout.addWidget(self.result_filter)
        self.finding_search = QLineEdit()
        self.finding_search.setPlaceholderText("Filter checklist by target, metric, scope or result")
        self.finding_search.textChanged.connect(self.filter_findings)
        layout.addWidget(self.finding_search)
        self.show_measurements = QCheckBox("Show individual measurements")
        self.show_measurements.setChecked(True)
        self.show_measurements.toggled.connect(self.filter_findings)
        layout.addWidget(self.show_measurements)
        self.checklist = QListWidget()
        self.checklist.setMinimumHeight(150)
        self.checklist.itemChanged.connect(self.selection_count)
        layout.addWidget(self.checklist)
        self.count_label = QLabel("Reading saved result summaries…")
        layout.addWidget(self.count_label)
        self.include_features = QCheckBox("Include all available saved features in the HTML explorer")
        self.include_features.setChecked(True)
        layout.addWidget(self.include_features)
        self.buttons = []
        bar = QHBoxLayout()
        layout.addLayout(bar)
        for label, extension in (("Export card (PNG)…", "card"), ("Export report (HTML)…", "html"),
                                 ("Export JSON…", "json")):
            button = QPushButton(label)
            button.setEnabled(False)
            button.clicked.connect(lambda _, ext=extension: self.export(ext))
            bar.addWidget(button)
            self.buttons.append(button)
        self.evidence = footprints.executor.submit(saved_evidence, store, key, include_overview=True, include_charts=True, include_features=True)
        self.pending = footprints.request(dataset, key) if dataset is not None else None
        self.timer = QTimer(self, interval=50)
        self.timer.timeout.connect(self.finish)
        self.timer.start()
        self.update_preview()

    def finish(self):
        if not self.evidence.done() or (self.pending is not None and not self.pending.done()):
            return
        self.timer.stop()
        self.footprint, self.status = footprint_outcome(self.pending)
        if self.footprint is not None and self.footprint.revision != self.definition["revision"]:
            self.footprint, self.status = None, "Stale map definition. Reopen the card."
        try:
            self.anchors, findings, self.overview, self.charts, self.feature_data = self.evidence.result()
        except (OSError, ValueError, KeyError) as exc:
            findings = []
            self.overview = dict(definition="Saved map " + self.definition["revision"], modules=[])
            self.charts = []
            self.feature_data = []
            QMessageBox.warning(self, "Saved findings unavailable", str(exc))
        self.checklist.blockSignals(True)
        findings_by_result = {}
        for finding in findings:
            findings_by_result.setdefault(finding["result"], []).append(finding)
        families = set()
        for module in self.overview["modules"]:
            result = f'{module["name"]}/{module["result"]}'
            family = module["name"].split("--", 1)[0]
            families.add(family)
            item = QListWidgetItem(f'{module["name"].replace("_", " ")} · Include result summary')
            item.setToolTip(module["scope"])
            font = item.font()
            font.setBold(True)
            item.setFont(font)
            item.setData(Qt.ItemDataRole.UserRole, {"module": module, "family": family})
            item.setCheckState(Qt.CheckState.Unchecked)
            self.checklist.addItem(item)
            for finding in findings_by_result.pop(result, []):
                self.add_finding(finding, family)
        for result, rows in findings_by_result.items():
            family = result.split("/", 1)[0].split("--", 1)[0]
            families.add(family)
            for finding in rows:
                self.add_finding(finding, family)
        for family in sorted(families):
            self.result_filter.addItem(family.replace("_", " "), family)
        self.checklist.blockSignals(False)
        self.filter_findings()
        self.apply_preset(self.preset.currentIndex())
        self.update_preview()
        for button in self.buttons:
            button.setEnabled(True)

    def add_finding(self, finding, family):
        item = QListWidgetItem(f'    {finding["target"]} · {finding["metric"]} = {finding["value"]:.5g}'
                               f' · {finding["scope"]}')
        item.setToolTip(finding["result"] + "\n" + item.text().strip())
        item.setData(Qt.ItemDataRole.UserRole, {"finding": finding, "family": family})
        item.setCheckState(Qt.CheckState.Unchecked)
        self.checklist.addItem(item)

    def filter_findings(self, *_):
        family = self.result_filter.currentData()
        query = self.finding_search.text().casefold()
        for row in range(self.checklist.count()):
            item = self.checklist.item(row)
            entry = item.data(Qt.ItemDataRole.UserRole)
            matches = query in (item.text() + " " + item.toolTip()).casefold()
            item.setHidden(not matches or bool(family and entry["family"] != family)
                           or ("finding" in entry and not self.show_measurements.isChecked()))

    def apply_preset(self, index):
        if index < 0:
            return
        items = [self.checklist.item(row) for row in range(self.checklist.count())]
        measurements = [item for item in items if "finding" in item.data(Qt.ItemDataRole.UserRole)]
        findings = [item.data(Qt.ItemDataRole.UserRole)["finding"] for item in measurements]
        preset = PRESETS[index]
        selected_items = [measurements[row] for row in preset_rows(findings, preset)]
        selected = {self.checklist.row(item) for item in selected_items}
        families = {item.data(Qt.ItemDataRole.UserRole)["family"] for item in selected_items}
        families.update({
            "Target distributions": {"feature_distribution", "feature_audit"},
            "Model evaluation": {"reconstruction", "probe_metrics", "reference_evaluation", "discrepancy"},
            "Geometry and support": {"geometry", "source_support", "resolved_support", "neighbors",
                                     "directions", "routes", "compression", "stability"},
        }.get(preset, ()))
        self.checklist.blockSignals(True)
        for row, item in enumerate(items):
            entry = item.data(Qt.ItemDataRole.UserRole)
            include = row in selected or ("module" in entry and
                       (index in (0, len(PRESETS)-2) or entry["family"] in families))
            item.setCheckState(Qt.CheckState.Checked if include else Qt.CheckState.Unchecked)
        self.checklist.blockSignals(False)
        self.selection_count()

    def checked_entries(self, kind):
        return [entry[kind] for row in range(self.checklist.count())
                if (item := self.checklist.item(row)).checkState() == Qt.CheckState.Checked
                and kind in (entry := item.data(Qt.ItemDataRole.UserRole))]

    def checked_findings(self):
        return self.checked_entries("finding")

    def selection_count(self):
        count = len(self.checked_findings())
        sections = len(self.checked_entries("module"))
        if not self.checklist.count():
            self.count_label.setText("No saved results for this map. The map profile can still be exported.")
        else:
            self.count_label.setText(f"{sections} result summaries · {count} findings selected · "
                                     f"{self.checklist.count()} checklist items")

    def update_preview(self):
        self.card = make_card(self.definition, self.footprint,
                              status=self.status or "Location unavailable", anchors=self.anchors)
        self.preview.show_card(self.card)

    def export(self, extension):
        compact = extension == "card"
        suffix = "png" if compact else extension
        name = self.definition["id"] + ("-card" if compact else "") + "." + suffix
        path, _ = QFileDialog.getSaveFileName(self, "Export map card", name, f"Map export (*.{suffix})")
        if path:
            try:
                findings = self.checked_findings()
                if len(findings) > MAX_FINDINGS and not compact:
                    raise ValueError(f"Select at most {MAX_FINDINGS} findings for a compact export.")
                overview = {**self.overview, "modules": self.checked_entries("module")}
                if compact:
                    card = {**self.card, "version": 2, "findings": findings[:MAX_FINDINGS], "overview": overview}
                    from ecology.card_image import export_card_image
                    export_card_image(card, path)
                else:
                    card = {**self.card, "version": 2, "findings": findings, "overview": overview}
                    if suffix == "html":
                        export_html(card, path, self.charts,
                                    features=self.feature_data if self.include_features.isChecked() else ())
                    else:
                        write_card(card, path)
            except (OSError, ValueError) as exc:
                QMessageBox.warning(self, "Map card export", str(exc))


class CardBrowser(QDialog):
    def __init__(self, store, open_map, show_population, parent):
        super().__init__(parent)
        self.setWindowTitle("Imported map cards")
        self.resize(580, 620)
        self.store = store
        self.open_map = open_map
        self.show_population = show_population
        self.match = None
        layout = QVBoxLayout(self)
        self.list = QListWidget()
        self.list.setMaximumHeight(150)
        layout.addWidget(self.list)
        self.preview = CardPreview()
        layout.addWidget(self.preview.scroll_area(), stretch=1)
        bar = QHBoxLayout()
        layout.addLayout(bar)
        self.report_toggle = QCheckBox("Show exported overview and findings")
        layout.addWidget(self.report_toggle)
        self.report_toggle.toggled.connect(self.selection)
        self.open_button = QPushButton("Open map")
        self.show_button = QPushButton("Show in population")
        import_button = QPushButton("Import card JSON…")
        for button in (import_button, self.open_button, self.show_button):
            bar.addWidget(button)
        import_button.clicked.connect(self.import_snapshot)
        self.open_button.clicked.connect(self.open_selected)
        self.show_button.clicked.connect(self.show_selected)
        self.list.currentItemChanged.connect(self.selection)
        self.refresh()

    def refresh(self, selected=None):
        self.list.clear()
        for path in sorted((self.store.catalog.root / "map-cards").glob("*.json")):
            try:
                card = read_card(path)
            except (ValueError, OSError, RecursionError):
                continue
            item = QListWidgetItem(card["title"])
            item.setData(Qt.ItemDataRole.UserRole, card)
            self.list.addItem(item)
            if card == selected:
                self.list.setCurrentItem(item)
        if self.list.currentRow() < 0 and self.list.count():
            self.list.setCurrentRow(0)
        self.selection()

    def selection(self, *_):
        item = self.list.currentItem()
        self.card = item.data(Qt.ItemDataRole.UserRole) if item else None
        self.match = local_match(self.store, self.card) if self.card else None
        self.open_button.setEnabled(self.match is not None)
        self.show_button.setEnabled(self.match is not None and self.show_population is not None)
        self.preview.show_card(self.card, "Import a map card to browse its snapshot.")
        self.report_toggle.setEnabled(bool(self.card and (self.card.get("overview") or self.card["findings"])))
        if self.card:
            details = self.preview.details.text()
            if not self.match:
                details += "\n\nSnapshot · no exact local map match"
            if self.report_toggle.isChecked():
                details += "\n\n" + report_details(self.card)
            self.preview.details.setText(details)

    def import_snapshot(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import map card", "", "Map card (*.json)")
        if path:
            try:
                self.refresh(import_card(self.store.catalog.root, path))
            except (ValueError, OSError, RecursionError) as exc:
                QMessageBox.warning(self, "Invalid map card", str(exc))

    def open_selected(self):
        if self.card and (key := local_match(self.store, self.card)):
            try:
                if self.open_map(key) is not None:
                    self.accept()
            except (ValueError, OSError, KeyError) as exc:
                QMessageBox.warning(self, "Open map", str(exc))

    def show_selected(self):
        if self.card and (key := local_match(self.store, self.card)):
            try:
                self.show_population(key, self.card["projection"], self.card["revision"])
            except (ValueError, OSError, KeyError) as exc:
                QMessageBox.warning(self, "Show in population", str(exc))
            else:
                self.accept()


OVERLAY_COLORS = ((89, 198, 221), (255, 184, 104), (189, 155, 247), (113, 219, 153),
                  (247, 142, 174), (214, 216, 110), (119, 160, 253), (241, 159, 124))


class SavedMapsPanel(QWidget):
    openRequested = Signal(str)

    def __init__(self, dataset, canvas):
        super().__init__()
        self.dataset = dataset
        self.canvas = canvas
        self.key = None
        self.checked = []
        self.expectations = {}
        self.definitions = {}
        self.ready = {}
        self.pending = None
        self.generation = 0
        layout = QVBoxLayout(self)
        self.enabled = QCheckBox("Show Saved maps layer")
        layout.addWidget(self.enabled)
        self.body = QWidget()
        layout.addWidget(self.body)
        body = QVBoxLayout(self.body)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Find saved maps by title or embedding")
        body.addWidget(self.search)
        self.list = QListWidget()
        self.list.setMaximumHeight(110)
        body.addWidget(self.list)
        form = QFormLayout()
        body.addLayout(form)
        self.radius = QSpinBox()
        self.radius.setRange(1, 32)
        self.radius.setValue(6)
        self.threshold = QDoubleSpinBox()
        self.threshold.setRange(0.01, 1.0)
        self.threshold.setSingleStep(0.05)
        self.threshold.setValue(0.38)
        self.opacity = QDoubleSpinBox()
        self.opacity.setRange(0, 1)
        self.opacity.setSingleStep(0.05)
        self.opacity.setValue(0.45)
        for label, control in (("Spread (grid cells)", self.radius), ("Threshold", self.threshold),
                               ("Field opacity", self.opacity)):
            form.addRow(label, control)
            control.valueChanged.connect(self.update_overlay)
        self.options = {}
        display = QHBoxLayout()
        for key, label in (("fill", "Field"), ("boundary", "Boundary"), ("points", "Points")):
            checkbox = QCheckBox(label)
            checkbox.setChecked(True)
            checkbox.toggled.connect(self.update_overlay)
            self.options[key] = checkbox
            display.addWidget(checkbox)
        form.addRow(display)
        self.preview = CardPreview()
        body.addWidget(self.preview)
        hint = QLabel("Check up to eight maps to overlay. Click a row to preview it. Colors match the checked rows.")
        hint.setWordWrap(True)
        body.addWidget(hint)
        self.open_button = QPushButton("Open map")
        self.card_button = QPushButton("Map card…")
        refresh = QPushButton("Refresh")
        bar = QHBoxLayout()
        for button in (self.open_button, self.card_button, refresh):
            bar.addWidget(button)
        body.addLayout(bar)
        self.timer = QTimer(self, interval=40)
        self.timer.timeout.connect(self.poll)
        self.enabled.toggled.connect(self.toggle)
        self.search.textChanged.connect(self.filter_maps)
        self.list.currentItemChanged.connect(self.select)
        self.list.itemChanged.connect(self.check_map)
        self.list.itemDoubleClicked.connect(self.open_map)
        self.open_button.clicked.connect(self.open_map)
        self.card_button.clicked.connect(self.open_card)
        refresh.clicked.connect(self.refresh)
        self.body.hide()

    def style(self):
        return dict(radius=self.radius.value(), threshold=self.threshold.value(),
                    opacity=self.opacity.value(),
                    **{key: control.isChecked() for key, control in self.options.items()})

    def restore_style(self, style):
        for key, control in (("radius", self.radius), ("threshold", self.threshold), ("opacity", self.opacity)):
            if key in style:
                control.setValue(style[key])
        for key, control in self.options.items():
            control.setChecked(style.get(key, True))

    def visible_checks(self):
        return [key for key in self.checked if key in self.definitions]

    def update_overlay(self, *_):
        layers = []
        if self.enabled.isChecked():
            for key, color in zip(self.visible_checks(), OVERLAY_COLORS):
                footprint, _ = self.ready.get(key, (None, ""))
                if footprint is not None:
                    layers.append((footprint, color))
        self.canvas.set_saved_footprints(layers, **self.style())

    def toggle(self, on):
        self.body.setVisible(on)
        if on:
            self.refresh()
        else:
            self.generation += 1
            self.ready.clear()
            self.update_overlay()

    def refresh(self, *_):
        if not self.enabled.isChecked():
            return
        self.generation += 1
        self.ready.clear()
        try:
            definitions = Store(self.dataset.session.root).definitions()
        except (ValueError, OSError, KeyError) as exc:
            self.definitions = {}
            self.filter_maps()
            self.preview.show_card(message=str(exc))
            self.update_overlay()
            return
        self.definitions = {d["id"]: d for d in definitions if matches_view(d, self.dataset)}
        overflow = set(self.visible_checks()[len(OVERLAY_COLORS):])
        if overflow:
            self.checked = [key for key in self.checked if key not in overflow]
            for key in overflow:
                self.expectations.pop(key, None)
        self.filter_maps()
        self.update_overlay()

    def filter_maps(self, *_):
        if not self.enabled.isChecked():
            return
        self.list.blockSignals(True)
        self.list.clear()
        query = self.search.text().casefold()
        for key, definition in self.definitions.items():
            if query not in f'{definition["title"]} {definition["domain"]}'.casefold():
                continue
            item = QListWidgetItem(definition["title"])
            item.setData(Qt.ItemDataRole.UserRole, key)
            item.setCheckState(Qt.CheckState.Checked if key in self.checked else Qt.CheckState.Unchecked)
            self.list.addItem(item)
            if key == self.key:
                self.list.setCurrentItem(item)
        self.list.blockSignals(False)
        self.update_swatches()
        self.preview_selected()
        self.start_next()

    def update_swatches(self):
        colors = dict(zip(self.visible_checks(), OVERLAY_COLORS))
        self.list.blockSignals(True)
        for index in range(self.list.count()):
            item = self.list.item(index)
            color = colors.get(item.data(Qt.ItemDataRole.UserRole))
            if color:
                icon = QPixmap(12, 12)
                icon.fill(QColor(*color))
                item.setIcon(QIcon(icon))
            else:
                item.setIcon(QIcon())
        self.list.blockSignals(False)

    def check_map(self, item):
        key = item.data(Qt.ItemDataRole.UserRole)
        if item.checkState() == Qt.CheckState.Checked:
            if key not in self.checked:
                if len(self.visible_checks()) >= len(OVERLAY_COLORS):
                    item.setCheckState(Qt.CheckState.Unchecked)
                    QMessageBox.information(self, "Saved maps", "Uncheck a map before adding a ninth overlay.")
                    return
                self.checked.append(key)
        elif key in self.checked:
            self.checked.remove(key)
            self.expectations.pop(key, None)
            self.ready.pop(key, None)
        self.update_swatches()
        self.update_overlay()
        self.preview_selected()
        self.start_next()

    def select(self, item, _previous):
        self.key = item.data(Qt.ItemDataRole.UserRole) if item else None
        self.preview_selected()
        self.start_next()

    def preview_selected(self):
        item = self.list.currentItem()
        self.open_button.setEnabled(item is not None)
        self.card_button.setEnabled(item is not None)
        if item is None:
            message = "Select a saved map." if self.list.count() else "No matching local maps."
            self.preview.show_card(message=message)
            return
        definition = self.definitions[self.key]
        footprint, status = self.ready.get(self.key, (None, "Preparing footprint…"))
        self.preview.show_card(make_card(definition, footprint, status=status or "Location unavailable"))

    def start_next(self):
        if self.pending is not None or not self.enabled.isChecked():
            return
        keys = self.visible_checks()
        if self.list.currentItem() is not None and self.key not in keys:
            keys.append(self.key)
        for key in keys:
            if key not in self.ready:
                self.pending = footprints.request(self.dataset, key)
                self.pending_key = key
                self.pending_generation = self.generation
                self.timer.start()
                return

    def poll(self):
        if not self.pending.done():
            return
        future, self.pending = self.pending, None
        self.timer.stop()
        key = self.pending_key
        if self.enabled.isChecked() and self.pending_generation == self.generation and key in self.definitions:
            definition = self.definitions[key]
            footprint, status = footprint_outcome(future)
            projection, revision = self.expectations.get(key, (None, None))
            if revision and definition["revision"] != revision:
                footprint, status = None, "Snapshot map revision differs from the local map"
            elif footprint is not None and footprint.revision != definition["revision"]:
                footprint, status = None, "Stale map definition. Refresh the saved maps list."
            elif projection is not None and footprint is not None and footprint.projection != projection:
                footprint, status = None, "Snapshot projection differs from this population view"
            self.ready[key] = footprint, status
            # Keep completed previews only while checked or currently selected.
            keep = set(self.visible_checks()) | {self.key}
            self.ready = {item: result for item, result in self.ready.items() if item in keep}
            self.update_overlay()
            self.preview_selected()
        self.start_next()

    def open_map(self, *_):
        if self.list.currentItem() is not None and self.key:
            _, revision = self.expectations.get(self.key, (None, None))
            if revision and local_match(Store(self.dataset.session.root),
                                        dict(map_id=self.key, revision=revision)) is None:
                self.refresh()
                return
            self.openRequested.emit(self.key)

    def open_card(self):
        if self.key:
            CardDialog(Store(self.dataset.session.root), self.key, self.dataset, self).exec()

    def activate(self, key, projection=None, revision=None):
        self.key = key
        if key not in self.checked:
            if len(self.visible_checks()) >= len(OVERLAY_COLORS):
                QMessageBox.information(self, "Saved maps", "Uncheck a map before adding a ninth overlay.")
                return
            self.checked.append(key)
        if projection or revision:
            self.expectations[key] = (projection, revision)
        else:
            self.expectations.pop(key, None)
        self.search.clear()
        if self.enabled.isChecked():
            self.refresh()
        else:
            self.enabled.setChecked(True)
