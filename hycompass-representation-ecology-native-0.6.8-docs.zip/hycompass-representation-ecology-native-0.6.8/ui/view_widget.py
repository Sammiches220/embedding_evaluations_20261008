################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import csv
import json
from dataclasses import replace
from datetime import datetime, timezone

import numpy as np
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox, QScrollArea, QSplitter, QVBoxLayout, QWidget

##### Internal Imports #####
from model.query.engine import PointQueryEngine
from model.query.types import QueryError
from model.query.features import FeatureProvider
from model.workspace import SavedQuerySpec, ViewSpec, WorkspaceSession
from model.workspace.session import ViewData
from ui.dialogs.export import FeatureExportDialog
from ui.dialogs.library import library_id
from ui.widgets.collapsible import CollapsibleSection
from .map_widget import MapWidget
from .panels.assets import AssetBindingsPanel
from .panels.inspection import InspectionPanel
from .panels.interaction import InteractionPanel
from .panels.layer_style import LayerStylePanel
from .panels.layers import LayersPanel
from .panels.saved_maps import SavedMapsPanel
from .panels.performance import PerformancePanel
from .panels.query import PointQueryPanel
from .panels.timeline import TimelinePanel


################################################################################
# CLASSES
################################################################################
class ViewWidget(QWidget):
    reconfigureRequested = Signal(object)
    openMapRequested = Signal(str)

    def __init__(self, session: WorkspaceSession, spec: ViewSpec, runtime=None, parent=None) -> None:
        super().__init__(parent)
        self.session = session
        self.spec = spec
        self.runtime = runtime
        self.dataset: ViewData = session.build_view(spec)
        self.query_engine = PointQueryEngine(self.dataset)
        self.selected_rows = np.empty(0, np.uint32)
        self.highlight_rows = np.empty(0, np.uint32)
        self.visibility_query: dict | None = spec.visibility_query
        self.visibility_mask: np.ndarray | None = None
        self.map = MapWidget(self.dataset)
        self._build_ui()
        self._configure()
        self._wire()
        self.map.set_pick_filter(self._interaction_candidate_mask)

        self.play_timer = QTimer(self); self.play_timer.setInterval(35); self.play_timer.timeout.connect(self._play_step)
        self.stats_timer = QTimer(self); self.stats_timer.setInterval(500); self.stats_timer.timeout.connect(self._refresh_stats); self.stats_timer.start()
        self.render_timer = QTimer(self); self.render_timer.setInterval(0); self.render_timer.timeout.connect(self.map.update)
        # Timeline changes can arrive at mouse/animation frequency. Runtime state is
        # updated immediately, while SSE notification is debounced so integrations
        # receive the settled state without a high-rate event flood.
        self.timeline_event_timer = QTimer(self); self.timeline_event_timer.setSingleShot(True); self.timeline_event_timer.setInterval(180); self.timeline_event_timer.timeout.connect(lambda:self._emit_timeline_event("debounced"))
        self._timeline_changed(500)
        if self.visibility_query:
            self._apply_visibility(self.visibility_query,notify_runtime=False)

    def _build_ui(self) -> None:
        layout=QVBoxLayout(self); layout.setContentsMargins(0,0,0,0)
        splitter=QSplitter(Qt.Orientation.Horizontal); layout.addWidget(splitter)
        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setMinimumWidth(390); scroll.setMaximumWidth(520)
        side=QWidget(); scroll.setWidget(side); sl=QVBoxLayout(side); sl.setContentsMargins(10,10,10,10); sl.setSpacing(2)

        self.assets_panel=AssetBindingsPanel(self.session.manifest,self.spec)
        self.layers_panel=LayersPanel()
        self.saved_maps=SavedMapsPanel(self.dataset,self.map)
        self.interaction_panel=InteractionPanel()
        self.query_panel=PointQueryPanel(self.dataset)
        self.inspection_panel=InspectionPanel()
        self.layer_style_panel=LayerStylePanel(self.dataset)
        self.timeline_panel=TimelinePanel()
        self.performance_panel=PerformancePanel()

        # User-facing order: composition -> rendering -> interaction -> predicates
        # -> inspection/state -> detailed styles -> timeline -> performance.
        # Every section starts folded, including when a Saved View is loaded.
        # Saved Views persist data/render state, not sidebar disclosure state.
        sections=(
            ("View composition",self.assets_panel,False),
            ("Saved maps",self.saved_maps,True),
            ("Rendering",self.layers_panel,False),
            ("Interaction",self.interaction_panel,False),
            ("Point predicates",self.query_panel,False),
            ("Inspection / State",self.inspection_panel,False),
            ("Layer styles",self.layer_style_panel,False),
            ("Timeline",self.timeline_panel,False),
            ("Performance",self.performance_panel,False),
        )
        for title,panel,expanded in sections: sl.addWidget(CollapsibleSection(title,panel,expanded=expanded))
        sl.addStretch(1)
        splitter.addWidget(scroll); splitter.addWidget(self.map); splitter.setStretchFactor(1,1)

    def _configure(self) -> None:
        ds=self.dataset
        self.timeline_panel.configure(ds.has_timeline,self.spec.timeline)
        self.layers_panel.configure(ds)
        self.interaction_panel.configure(ds.spatial_index is not None)
        render_state=(self.spec.metadata or {}).get("render_state",{}) if isinstance(self.spec.metadata,dict) else {}
        self.saved_maps.key = render_state.get("saved_map")
        key = self.saved_maps.key
        self.saved_maps.checked = list(dict.fromkeys(render_state.get("saved_map_checks", [key] if key else [])))
        self.saved_maps.expectations = dict(render_state.get("saved_map_expectations", {}))
        if key and render_state.get("saved_map_revision"):
            self.saved_maps.expectations[key] = (render_state.get("saved_map_projection"),
                                                 render_state["saved_map_revision"])
        self.saved_maps.restore_style(render_state.get("saved_map_style", {}))
        self.saved_maps.enabled.setChecked(bool(render_state.get("show_saved_maps", False)))
        if "point_size" in render_state:
            self.layers_panel.point_size.setValue(float(render_state["point_size"]))
            self.map.state.point_size=float(render_state["point_size"])

    def _wire(self) -> None:
        self.assets_panel.applyRequested.connect(self.reconfigureRequested)
        self.saved_maps.openRequested.connect(self.openMapRequested)
        t=self.timeline_panel
        t.timeline.valueChanged.connect(self._timeline_changed); t.play_btn.toggled.connect(self._toggle_play)
        t.back_btn.clicked.connect(lambda:t.timeline.setValue(max(0,t.timeline.value()-10)))
        t.forward_btn.clicked.connect(lambda:t.timeline.setValue(min(1000,t.timeline.value()+10)))

        l=self.layers_panel
        for widget,name in ((l.show_active,"show_active"),(l.show_future,"show_future"),(l.show_outside,"show_outside"),(l.cluster_colors,"cluster_colors"),(l.show_coverage_field,"show_coverage_field"),(l.show_coverage_field_boundary,"show_coverage_field_boundary"),(l.show_density,"show_density"),(l.show_segmentations,"show_segmentations"),(l.segmentation_fill,"segmentation_fill")):
            widget.toggled.connect(lambda value,n=name:self._set_render_state(n,value))
        l.point_size.valueChanged.connect(lambda v:self._set_render_state("point_size",float(v)))
        l.save_btn.clicked.connect(self.map.save_png)
        self.layer_style_panel.changed.connect(self.map.update)

        q=self.query_panel
        q.applySelectionRequested.connect(self._apply_query_selection)
        q.applyVisibilityRequested.connect(self._apply_visibility)
        q.clearVisibilityRequested.connect(self._clear_visibility)
        q.saveQueryRequested.connect(self._save_query)
        q.deleteQueryRequested.connect(self._delete_query)
        q.predicateChanged.connect(self._predicate_changed)

        i=self.interaction_panel
        i.lasso_btn.toggled.connect(self._lasso_toggle); i.reset_btn.clicked.connect(self.map.reset_view)
        i.clear_selection_btn.clicked.connect(self.clear_working_selection)
        i.export_btn.clicked.connect(self._export_selection)

        p=self.performance_panel
        p.cap.toggled.connect(lambda v:self._set_render_state("cap_background",v)); p.cap_count.valueChanged.connect(lambda v:self._set_render_state("background_cap",int(v))); p.continuous.toggled.connect(self._continuous)

        self.map.pointHovered.connect(self._hover); self.map.pointClicked.connect(self._click); self.map.landmarkClicked.connect(self._landmark); self.map.lassoFinished.connect(self._lasso_done)

    def snapshot_spec(self) -> ViewSpec:
        metadata=dict(self.spec.metadata)
        metadata["camera"]=self.map.camera_state()
        metadata["render_state"]={
            **metadata.get("render_state", {}), "point_size": float(self.map.state.point_size),
            "show_saved_maps": self.saved_maps.enabled.isChecked(), "saved_map": self.saved_maps.key,
            "saved_map_checks": list(self.saved_maps.checked),
            "saved_map_expectations": dict(self.saved_maps.expectations),
            "saved_map_projection": None, "saved_map_revision": None,
            "saved_map_style": self.saved_maps.style(),
        }
        return replace(self.spec, visibility_query=self.visibility_query, metadata=metadata)

    def _set_render_state(self,name,value): setattr(self.map.state,name,value); self.map.update()

    def _timeline_changed(self,value:int)->None:
        t=value/1000.0; self.dataset.current_timeline=t; self.map.state.timeline=t; self.map.state.coverage_field_timeline=self.dataset.coverage_field_progress(t)
        if self.runtime is not None:
            self.runtime.set_timeline(self.spec.id,t,emit_event=False)
            if hasattr(self,"timeline_event_timer"):
                self.timeline_event_timer.start()
        if self.dataset.has_timeline:
            unix_time=self.dataset.timeline_unix(t); count=self.dataset.observed_count(t)
            text=(f"<b>{datetime.fromtimestamp(unix_time,timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}</b>" if unix_time is not None else f"Progress: <b>{t:.3f}</b>")
            if count is not None:text+=f"<br>Primary-selection items seen: <b>{count:,}</b>"
            self.timeline_panel.time_label.setText(text)
        self.map.update()

    def _toggle_play(self,on):
        self.timeline_panel.play_btn.setText("⏸ Pause" if on else "▶ Play")
        self.play_timer.start() if on else self.play_timer.stop()
        if not on:self._emit_timeline_event("playback_stopped")

    def _emit_timeline_event(self,cause:str="timeline") -> None:
        if self.runtime is not None:
            self.runtime.emit_timeline(self.spec.id,cause=cause)
    def _play_step(self):
        s=self.timeline_panel.timeline; v=s.value()+4
        if v>1000:self.timeline_panel.play_btn.setChecked(False)
        else:s.setValue(v)
    def _continuous(self,on): self.render_timer.start() if on and self.isVisible() else self.render_timer.stop()
    def showEvent(self,event):
        super().showEvent(event)
        if self.performance_panel.continuous.isChecked():self.render_timer.start()
    def hideEvent(self,event): self.render_timer.stop(); super().hideEvent(event)

    def _lasso_toggle(self,on):
        if on and self.dataset.spatial_index is None:self.interaction_panel.lasso_btn.setChecked(False);return
        self.map.set_mode("lasso" if on else "pan"); self.interaction_panel.lasso_btn.setText("Drawing lasso…" if on else "Lasso select")

    def _combine(self,incoming:np.ndarray)->np.ndarray:
        mode=self.interaction_panel.combine_mode.currentData(); current=self.selected_rows
        if mode=="add":return np.union1d(current,incoming).astype(np.uint32)
        if mode=="subtract":return np.setdiff1d(current,incoming).astype(np.uint32)
        if mode=="intersect":return np.intersect1d(current,incoming).astype(np.uint32)
        return np.unique(incoming).astype(np.uint32)

    def _set_working_selection(self,rows:np.ndarray,*,cause:str="ui",notify_runtime:bool=True)->None:
        self.selected_rows=np.asarray(rows,dtype=np.uint32); self.map.set_selection(self.selected_rows)
        self.query_panel.status.setText(f"Working selection: {len(self.selected_rows):,} points.")
        if notify_runtime and self.runtime is not None:self.runtime.set_working(self.spec.id,self.selected_rows,cause=cause)

    def clear_working_selection(self): self._set_working_selection(np.empty(0,np.uint32),cause="clear")
    def set_external_working_selection(self,rows): self._set_working_selection(np.asarray(rows,dtype=np.uint32),cause="api",notify_runtime=False)

    def set_highlights(self,rows,*,cause:str="ui",notify_runtime:bool=True):
        self.highlight_rows=np.asarray(rows,dtype=np.uint32); self.map.set_highlights(self.highlight_rows)
        if notify_runtime and self.runtime is not None:self.runtime.set_highlights(self.spec.id,self.highlight_rows,cause=cause)
    def set_external_highlights(self,rows): self.set_highlights(rows,cause="api",notify_runtime=False)
    def clear_highlights(self): self.set_highlights(np.empty(0,np.uint32),cause="clear")

    def _interaction_candidate_mask(self, rows: np.ndarray) -> np.ndarray:
        rows=np.asarray(rows,dtype=np.uint32)
        allowed=np.ones(len(rows),dtype=bool)
        if self.interaction_panel.restrict_visible.isChecked() and self.visibility_mask is not None:
            allowed &= np.asarray(self.visibility_mask[rows],dtype=bool)
        if self.interaction_panel.restrict_predicates.isChecked():
            try:
                matched=self.query_engine.query(self.query_panel.expression(),candidate_rows=rows)
                if len(matched)!=len(rows): allowed &= np.isin(rows,matched)
            except QueryError:
                allowed &= False
        return allowed

    def _interaction_rows(self, rows: np.ndarray) -> np.ndarray:
        rows=np.asarray(rows,dtype=np.uint32)
        return rows[self._interaction_candidate_mask(rows)]

    def _lasso_done(self,polygon):
        if self.dataset.spatial_index is None:return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            spatial=self.dataset.spatial_index.select_polygon(polygon)
            filtered=self._interaction_rows(spatial)
            self._set_working_selection(self._combine(filtered),cause="lasso")
        except QueryError as exc:self.query_panel.status.setText(str(exc))
        finally:QApplication.restoreOverrideCursor()
        self.interaction_panel.lasso_btn.setChecked(False)

    def _apply_query_selection(self,expr):
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:self._set_working_selection(self._combine(self.query_engine.query(expr)),cause="point_predicate")
        except QueryError as exc:self.query_panel.status.setText(str(exc))
        finally:QApplication.restoreOverrideCursor()

    def _apply_visibility(self,expr,notify_runtime:bool=True):
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            rows=self.query_engine.query(expr); mask=np.zeros(self.dataset.n,dtype=np.uint8); mask[rows]=1
            self.visibility_mask=mask
            self.map.set_visibility_mask(mask); self.visibility_query=expr
            self.query_panel.status.setText(f"Visibility filter: {len(rows):,}/{self.dataset.n:,} points visible.")
            if notify_runtime and self.runtime is not None:self.runtime.set_visibility(self.spec.id,expr,visible_count=len(rows),cause="point_predicate")
        except QueryError as exc:self.query_panel.status.setText(str(exc))
        finally:QApplication.restoreOverrideCursor()
    def set_external_visibility(self,mask,query=None):
        self.visibility_mask=None if mask is None else np.asarray(mask,dtype=np.uint8)
        self.map.set_visibility_mask(mask); self.visibility_query=query
    def _clear_visibility(self):
        self.visibility_mask=None; self.map.set_visibility_mask(None); self.visibility_query=None; self.query_panel.status.setText("Visibility filter cleared.")
        if self.runtime is not None:self.runtime.set_visibility(self.spec.id,None,visible_count=self.dataset.projected_count,cause="clear")

    def _predicate_changed(self,expr,source:str,metadata) -> None:
        if self.runtime is None:return
        meta=dict(metadata or {})
        self.runtime.set_predicate(
            self.spec.id,dict(expr or {"op":"all"}),source=source,
            saved_query_id=meta.get("saved_query_id"),saved_query_name=meta.get("saved_query_name"),
        )

    def _save_query(self,title:str,folder:str,expr):
        try:
            existing=next((q.id for q in self.session.manifest.saved_queries.values() if q.folder==folder and (q.title or q.id)==title and q.domain==self.spec.domain and q.projection==self.spec.projection),None)
            qid=existing or library_id("query",folder,title,set(self.session.manifest.saved_queries))
            self.session.manifest.saved_queries[qid]=SavedQuerySpec(id=qid,title=title,folder=folder,domain=self.spec.domain,projection=self.spec.projection,query=expr)
            self.session.manifest.save(); self.query_panel.status.setText(f"Saved query {folder + '/' if folder else ''}{title}.")
            if self.runtime is not None:self.runtime.workspace_changed("saved_query.changed",{"action":"saved","query_id":qid},domain=self.spec.domain,projection=self.spec.projection)
        except Exception as exc:self.query_panel.status.setText(f"Unable to save query: {exc}")

    def _delete_query(self,query_id:str):
        if self.session.manifest.delete_saved_query(query_id):
            self.session.manifest.save()
            if self.runtime is not None:self.runtime.workspace_changed("saved_query.changed",{"action":"deleted","query_id":query_id})

    def _export_features(self) -> list[tuple[str,str]]:
        out=[("Projection position (x/y)","position")]
        if self.dataset.has_timeline: out.append((f"Timeline ({self.spec.timeline})","timeline"))
        for s in self.session.manifest.compatible_selections(self.spec.domain):
            if s.kind!="all": out.append((f"Selection: {s.id}",f"selection:{s.id}"))
        for c in self.session.manifest.compatible_clusterings(self.spec.domain,self.spec.projection): out.append((f"Cluster: {c.id}",f"cluster:{c.id}"))
        for d in self.session.manifest.compatible_densities(self.spec.projection): out.append((f"Density: {d.id}",f"density:{d.id}"))
        for s in self.session.manifest.compatible_segmentations(self.spec.projection): out.append((f"Segmentation: {s.id}",f"segmentation:{s.id}"))
        for e in self.session.manifest.compatible_coverage_fields(self.spec.projection,self.spec.timeline): out.append((f"CoverageField: {e.id}",f"coverage_field:{e.id}"))
        return out

    def _export_selection(self):
        if len(self.selected_rows)==0:
            QMessageBox.information(self,"Nothing selected","Create a Working Selection before exporting."); return
        dlg=FeatureExportDialog(self._export_features(),self)
        if not dlg.exec(): return
        features=dlg.selected_features(); fmt=str(dlg.format.currentData())
        suffix="csv" if fmt=="csv" else "jsonl"
        filename,_=QFileDialog.getSaveFileName(self,"Export selected points",f"selection.{suffix}",f"{suffix.upper()} (*.{suffix})")
        if not filename:return
        provider=FeatureProvider(self.dataset); chunk=25_000
        try:
            if fmt=="jsonl":
                with open(filename,"w",encoding="utf-8") as fh:
                    for lo in range(0,len(self.selected_rows),chunk):
                        for record in provider.records(self.selected_rows[lo:lo+chunk],features): fh.write(json.dumps(record,ensure_ascii=False)+"\n")
            else:
                writer=None
                with open(filename,"w",newline="",encoding="utf-8") as fh:
                    for lo in range(0,len(self.selected_rows),chunk):
                        records=provider.records(self.selected_rows[lo:lo+chunk],features)
                        if not records: continue
                        if writer is None:
                            fieldnames=list(records[0].keys()); writer=csv.DictWriter(fh,fieldnames=fieldnames); writer.writeheader()
                        writer.writerows(records)
            self.query_panel.status.setText(f"Exported {len(self.selected_rows):,} selected points to {filename}.")
        except Exception as exc: QMessageBox.critical(self,"Export failed",f"{type(exc).__name__}: {exc}")

    def _row_text(self,row:int)->str:
        row=int(row); xy=self.dataset.positions[row]; lines=[f"Row <b>{row:,}</b>",f"item id: {self.dataset.item_id(row)}",f"x={xy[0]:.5f}, y={xy[1]:.5f}"]
        if self.spec.selection:lines.append(f"in primary selection: {'yes' if self.dataset.row_selected(row) else 'no'}")
        ts=self.dataset.row_timestamp(row)
        if self.dataset.has_timeline:
            if ts is None:lines.append("timeline timestamp: missing")
            else:
                lines.append(f"timeline timestamp: {ts} ({datetime.fromtimestamp(ts,timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')})")
                lines.append("seen at current time: "+("yes" if self.dataset.row_observed(row,self.map.state.timeline) else "no"))
        if self.dataset.cluster is not None:lines.append(f"cluster: {int(self.dataset.cluster[row])}")
        for d in self.dataset.densities:
            try: lines.append(f"density {d.spec.id}: {float(self.query_engine.field_values('density',d.spec.id,np.array([row],np.uint32))[0]):.3f}")
            except Exception:pass
        for s in self.dataset.segmentations:
            try:
                sid=int(self.query_engine.field_values('segmentation',s.spec.id,np.array([row],np.uint32))[0]); lines.append(f"segment {s.spec.id}: {sid if sid else '—'}")
            except Exception:pass
        if self.dataset.coverage_field:
            try:lines.append(f"coverage_field {self.dataset.coverage_field.spec.id}: {float(self.query_engine.field_values('coverage_field',self.dataset.coverage_field.spec.id,np.array([row],np.uint32))[0]):.3f}")
            except Exception:pass
        return "<br>".join(lines)

    def _hover(self,row):
        if row is not None:self.inspection_panel.inspect.setText(self._row_text(row))
    def _click(self,row):
        if row is None:return
        self.inspection_panel.inspect.setText("<b>Point</b><br>"+self._row_text(row))
        # Click and lasso now share WorkingSelection semantics. External/API
        # HighlightSets remain a separate channel and are never created by click.
        self._set_working_selection(self._combine(np.array([int(row)],np.uint32)),cause="click")
    def _landmark(self,landmark_id):
        if self.dataset.landmarks is None:return
        info=self.dataset.landmarks.get(landmark_id)
        if info:self.inspection_panel.inspect.setText(f"<b>Segment L{landmark_id}</b><br>population: {int(info.get('population',0)):,}<br>peak density: {float(info.get('peak_density',0)):.3f}<br>area cells: {int(info.get('area_cells',0)):,}")

    def focus_row(self,row:int): self.map.focus_row(int(row)); self.inspection_panel.inspect.setText("<b>Focused externally</b><br>"+self._row_text(int(row)))
    def fit_rows(self,rows): self.map.fit_rows(np.asarray(rows,dtype=np.uint32))

    def _refresh_stats(self):
        r=self.map.renderer
        self.inspection_panel.stats.setText(f"Domain: <b>{self.spec.domain}</b><br>Projection: <b>{self.spec.projection}</b><br>Domain points: <b>{self.dataset.n:,}</b><br>Projected points: <b>{self.dataset.projected_count:,}</b><br>Primary selection: {self.spec.selection or 'all domain'} ({self.dataset.selection_count:,} items)<br>Working selection: {len(self.selected_rows):,}<br>External/API highlights: {len(self.highlight_rows):,}<br>Timeline: {self.spec.timeline or 'none'}<br>Point coloring: {self.spec.clustering or 'none'}<br>Density layers: {len(self.dataset.densities)}<br>Segmentation layers: {len(self.dataset.segmentations)}<br>CoverageField: {self.spec.coverage_field or 'none'}<br>Theme: {self.spec.theme or 'default-dark'}<br>Active point payload: {self.dataset.point_payload_bytes/1024**2:.1f} MiB<br>Active fields: {self.dataset.field_payload_bytes/1024**2:.1f} MiB<br>GPU: {r.gl_renderer}<br>OpenGL: {r.gl_version}<br>Initial resource bind/upload: {r.upload_ms:.1f} ms<br>FPS: {r.fps:.1f}<br>CPU GL submit: {r.cpu_submit_ms:.2f} ms/frame<br>Zoom: {self.map.camera.zoom:.2f}×")


################################################################################
if __name__=="__main__":
    pass
