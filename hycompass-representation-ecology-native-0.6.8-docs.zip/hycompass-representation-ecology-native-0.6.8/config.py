################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import argparse
import os
from dataclasses import dataclass
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QSurfaceFormat
from PySide6.QtWidgets import QApplication


################################################################################
# CLASSES
################################################################################
@dataclass(frozen=True)
class AppConfig:
    workspace: Path = Path("data/workspace")
    map: str | None = None
    qpa: str = "auto"
    gl_format: str = "core33"
    vsync: int = 1
    api_host: str = "127.0.0.1"
    api_port: int | None = None


################################################################################
# FUNCTIONS
################################################################################
def parse_args(argv: list[str] | None = None) -> AppConfig:
    p=argparse.ArgumentParser(description="Latent Observer — modular embedding workspace")

    p.add_argument("--workspace",type=Path,default=Path("data/workspace")); 
    p.add_argument("--map",help="open a saved analytical map after the population tab")
    p.add_argument("--qpa",choices=("auto","wayland","xcb"),default="auto"); 
    p.add_argument("--gl-format",choices=("core33","default"),default="core33"); 
    p.add_argument("--vsync",type=int,choices=(0,1),default=1)
    p.add_argument("--api-port",type=int,help="start local REST API on this port, e.g. 8765"); 
    p.add_argument("--api-host",default="127.0.0.1",help="REST bind address; loopback is recommended")

    ns=p.parse_args(argv); 

    return AppConfig(ns.workspace,ns.map,ns.qpa,ns.gl_format,ns.vsync,ns.api_host,ns.api_port)


def configure_before_app(config:AppConfig)->None:
    # Set the QT_QPA_PLATFORM environment variable if the user specified a platform
    if config.qpa!="auto":
        os.environ["QT_QPA_PLATFORM"]=config.qpa

    # Configure the OpenGL context format and attributes before creating the QApplication instance
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_UseDesktopOpenGL,True); 
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts,True)
    fmt=QSurfaceFormat.defaultFormat(); 
    fmt.setSwapInterval(config.vsync)

    # If the user requested a specific OpenGL format, configure it accordingly
    if config.gl_format=="core33":
        fmt.setRenderableType(QSurfaceFormat.RenderableType.OpenGL); 
        fmt.setVersion(3,3); 
        fmt.setProfile(QSurfaceFormat.OpenGLContextProfile.CoreProfile)
    
    QSurfaceFormat.setDefaultFormat(fmt)


def apply_theme(app:QApplication)->None:
    app.setStyle("Fusion"); 
    app.setStyleSheet("""
    QWidget { font-size: 10pt; }
    QMainWindow,QWidget { background:#202124;color:#e8eaed; }
    QGroupBox { border:1px solid #3c4043;border-radius:5px;margin-top:10px;padding-top:8px;font-weight:600; }
    QGroupBox::title { subcontrol-origin:margin;left:8px;padding:0 4px; }
    QPushButton,QDoubleSpinBox,QSpinBox,QComboBox,QLineEdit { background:#303134;border:1px solid #5f6368;border-radius:4px;padding:5px; }
    QPushButton:checked { background:#3c6e91; }
    QScrollArea { border:0; }
    QTreeWidget,QListWidget { background:#171717; }
    """)


################################################################################
if __name__=="__main__":
    pass
