#!/usr/bin/env python3

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication, QMessageBox

##### Internal Imports #####
from api.app import start_api_server
from api.runtime import RuntimeState
from config import apply_theme, configure_before_app, parse_args
from model.workspace import WorkspaceSession
from ui.main_window import MainWindow


################################################################################
# MAIN
################################################################################
def main(argv=None):
    config=parse_args(argv);

    # Configure the application before creating the QApplication instance. 
    configure_before_app(config); 
    app=QApplication(sys.argv if argv is None else [sys.argv[0],*argv]); 
    apply_theme(app)

    # Open the workspace session. If this fails, show an error message and exit.
    try:
        session=WorkspaceSession(config.workspace)
    except Exception as exc:
        QMessageBox.critical(None,"Unable to open Latent Observer workspace",f"{type(exc).__name__}: {exc}");
        return 1

    runtime=RuntimeState()

    # Create the main window and its views. If this fails, show an error message and exit.
    try:
        window=MainWindow(session,runtime)
        if config.map: window.open_map(config.map)
    except Exception as exc:
        QMessageBox.critical(None,"Unable to create workspace views",f"{type(exc).__name__}: {exc}");
        return 1

    # Start the REST API server if requested. If the server fails to start, show a warning but continue to run the GUI.
    if config.api_port is not None:
        try:
            start_api_server(session,runtime,config.api_host,config.api_port); 
            window.statusBar().showMessage(f"REST API: http://{config.api_host}:{config.api_port}")
        except Exception as exc:
            QMessageBox.warning(window,"REST API unavailable",f"{type(exc).__name__}: {exc}")

    window.show(); 
    return app.exec()


################################################################################
if __name__=="__main__":
    raise SystemExit(main())
