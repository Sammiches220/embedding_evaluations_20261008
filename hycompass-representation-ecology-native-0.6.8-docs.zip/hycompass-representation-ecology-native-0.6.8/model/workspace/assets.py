################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


################################################################################
# CLASSES
################################################################################
@dataclass(frozen=True)
class DomainSpec:
    id: str
    version: int
    embeddings: str
    item_ids: str
    n_items: int | None = None
    dimensions: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ProjectionSpec:
    id: str
    domain: str
    positions: str
    domain_version: int | None = None
    x_order: str | None = None
    x_sorted: str | None = None
    selection: str | None = None
    world_bounds: tuple[float, float, float, float] | None = None
    method: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SelectionSpec:
    id: str
    domain: str
    domain_version: int | None = None
    kind: str = "mask"  # mask | all
    mask: str | None = None
    source: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TimelineSpec:
    id: str
    domain: str
    timestamps: str
    domain_version: int | None = None
    missing_value: int = -1
    unit: str = "unix_seconds"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ClusteringSpec:
    id: str
    domain: str
    labels: str
    domain_version: int | None = None
    projection: str | None = None
    selection: str | None = None
    method: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class DensitySpec:
    id: str
    projection: str
    field: str
    selection: str | None = None
    method: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SegmentationSpec:
    id: str
    projection: str
    labels: str
    stats: str
    density: str | None = None
    selection: str | None = None
    method: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CoverageFieldSpec:
    id: str
    projection: str
    selection: str
    frames: str
    timeline: str | None = None
    method: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SavedQuerySpec:
    """Reusable application-native point predicate stored in a folder hierarchy."""

    id: str
    domain: str
    projection: str | None = None
    query: dict[str, Any] = field(default_factory=dict)
    title: str | None = None
    folder: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ThemeSpec:
    id: str
    config: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ViewSpec:
    id: str
    title: str
    domain: str
    projection: str
    folder: str = ""
    selection: str | None = None
    timeline: str | None = None
    clustering: str | None = None
    densities: list[str] = field(default_factory=list)
    segmentations: list[str] = field(default_factory=list)
    coverage_field: str | None = None
    playback_start: int | None = None
    playback_end: int | None = None

    # Rendering is per View/LayerInstance, not part of the immutable data asset.
    density_styles: dict[str, dict[str, Any]] = field(default_factory=dict)
    segmentation_styles: dict[str, dict[str, Any]] = field(default_factory=dict)
    coverage_field_style: dict[str, Any] = field(default_factory=dict)
    overlay_style: dict[str, Any] = field(default_factory=dict)
    theme: str | None = None

    # A saved visibility predicate may be attached to a View. Working selections
    # and highlight/result sets remain ephemeral runtime state.
    visibility_query: dict[str, Any] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def clone(self, *, new_id: str, title: str | None = None) -> "ViewSpec":
        return ViewSpec(
            id=new_id,
            title=title or f"{self.title} copy",
            folder=self.folder,
            domain=self.domain,
            projection=self.projection,
            selection=self.selection,
            timeline=self.timeline,
            clustering=self.clustering,
            densities=list(self.densities),
            segmentations=list(self.segmentations),
            coverage_field=self.coverage_field,
            playback_start=self.playback_start,
            playback_end=self.playback_end,
            density_styles={k: dict(v) for k, v in self.density_styles.items()},
            segmentation_styles={k: dict(v) for k, v in self.segmentation_styles.items()},
            coverage_field_style=dict(self.coverage_field_style),
            overlay_style={k: (dict(v) if isinstance(v, dict) else v) for k, v in self.overlay_style.items()},
            theme=self.theme,
            visibility_query=(dict(self.visibility_query) if self.visibility_query else None),
            metadata=dict(self.metadata),
        )


################################################################################
if __name__=="__main__":
    pass
