"""Registration of externally-computed, file-backed workspace assets.

The application intentionally treats built-in ``build-*`` commands as optional
producers.  These helpers implement the canonical *consumer* contracts: an
external program may compute an asset however it likes and register the
finished NumPy/JSON files here.

All registered numerical assets stay aligned to an immutable Domain row space.
"""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from dataclasses import asdict
import json
import math
from pathlib import Path
import shutil
from typing import Any, Iterable

import numpy as np

##### Internal Imports #####
from .assets import (
    ClusteringSpec,
    DensitySpec,
    DomainSpec,
    CoverageFieldSpec,
    ProjectionSpec,
    SegmentationSpec,
    SelectionSpec,
    TimelineSpec,
)
from .manifest import WorkspaceManifest
from ecology.locking import mutation


################################################################################
# CLASSES
################################################################################
class RegistrationError(ValueError):
    """Raised when externally supplied data violates an asset contract."""


################################################################################
# FUNCTIONS
################################################################################
def _require_path(path: str | Path, label: str) -> Path:
    p = Path(path).expanduser().resolve()
    if not p.exists() or not p.is_file():
        raise RegistrationError(f"{label} does not exist: {p}")
    return p


def _load_npy(path: str | Path, label: str) -> tuple[Path, np.ndarray]:
    p = _require_path(path, label)
    try:
        arr = np.load(p, mmap_mode="r", allow_pickle=False)
    except Exception as exc:
        raise RegistrationError(f"unable to load {label} as a non-pickle .npy file: {exc}") from exc
    return p, arr


def _ensure_storage(storage: str) -> str:
    value = str(storage or "copy").lower()
    if value not in {"copy", "reference"}:
        raise RegistrationError("storage must be 'copy' or 'reference'")
    return value


def _metadata(value: dict[str, Any] | None) -> dict[str, Any]:
    return dict(value or {})


def _copy_array(
    source: np.ndarray,
    destination: Path,
    *,
    dtype: np.dtype | type | None = None,
    chunk_size: int = 1_000_000,
) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    out_dtype = np.dtype(dtype) if dtype is not None else source.dtype
    out = np.lib.format.open_memmap(destination, mode="w+", dtype=out_dtype, shape=source.shape)
    if source.ndim == 0:
        out[...] = np.asarray(source, dtype=out_dtype)
    else:
        chunk = max(1, int(chunk_size))
        for lo in range(0, source.shape[0], chunk):
            hi = min(source.shape[0], lo + chunk)
            out[lo:hi] = np.asarray(source[lo:hi], dtype=out_dtype)
    out.flush()
    del out


def _store_array(
    manifest: WorkspaceManifest,
    *,
    source_path: Path,
    source: np.ndarray,
    destination: Path,
    storage: str,
    dtype: np.dtype | type | None = None,
    reference_requires_dtype: np.dtype | type | None = None,
    chunk_size: int = 1_000_000,
) -> str:
    storage = _ensure_storage(storage)
    if storage == "reference":
        if reference_requires_dtype is not None and source.dtype != np.dtype(reference_requires_dtype):
            raise RegistrationError(
                f"reference storage requires dtype {np.dtype(reference_requires_dtype)}, got {source.dtype}; "
                "use storage='copy' to convert it"
            )
        return manifest.relative_or_absolute(source_path)
    _copy_array(source, destination, dtype=dtype, chunk_size=chunk_size)
    return manifest.relative_or_absolute(destination)


def _domain_size(manifest: WorkspaceManifest, domain_id: str) -> int:
    try:
        domain = manifest.domains[domain_id]
    except KeyError as exc:
        raise RegistrationError(f"unknown domain: {domain_id!r}") from exc
    if domain.n_items is not None:
        return int(domain.n_items)
    _, ids = _load_npy(manifest.resolve(domain.item_ids), f"domain {domain_id} item_ids")
    return int(len(ids))


def _selection_mask(manifest: WorkspaceManifest, selection_id: str | None, domain_id: str) -> np.ndarray | None:
    if selection_id in (None, "", "all"):
        return None
    spec = manifest.selections.get(str(selection_id))
    if spec is None:
        raise RegistrationError(f"unknown selection: {selection_id!r}")
    if spec.domain != domain_id:
        raise RegistrationError(f"selection {selection_id!r} belongs to another domain")
    if spec.kind == "all":
        return None
    _, mask = _load_npy(manifest.resolve(spec.mask), f"selection {selection_id} mask")
    return mask


def _infer_bounds(positions: np.ndarray) -> tuple[float, float, float, float]:
    finite = np.isfinite(positions).all(axis=1)
    if not np.any(finite):
        raise RegistrationError("projection contains no finite positions")
    xy = np.asarray(positions[finite], dtype=np.float32)
    xmin, xmax = float(xy[:, 0].min()), float(xy[:, 0].max())
    ymin, ymax = float(xy[:, 1].min()), float(xy[:, 1].max())
    if xmax <= xmin:
        xmin, xmax = xmin - 0.5, xmax + 0.5
    if ymax <= ymin:
        ymin, ymax = ymin - 0.5, ymax + 0.5
    return xmin, xmax, ymin, ymax


def _validate_unit_field(arr: np.ndarray, label: str, value_range: str) -> tuple[float, float]:
    if arr.dtype.kind not in "fiu":
        raise RegistrationError(f"{label} must use a real numeric dtype")
    values = np.asarray(arr)
    if not np.all(np.isfinite(values)):
        raise RegistrationError(f"{label} must contain only finite values")
    vmin = float(values.min()) if values.size else 0.0
    vmax = float(values.max()) if values.size else 0.0
    mode = str(value_range or "unit").lower()
    if mode not in {"unit", "finite"}:
        raise RegistrationError("value_range must be 'unit' or 'finite'")
    if mode == "unit" and (vmin < -1e-6 or vmax > 1.0 + 1e-6):
        raise RegistrationError(
            f"{label} is expected to be normalized to [0,1], observed range [{vmin:g}, {vmax:g}]. "
            "Use value_range='finite' only if you intentionally want raw field values."
        )
    return vmin, vmax


def _save_and_validate(manifest: WorkspaceManifest) -> None:
    manifest.save()
    # Re-open the manifest so every cross-reference is validated through the
    # same public loading path used by the GUI/API.
    WorkspaceManifest.load(manifest.root)


@mutation
def register_domain(
    manifest: WorkspaceManifest,
    *,
    asset_id: str,
    embeddings_path: str | Path,
    item_ids_path: str | Path,
    version: int = 1,
    storage: str = "reference",
    replace: bool = False,
    metadata: dict[str, Any] | None = None,
    chunk_size: int = 250_000,
) -> DomainSpec:
    """Register a completed embedding Domain.

    ``reference`` is the default because embedding matrices may be extremely
    large.  ``copy`` creates a self-contained workspace copy.
    """
    if not asset_id:
        raise RegistrationError("domain id is required")
    if asset_id in manifest.domains and not replace:
        raise RegistrationError(f"domain {asset_id!r} already exists; set replace=true")
    if asset_id in manifest.domains and replace:
        auto_all_id = f"{asset_id}-all"
        has_dependents = (
            any(p.domain == asset_id for p in manifest.projections.values())
            or any(s.domain == asset_id and not (s.id == auto_all_id and s.kind == "all") for s in manifest.selections.values())
            or any(t.domain == asset_id for t in manifest.timelines.values())
            or any(c.domain == asset_id for c in manifest.clusterings.values())
            or any(v.domain == asset_id for v in manifest.views)
        )
        if has_dependents:
            raise RegistrationError(
                f"domain {asset_id!r} already has dependent assets/views. Domain row spaces are immutable; "
                "register the new row space under a new domain ID."
            )

    emb_path, embeddings = _load_npy(embeddings_path, "embeddings")
    ids_path, item_ids = _load_npy(item_ids_path, "item_ids")
    if embeddings.ndim != 2 or embeddings.dtype.kind not in "fiu":
        raise RegistrationError("embeddings must be a real numeric [N,D] array")
    if item_ids.ndim != 1 or len(item_ids) != len(embeddings):
        raise RegistrationError("item_ids must be [N] and match embeddings")
    if item_ids.dtype.hasobject:
        raise RegistrationError("item_ids must use a non-object NumPy dtype")
    storage = _ensure_storage(storage)
    if storage == "copy":
        out_dir = manifest.root / "domains" / asset_id
        emb_dst, ids_dst = out_dir / "embeddings.npy", out_dir / "item_ids.npy"
        _copy_array(embeddings, emb_dst, chunk_size=chunk_size)
        _copy_array(item_ids, ids_dst, chunk_size=chunk_size)
        emb_ref = manifest.relative_or_absolute(emb_dst)
        ids_ref = manifest.relative_or_absolute(ids_dst)
    else:
        emb_ref = manifest.relative_or_absolute(emb_path)
        ids_ref = manifest.relative_or_absolute(ids_path)

    md = _metadata(metadata)
    md.update({"dtype": str(embeddings.dtype), "registration": "external", "storage": storage})
    spec = DomainSpec(
        id=asset_id,
        version=max(1, int(version)),
        embeddings=emb_ref,
        item_ids=ids_ref,
        n_items=int(embeddings.shape[0]),
        dimensions=int(embeddings.shape[1]),
        metadata=md,
    )
    manifest.domains[asset_id] = spec
    all_id = f"{asset_id}-all"
    manifest.selections[all_id] = SelectionSpec(
        id=all_id, domain=asset_id, domain_version=spec.version, kind="all",
        metadata={"registration": "automatic-domain-selection"},
    )
    _save_and_validate(manifest)
    return spec


@mutation
def register_selection(
    manifest: WorkspaceManifest,
    *,
    asset_id: str,
    domain_id: str,
    mask_path: str | Path,
    source: str | None = None,
    storage: str = "copy",
    replace: bool = False,
    metadata: dict[str, Any] | None = None,
    chunk_size: int = 1_000_000,
) -> SelectionSpec:
    if domain_id not in manifest.domains:
        raise RegistrationError(f"unknown domain: {domain_id!r}")
    if asset_id in manifest.selections and not replace:
        raise RegistrationError(f"selection {asset_id!r} already exists; set replace=true")
    n = _domain_size(manifest, domain_id)
    source_path, mask = _load_npy(mask_path, "selection mask")
    if mask.ndim != 1 or len(mask) != n or mask.dtype.kind not in "biu":
        raise RegistrationError(f"selection mask must be bool/integer [{n}]")
    dst = manifest.root / "assets" / "selections" / asset_id / "mask.npy"
    mask_ref = _store_array(
        manifest, source_path=source_path, source=mask, destination=dst,
        storage=storage, dtype=np.uint8, chunk_size=chunk_size,
    )
    md=_metadata(metadata); md.update({"registration":"external","storage":_ensure_storage(storage),"source_dtype":str(mask.dtype)})
    spec=SelectionSpec(
        id=asset_id,domain=domain_id,domain_version=manifest.domains[domain_id].version,
        kind="mask",mask=mask_ref,source=source,metadata=md,
    )
    manifest.selections[asset_id]=spec
    _save_and_validate(manifest)
    return spec


@mutation
def register_timeline(
    manifest: WorkspaceManifest,
    *,
    asset_id: str,
    domain_id: str,
    timestamps_path: str | Path,
    missing_value: int = -1,
    storage: str = "copy",
    replace: bool = False,
    metadata: dict[str, Any] | None = None,
    chunk_size: int = 1_000_000,
) -> TimelineSpec:
    if domain_id not in manifest.domains:
        raise RegistrationError(f"unknown domain: {domain_id!r}")
    if asset_id in manifest.timelines and not replace:
        raise RegistrationError(f"timeline {asset_id!r} already exists; set replace=true")
    n=_domain_size(manifest,domain_id)
    source_path,timestamps=_load_npy(timestamps_path,"timeline timestamps")
    if timestamps.ndim!=1 or len(timestamps)!=n or timestamps.dtype.kind not in "iu":
        raise RegistrationError(f"timeline timestamps must be integer UNIX seconds [{n}]")
    dst=manifest.root/"assets"/"timelines"/asset_id/"timestamps.npy"
    timestamps_ref=_store_array(
        manifest,source_path=source_path,source=timestamps,destination=dst,
        storage=storage,dtype=np.int64,chunk_size=chunk_size,
    )
    md=_metadata(metadata); md.update({"registration":"external","storage":_ensure_storage(storage),"source_dtype":str(timestamps.dtype)})
    spec=TimelineSpec(
        id=asset_id,domain=domain_id,domain_version=manifest.domains[domain_id].version,
        timestamps=timestamps_ref,missing_value=int(missing_value),unit="unix_seconds",metadata=md,
    )
    manifest.timelines[asset_id]=spec
    _save_and_validate(manifest)
    return spec


@mutation
def register_projection(
    manifest: WorkspaceManifest,
    *,
    asset_id: str,
    domain_id: str,
    positions_path: str | Path,
    selection_id: str | None = None,
    x_order_path: str | Path | None = None,
    x_sorted_path: str | Path | None = None,
    build_spatial_index: bool = True,
    world_bounds: Iterable[float] | None = None,
    method: str = "external",
    storage: str = "copy",
    replace: bool = False,
    metadata: dict[str, Any] | None = None,
    chunk_size: int = 1_000_000,
) -> ProjectionSpec:
    if not asset_id:
        raise RegistrationError("projection id is required")
    if domain_id not in manifest.domains:
        raise RegistrationError(f"unknown domain: {domain_id!r}")
    if asset_id in manifest.projections and not replace:
        raise RegistrationError(f"projection {asset_id!r} already exists; set replace=true")
    n = _domain_size(manifest, domain_id)
    source_path, positions = _load_npy(positions_path, "projection positions")
    if positions.ndim != 2 or positions.shape != (n, 2) or positions.dtype.kind not in "fiu":
        raise RegistrationError(f"projection positions must be real numeric [{n},2]")
    values = np.asarray(positions)
    if np.any(np.isinf(values)):
        raise RegistrationError("projection positions may use NaN for out-of-scope rows but may not contain +/-inf")
    finite_x = np.isfinite(values[:, 0]); finite_y = np.isfinite(values[:, 1])
    if np.any(finite_x != finite_y):
        raise RegistrationError("each projection row must contain either two finite coordinates or two NaNs")
    finite = finite_x & finite_y
    if not np.any(finite):
        raise RegistrationError("projection contains no finite rows")

    scope_id = None if selection_id in (None, "", "all") else str(selection_id)
    scope = _selection_mask(manifest, scope_id, domain_id)
    if scope_id is not None:
        expected = np.asarray(scope, dtype=bool)
        if not np.array_equal(finite, expected):
            missing = int(np.count_nonzero(expected & ~finite))
            extra = int(np.count_nonzero(~expected & finite))
            raise RegistrationError(
                f"subset projection finite-row mask must exactly match selection {scope_id!r}; "
                f"missing selected rows={missing:,}, projected outside selection={extra:,}"
            )

    bounds = tuple(float(x) for x in world_bounds) if world_bounds is not None else _infer_bounds(positions)
    if len(bounds) != 4 or not np.all(np.isfinite(bounds)):
        raise RegistrationError("world_bounds must contain four finite numbers: xmin xmax ymin ymax")
    if bounds[1] <= bounds[0] or bounds[3] <= bounds[2]:
        raise RegistrationError("world_bounds must have positive width and height")

    out_dir = manifest.root / "assets" / "projections" / asset_id
    positions_ref = _store_array(
        manifest,
        source_path=source_path,
        source=positions,
        destination=out_dir / "positions.npy",
        storage=storage,
        dtype=np.float32,
        reference_requires_dtype=np.float32,
        chunk_size=chunk_size,
    )

    x_order_ref = x_sorted_ref = None
    if (x_order_path is None) != (x_sorted_path is None):
        raise RegistrationError("x_order_path and x_sorted_path must be supplied together")
    if x_order_path is not None:
        order_path, x_order = _load_npy(x_order_path, "x_order")
        sorted_path, x_sorted = _load_npy(x_sorted_path, "x_sorted")
        count = int(np.count_nonzero(finite))
        if x_order.ndim != 1 or x_sorted.ndim != 1 or len(x_order) != count or len(x_sorted) != count:
            raise RegistrationError(f"spatial index arrays must both have length {count}")
        if x_order.dtype.kind not in "iu" or x_sorted.dtype.kind not in "fiu":
            raise RegistrationError("x_order must be integer and x_sorted must be numeric")
        order64 = np.asarray(x_order, dtype=np.int64)
        if np.any((order64 < 0) | (order64 >= n)) or len(np.unique(order64)) != count:
            raise RegistrationError("x_order must contain unique valid domain rows")
        expected_rows = np.flatnonzero(finite).astype(np.int64)
        if not np.array_equal(np.sort(order64), expected_rows):
            raise RegistrationError("x_order must contain exactly the finite projected domain rows")
        sorted_values = np.asarray(x_sorted, dtype=np.float32)
        if np.any(np.diff(sorted_values) < 0):
            raise RegistrationError("x_sorted must be ascending")
        expected_x = np.asarray(positions[order64, 0], dtype=np.float32)
        if not np.allclose(sorted_values, expected_x, rtol=1e-5, atol=1e-6):
            raise RegistrationError("x_sorted must equal positions[x_order,0]")
        x_order_ref = _store_array(
            manifest, source_path=order_path, source=x_order,
            destination=out_dir / "x_order.npy", storage=storage,
            dtype=np.uint32, chunk_size=chunk_size,
        )
        x_sorted_ref = _store_array(
            manifest, source_path=sorted_path, source=x_sorted,
            destination=out_dir / "x_sorted.npy", storage=storage,
            dtype=np.float32, chunk_size=chunk_size,
        )
    elif build_spatial_index:
        out_dir.mkdir(parents=True, exist_ok=True)
        rows = np.flatnonzero(finite).astype(np.uint32)
        xvals = np.asarray(positions[rows, 0], dtype=np.float32)
        order_local = np.argsort(xvals, kind="stable")
        x_order = rows[order_local].astype(np.uint32, copy=False)
        x_sorted = xvals[order_local].astype(np.float32, copy=False)
        np.save(out_dir / "x_order.npy", x_order, allow_pickle=False)
        np.save(out_dir / "x_sorted.npy", x_sorted, allow_pickle=False)
        x_order_ref = manifest.relative_or_absolute(out_dir / "x_order.npy")
        x_sorted_ref = manifest.relative_or_absolute(out_dir / "x_sorted.npy")

    md = _metadata(metadata)
    md.update({
        "registration": "external",
        "storage": _ensure_storage(storage),
        "projected_items": int(np.count_nonzero(finite)),
        "domain_items": int(n),
        "source_dtype": str(positions.dtype),
    })
    spec = ProjectionSpec(
        id=asset_id,
        domain=domain_id,
        positions=positions_ref,
        domain_version=manifest.domains[domain_id].version,
        x_order=x_order_ref,
        x_sorted=x_sorted_ref,
        selection=scope_id,
        world_bounds=bounds,
        method=str(method or "external"),
        metadata=md,
    )
    manifest.projections[asset_id] = spec
    _save_and_validate(manifest)
    return spec


@mutation
def register_clustering(
    manifest: WorkspaceManifest,
    *,
    asset_id: str,
    domain_id: str,
    labels_path: str | Path,
    projection_id: str | None = None,
    selection_id: str | None = None,
    method: str = "external",
    storage: str = "copy",
    replace: bool = False,
    metadata: dict[str, Any] | None = None,
    chunk_size: int = 1_000_000,
) -> ClusteringSpec:
    if domain_id not in manifest.domains:
        raise RegistrationError(f"unknown domain: {domain_id!r}")
    if asset_id in manifest.clusterings and not replace:
        raise RegistrationError(f"clustering {asset_id!r} already exists; set replace=true")
    if projection_id:
        p = manifest.projections.get(projection_id)
        if p is None or p.domain != domain_id:
            raise RegistrationError("clustering projection is unknown or belongs to another domain")
    if selection_id:
        _selection_mask(manifest, selection_id, domain_id)
    n = _domain_size(manifest, domain_id)
    source_path, labels = _load_npy(labels_path, "clustering labels")
    if labels.ndim != 1 or len(labels) != n or labels.dtype.kind not in "iu":
        raise RegistrationError(f"clustering labels must be integer [{n}]")
    if np.any(np.asarray(labels) < 0):
        raise RegistrationError("clustering labels must be non-negative")
    dst = manifest.root / "assets" / "clustering" / asset_id / "labels.npy"
    labels_ref = _store_array(
        manifest, source_path=source_path, source=labels, destination=dst,
        storage=storage, dtype=np.uint32, chunk_size=chunk_size,
    )
    md = _metadata(metadata)
    md.update({"registration": "external", "storage": _ensure_storage(storage), "source_dtype": str(labels.dtype)})
    spec = ClusteringSpec(
        id=asset_id, domain=domain_id, labels=labels_ref,
        domain_version=manifest.domains[domain_id].version,
        projection=projection_id, selection=selection_id,
        method=str(method or "external"), metadata=md,
    )
    manifest.clusterings[asset_id] = spec
    _save_and_validate(manifest)
    return spec


@mutation
def register_density(
    manifest: WorkspaceManifest,
    *,
    asset_id: str,
    projection_id: str,
    field_path: str | Path,
    selection_id: str | None = None,
    method: str = "external",
    storage: str = "copy",
    value_range: str = "unit",
    replace: bool = False,
    metadata: dict[str, Any] | None = None,
    chunk_size: int = 4096,
) -> DensitySpec:
    projection = manifest.projections.get(projection_id)
    if projection is None:
        raise RegistrationError(f"unknown projection: {projection_id!r}")
    if asset_id in manifest.densities and not replace:
        raise RegistrationError(f"density {asset_id!r} already exists; set replace=true")
    scope_id = None if selection_id in (None, "", "all") else str(selection_id)
    if scope_id:
        _selection_mask(manifest, scope_id, projection.domain)
    source_path, field = _load_npy(field_path, "density field")
    if field.ndim != 2 or min(field.shape) < 2:
        raise RegistrationError("density field must have shape [H,W] with both dimensions >=2")
    vmin, vmax = _validate_unit_field(field, "density field", value_range)
    dst = manifest.root / "assets" / "density" / asset_id / "density.npy"
    field_ref = _store_array(
        manifest, source_path=source_path, source=field, destination=dst,
        storage=storage, dtype=np.float32, chunk_size=chunk_size,
    )
    md = _metadata(metadata)
    md.update({
        "registration": "external", "storage": _ensure_storage(storage),
        "grid": [int(field.shape[0]), int(field.shape[1])],
        "value_min": vmin, "value_max": vmax, "value_range_contract": value_range,
        "source_dtype": str(field.dtype),
    })
    spec = DensitySpec(
        id=asset_id, projection=projection_id, field=field_ref,
        selection=scope_id, method=str(method or "external"), metadata=md,
    )
    manifest.densities[asset_id] = spec
    _save_and_validate(manifest)
    return spec


def _segmentation_stats(
    *,
    labels: np.ndarray,
    positions: np.ndarray,
    bounds: tuple[float, float, float, float],
    density: np.ndarray | None,
    selection_mask: np.ndarray | None,
    chunk_size: int,
) -> list[dict[str, Any]]:
    flat = np.asarray(labels).reshape(-1)
    positive = flat > 0
    if not np.any(positive):
        return []
    ids, area = np.unique(flat[positive].astype(np.int64), return_counts=True)
    id_to_idx = {int(v): i for i, v in enumerate(ids)}
    h, w = labels.shape
    flat_indices = np.flatnonzero(positive)
    yy = (flat_indices // w).astype(np.float64)
    xx = (flat_indices % w).astype(np.float64)
    inv = np.searchsorted(ids, flat[positive].astype(np.int64))
    sum_x = np.bincount(inv, weights=xx, minlength=len(ids))
    sum_y = np.bincount(inv, weights=yy, minlength=len(ids))
    cent_x = sum_x / np.maximum(area, 1)
    cent_y = sum_y / np.maximum(area, 1)

    peak = np.zeros(len(ids), dtype=np.float64)
    if density is not None and density.shape == labels.shape:
        peak[:] = -np.inf
        np.maximum.at(peak, inv, np.asarray(density).reshape(-1)[positive].astype(np.float64))
        peak[~np.isfinite(peak)] = 0.0

    population = np.zeros(len(ids), dtype=np.int64)
    xmin, xmax, ymin, ymax = bounds
    chunk = max(1, int(chunk_size))
    for lo in range(0, len(positions), chunk):
        hi = min(len(positions), lo + chunk)
        xy = np.asarray(positions[lo:hi], dtype=np.float32)
        valid = np.isfinite(xy).all(axis=1)
        if selection_mask is not None:
            valid &= np.asarray(selection_mask[lo:hi], dtype=bool)
        if not np.any(valid):
            continue
        block = xy[valid]
        ix = ((block[:, 0] - xmin) * (w / max(xmax - xmin, 1e-12))).astype(np.int32)
        iy = ((block[:, 1] - ymin) * (h / max(ymax - ymin, 1e-12))).astype(np.int32)
        np.clip(ix, 0, w - 1, out=ix); np.clip(iy, 0, h - 1, out=iy)
        lids = np.asarray(labels[iy, ix], dtype=np.int64)
        lids = lids[lids > 0]
        if not len(lids):
            continue
        found, counts = np.unique(lids, return_counts=True)
        for lid, count in zip(found, counts):
            idx = id_to_idx.get(int(lid))
            if idx is not None:
                population[idx] += int(count)

    cell_w = (xmax - xmin) / max(w, 1)
    cell_h = (ymax - ymin) / max(h, 1)
    cell_area = abs(cell_w * cell_h)
    out: list[dict[str, Any]] = []
    for i, lid in enumerate(ids):
        basin_area = float(area[i]) * cell_area
        scale = max(math.sqrt(max(basin_area, 0.0) / math.pi), max(abs(cell_w), abs(cell_h)))
        out.append({
            "id": int(lid),
            "name": f"Segment {int(lid)}",
            "x": float(xmin + (cent_x[i] + 0.5) * cell_w),
            "y": float(ymin + (cent_y[i] + 0.5) * cell_h),
            "population": int(population[i]),
            "peak_density": float(peak[i]),
            "area_cells": int(area[i]),
            "basin_scale": float(scale),
        })
    return out


@mutation
def register_segmentation(
    manifest: WorkspaceManifest,
    *,
    asset_id: str,
    projection_id: str,
    labels_path: str | Path,
    stats_path: str | Path | None = None,
    density_id: str | None = None,
    selection_id: str | None = None,
    method: str = "external",
    storage: str = "copy",
    replace: bool = False,
    metadata: dict[str, Any] | None = None,
    chunk_size: int = 250_000,
) -> SegmentationSpec:
    projection = manifest.projections.get(projection_id)
    if projection is None:
        raise RegistrationError(f"unknown projection: {projection_id!r}")
    if asset_id in manifest.segmentations and not replace:
        raise RegistrationError(f"segmentation {asset_id!r} already exists; set replace=true")
    scope_id = None if selection_id in (None, "", "all") else str(selection_id)
    selection_mask = _selection_mask(manifest, scope_id, projection.domain)
    density_spec = None
    density = None
    if density_id:
        density_spec = manifest.densities.get(density_id)
        if density_spec is None or density_spec.projection != projection_id:
            raise RegistrationError("segmentation density is unknown or uses another projection")
        _, density = _load_npy(manifest.resolve(density_spec.field), f"density {density_id}")

    source_path, labels = _load_npy(labels_path, "segmentation labels")
    if labels.ndim != 2 or labels.dtype.kind not in "iu" or min(labels.shape) < 2:
        raise RegistrationError("segmentation labels must be a non-negative integer [H,W] array")
    if np.any(np.asarray(labels) < 0):
        raise RegistrationError("segmentation labels must be non-negative; label 0 is reserved for background")
    if density is not None and density.shape != labels.shape:
        raise RegistrationError("associated density field and segmentation labels must have the same [H,W] shape")

    out_dir = manifest.root / "assets" / "segmentation" / asset_id
    labels_ref = _store_array(
        manifest, source_path=source_path, source=labels,
        destination=out_dir / "labels.npy", storage=storage,
        dtype=np.uint32, chunk_size=max(1, chunk_size),
    )

    if stats_path is not None:
        stats_source = _require_path(stats_path, "segmentation stats")
        try:
            stats = json.loads(stats_source.read_text())
        except Exception as exc:
            raise RegistrationError(f"unable to parse segmentation stats JSON: {exc}") from exc
        if not isinstance(stats, list) or any(not isinstance(x, dict) or "id" not in x for x in stats):
            raise RegistrationError("segmentation stats must be a JSON list of objects containing at least 'id'")
        # Fill optional visualization fields from generic geometry and add any
        # raster labels omitted by the external stats file. Supplied names and
        # custom metadata always win.
        ids_seen=[int(x["id"]) for x in stats]
        if any(i <= 0 for i in ids_seen) or len(set(ids_seen)) != len(ids_seen):
            raise RegistrationError("segmentation stats ids must be unique positive integers")
        raster_ids=set(int(x) for x in np.unique(labels) if int(x)>0)
        extra_ids=set(ids_seen)-raster_ids
        if extra_ids:
            raise RegistrationError(f"segmentation stats contain ids not present in labels: {sorted(extra_ids)[:8]}")
        need_fill = (set(ids_seen) != raster_ids) or any(
            any(k not in x for k in ("x", "y", "population", "peak_density", "area_cells", "basin_scale"))
            for x in stats
        )
        if need_fill:
            positions = np.load(manifest.resolve(projection.positions), mmap_mode="r", allow_pickle=False)
            bounds = projection.world_bounds or _infer_bounds(positions)
            derived_list = _segmentation_stats(
                labels=labels, positions=positions, bounds=tuple(map(float, bounds)), density=density,
                selection_mask=selection_mask, chunk_size=chunk_size,
            )
            derived = {int(x["id"]): x for x in derived_list}
            supplied = {int(x["id"]): dict(x) for x in stats}
            merged=[]
            for lid in sorted(raster_ids):
                e=dict(derived.get(lid, {"id":lid,"name":f"Segment {lid}"}))
                e.update(supplied.get(lid, {}))
                merged.append(e)
            stats=merged
    else:
        positions = np.load(manifest.resolve(projection.positions), mmap_mode="r", allow_pickle=False)
        bounds = projection.world_bounds or _infer_bounds(positions)
        stats = _segmentation_stats(
            labels=labels, positions=positions, bounds=tuple(map(float, bounds)), density=density,
            selection_mask=selection_mask, chunk_size=chunk_size,
        )

    stats_dst = out_dir / "stats.json"
    stats_dst.parent.mkdir(parents=True, exist_ok=True)
    stats_dst.write_text(json.dumps(stats, indent=2) + "\n")
    stats_ref = manifest.relative_or_absolute(stats_dst)
    md = _metadata(metadata)
    md.update({
        "registration": "external", "storage": _ensure_storage(storage),
        "grid": [int(labels.shape[0]), int(labels.shape[1])],
        "segments": int(len(stats)), "source_dtype": str(labels.dtype),
    })
    spec = SegmentationSpec(
        id=asset_id, projection=projection_id, labels=labels_ref, stats=stats_ref,
        density=density_id, selection=scope_id,
        method=str(method or "external"), metadata=md,
    )
    manifest.segmentations[asset_id] = spec
    _save_and_validate(manifest)
    return spec


@mutation
def register_coverage_field(
    manifest: WorkspaceManifest,
    *,
    asset_id: str,
    projection_id: str,
    selection_id: str,
    frames_path: str | Path,
    timeline_id: str | None = None,
    timeline_start: int | None = None,
    timeline_end: int | None = None,
    method: str = "external",
    storage: str = "copy",
    value_range: str = "unit",
    replace: bool = False,
    metadata: dict[str, Any] | None = None,
    chunk_size: int = 64,
) -> CoverageFieldSpec:
    projection = manifest.projections.get(projection_id)
    if projection is None:
        raise RegistrationError(f"unknown projection: {projection_id!r}")
    if asset_id in manifest.coverage_fields and not replace:
        raise RegistrationError(f"coverage_field {asset_id!r} already exists; set replace=true")
    selection = manifest.selections.get(selection_id)
    if selection is None or selection.domain != projection.domain:
        raise RegistrationError("coverage_field requires a selection belonging to the projection domain")
    timeline = None
    if timeline_id:
        timeline = manifest.timelines.get(timeline_id)
        if timeline is None or timeline.domain != projection.domain:
            raise RegistrationError("coverage_field timeline is unknown or belongs to another domain")

    source_path, frames = _load_npy(frames_path, "coverage_field field/frames")
    if frames.ndim not in {2, 3} or frames.dtype.kind not in "fiu":
        raise RegistrationError("coverage_field must be numeric [H,W] or [T,H,W]")
    if frames.ndim == 2:
        shape = (1, *frames.shape)
    else:
        shape = frames.shape
    if min(shape[-2:]) < 2:
        raise RegistrationError("coverage_field raster dimensions must both be >=2")
    if timeline is None and shape[0] != 1:
        raise RegistrationError("multi-frame coverage_field requires a timeline; static coverage_field must contain one frame")
    if timeline is not None and shape[0] < 1:
        raise RegistrationError("temporal coverage_field requires at least one frame")
    vmin, vmax = _validate_unit_field(frames, "coverage_field field", value_range)

    if timeline is not None and (timeline_start is None or timeline_end is None):
        _, timestamps = _load_npy(manifest.resolve(timeline.timestamps), f"timeline {timeline.id}")
        valid = np.asarray(timestamps) != int(timeline.missing_value)
        if np.any(valid):
            inferred_start = int(np.min(np.asarray(timestamps)[valid]))
            inferred_end = int(np.max(np.asarray(timestamps)[valid]))
        else:
            inferred_start, inferred_end = 0, 1
        timeline_start = inferred_start if timeline_start is None else int(timeline_start)
        timeline_end = inferred_end if timeline_end is None else int(timeline_end)
    if timeline is not None:
        timeline_start = int(timeline_start)
        timeline_end = int(timeline_end)
        if timeline_end <= timeline_start:
            raise RegistrationError("timeline_end must be greater than timeline_start")

    out_dir = manifest.root / "assets" / "coverage_field" / asset_id
    # Preserve a compact float16 representation in copy mode, matching built-in
    # coverage_field assets. Reference mode may use any numeric floating dtype.
    frames_ref = _store_array(
        manifest, source_path=source_path, source=frames,
        destination=out_dir / "frames.npy", storage=storage,
        dtype=np.float16, chunk_size=max(1, chunk_size),
    )
    md = _metadata(metadata)
    md.update({
        "registration": "external", "storage": _ensure_storage(storage),
        "temporal": bool(timeline is not None), "frames": int(shape[0]),
        "grid": [int(shape[-2]), int(shape[-1])],
        "timeline_start": timeline_start, "timeline_end": timeline_end,
        "value_min": vmin, "value_max": vmax, "value_range_contract": value_range,
        "source_dtype": str(frames.dtype),
    })
    spec = CoverageFieldSpec(
        id=asset_id, projection=projection_id, selection=selection_id,
        frames=frames_ref, timeline=timeline_id,
        method=str(method or "external"), metadata=md,
    )
    manifest.coverage_fields[asset_id] = spec
    _save_and_validate(manifest)
    return spec


def spec_dict(spec: Any) -> dict[str, Any]:
    """JSON-safe dataclass representation used by CLI/API responses."""
    return asdict(spec)


################################################################################
if __name__=="__main__":
    pass
