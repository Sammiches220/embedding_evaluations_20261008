# REST API

The REST API documentation has two layers:

1. these hand-written pages explain behavioral contracts and usage patterns;
2. the **Reference** section is generated from the FastAPI OpenAPI schema during the same MkDocs build.

No request or response schema is maintained here manually. The Python API models and route metadata remain the source of truth.

## Generated reference

Open **REST API → Reference** in the navigation. It contains one page per operation and one page per reusable OpenAPI schema.

!!! tip "Improving the generated reference"
    Add descriptions and validation constraints to request/response models, and add `summary`, `description`, and `tags` to FastAPI routes. Rebuilding the docs automatically carries those changes into the API reference.

## Build flow

```text
FastAPI routes + typed models
             |
             v
      export_openapi.py
             |
             v
 docs_src/openapi/openapi.json
             |
             v
       mkdocs-openapi
             |
             v
 same Material/MkDocs site
```

---

## PointQuery and FeatureProvider languages

HyCompass exposes two small application-native languages for point-oriented automation:

- **PointQuery** is a JSON predicate language evaluated by `PointQueryEngine`.
- **FeatureProvider feature names** select the values returned for resolved/query-matched rows.

These languages are shared by GUI and REST workflows. They remain ordinary JSON objects and strings; the refactor described here reorganizes their Python implementation without changing the accepted inputs, evaluation semantics, error behavior, or output record shape.

---

## Recommended integration flow

A typical external producer/consumer workflow is:

```text
1. Initialize workspace
2. Register Domain
3. Register Selection(s)
4. Register Timeline(s)
5. Register externally computed Projection(s)
6. Register Clustering/Density/Segmentation/CoverageField assets
7. Discover compatible features with /features/catalog
8. Query points with /query or /query/features
9. Enrich/rank externally
10. Send ordered identities back as a ResultSet
11. Highlight/focus/fit items in a runtime View when desired
```

Example conceptual flow:

```text
external data source
        │
        ├── embeddings.npy
        ├── item_ids.npy
        ├── selection masks
        └── timestamps
        │
        ▼
external analytics
        ├── UMAP
        ├── HDBSCAN
        ├── custom KDE
        └── custom coverage_field
        │
        ▼
Latent Observer asset registration
        │
        ▼
PointQuery / native features
        │
        ▼
external enrichment / ranking
        │
        ▼
ResultSet / highlight / focus
```

---

## Important compatibility rules

1. **Domain row order is canonical.** Never reorder a domain-aligned asset independently.
2. **Domain row spaces are immutable once depended upon.** Register changed populations under a new Domain/version.
3. **Selections and Timelines are independent.**
4. **Projection subset membership is represented by `NaN,NaN` outside the declared Selection.**
5. **Density/Segmentation/CoverageField rasters use Projection `world_bounds`.**
6. **Clustering labels must be non-negative.**
7. **Segmentation label `0` is background.**
8. **Normalized scalar fields `[0,1]` are strongly preferred.**
9. **Temporal CoverageField must reference a Timeline on the same Domain.**
10. **Externally referenced files must be visible to the Latent Observer process.**
11. **Use explicit asset IDs in PointQuery and feature requests.**
12. **WorkingSelection, HighlightSet, and ordered ResultSets have different semantics.**
13. **Rows are the most efficient identity for repeated high-volume API round-trips; stable item IDs are the portable identity between systems.**