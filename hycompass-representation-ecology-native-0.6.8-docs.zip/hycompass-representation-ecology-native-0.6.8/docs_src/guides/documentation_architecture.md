# Documentation Architecture

## Goal

Keep Python code as the source of truth while producing two different generated
documentation surfaces:

1. a REST API reference from FastAPI/Pydantic/OpenAPI; and
2. a Python/developer reference from Google-style docstrings.

A third, smaller code-backed contract layer is used for information that JSON
Schema does not describe well, such as NumPy dtype/shape and cross-file row
alignment.

## Source-of-truth mapping

| Information | Canonical source | Generated output |
| --- | --- | --- |
| Request/response fields and constraints | `api/schemas/*.py` | OpenAPI, Swagger UI, ReDoc |
| Endpoint behavior | Route docstrings | OpenAPI descriptions + Python docs |
| Internal Python APIs | Google-style docstrings | mkdocstrings HTML |
| NumPy/file semantics | `api/contracts/*.py` | `/assets/contracts` + prose docs |
| Tutorials/design notes | Markdown | MkDocs HTML |

The important rule is that request/response schemas are **not** copied into
Markdown or YAML by hand.

## Proposed API layout

```text
api/
├── __init__.py
├── app.py                 # FastAPI application factory
├── server.py              # Uvicorn/thread startup only
├── dependencies.py        # obtain session/runtime from app.state
├── services.py            # thin HTTP-to-project adapters
├── runtime.py             # keep the existing project implementation
│
├── routers/
│   ├── system.py
│   ├── query.py
│   ├── views.py
│   ├── assets.py
│   ├── saved.py
│   └── events.py
│
├── schemas/
│   ├── base.py
│   ├── common.py
│   ├── system.py
│   ├── query.py
│   ├── views.py
│   ├── assets.py
│   ├── saved.py
│   └── events.py
│
└── contracts/
    └── assets.py
```

### Why this separation exists

`routers/` describes HTTP operations. `schemas/` describes JSON contracts and is
therefore what gives FastAPI enough information to generate useful OpenAPI.
`services.py` adapts those HTTP models to the existing project logic without
moving domain behavior into the API package.

`contracts/` is intentionally separate. A rule such as `float32 [N,2] .npy`
with NaN and row-alignment semantics does not belong in a JSON request schema.

## Docstrings

Use Google-style docstrings for behavior, rationale, side effects, and
exceptions. Put machine-enforceable wire constraints in Pydantic fields.

For route functions, a form-feed can separate the concise OpenAPI description
from longer Python-only sections:

```python
def query_points(payload: QueryRequest) -> QueryResponse:
    """Query points in the selected context.

    This paragraph is useful in the REST reference.

    \f
    Args:
        payload: Query request.

    Returns:
        Matching rows and item identifiers.
    """
```

FastAPI stops its operation description at the form-feed, while Python
documentation tools can still inspect the full docstring.

## Generated artifacts

The intended generated artifacts are:

```text
docs_generated/generated/openapi.json   # machine-readable contract
docs_generated/generated/openapi.html   # static ReDoc wrapper
site/                         # complete MkDocs HTML build
```

`openapi.json` may be committed if API diffs are useful during review. It should
never be edited manually.

## Migration strategy

Convert endpoints incrementally. Replacing a single `payload: dict` with a
Pydantic request model immediately improves validation and OpenAPI for that
endpoint; the rest of the API can remain unchanged until converted.

## Illustrated representation ecology guides

The [Representation Ecology guide](representation_ecology/index.md) and its seven topic chapters live in `docs_src/guides/representation_ecology/`. Their entries are registered under **Guides → Representation Ecology** in `scripts/docs/mkdocs.yml`. Screenshots are copied into `docs_src/img/representation_ecology/`, preserving their versioned `docs_merge` filenames. They are ordinary static assets, so the generated documentation has no dependency on an external image host or the source-only `docs_merge` directory.

Rebuild from the project root:

```bash
python -m pip install -r requirements.txt -r requirements-docs.txt
bash scripts/docs/build_docs.sh
```

Open `docs_generated/site/index.html`, then **Guides → Representation Ecology**. The build also refreshes the Markdown context manifest, making these chapters available to the Markdown context generator. When updating screenshots, preserve alt text, brief reading captions and the distinction between historical layouts and current controls.
