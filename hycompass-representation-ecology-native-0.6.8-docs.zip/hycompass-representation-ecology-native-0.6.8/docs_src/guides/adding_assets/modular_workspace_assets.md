# Modular Workspace Assets

See [Data Concepts Core Concepts](../../data_contracts/core_concepts.md) for more technical details


## Independent reusable assets

- **Selection** — membership only.
- **Timeline** — domain-scoped UNIX timestamps.
- **Projection** — subset-local projections keep row alignment and use `NaN` outside scope.
- **Clustering** — domain-row category labels.
- **Density** — scalar projected field, optionally Selection-scoped.
- **Segmentation** — categorical projected field + region stats.
- **CoverageField** — scalar or temporal, tied to a Projection + Selection and optional Timeline.
- **SavedQuery** — reusable application-native PointQuery plus hierarchical folder.
- **Theme** — user-defined rendering/UI defaults.

Selections never imply time. Timelines never imply membership.

## Computation method versus display style

Assets describe *what was computed*. A View describes *how an asset is shown*.

Current producer families:

```text
Projection:   passthrough | ipca | random | tsne | umap
Density:      gaussian | adaptive-gaussian | histogram
CoverageField:  box-blur | gaussian | distance
Clustering:   supplied | minibatch-kmeans | birch
Segmentation: watershed | connected-components
```

Density/CoverageField methods normalize to scalar raster contracts; Segmentation methods normalize to integer labels + region stats. This lets rendering and PointQuery sampling remain independent from the producer algorithm.

View opacity scales the entire layer (field + contours), and the normalized maximum is not treated as a contour plateau.

## View composition and library

A View references assets rather than copying them:

```text
View
├── Domain + Projection
├── optional primary Selection
├── zero/one Timeline
├── zero/one point-color Clustering
├── zero/many Density layers + styles
├── zero/many Segmentation layers + styles
├── zero/one CoverageField + style
├── WorkingSelection/Highlight overlay style
├── optional Theme
├── optional saved VisibilityQuery
└── camera/playback metadata
```

Saved Views carry `folder` paths and form a lightweight hierarchical preset library. Opening a preset creates/reuses a tab; presets are not all automatically rendered at startup.

Views over the same assets reuse NumPy mmaps and shared same-process OpenGL resources. Hidden tabs do not continuously repaint; detached visible views still incur their own draw work.

## Runtime interaction state

Persistent domain semantics are separate from temporary GUI/API state:

- **WorkingSelection** — currently selected rows.
- **VisibilityFilter** — rows currently allowed to draw.
- **HighlightSet** — externally/API-emphasized rows.
- **ExternalResultSet** — ordered externally supplied rows + optional opaque metadata.

WorkingSelection and HighlightSet have independent per-View rendering styles.

## PointQuery as a common predicate layer

The same query engine is shared by:

```text
whole-domain Select matches
Show only / Hide matches
lasso eligibility
click eligibility
headless /query
external adapters
```

Predicate families include Selection membership, multi-ID Clustering/Segmentation, Density threshold/percentile, CoverageField inside/outside/value, Timeline state, projected state, and rows. v0.5.4 allows several clustering/segmentation/density/coverage_field assets to participate in the same composed query, both in the GUI and REST API.

Click/lasso eligibility optionally respect both the active PointQuery and VisibilityFilter. Candidate rows are filtered before nearest-point selection.

See [Interaction and Point Queries](../interaction_and_point_queries.md).

## Timeline semantics

Canonical Timeline values remain UNIX seconds. A View has at most one active Timeline/current time. A normalized GPU buffer is a runtime cache relative to the View playback interval.

A temporal CoverageField asset records the absolute UNIX interval used to build its frames, allowing a View to use a narrower playback window without changing frame semantics.

## Dependency / invalidation model

```text
Domain -> Projection -> Density -> Segmentation
   |          |
   |          +-------------------- CoverageField
   |                               /
   +-> Selection -----------------+
   +-> Timeline ------------------+
   +-> Clustering
```

Updating observation timestamps does not invalidate Projection/Density/Segmentation. Updating a Selection may invalidate Selection-scoped density/coverage_field. File-backed Selection/Timeline replacement through the REST interface invalidates runtime mmap/timeline caches, and explicit workspace reload rebuilds active GUI Views while preserving ephemeral interaction state where possible.

## Workspace format 3

HyCompass uses manifest format `3` to persist hierarchical Saved View/Query folders and overlay styles. Older v1/v2 manifests are migrated with compatible defaults when loaded.

## View-independent query context

A View remains the GUI composition unit, but it is no longer a restriction on headless analysis. The REST data plane can construct an ephemeral context from `domain + projection + optional timeline` and query/sample every compatible asset. GUI-control commands (focus/highlights/camera) still require a concrete runtime View.

## External-system boundary

HyCompass owns app-native geometry/context only. Arbitrary Hydrus metadata, ratings, model scores, and ranking logic remain external. The REST API exposes item identities/features and accepts ordered ResultSets/highlights/focus commands in return.

See [REST API Overview](../../api/index.md).


## Producers are optional

The asset catalog is deliberately producer-agnostic. A `ProjectionSpec` does not require `TSNEProjection`, UMAP, or any other in-project class to have created its coordinates; likewise Density, Segmentation, CoverageField, and Clustering specs only require files that satisfy their contracts. HyCompass exposes this directly through CLI and REST registration.

This lets heavy/offline/research pipelines remain separate while Views, PointQuery, rendering, and adapters consume the same standardized file-backed assets. 

## Runtime synchronization layer

HyCompass keeps runtime interaction state separate from the persistent workspace manifest. `RuntimeState` owns temporary Working Selections, Point Predicate state, Visibility filters, Timeline progress, highlights, focus, ResultSets, active View state, and per-family revisions.

External consumers should use:

```text
GET /events       -> lightweight SSE notification
GET /state        -> cheap global revision snapshot
GET /views/{id}/state
                   -> cheap per-View revision/count snapshot
normal REST       -> bulk rows/features only when needed
```

The event system never makes Working Selection membership part of the workspace manifest. Runtime revisions and SSE event IDs are process-local synchronization tokens. See [Event Stream](../../api/events.md).
