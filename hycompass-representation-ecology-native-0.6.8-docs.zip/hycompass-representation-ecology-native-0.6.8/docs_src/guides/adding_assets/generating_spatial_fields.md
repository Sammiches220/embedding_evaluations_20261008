# Generating Spatial Fields

## Purpose

A spatial field converts information associated with projected points into an **image-like scalar function over the projection**.

The guiding question is:

> **How can point-level information be turned into a spatial field that describes the visible map?**

Unlike a segmentation, a field does not divide the map into region identities. Each raster cell instead stores a value: density, proximity, coverage, accumulated observation, or some other spatial quantity.

Conceptually:

```text
projected positions [N,2]
        +
optional selection / weights / timeline
        ↓
aligned raster grid
        ↓
accumulate point evidence
        ↓
spread / regularize the evidence
        ↓
normalize according to field semantics
        ↓
static field [H,W]
or temporal field [T,H,W]
```

The most important design decision is therefore not simply *how to smooth the points*, but **what quantity the resulting field is intended to mean**.

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/01_projected_points.png"
    alt="Projected point distribution."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 1. A projected point distribution provides the geometry on which a spatial field is defined.*

---

## 1. Rasterize the projected evidence

Field generation begins by mapping projected point positions into an aligned raster.

The simplest operation is accumulation: each point contributes evidence to the cell containing its position. Depending on the field, that contribution may be:

- one unit of occupancy;
- a point-specific weight;
- membership in a selected subset;
- an event associated with a time value.

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/02_raw_occupancy.png"
    alt="Raw raster occupancy."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 2. Rasterization converts irregular point locations into an image-like representation.*

The raster resolution determines **where values can vary**, but it does not by itself determine the field's effective spatial scale. Resolution and smoothing should be treated as separate choices.

---

## 2. Choose what the field should represent

Different field constructions answer different spatial questions.

### Histogram / occupancy field

A histogram field preserves the most literal interpretation:

> **How much point mass falls into each local part of the map?**

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/03_histogram_field.png"
    alt="Histogram field."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 3. A histogram field closely reflects cell occupancy. It preserves local detail but can be noisy and sensitive to grid resolution.*

This is useful when exact local accumulation matters or when later processing will perform its own smoothing.

### Fixed-scale kernel field

Local point evidence can be spread into neighboring cells using a fixed kernel, such as a Gaussian.

This asks:

> **How much point mass exists near this location at a chosen observation scale?**

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/04_gaussian_field.png"
    alt="Fixed-scale Gaussian field."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 4. Fixed-scale smoothing suppresses cell noise and turns occupancy into a continuous-looking spatial density.*

A smaller kernel preserves local structure; a larger kernel emphasizes broad geography. The tradeoff is that one global scale may be inappropriate when some parts of the map are extremely dense and others are sparse.

### Adaptive field

The effective smoothing scale can instead vary with local structure. Dense regions may preserve more detail while sparse regions borrow information from a wider neighborhood.

This asks:

> **What spatial mass is visible when the observation scale adapts to local sampling density?**

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/05_adaptive_field.png"
    alt="Adaptive multi-scale field."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 5. Adaptive smoothing can retain detail in dense areas while stabilizing sparse areas.*

Adaptive fields are useful when the projection contains large differences in local sampling density, but their values are less literal than a raw histogram because the observation scale itself varies spatially.

### Distance / proximity field

A field does not have to measure mass. It can instead measure proximity to evidence.

For example:

> **How close is this location to the nearest observed or selected point?**

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/06_proximity_field.png"
    alt="Distance/proximity field."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 6. A proximity field spreads influence according to distance rather than accumulated local mass.*

This is often more appropriate for coverage, reachability, familiarity, or "known versus unknown" interpretations than ordinary density.

---

## 3. Generate fields from subsets

A field may describe the complete projected population or only a selected subset.

The important distinction is that the **projection provides the coordinate system**, while the selection determines which points contribute evidence.

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/07_selected_subset.png"
    alt="Selected subset."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 7. A subset of the projected population can contribute to a field without changing the underlying projection.*

The selected points can then be rasterized and propagated using the same family of field constructions.

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/08_selection_field.png"
    alt="Selection-restricted field."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 8. A selection-restricted field answers where the selected population is spatially concentrated or influential.*

This makes fields useful as overlays: several fields may share the same projection while representing different populations or different notions of spatial evidence.

---

## 4. Generate temporal fields

If contributing points also have timestamps, field generation can be extended from a static raster to a sequence of frames.

Conceptually:

```text
positions + timestamps
        ↓
assign events to time
        ↓
accumulate spatial evidence through time
        ↓
apply the chosen spatial propagation
        ↓
frames [T,H,W]
```

The frames may represent independent time windows or a cumulative state. For navigation and coverage_field, a cumulative interpretation is often useful because the field shows how coverage grows as more of the population becomes observed.

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/09_temporal_early.png"
    alt="Early temporal field."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 9. Early in the timeline, only part of the projected geography contributes.*

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/10_temporal_middle.png"
    alt="Middle temporal field."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 10. Additional spatial structure becomes covered as more events are included.*

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/11_temporal_late.png"
    alt="Late temporal field."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 11. A later cumulative field approaches the coverage of the complete contributing population.*

The timeline determines **when** evidence enters the field; it should not implicitly change which points belong to a selection.

---

## 5. Separate raster resolution from observation scale

Two fields can describe the same quantity while using different raster resolutions.

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/12_coarse_resolution.png"
    alt="Coarse raster resolution."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 12. A coarse raster stores fewer spatial samples and emphasizes broad structure.*

<div style="text-align: center;">
  <img
    src="../../img/field_visual_examples/13_fine_resolution.png"
    alt="Fine raster resolution."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 13. A fine raster can preserve more local variation, provided the field construction supports that detail.*

Increasing resolution does not automatically make the field more informative. A very fine raster with insufficient smoothing may only expose sampling noise, while excessive smoothing can erase detail even on a high-resolution grid.

It is useful to think of the controls separately:

```text
raster resolution
    → how finely the field can vary

smoothing / propagation scale
    → how far each point influences nearby space
```

---

## 6. Normalize according to meaning

After accumulation and propagation, field values may span an inconvenient dynamic range.

Common transformations include:

- **log compression** to prevent dense peaks from dominating;
- **percentile scaling** to reduce sensitivity to extreme outliers;
- **bounded normalization** when the consumer expects a standard display range;
- preserving **raw counts or distances** when absolute values themselves matter.

Normalization should be treated as part of the field's contract. A normalized display field should not silently be interpreted later as raw population density.

---

## 7. Choose the approach from the question

A useful rule is to begin with the spatial question rather than the algorithm.

```text
"How much is here?"
    → histogram / density field

"How much is nearby at this scale?"
    → fixed-kernel field

"How can dense and sparse areas be shown at useful local scales?"
    → adaptive field

"How far is this location from known evidence?"
    → distance / proximity field

"Where is this selected population represented?"
    → selection-restricted field

"How does spatial coverage develop over time?"
    → temporal field
```

Several fields may coexist over the same projection because they encode different scalar questions rather than competing partitions of the map.

---

## 8. Validate the field

A generated field should be checked according to its intended semantics.

Useful checks include:

- **Alignment** — raster coordinates correspond exactly to the projection.
- **Coverage** — contributing points appear where expected.
- **Scale** — smoothing is neither dominated by point noise nor so broad that meaningful geography disappears.
- **Stability** — modest changes in grid resolution do not completely change the important structures.
- **Subset correctness** — excluded points do not contribute to selection-restricted fields.
- **Temporal correctness** — frames respect timestamp ordering and missing-time semantics.
- **Interpretability** — the stored values have a clear meaning after normalization.

The final question is therefore:

> **What scalar quantity should be defined over the projected geography, and what accumulation and propagation rule best expresses that quantity?**

That framing keeps field generation distinct from projection, clustering, and segmentation while allowing all of them to use the same spatial coordinate system.
