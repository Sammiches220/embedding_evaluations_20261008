# Extending Built-In Methods


> **You do not need to implement these Python protocols to use a new algorithm.** The protocol examples are only for adding an in-project producer. If an external process already emits the completed asset, HyCompass can register it directly; see [External Assets](./registering_external_assets.md).

The project intentionally keeps heavy computation implementations behind small contracts. HyCompass deliberately ships several contrasting implementations so the contracts are visible in practice rather than theoretical.

## 1. Example ProjectionMethod: Gaussian random projection

The protocol is defined in `model/projection/base.py`:

```python
class ProjectionMethod(Protocol):
    name: str

    def project(self, source, output_path, *, chunk_size): ...
    def metadata(self) -> dict: ...
```

`model/projection/random_projection.py` implements `GaussianRandomProjection`. It creates a seeded `[D,2]` Gaussian matrix and transforms the source in chunks into an on-disk `float32 [N,2]` array. It is intended primarily as a compact extension example and fast baseline—not as a claim that random projection is the best semantic 2-D visualization.

Adding the projection into a workspace:

```bash
python scripts/workspace_tool.py --workspace data/example_workspace build-projection \
  --id random-demo \
  --domain domain \
  --method random \
  --random-projection-seed 7
```

A new projection implementation should produce row-aligned `[N,2]` positions (or the subset-local `NaN` convention used by the workspace builder), return method metadata, and then be registered in the preparation/tool method factory/CLI choice.

Existing implementations provide additional examples:

```text
PassthroughProjection
IncrementalPCAProjection
GaussianRandomProjection
TSNEProjection
UMAPProjection
```

### Real t-SNE example

`model/projection/tsne_projection.py` implements standard scikit-learn t-SNE behind the same `ProjectionMethod` protocol. It is intentionally **in-memory** and therefore suited to smaller/subset-local exploratory projections, not the multi-million-item out-of-core default.

```bash
python scripts/workspace_tool.py --workspace data/example_workspace build-projection \
  --id local-tsne \
  --domain domain \
  --selection interesting-subset \
  --method tsne \
  --tsne-perplexity 30 \
  --tsne-max-iter 750
```

This is a useful example of why Projection is first-class: t-SNE can coexist beside a global PCA projection rather than replacing it.


## 2. Example ClusteringMethod: BIRCH

`model/clustering/birch.py` implements a second genuine clustering technique behind the same clustering asset contract used by MiniBatchKMeans and supplied labels.

```bash
python scripts/workspace_tool.py --workspace data/example_workspace build-clustering \
  --id birch-demo \
  --domain domain \
  --method birch \
  --clusters 32 \
  --birch-threshold 0.7
```

The resulting asset is still just domain-row categorical labels, so point coloring, PointQuery predicates, feature export, and REST access do not need BIRCH-specific code.

## 3. Example user themes

Bundled JSON examples:

```text
themes/example-ocean.json
themes/example-paper.json
themes/example-high-contrast.json
```

Theme files can override any subset of the default configuration; missing values fall back to the built-in default. Common keys include:

```json
{
  "canvas": {"background": [0.02, 0.03, 0.05, 1.0]},
  "points": {
    "active": [1.0, 0.8, 0.3, 0.9],
    "future": [0.5, 0.6, 0.7, 0.2],
    "outside": [0.4, 0.4, 0.4, 0.1]
  },
  "working_selection": [0.2, 0.85, 1.0, 0.95],
  "highlight": [1.0, 0.25, 0.55, 1.0],
  "lasso": [0.7, 0.9, 1.0, 0.95],
  "segmentation": {
    "boundary": [1.0, 1.0, 1.0, 0.75],
    "label": [1.0, 1.0, 1.0, 0.95],
    "label_outline": [0.0, 0.0, 0.0, 0.85]
  },
  "density_palette": [[0.0,0.0,0.1],[0.0,0.3,0.5],[0.1,0.7,0.5],[1.0,0.8,0.3]],
  "coverage_field_palette": [[0.1,0.0,0.3],[0.1,0.4,0.5],[0.2,0.7,0.4],[0.9,0.9,0.2]],
  "ui": {"stylesheet": ""}
}
```

Register a custom theme:

```bash
python scripts/workspace_tool.py --workspace data/example_workspace add-theme \
  --id my-theme \
  --config /path/to/my-theme.json
```

`prepare.py` automatically registers the bundled `example-*.json` themes unless `--no-example-themes` is supplied.

Per-View Layer Styles still override relevant theme defaults, allowing a theme to define global visual defaults while an individual View changes a particular density, segmentation, WorkingSelection, or Highlight style.

## 4. Other modular computation families

The same design principle already applies to:

```text
Density:      gaussian | adaptive-gaussian | histogram
CoverageField:  box-blur | gaussian | distance
Segmentation: watershed | connected-components
```

These families deliberately normalize their outputs to stable asset contracts:

- Density / CoverageField → scalar raster (`[H,W]` or `[T,H,W]` for temporal coverage_field).
- Segmentation → integer region raster + stats.

That keeps rendering/query code independent of the particular producer and makes additional algorithms possible without introducing a new visualization contract for every method.
