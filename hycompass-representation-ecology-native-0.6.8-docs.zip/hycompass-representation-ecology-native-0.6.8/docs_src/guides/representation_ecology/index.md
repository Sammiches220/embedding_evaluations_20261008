# Representation ecology: illustrated guide

Representation ecology helps you investigate **what an embedding preserves, what changes locally, and which features can be reconstructed from it**. Start with the population, freeze an interesting set of items as a map, then inspect saved evidence without losing your population view.

This guide follows the native workflow in the supplied 0.6.8 project. Screenshots come from the project's `docs_merge` examples (0.2–0.6.1); older layouts illustrate the same concepts, while toolbar placement and available results can differ. Their versioned filenames are preserved. Images are bundled with the docs and work offline.

[![Native map with field guide, observer and linked evidence](../../img/representation_ecology/native-guide-0.3.png)](../../img/representation_ecology/native-guide-0.3.png)

*Field guide (0.3): the map and evidence panels show the same here/ahead attention regions. Select the image for full size.*
## Choose a part of the workflow

| Guide | What you will learn |
|---|---|
| [Population and saved maps](maps.md) | Define a stable question, find its footprint in the population, and keep or link items. |
| [Observer and local geometry](geometry.md) | Navigate here/ahead, read profiles, compare neighborhood shapes and inspect graph support. |
| [Features and source audits](features.md) | Follow typed values, distinguish membership from sampled support, and inspect source diagnostics. |
| [Reconstruction and prediction evidence](reconstruction.md) | Read held-out broad/local accounts, dimensional curves, standard metrics and saved variants. |
| [Compute, load and storage](compute.md) | Use resource actions, broad checklists, budgets and explicit job feedback. |
| [Compare representations and results](comparisons.md) | Compare matched identities, paired losses and frozen-reference evaluations. |
| [Cards, reports and portable packages](sharing.md) | Export a PNG overview, an illustrated HTML report or a reopenable `.hcmap`. |

## Try the included demo

From the extracted project root:

```bash
python -m pip install -r requirements.txt
python main.py --workspace demo_workspace --map shared-base
```

Use Python 3.10+ and a desktop OpenGL 3.3 context for population views. The analytical viewer uses native Qt and bounded CPU-rendered charts. The demo's `shared-base` map has **288 frozen members**, with detailed geometry on **144 anchors**; full-membership feature summaries and anchor measurements therefore have different support.

1. Open **shared-base** and start with **What shape is this?**.
2. Place the observer; compare the yellow **here** and coral **ahead** regions.
3. Follow a feature with **What changes here?**, then inspect **Will it predict here?**.
4. If evidence is unavailable, use that screen's explicit compute/load controls.
5. Keep an interesting set, or return to the independent population tab.

## Keep these distinctions in view

| Term | Meaning |
|---|---|
| Population | The independent large-scale browser and its registered domain/projection. |
| Map membership | Frozen canonical identities defining the analytical question. |
| Anchors / context | Sampled evaluation locations / candidate neighbors used by an instrument. |
| Here / ahead | Moving attention regions in the displayed projection, not guaranteed source-vector neighborhoods. |
| Kept items | An explicit selection, separate from moving attention and frozen membership. |
| Saved / loaded | Results on disk / results currently resident in the viewer. |

Read support counts, units and missingness with every chart. Projected proximity, source-space geometry, descriptive association and held-out prediction answer different questions; there is no combined quality score. For the surrounding platform, see [Architecture](../architecture.md) and [Interaction and Point Queries](../interaction_and_point_queries.md).
