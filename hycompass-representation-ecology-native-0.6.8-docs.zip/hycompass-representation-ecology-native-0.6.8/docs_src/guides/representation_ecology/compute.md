# Compute, load and storage

Computation produces persistent evidence; loading makes saved evidence available in the current viewer. Display actions do not silently fit models or scan source vectors. A missing panel should lead to a concrete resource action and availability reason.

## Use the screen's resource action

Each screen offers **Compute missing + load this screen** and a saved-only load action. The compact toolbar follows the active screen: source audits request `source_support`, while full-membership plots request `feature_distribution`. Open **Compute / storage** for resource-by-resource control.

[![Compact resource toolbar above the evidence area](../../img/representation_ecology/compact-toolbar-0.5.2.png)](../../img/representation_ecology/compact-toolbar-0.5.2.png)

*Resource toolbar (0.5.2): compute prerequisites or load saved results for the current screen. Select the image for full size.*
## Select broadly with checklists

Use **All applicable**, **Prediction + population** or **Geometry + audits** to select resource families. Target presets include all, numeric, Boolean/category, current and none. Target/dimension/account checkboxes coordinate what you browse. Computation still generates each configured resource family rather than promising individual-cell fitting.

[![Checklists and presets for targets dimensions accounts and resources](../../img/representation_ecology/group-batch-0.6.1.png)](../../img/representation_ecology/group-batch-0.6.1.png)

*Checklists & presets (0.6.1): select a broad batch and run one explicit compute/load action. Select the image for full size.*
**Compute checked · continue errors** attempts independent families even when one fails, retaining completed artifacts and reporting failures. Cancellation is cooperative at bounded checkpoints. Complete reconstruction batches can be reused after interruption.

**Load checked** gives active/comparison groups priority within **Viewer RAM** (64 MiB–1 GiB). Omitted groups are reported as saved but not resident; increase the budget and load again if needed. Changing this budget does not change analysis budgets.

[![Compute and storage resource checklist with action controls](../../img/representation_ecology/resource-checklist-0.5.1.png)](../../img/representation_ecology/resource-checklist-0.5.1.png)

*Compute / storage (0.5.1): saved/loading state and explicit actions stay separate from the chart. Select the image for full size.*
## Read cost and state correctly

| State or estimate | Meaning |
|---|---|
| Missing / unavailable | Evidence is absent, or a required source/scope is unsupported; inspect the reason. |
| Queued / running | A requested job is waiting or executing. |
| Saved / unloaded | Results exist but are not resident in this viewer. |
| Loaded / measured | Saved evidence is available for browsing. |
| Partial / failed / cancelled | Inspect completed families and concrete failure/cancellation feedback. |
| Already saved; zero NEW compute | Numerical work can be reused; loading/checksum I/O still costs time. |

The cost preview describes question/anchor/context sizes, structural work, RAM/output bounds, source payload and column scans. Big-O estimates are not calibrated wall-clock promises. Full-membership source summaries can scan substantial columns even when geometry uses few anchors. Large analytical throughput needs measurements on representative data/hardware.

Unloading does not delete results. Deletion is explicit and dependency-aware; preview it in the manager. Closing unused tabs reduces total residency. One heavy worker per workspace/process serializes jobs, with a writer lock coordinating cooperating processes.

## Headless equivalents

From the project root:

```bash
python -m ecology.cli --workspace demo_workspace plan shared-base --instruments source_support feature_distribution
python -m ecology.cli --workspace demo_workspace generate shared-base --instruments source_support feature_distribution --continue-on-error
python -m ecology.cli --workspace demo_workspace inspect shared-base
```

REST clients use `/ecology/maps/{key}/plan`, `/jobs` and `/ecology/jobs/{job_id}`; see the [REST API overview](../../api/index.md). A job snapshot is authoritative; events signal changes. A source being absent can prevent new computation while saved results remain browsable. Changed available sources can instead mark dependent results stale.

Next: [Export saved evidence](sharing.md).
