# Cards, reports and portable packages

Choose the deliverable according to what someone needs to do: recognize a map, read its findings offline, or reopen its saved interactive evidence. Exports summarize saved work; they do not automatically generate missing analyses.

## Map card and PNG

Choose **Map card…** in the population sidebar or map manager. **Edit card note** saves the question, motivation or context. The compact in-app profile shows a points-and-field thumbnail, identity, projection and membership count. Open the exact population projection to supply a manager thumbnail.

**Export card (PNG)…** creates one shareable image with thumbnail, profile, coverage counts and up to three selected highlights. The GUI profile and exported PNG serve different reading sizes.

## Illustrated HTML report

**Export report (HTML)…** creates a self-contained page with footprint preview, coverage, result inventory, selected findings, charts, interpretations and provenance. The available saved results determine which charts appear: examples include spectra, neighborhood radius/dimension distributions, graph connectivity, perturbation/compression, source distributions and held-out reconstruction curves.

Use **Broad overview** for a spread across result families/targets; narrower presets focus distributions, model evaluation or geometry/support. Family/search filters and individual checkboxes refine the selection. Filtering keeps hidden checked items selected.

The **Feature representation and reconstruction** explorer appears when saved per-feature evidence exists and is included by default. Search/filter features, sort by observed coverage, and choose metric/account/evaluation scope for exact values, support and curves. It includes all available feature evidence independently of the highlight checklist. Static chapters avoid repeating charts owned by the explorer; disabling it retains the relevant static charts. Descriptive associations stay separate from held-out model evidence.

!!! note "Report screenshots"

    The supplied `docs_merge` images do not show the newer PNG card or 0.6.8 HTML feature explorer. Their behavior is described here; the screenshot below illustrates the separate interactive viewer reopened from saved evidence.

## Lightweight imported cards

**Export JSON…** creates a bounded versioned card snapshot. In another project, use **Open map… → Imported cards… → Import card JSON…**. A card is readable without local data. Opening its map requires an exact local map ID/revision; showing it in population requires the matching domain/projection and any recorded projection provenance. A JSON card is not an interactive result package.

## Reopen saved evidence with `.hcmap`

[![Native analytical viewer showing saved portable map evidence](../../img/representation_ecology/map-portable-view.png)](../../img/representation_ecology/map-portable-view.png)

*Portable viewing workflow: reopen saved analytical evidence without recomputing it. Select the image for full size.*
| Profile | What it includes |
|---|---|
| `definition` | Definition, membership, identities/correspondences and source declarations. |
| `viewing` | Definition, complete saved results and self-contained view support. |
| `embeddings` | Definition plus available embeddings, coordinates and groups. |
| `targets` | Definition plus typed values, validity, codebooks and groups. |
| `full` | Selected map/reference closure, available sources and saved results. |

```bash
python -m ecology.cli --workspace demo_workspace export shared-base reference.hcmap --profile viewing
python -m ecology.cli import-package reference.hcmap relocated_workspace
python main.py --workspace relocated_workspace --map shared-base
```

Import creates a **new workspace directory** and refuses an existing destination. Viewing packages support saved browsing without original vectors/target columns; a definition-only package has no landscape until geometry exists. Attach an exact compatible package to add declared missing layers. Changed data requires a separately registered revision/new map.

Packages preserve source identity and ordering, verify checksums and declared dependencies, and cover the selected map/reference closure. They are not whole-workspace backups of unrelated population densities, segmentations, themes or saved views.

Return to the [illustrated guide overview](index.md).
