# Features and source audits

Use **What changes here?** to follow a typed feature and **What doesn't fit?** to inspect supported signed feature-to-geometry residuals. A descriptive association can suggest a pattern; held-out reconstruction provides separate evidence about prediction.

## Follow values with their type

The searchable **Follow feature** picker selects numeric, Boolean or categorical targets. Numeric values retain their units; Boolean values retain their bounded scale; categories use named colors with no artificial numeric height. Unknown values remain distinct from zero, false or category zero.

[![Categorical feature on a map with discrete colors](../../img/representation_ecology/navigation-category-0.6.0.png)](../../img/representation_ecology/navigation-category-0.6.0.png)

*Categorical navigation (0.6.0): named classes are groups, not ordered magnitudes. Select the image for full size.*

[![Boolean feature displayed in prediction evidence](../../img/representation_ecology/navigation-flag-0.6.0.png)](../../img/representation_ecology/navigation-flag-0.6.0.png)

*Boolean navigation (0.6.0): retain knownness and the target kind when interpreting values. Select the image for full size.*
## Feature audit

The audit separates summary/prediction evidence, distributions and associations. Start with known/missing counts, then read numeric moments/ranges/histograms or Boolean/category counts. Click a feature row to follow it on the map. Editable JSON category names/colors can be reloaded without refitting.

[![Feature audit distributions beside the analytical map](../../img/representation_ecology/native-feature-audit-0.2.png)](../../img/representation_ecology/native-feature-audit-0.2.png)

*Feature distributions (0.2): compare observed values and missingness before interpreting relationships. Select the image for full size.*
**Full membership**, inside Prediction evidence, displays saved histograms/counts for every frozen member with known values. It requires `feature_distribution`. Local distributions and measured-anchor associations describe different supports; neither silently becomes a full-population estimate.

[![Saved full membership histograms in the prediction evidence tabs](../../img/representation_ecology/group-population-0.6.1.png)](../../img/representation_ecology/group-population-0.6.1.png)

*Full membership (0.6.1): distributions cover the frozen map, including members outside prediction anchors. Select the image for full size.*
## Source audits

**Source audits** shows norm histograms, covariance energy/participation ratio, neighbor occurrence counts and exact duplicate-group sizes. Two plots at a time keep the view readable. Use **Prepare / load audit** or the screen resource action to generate/load `source_support` explicitly.

[![Visual source audit with norm histogram and cumulative spectrum](../../img/representation_ecology/group-audits-0.6.1.png)](../../img/representation_ecology/group-audits-0.6.1.png)

*Source audits (0.6.1): diagnose source support separately from feature prediction quality. Select the image for full size.*
These audits cover at most **8,192 resolved context rows × 512 embedding dimensions**. They report sampled non-finite/near-zero exclusions. Duplicate equality is exact source-coordinate or individually normalized equality, not near-duplicate similarity; neighbor counts describe the saved anchor-to-context search. These are scoped diagnostics, not an exhaustive corpus diagnosis.

## Register source columns

Use the project's workspace tooling to register domains/projections, then the ecology CLI for collections, domain correspondence and typed features. Arrays align to canonical collection rows; validity is explicit.

```bash
python -m ecology.cli --workspace YOUR_WORKSPACE register-feature score items --kind numeric --values arrays/score.npy --valid arrays/score_valid.npy
```

The analytical configuration currently supports at most **16 active features** and **64 category codes**. The report's searchable feature browser does not remove those computation limits. Treat registered sources as immutable; explicitly re-register changes rather than relying on a viewer refresh.

Next: [Read held-out prediction evidence](reconstruction.md).
