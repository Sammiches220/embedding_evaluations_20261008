# Observer and local geometry

Use **What shape is this?** to follow geometry, stability or compression. The map locates measurements; the evidence panels explain them. A high or bright area is meaningful only with its selected measurement, units and support.

## Move attention through the map

Click the map for keyboard focus. **WASD** moves; **← / →** turns; **↑ / ↓** changes look distance. Right-click places the observer in 2D. Wheel zooms. The mouse-tool selector offers Navigate, Pan and Lasso; middle-drag pans in either 2D or 3D. Camera motion and observer position are independent.

[![Analytical terrain in three dimensions with local evidence](../../img/representation_ecology/native-map-3d.png)](../../img/representation_ecology/native-map-3d.png)

*3D relief: height emphasizes the active field; it is not a new source embedding dimension. Select the image for full size.*
Yellow marks **here**, coral marks **ahead**, and the corridor shows the observation footprint. These regions are projected attention windows. Source-neighbor instruments use actual vectors and their declared bounded contexts.

## Here → ahead

Three linked lanes show geometry, observed feature and explanation residuals. Their spread bands show local interquartile ranges, **not confidence intervals**. Missing support and graph boundaries break traces. Boolean/category profiles show shares rather than averaging category codes.

[![Here to ahead profiles linked to the map observer](../../img/representation_ecology/native-field-guide-0.2.png)](../../img/representation_ecology/native-field-guide-0.2.png)

*Here/ahead profiles (0.2 layout): read change together with the spread of local values. Select the image for full size.*
## Geometry in context

**Compact groups** summarizes available measurements in four cards. Click a small profile to map it. **Profiles & endpoints** exposes line readings with here/ahead medians; **Values & deltas** provides exact values and support.

[![Four compact groups of geometry profiles](../../img/representation_ecology/native-compact-groups-0.4.png)](../../img/representation_ecology/native-compact-groups-0.4.png)

*Compact geometry groups (0.4): compare complementary measurements without combining them into a score. Select the image for full size.*
Neighborhood radius describes local spacing; covariance dimension describes how variance is distributed across directions. Projection-neighbor loss asks whether the displayed projection preserves source neighbors. Stress and compression readings test different kinds of change. Their scales are not interchangeable.

## Shapes & spectra

Read each row as a neighborhood: **here** above **ahead**. Columns show the complete local variance spectrum, the local PCA-3 hull/cloud and neighbor direction ribbons. Covariance dimensions appear below. A spectrum concentrated in a few directions suggests lower local effective dimension; the PCA-3 view can hide variance outside those three directions.

[![Paired neighborhood spectra, PCA three dimensional clouds and direction ribbons](../../img/representation_ecology/native-anatomy-0.4.2.png)](../../img/representation_ecology/native-anatomy-0.4.2.png)

*Shapes & spectra (0.4.2): compare the same kinds of evidence across here and ahead. Select the image for full size.*
Direction ribbons are one polyline per neighbor in local PCA coordinates. They are not uncertainty bands or globally aligned trajectories. Degenerate neighborhoods can have no meaningful hull.

## Filtration, stability and routes

The filtration slider thresholds source distances on the frozen mutual candidate graph. Its label reports chord distance, components and eligible edges. **Keep connected extent** keeps the measured component nearest the observer. This is candidate-graph H0 connectivity, not full-corpus topology or higher-order persistent homology.

Perturbation and reference subsampling test neighbor stability. Route/fragility results describe saved bounded graph experiments; a full interactive endpoint/route atlas is not provided. Missing instruments remain unavailable until explicitly computed. Use **Expand evidence** or the splitters for more room.

Next: [Follow features](features.md) or [inspect reconstruction](reconstruction.md).
