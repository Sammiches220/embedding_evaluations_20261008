# Population and saved maps

A map is a frozen analytical question over canonical items. It records membership, embeddings, context and analysis settings. Moving the observer, changing visibility or selecting a chart does not redefine it.

## Define and reopen a map

Select items in the population with picking, lasso or query tools, then choose **Explore selection**. An empty working selection means the full domain. Check the scope and budgets before generating evidence. Open **Open map…** to search saved maps and reopen their interactive tabs.

[![Saved map manager with map list and lifecycle actions](../../img/representation_ecology/map-manager.png)](../../img/representation_ecology/map-manager.png)

*Map manager: open, rename, duplicate, package and inspect saved definitions. Select the image for full size.*
Renaming changes metadata while retaining results. Duplicating creates a new identity without copying results; generation can reuse compatible numerical work. **Browse saved results** opens saved target/module/scope/metric navigation without fitting anything.

## Show maps in the population

In a population view, enable **Saved maps → Show Saved maps layer**. The list contains only maps for that exact domain and projection. Check up to eight maps to overlay their frozen membership. Select a row for its profile; **Open map** or a double-click opens its interactive viewer.

Adjust **Spread**, **Threshold** and **Field opacity**; toggle **Field**, **Boundary** and **Points** independently. The overlay is a cached 256 × 256 footprint, computed off the UI thread. Pan/zoom draws its raster rather than rescanning membership each frame. A thumbnail shows the map's own points and field. Maps using a different projection or map-local PCA remain available through the manager.

!!! note "Screenshot coverage"

    The bundled screenshots predate the Saved maps population sidebar. The controls above describe 0.6.8; the images on this page show the manager and analytical viewer rather than that newer sidebar.

## Keep items and link them back

Click a point to keep it; Shift-click adds/removes. **Keep here**, **Keep ahead**, **Keep connected extent** and **Feature query** offer bulk alternatives. **Explore kept** creates a new frozen question; it does not replace the original membership.

[![Two dimensional analytical map with linked lower evidence](../../img/representation_ecology/native-map-2d.png)](../../img/representation_ecology/native-map-2d.png)

*Analytical 2D map: inspect a local area while the population remains available in its own tab. Select the image for full size.*
With **Link to all open population windows** enabled, selection actions update highlights in compatible population windows. **Link now** reapplies the link and reports correspondence coverage. **Export kept** includes the complete kept membership, including members absent from the current projected sample. **Save view** retains camera, observer and kept state separately from the definition.

Next: [Navigate and read local geometry](geometry.md), or [compute the required resources](compute.md).
