# Compare representations and results

Comparisons should preserve the item question and disclose differences in coverage, embedding, context and evaluation protocol. A similar-looking pair of projected maps alone does not establish equivalent source geometry or predictive content.

## Compare maps on canonical identities

Use the map comparison workflow to inspect two native maps and matched numerical evidence. Shared display bounds aid reading, while each map retains coordinate provenance and missing-support reporting. The included demo has partially overlapping embeddings with shuffled rows, so matching must use canonical IDs rather than row position.

[![Two analytical maps side by side with a numerical comparison table](../../img/representation_ecology/native-comparison.png)](../../img/representation_ecology/native-comparison.png)

*Map comparison: inspect both landscapes and the declared matched support. Select the image for full size.*
The same embedding can also be compared across different saved memberships. For a deliberately matched experiment, the `controlled-pair` CLI command resolves shared eligible identities. Review the frozen definitions and contexts before interpreting changes.

```bash
python -m ecology.cli --workspace demo_workspace compare shared-base shared-distorted --instrument geometry
```

## Compare prediction losses

In **Error** view, choose comparison B. The field shows **loss A − loss B**: positive values mean B has lower loss. Means use the exact paired canonical intersection. Revisions, units, codebooks, collection and evaluation assignments must match; changed contexts are disclosed. Do not compare two separately averaged losses as if their support were paired.

[![Diverging signed loss comparison on the analytical map](../../img/representation_ecology/navigation-comparison-0.6.0.png)](../../img/representation_ecology/navigation-comparison-0.6.0.png)

*Paired comparison (0.6.0): a diverging scale shows where one saved variant loses more than the other. Select the image for full size.*
## Reuse a frozen reference

A reference-evaluation map reuses saved transforms and models on a new selection without refitting. It requires compatible domain/feature revisions. This asks whether an existing account transfers to the new question; it is different from training a fresh local account there. Transfer tables expose losses and support separately.

## Find the exact saved result

**Open map… → Browse saved results** lists component variants, targets, scopes and metrics. Selection resolves existing artifacts and never starts fitting. Completed reconstruction checkpoints can appear before a final combined reconstruction is available.

[![Saved component result browser with resource families and status](../../img/representation_ecology/map-result-browser.png)](../../img/representation_ecology/map-result-browser.png)

*Saved result browser: distinguish available artifacts, missing prerequisites and partial work. Select the image for full size.*
External producer predictions retain their producer identity, explicit scope and provenance. Producer aggregate metrics remain unverified. Matching registered truth can support local loss scoring, but external comparisons remain restricted; they are not silently merged into verified built-in held-out curves.

Next: [Share a comparison's evidence](sharing.md) or [review prediction support](reconstruction.md).
