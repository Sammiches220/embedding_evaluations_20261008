# Reconstruction and prediction evidence

**Will it predict here?** asks how well a feature can be reconstructed from retained embedding directions. Choose a target, retained-direction count and saved account. Broad and regional models use a fixed group-held-out protocol with training-only transforms; baseline readings provide a reference for loss.

## What survives scale?

The curves compare broad/local errors across retained dimensions. Read numeric MAE and Boolean/category Brier losses in their own units. Local gain compares matched losses and can be negative. The accompanying tabs expose exact values, validation-selected accounts, transfer losses and support.

[![Saved broad account selected with distribution and exact values](../../img/representation_ecology/navigation-broad-0.6.0.png)](../../img/representation_ecology/navigation-broad-0.6.0.png)

*Saved prediction variant (0.6.0): target, account, dimension and scope identify the reading. Select the image for full size.*
Increasing retained directions is an experimental axis, not a promise of improvement. Missing source values, partial identity coverage and held-out support affect which observations contribute.

## Browse groups before individual cases

Open **Prediction evidence**. Use **Checklists & presets → Load checked** to admit selected saved targets/dimensions. **Across targets** shows curves two targets per page; each point carries support and can select its saved variant. Account checkboxes filter the displayed curves.

[![Across targets held out curves with two feature panels](../../img/representation_ecology/group-targets-0.6.1.png)](../../img/representation_ecology/group-targets-0.6.1.png)

*Across targets (0.6.1): compare dimensions/accounts within each feature, preserving separate target units. Select the image for full size.*
| Subtab | Use it for |
|---|---|
| Distribution | The active measurement across supported observations in the displayed subset. |
| Subset visuals | Spatial hexagons and cumulative distribution, or named class groups. |
| Across targets | Saved aggregate curves for checked targets, dimensions and accounts. |
| Full membership | Source distributions over frozen membership, rather than sampled predictions. |
| Cases & keep | A bounded case list with checkboxes and bulk kept-set presets. |
| Classification | Labelled confusion counts and per-class statistics. |
| Source audits | Norm, covariance, neighbor-occurrence and duplicate diagnostics. |
| Availability | Saved, loaded and unavailable states for target × variant. |
| Checklists & presets | Bulk target/resource selection, computation, loading and viewer RAM. |

[![Whole subset spatial and cumulative measurement summaries](../../img/representation_ecology/group-subset-0.6.1.png)](../../img/representation_ecology/group-subset-0.6.1.png)

*Subset visuals (0.6.1): see the measured subset beyond the bounded case table. Select the image for full size.*
Choose all measured anchors, here, ahead or kept to filter observation-level views. Across-target curves keep their saved evaluation support; moving the observer does not turn them into newly estimated regional curves. No chart infers predictions for unmeasured members.

## Standard metrics and residuals

**Feature audit → Regression probes / Classification probes** exposes held-out metrics and raw counts. Numeric targets use MAE, RMSE, R² and a training-mean baseline. Classification exposes accuracy, balanced accuracy, observed-class macro F1, AUC where defined, log loss and the declared Brier convention. Generate **Held-out probe metrics** if needed; saved reconstruction models are replayed rather than refitted.

[![Held out regression metrics by target and account](../../img/representation_ecology/native-regression-probes-0.3.png)](../../img/representation_ecology/native-regression-probes-0.3.png)

*Regression probes (0.3): inspect standard metrics separately, alongside their support. Select the image for full size.*

[![Classification metric table for saved accounts](../../img/representation_ecology/native-classification-probes-0.3.png)](../../img/representation_ecology/native-classification-probes-0.3.png)

*Classification probes (0.3): undefined metrics remain unavailable. Select the image for full size.*
Numeric **Error** is absolute error; signed residual fields are a separate display. Boolean/category decoders use clipped/normalized linear Ridge outputs, not calibrated logistic models. Keep this in mind when interpreting probabilities.

Bulk kept-set presets can select all supported observations, all measured anchors, the active measurement's largest absolute 10%, or the union of worst-loss fractions per checked variant. Raw target units are never pooled into one ranking score. The case list displays at most 50 rows; the bulk presets act on their declared complete support.

Next: [Compare accounts and representations](comparisons.md), or [compute/load evidence](compute.md).
