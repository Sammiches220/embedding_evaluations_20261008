# Booru Atlas — Research Findings and Technical Reconstruction

**Project:** Booru Atlas  
**Observed URL:** https://booruatlas.b-cdn.net/  
**Research date:** August 2026

## Executive Summary

Booru Atlas appears to be a recent interactive project for exploring Danbooru artists in a learned visual-semantic space.

The most important finding is that the project is **not merely a map of Danbooru tags**. A creator announcement reposted from the NovelAI Discord states that the original version represented artists using an image vision model described as **“sigclip” / SigLIP**, applied to **24 artwork samples per artist**.

The project then exposes several ways to navigate artists:

- visual similarity based on artwork;
- semantic/content similarity based on Danbooru tags;
- a combined representation;
- nearest-neighbor search in the original high-dimensional space;
- a t-SNE projection for human visualization;
- directional searches such as **“like this artist, but more/less of concept X.”**

The current site reports roughly **24,402 artists**, while the apparent launch announcement described roughly **10,000 artists**, indicating either rapid expansion or loose rounding in the original post.

No public GitHub, GitLab, Codeberg, or other source repository for Booru Atlas itself was found during the investigation. However, a highly relevant open-source antecedent exists: **SmilingWolf’s Danbooru2022 Embeddings Playground**, which implements shared image/tag embeddings, positive/negative embedding arithmetic, cosine similarity, and FAISS search. Its architecture is strikingly similar to machinery required by Booru Atlas.

---

# 1. What Booru Atlas Is

Booru Atlas is an interactive map of Danbooru artists intended to organize artists according to similarity.

The site describes its primary visual representation as placing artists according to:

> how they draw — measured from their actual artwork, not their tags.

This makes the project closer to an **artist latent-space browser** than a conventional tag browser.

The application currently reports approximately:

- **24,402 artists**
- artists selected from Danbooru
- a minimum-post threshold of roughly **200 posts per artist**
- **10 soft regions**
- a reported clustering silhouette score around **0.083**

The site warns that the regions should be interpreted as a continuum rather than rigid categories.

---

# 2. Strongest Provenance Lead

A 4chan post from **August 11, 2026** reposted a message that it explicitly attributed to the **NovelAI Discord**.

The quoted creator described building a tool that mapped roughly **10,000 Danbooru artists**, using artists with more than approximately 200 posts.

Most importantly, the creator stated that the representation was created:

> using an image vision model (sigclip) on 24 samples from each artist

This provides the strongest concrete implementation detail discovered so far.

## Implications

The principal representation is therefore derived from image pixels rather than merely tag co-occurrence.

A likely conceptual pipeline is:

```text
Danbooru artist
    ↓
sample 24 artworks
    ↓
SigLIP image encoder
    ↓
24 image embeddings
    ↓
artist-level aggregation
    ↓
artist embedding
```

Exactly how the 24 image embeddings are aggregated was not disclosed.

Possible approaches include:

- normalized mean / centroid;
- weighted mean;
- trimmed mean;
- medoid;
- multiple centroids;
- learned pooling.

The simplest and most likely baseline would be a normalized centroid:

```text
artist_vector = normalize(mean(image_embeddings))
```

This remains an inference rather than a verified implementation detail.

---

# 3. Version History / Expansion

The apparent launch-era announcement described approximately:

**10,000 artists**

The current site reports approximately:

**24,402 artists**

This suggests one of two possibilities:

1. the dataset expanded very rapidly after release; or
2. “10k” was loose shorthand for the initial population.

The launch screenshot also appears to show an earlier regional organization.

Visible region names reportedly included concepts such as:

- Comics & sketch
- Pastel cel
- Airbrush gloss
- Western adult
- Ero-doujin
- Full-body & scenes

The current application reports 10 regions.

This suggests the project is relatively new and was being actively iterated during August 2026.

---

# 4. Multiple Representation Spaces

Booru Atlas appears to maintain multiple distinct representations rather than collapsing everything into one map.

## 4.1 Visual / Style Space

The “How it looks” mode represents similarity derived from the artwork itself.

The site describes factors such as:

- linework;
- shading;
- color;
- texture.

The launch announcement strongly suggests SigLIP-derived image embeddings are the foundation of this representation.

## 4.2 Content Space

The “What’s in it” mode uses Danbooru tag information.

Importantly, franchise / series tags are removed or suppressed.

This is a meaningful design choice. Without removing franchise information, two artists might be declared similar mainly because they both draw the same franchise.

Removing those tags makes the content space more about things such as:

- subjects;
- compositions;
- poses;
- clothing;
- activities;
- visual themes;
- scene types.

rather than simply shared fandom.

## 4.3 Combined Space

The interface also appears to provide a combined mode.

Conceptually:

```text
visual representation
        +
content representation
        ↓
hybrid similarity
```

The exact fusion method is not publicly documented.

Possible approaches include:

- concatenation followed by normalization;
- weighted cosine similarity;
- weighted sum of normalized embeddings;
- rank fusion;
- late fusion between independent nearest-neighbor results.

---

# 5. t-SNE Is a Visualization Layer, Not the Actual Similarity Metric

One of the most important design choices in Booru Atlas is that the two-dimensional map is not treated as ground truth.

The site states that the map uses fixed **t-SNE coordinates**, but actual nearest-neighbor similarity is calculated in the original high-dimensional representation.

Conceptually:

```text
high-dimensional artist embedding
             │
             ├── nearest-neighbor search
             │
             └── t-SNE
                    ↓
               2-D display
```

This is good practice.

Using the high-dimensional representation for actual similarity avoids interpreting display-space distance as the true metric.

---

# 6. “Like Them, But…” — Latent-Space Navigation

One of the most interesting Booru Atlas features is a query mechanism resembling:

> Find artists like Artist A, but more/less of Concept B.

This is effectively a form of **latent-space directional search**.

A plausible formulation is:

```text
query = normalize(
    artist_embedding
    + λ * concept_embedding
)
```

For subtraction:

```text
query = normalize(
    artist_embedding
    - λ * concept_embedding
)
```

Then retrieve nearest artists from the artist embedding index.

The site reportedly notes that **subtracting concepts often works better than adding them**.

That behavior makes intuitive sense. Subtracting a known property can move away from a strongly represented feature while retaining much of the original artist vector. Adding a property only works well when the dataset contains artists occupying the desired intersection.

---

# 7. Relevant Open-Source Antecedent: SmilingWolf Danbooru2022 Embeddings Playground

A particularly important related project is:

**SmilingWolf — Danbooru2022 Embeddings Playground**

Hugging Face Space:

https://huggingface.co/spaces/SmilingWolf/danbooru2022_embeddings_playground

This project predates Booru Atlas and implements machinery remarkably similar to what Booru Atlas appears to require.

## Key capabilities

It supports:

- Danbooru image embeddings;
- Danbooru tag embeddings;
- a shared embedding space;
- CLIP-style representations;
- SigLIP-trained variants;
- positive image/tag embeddings;
- negative image/tag embeddings;
- embedding arithmetic;
- vector normalization;
- cosine-style nearest-neighbor search;
- FAISS indexing.

A simplified query looks conceptually like:

```text
positive =
    positive_image_embedding
    + positive_tag_embedding

negative =
    negative_image_embedding
    + negative_tag_embedding

query =
    normalize(positive - negative)

nearest =
    FAISS.search(query)
```

This is extremely close to the machinery needed for:

```text
"Artist A, but more X"
"Artist A, but less X"
```

## Important caution

No evidence was found proving that Booru Atlas directly uses:

- SmilingWolf’s code;
- SmilingWolf’s weights;
- SmilingWolf’s FAISS index;
- the Danbooru2022 Embeddings Playground.

The relationship is architectural, not proven lineage.

Still, the similarity is technically significant because it provides an open implementation of nearly the same latent-navigation idea.

---

# 8. Possible Reconstruction of the Booru Atlas Pipeline

Based on verified information plus conservative inference, a likely architecture is:

```text
                         ┌──────────────────────┐
                         │      Danbooru        │
                         └──────────┬───────────┘
                                    │
                      artist posts + metadata
                                    │
             ┌──────────────────────┴──────────────────────┐
             │                                             │
             ▼                                             ▼
      artwork sampling                                tag extraction
       (~24 / artist)                                      │
             │                                             │
             ▼                                             ▼
       SigLIP encoder                              remove franchise tags
             │                                             │
             ▼                                             ▼
       image embeddings                             content representation
             │                                             │
             ▼                                             │
     aggregate by artist                                   │
             │                                             │
             ▼                                             │
       artist embedding                                    │
             │                                             │
      ┌──────┴──────────────┐                              │
      │                     │                              │
      ▼                     ▼                              │
 nearest-neighbor         t-SNE                            │
      index                 │                              │
      │                     ▼                              │
      │                interactive map                     │
      │                                                    │
      └──────────────────────┬─────────────────────────────┘
                             │
                             ▼
                   hybrid / constrained search
                             │
                             ▼
                "like A, but more/less B"
```

---

# 9. Nearest-Neighbor Infrastructure

The exact nearest-neighbor implementation used by Booru Atlas is unknown.

Reasonable candidates include:

- FAISS;
- HNSW / hnswlib;
- Annoy;
- ScaNN;
- brute-force cosine similarity for a dataset this small.

With approximately 24k artist vectors, brute-force similarity is actually feasible.

For example, if each artist embedding is 1,024 dimensions:

```text
24,402 × 1,024
```

is only about 25 million scalar values.

Even a simple matrix multiplication can retrieve nearest neighbors interactively on modern hardware.

Therefore Booru Atlas does not necessarily require an ANN system. However, FAISS would be a natural choice, especially given the precedent of the SmilingWolf project.

---

# 10. Style Axes

The current interface exposes several explicit style-related dimensions.

Reported axes include:

- chroma;
- contrast;
- palette;
- warm;
- linework;
- detail.

These appear to be interpretable dimensions over artists rather than the raw latent coordinates themselves.

The mechanism producing these axes is not documented.

Possible implementations include:

### Linear probes

```text
embedding → regression/classifier → style score
```

### Concept directions

```text
mean(high-style examples)
-
mean(low-style examples)
```

### LLM / VLM scoring

Individual artworks could be scored for style properties, with values aggregated by artist.

### Tag proxies

Some dimensions might be approximated from tag distributions.

The site’s wording suggests at least some style dimensions were intentionally measured rather than simply discovered through unsupervised clustering.

---

# 11. Clustering and Regions

The current interface reports:

- approximately **10 regions**
- **silhouette ≈ 0.083**

A silhouette coefficient near 0.083 is quite low for conventional clustering.

However, this is actually compatible with the creator’s interpretation that artistic style forms overlapping continua rather than clean categories.

A likely workflow is:

```text
continuous artist latent space
        ↓
clustering / spatial partition
        ↓
inspect representative members
        ↓
human-generated semantic label
        ↓
evaluate label against held-out members
```

The site reportedly says that region labels were written after examining members and then checked against artists not used to construct the label.

That resembles a small human validation process rather than purely decorative labeling.

The exact clustering method has not been identified.

Possible candidates include:

- k-means;
- Gaussian mixture models;
- HDBSCAN;
- spectral clustering;
- clustering in a reduced PCA space;
- manually partitioned t-SNE regions.

The explicit silhouette statistic makes some form of algorithmic clustering likely, but this is not confirmed.

---

# 12. A Major Empirical Finding: Content Dominates Global Geometry

The creator reportedly found that the visual representation behaves differently at different scales.

## Local scale

Nearest neighbors often genuinely draw alike.

This implies that local geometry in the learned representation is useful.

## Global scale

Large-scale organization is heavily affected by **content**, particularly explicitness / NSFW characteristics.

The creator states that explicitness predicted broad neighborhood structure better than any of the six measured style axes.

Attempts to remove this influence reportedly damaged useful local similarity relationships.

This is a very important result.

It implies that representation dimensions such as:

```text
style
content
genre
explicitness
composition
medium
subject
```

are entangled in the learned feature space.

That is exactly what would be expected from a general-purpose vision representation.

The model was not trained to respect the human distinction between:

> “what is depicted”

and

> “how it is drawn.”

---

# 13. Why This Matters for Latent-Space CoverageField

Booru Atlas demonstrates an important principle:

## A single embedding can be useful without being semantically pure.

The visual embedding may simultaneously encode:

```text
artist style
subject matter
composition
medium
character design
explicitness
color distribution
rendering technique
genre conventions
```

Trying to forcibly remove one factor can damage the useful geometry created by correlations among these features.

This suggests that a richer coverage_field system may be better served by maintaining **multiple parallel representations** rather than trying to create one perfectly disentangled embedding.

For example:

```text
image
├── semantic visual embedding
├── perceptual embedding
├── tag-semantic embedding
├── pose representation
├── NSFW representation
├── color/style descriptors
└── metadata-derived representation
```

Then similarity can be controlled through weighted fusion or alternate views.

---

# 14. Relationship to a General Media-Latent-Space System

Booru Atlas can be interpreted as a specialized instance of a much broader architecture:

```text
media object
    │
    ├── visual representation
    ├── semantic representation
    ├── symbolic/tag representation
    ├── metadata representation
    └── behavioral / observer representation

                   ↓

          independent latent spaces

                   ↓

          weighted / constrained fusion

                   ↓

        high-dimensional navigation

                   ↓

       human-friendly projections
```

The important insight is that the 2-D map is not the latent space itself.

It is merely one interface into a higher-dimensional representation.

Booru Atlas already partially embraces this by:

- maintaining high-dimensional similarity separately from t-SNE;
- allowing multiple similarity definitions;
- supporting semantic vector modification;
- providing human-named regions;
- exposing interpretable style axes.

---

# 15. Hosting / Infrastructure Clue

The hostname:

```text
booruatlas.b-cdn.net
```

is consistent with a **Bunny CDN Pull Zone** hostname.

Bunny CDN commonly gives pull zones hostnames in the form:

```text
<zone-name>.b-cdn.net
```

This means `booruatlas` is likely the CDN zone name rather than a standalone registered project domain.

That limits provenance discovery because there may be no public WHOIS trail specific to Booru Atlas.

It also suggests that at least much of the application may be statically hosted.

A plausible architecture is therefore:

```text
offline preprocessing
    ↓
precomputed artist vectors
precomputed t-SNE coordinates
precomputed metadata
possibly precomputed neighbors
    ↓
static frontend
    ↓
Bunny CDN
```

This would be entirely practical for only ~24k artists.

The current 403 response may therefore reflect CDN configuration rather than the original project disappearing.

---

# 16. What Could Not Be Found

Despite extensive searching, no clearly associated public source repository was found.

No verified Booru Atlas repository was located on:

- GitHub;
- GitLab;
- Codeberg;
- Hugging Face;
- other commonly indexed code-hosting services.

No verified public creator profile was identified.

No technical blog post, paper, issue tracker, or standalone documentation page was found.

The strongest creator trail remains:

```text
NovelAI Discord
      ↓
message reposted to 4chan
      ↓
Booru Atlas URL
```

The repost unfortunately does not preserve enough reliable identity information to attribute the project confidently.

---

# 17. Unrelated Search Result to Avoid

Search engines may surface:

**Atlas-Commons / StreamBooru**

This appears unrelated to Booru Atlas.

The overlap in the word “Atlas” is coincidental.

---

# 18. Reproducing the Core Idea

Even without source code, the central system is straightforward enough to reproduce.

## Step 1 — Select artists

Query Danbooru artists satisfying:

```text
post_count >= threshold
```

For example:

```text
>= 200 posts
```

## Step 2 — Sample artwork

For every artist, select approximately:

```text
24 images
```

Sampling strategy matters.

Possible strategies:

- random sample;
- recent sample;
- stratified across time;
- stratified across ratings;
- popularity-weighted;
- diversity-maximized;
- representative medoids.

A diversity-based sample may outperform purely random sampling.

## Step 3 — Generate image embeddings

Use SigLIP or SigLIP 2.

Conceptually:

```python
embedding = model(image)
embedding = normalize(embedding)
```

Store embeddings for every sampled artwork.

## Step 4 — Aggregate into artist embeddings

Simple baseline:

```python
artist_embedding = normalize(
    mean(image_embeddings)
)
```

Better methods could include:

- trimmed centroid;
- geometric median;
- multiple prototypes per artist;
- clustering artwork embeddings per artist;
- attention-based pooling.

## Step 5 — Build exact or approximate nearest-neighbor search

For only ~24k artists, exact matrix cosine similarity may be sufficient.

Otherwise use:

- FAISS;
- HNSW.

## Step 6 — Build tag/content representations

Collect each artist’s tag frequencies.

Remove:

- copyright tags;
- franchise tags;
- potentially character tags.

Create a weighted vector using something similar to TF-IDF:

```text
artist_tag_weight(tag)
=
artist_frequency(tag)
×
inverse_global_frequency(tag)
```

This naturally emphasizes tags unusually characteristic of an artist.

## Step 7 — Create interpretable concept vectors

If text/tag embeddings share the same representation as images:

```text
concept_vector = encode_text(tag)
```

Otherwise construct concept directions empirically:

```text
concept_vector =
mean(artists_with_tag)
-
mean(artists_without_tag)
```

## Step 8 — Implement directional search

```python
query = normalize(
    artist_vector
    + strength * concept_vector
)
```

or:

```python
query = normalize(
    artist_vector
    - strength * concept_vector
)
```

Retrieve nearest artist vectors.

## Step 9 — Project for visualization

Possible projections:

- t-SNE;
- UMAP;
- PaCMAP;
- TriMap;
- LargeVis;
- PCA;
- parametric UMAP.

Use the projection only for display.

Never replace high-dimensional similarity with projected distance.

---

# 19. Improvements Beyond Booru Atlas

A more general system could preserve multiple embeddings rather than collapsing everything into one representation.

For example:

```text
Artist / media object
│
├── SigLIP 2
│      semantic visual similarity
│
├── DreamSim
│      perceptual similarity
│
├── Danbooru tag embedding
│      explicit symbolic semantics
│
├── pose representation
│      body configuration
│
├── NSFW representation
│      explicitness / sexual-content topology
│
├── palette / style descriptors
│      interpretable visual properties
│
└── metadata
       time, popularity, source, etc.
```

Similarity could then be evaluated independently or fused:

```text
score =
w_visual      * visual_similarity
+
w_perceptual  * perceptual_similarity
+
w_semantic    * semantic_similarity
+
w_pose        * pose_similarity
+
w_nsfw        * nsfw_similarity
+
w_metadata    * metadata_similarity
```

This would allow humans to dynamically decide what “similar” means.

---

# 20. A Particularly Interesting Extension: Navigation Through Invisible Dimensions

The Booru Atlas map is only 2-D, but the actual representation is high-dimensional.

A future interface could expose those hidden dimensions interactively.

Instead of treating the projection as fixed:

```text
high-D embedding
      ↓
fixed 2-D UMAP/t-SNE
```

the user could manipulate projection directions:

```text
high-D embedding
      ↓
interactive viewing basis
      ↓
2-D / 3-D viewport
```

This would be analogous to 4-D visualization interfaces where a slider moves the viewer through an otherwise invisible dimension.

Possible controls could include:

- semantic concept sliders;
- learned principal axes;
- locally discovered directions;
- user-defined tag vectors;
- contrastive directions;
- latent interpolation;
- weighted representation fusion.

For example:

```text
[ explicitness ]  ◄────●────────►
[ painterly     ]  ◄────────●────►
[ pose emphasis ]  ◄──●──────────►
[ tag semantics ]  ◄──────●──────►
```

The displayed map could continuously recompute based on those latent constraints.

That would turn the system from a static map into a **latent-space navigation instrument**.

---

# 21. Key Takeaways

The most important findings are:

1. **Booru Atlas appears to use actual image embeddings, not just tags.**
2. The launch description says it used **SigLIP / “sigclip”**.
3. The initial representation used approximately **24 images per artist**.
4. Artists were restricted to roughly **200+ Danbooru posts**.
5. The launch version described roughly **10k artists**.
6. The current interface reports approximately **24,402 artists**.
7. **t-SNE is only the visualization layer.**
8. Actual similarity is calculated in the original high-dimensional space.
9. A separate tag/content representation is maintained.
10. Franchise information is intentionally removed from content similarity.
11. The interface supports **“like this artist, but more/less X”** latent navigation.
12. Visual and semantic representations can apparently be combined.
13. The creator found **content and explicitness strongly influence global embedding geometry**.
14. Local nearest-neighbor similarity remains useful even when global structure is entangled.
15. The current project reports **10 soft regions** with silhouette around **0.083**.
16. No public Booru Atlas source repository has been found.
17. SmilingWolf’s open-source **Danbooru2022 Embeddings Playground** provides a strong architectural precedent.
18. The broader design strongly supports maintaining **multiple independent representation spaces** rather than relying on a single universal embedding.

---

# 22. Useful Links

## Booru Atlas

https://booruatlas.b-cdn.net/

## Apparent launch / NovelAI Discord repost

https://boards.4chan.org/vp/thread/59497723

Note: 4chan threads are ephemeral. An archive may be required later if the thread disappears.

## SmilingWolf Danbooru2022 Embeddings Playground

https://huggingface.co/spaces/SmilingWolf/danbooru2022_embeddings_playground

## SmilingWolf source files

https://huggingface.co/spaces/SmilingWolf/danbooru2022_embeddings_playground/tree/main

---

# 23. Remaining Research Questions

The most valuable unresolved questions are:

- Which exact SigLIP model/checkpoint does Booru Atlas use?
- How are the 24 artwork embeddings aggregated into one artist vector?
- How are artwork samples selected?
- Are image embeddings normalized before aggregation?
- Does the system use one artist centroid or multiple artist prototypes?
- How is the content/tag vector constructed?
- How are franchise tags detected and removed?
- How is the “Both” representation fused?
- How exactly are “more/less concept” queries calculated?
- Are concept directions derived from text embeddings or empirical artist differences?
- Does the system use FAISS, HNSW, or exact cosine search?
- Which clustering algorithm produced the 10 regions?
- How were the six style dimensions produced?
- Is explicitness represented explicitly or simply emergent in the image embedding?
- Are nearest neighbors computed client-side or precomputed?
- Is there an unindexed GitHub repository or private development repository?
- Who authored the original NovelAI Discord announcement?
- Will the project eventually release its embeddings or source?

---

# 24. Overall Interpretation

Booru Atlas is more than a 2-D artist map.

It is better understood as an early example of a **human-facing latent-space coverage_field system**.

Its architecture appears to follow a valuable separation:

```text
representation space
        ≠
visualization space
```

The high-dimensional representation contains the useful geometry.

The t-SNE map is merely one human-readable lens.

Tags provide another lens.

Style axes provide another.

Directional concept arithmetic provides another.

This distinction is likely the most important lesson from the project.

Rather than forcing a complex media collection into a single 2-D organization, a mature system can allow the human observer to move among many overlapping representations of the same underlying objects.

Booru Atlas demonstrates a small but compelling version of that idea.
