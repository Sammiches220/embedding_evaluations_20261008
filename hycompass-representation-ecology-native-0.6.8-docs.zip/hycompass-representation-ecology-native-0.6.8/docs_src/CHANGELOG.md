# Changelog

## 0.5.4

### SSE events and revisioned runtime synchronization

- Added `GET /events` Server-Sent Events with compact `type + view + domain + projection + revision` envelopes.
- Added bounded event replay through `Last-Event-ID` / `since_event_id`, idle heartbeats, View/Domain/type filters, and `stream.resync_required` recovery when history or a slow-subscriber queue cannot bridge the gap.
- Added per-family revisions for Working Selection, Point Predicate state, Visibility, Timeline, Highlights, Focus, external ResultSets, and View state, plus active-View and workspace revisions.
- Added cheap memory-only `GET /state`, `/active-view/state`, `/views/{view}/state`, `/views/{view}/working-selection/state`, and `/views/{view}/predicate/state` endpoints.
- Added WorkingSelection snapshot revisions and optional revision pinning while paging. Stale revision requests return `409 Conflict` rather than combining two selection states.
- Added bounded `/views/{view}/working-selection/delta` synchronization. Small retained add/remove transitions can be merged across revisions; large/expired transitions explicitly return `snapshot_required=true`.
- WorkingSelection feature paging can also be pinned to a Selection revision.
- GUI WorkingSelection changes now publish causes such as click/lasso/predicate/clear without duplicating events when REST-originated state is reflected back into Qt.
- Point Predicate control/saved-query changes emit lightweight `point_predicate.changed` notifications without evaluating the predicate.
- Main-tab changes emit `active_view.changed`; View open/close/reconfiguration, visibility, highlights, focus, ResultSets, asset registration, workspace reload, and saved library mutations also emit compact events.
- Timeline state/revision updates immediately while GUI SSE emission is debounced to avoid high-frequency playback/drag floods.
- Added `adapters/watch_events.py` and `adapters/selection_sync_demo.py`.
- Added `EVENTS_AND_STATE.md`.

## 0.5.3

### External/precomputed asset registration

- Added a shared validation/registration layer for externally computed Domains, Projections, Clusterings, Density fields, Segmentations, and CoverageField fields.
- Added `scripts/workspace_tool.py init`, allowing a completely external pipeline to bootstrap an empty workspace without invoking `prepare.py` or any built-in producer.
- Added CLI `add-projection`, `add-density`, `add-segmentation`, and `add-coverage_field`; `add-clustering` now uses the same external-registration contract and supports copy/reference storage.
- Added REST registration endpoints for Domains, Projections, Clusterings, Densities, Segmentations, and Coverage fields alongside the existing Selection/Timeline endpoints.
- Refactored Selection and Timeline registration through the same shared registrar, so Python/CLI/REST validation and copy/reference semantics are consistent across all file-backed asset families.
- Added `GET /assets/contracts` and `GET /assets/catalog`.
- Projection registration validates immutable Domain alignment, subset finite-row masks, optional supplied spatial indexes, and can derive the projected-x index automatically.
- Density/CoverageField registration validates finite scalar fields and the recommended normalized `0..1` contract.
- Segmentation registration accepts externally supplied stats or derives missing anchors/populations/area/scale/peak-density metadata without recomputing labels.
- Temporal CoverageField registration validates Selection/Timeline compatibility and infers timeline bounds when omitted.
- Added `copy` versus `reference` storage modes for external derived assets.
- Shared OpenGL resource keys now include backing-file stat/version information, preventing stale GPU resources after explicit replacement/reload of a file under the same catalog path.
- Added `EXTERNAL_ASSETS.md` with canonical contracts and CLI/REST examples.

## 0.5.2

### Tabs and sidebar state

- Restored tab close buttons and draggable tab reordering.
- Added middle-click tab closing.
- Fixed custom-tab-bar initialization order so Qt close/move configuration is not lost.
- Every main sidebar section now starts collapsed, including newly loaded Saved Views.

### Predicate UX and multi-asset composition

- Saved Query state now explicitly displays **Visible controls** versus **Saved query override**; the switch-back action is named accordingly.
- Clustering predicates can enable several compatible clustering assets simultaneously, with multiple IDs per asset and ANY/ALL composition across assets.
- Segmentation predicates now provide the same multi-asset/multi-ID composition.
- Density and CoverageField predicates can also enable several compatible field assets with ANY/ALL composition.
- Predicate controls remain independently disableable so unused feature families disappear from query semantics.

### Segmentation labels

- Increased default segmentation-label visibility and size.
- Added per-layer label size, opacity, foreground color, outline color, and outline-width controls.
- Label drawing now uses outlined painter paths for stronger contrast over dense maps.

### REST query/data plane

- `/query`, `/items/features`, `/features/catalog`, and `/query/features` accept either a View ID or an ad-hoc Domain + Projection (+ optional Timeline) context.
- Added `/features/catalog` for discovering all compatible feature assets before constructing external predicates.
- Added `/query/features` to page PointQuery results and native features in one request.
- Verified predicates/features can combine multiple clustering, segmentation, and density assets without those assets being selected as the View's primary display channels.

### More explicit modular method examples

- Added `TSNEProjection`, a real scikit-learn t-SNE `ProjectionMethod` implementation for modest/subset-local workloads.
- Added BIRCH clustering alongside MiniBatchKMeans and supplied label assets.
- `prepare.py` and `scripts/workspace_tool.py` expose t-SNE parameters; `scripts/workspace_tool.py build-clustering` supports MiniBatchKMeans and BIRCH.
- Added `generate_modular_example_inputs.py` and `prepare_modular_example.py`: an executable tutorial that constructs two Domains, several projections, clusterings, densities, segmentations, coverage_field methods, themes, and Saved Views in one workspace.
- Updated preparation/extension/API documentation around the richer example.

## 0.5.1

### Density rendering fixes

- Fixed Density opacity so `0.0..1.0` continuously scales the entire density layer rather than appearing effectively binary.
- Contours now obey the same opacity control as the underlying field.
- Contour levels are placed strictly inside the normalized `(0,1)` range so the maximum-density plateau is no longer rendered as a filled innermost contour.
- Density layer opacity is no longer silently divided by the number of active density assets.

### Sidebar / usability redesign

- Reordered the sidebar to: **View composition → Rendering → Interaction → Point predicates → Inspection / State → Layer styles → Timeline → Performance**.
- Every major sidebar section is collapsible.
- Moved point size into Rendering and Save PNG into a general Output subsection.
- Removed the GUI **Clear highlights** action; external/API highlights remain a separate runtime channel.
- Split Layer Styles into Density, CoverageField, Segmentation, and Selection/Highlight overlay subsections.
- Split Inspection / State into point-inspection and view-state subsections.

### Point predicates and interaction

- Point Predicate families are independently checkable. Disabled predicates gray out their controls and do not participate in the query.
- Selection predicates expose compatible SelectionAssets.
- Clustering predicates expose a checkable list of actual cluster IDs with populations and allow any combination.
- Segmentation predicates expose a checkable list of actual segment IDs plus available names/populations and allow any combination.
- Density supports value thresholds and top/bottom percentiles.
- CoverageField supports inside/outside boundary and literal value comparisons.
- Timeline state remains optional.
- Added `cmp: "in"` support for categorical query features.
- Density percentile thresholds are computed against the full projected population, keeping percentile semantics stable inside lassos/candidate subsets.
- Click and lasso interaction can independently respect the active PointQuery and current visibility mask.
- Nearest-point picking filters ineligible candidates *before* choosing the nearest row, so invisible/ineligible rows cannot steal clicks.
- Clicking now participates in the WorkingSelection (using the configured replace/add/subtract/intersect mode) rather than creating an external-style highlight.
- Added direct export of the WorkingSelection with selected app-native features to CSV or JSONL.

### Overlay styling

- Working Selection visibility, RGBA color, and point size are configurable per View.
- External/API HighlightSet visibility, RGBA color, and point size are independently configurable per View.
- View manifests now persist `overlay_style`.

### Saved View / Saved Query libraries

- Saved Views and Saved Queries now carry hierarchical `folder` paths.
- Added organizer/browser dialogs with folder trees, load/double-click, and delete actions.
- Save View opens a name/folder organizer instead of mutating an awkward toolbar entry.
- Double-clicking empty tab-bar space opens the Saved View browser.
- Startup opens a default/first saved View rather than opening every preset as a tab.
- Saved-query UI refreshes from the live manifest and provides Load / Save current / Delete actions.
- Workspace manifest format bumped to **3** with v1/v2 migration defaults.

### Modular extension examples

- Added `GaussianRandomProjection` as a compact example implementation of the `ProjectionMethod` protocol.
- Added `--projection random` and `--random-projection-seed` to `prepare.py` and `scripts/workspace_tool.py`.
- Added bundled user-theme examples: Ocean, Paper, and High Contrast.
- `prepare.py` registers bundled sample themes by default; `--no-example-themes` disables this.
- Refreshed `generate_example_inputs.py` with overlapping selection examples and random-projection usage.
- Added `EXTENDING_METHODS.md`.

### REST additions

- Added paged WorkingSelection native-feature retrieval.
- Added listing/deletion for Saved Queries.
- Added listing/deletion for Saved Views.
- API version/health now reports `0.5.1`.

## 0.5.0

### Interaction and query model

- Removed the in-app candidate/ranking analyzer and sorting table.
- Added a reusable JSON-friendly PointQuery engine.
- Added predicates for Selection membership, Clustering labels, Density values/percentiles, Segmentation IDs, CoverageField inside/outside/value, Timeline state, row IDs, and finite projected coordinates.
- Lasso applies the active PointQuery and supports replace/add/subtract/intersect semantics.
- Added whole-view `Select matches`, `Show only matches`, `Hide matches`, and `Reset visibility` actions.
- Separated WorkingSelection, VisibilityFilter, HighlightSet, persistent Selection assets, and ordered external ResultSets.
- External ResultSets preserve supplied order and can be addressed by index for camera focus.

### Field and segmentation modularity

- Density methods: Gaussian-smoothed occupancy, adaptive-Gaussian approximation, and raw/log histogram density.
- CoverageField methods: box-blur coverage, Gaussian coverage, and distance-based coverage.
- Segmentation methods: watershed and density connected components.
- Separated immutable asset computation from per-View display style.
- Added density/coverage_field/segmentation style controls and optional segmentation labels.

### Rendering / REST / external analysis

- Removed native wide `glLineWidth` from lasso rendering and moved lasso feedback to a Qt overlay.
- Added FastAPI service, headless `api_serve.py`, external ResultSets, focus/fit, feature retrieval, asset registration/reload, saved queries, themes, and Embedding Atlas export adapter.
