## **Storage modes**

External registration supports two storage modes.

### `copy`

HyCompass validates and writes a workspace-owned copy, converting to its preferred runtime dtype where applicable.

Large remote transfers are intentionally not encoded as JSON blobs: synchronize the completed `.npy`/JSON files to storage visible to the service, then register them.

Typical copy-mode conversions:

| Asset | Workspace copy dtype |
|---|---|
| Selection | `uint8` |
| Timeline | `int64` |
| Projection | `float32` |
| Clustering | `uint32` |
| Density | `float32` |
| Segmentation | `uint32` |
| CoverageField | `float16` |
| Domain | preserves supplied embedding/item-ID dtypes |

### `reference`

HyCompass validates the supplied file and stores its path without copying the main array.

This is useful for very large arrays already managed elsewhere.

Important:

- referenced paths must be visible to the machine running Latent Observer;
- Projection reference mode requires `positions.npy` to already be `float32 [N,2]`;
- files must remain available at the registered path;
- the REST API does not upload giant NumPy arrays in JSON.

A remote producer should write/synchronize completed files to shared storage visible to the service and then register those paths.

---

## **External asset registration**

HyCompass exposes functions to let assets be registered for reference externally.

See [REST API Assets Overview](../api/reference/assets/index.html)

The same validation contracts are used by:

- the Python registration helpers;
- `scripts/workspace_tool.py add-*`;
- the REST registration endpoints.

### Empty workspace bootstrap

A pipeline that uses no built-in computation can initialize an empty workspace:

```bash
python scripts/workspace_tool.py --workspace data/workspace init
```

It can then register all completed assets.