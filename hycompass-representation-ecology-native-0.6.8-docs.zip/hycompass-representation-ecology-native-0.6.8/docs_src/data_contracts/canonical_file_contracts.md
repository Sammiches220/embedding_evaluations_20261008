## Canonical file contracts

| Asset | Required data | Canonical/required constraints |
|---|---|---|
| Domain embeddings | `.npy [N,D]` | real numeric dtype |
| Domain item IDs | `.npy [N]` | non-object dtype, same `N` |
| Selection | `.npy [N]` | bool or integer |
| Timeline | `.npy [N]` | integer UNIX seconds |
| Projection | `.npy [N,2]` | numeric; reference mode requires `float32` |
| Clustering | `.npy [N]` | non-negative integer |
| Density | `.npy [H,W]` | finite real numeric; normally `[0,1]` |
| Segmentation | `.npy [H,W]` | non-negative integer; `0` background |
| CoverageField | `.npy [H,W]` or `[T,H,W]` | finite real numeric; normally `[0,1]` |

All `.npy` files are loaded with `allow_pickle=False`.

### Recommended item IDs

`item_ids.npy` may use any non-object NumPy dtype, but stable Unicode/string identifiers are recommended for REST integrations.

For very large external workflows, retain Domain row numbers when practical. Row-based API calls avoid scanning a large `item_ids.npy` to resolve IDs.