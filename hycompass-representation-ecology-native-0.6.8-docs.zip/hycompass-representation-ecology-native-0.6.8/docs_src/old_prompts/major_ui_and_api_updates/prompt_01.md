In its current state, does the project support the following approaches?

The root is the complete domain (i.e. the complete set of embeddings). This is the potentially massive `embeddings.npy` file per embedding type. Per complete domain, there is also only one corresponding set of item_ids. 


Each complete domain view can have many layers of "first_seen", which correspond to some Hydrus selection criteria (cannot have duplicates, BUT can have duplicate "layers" within the complete domain view). This is currently tracked via a separate hydrus embedding type tracker application, and may stay separated depending on performance concerns.
- Each of these first seen layers has potentially many corresponding implementations of "coverage_field" boundaries (only one can be selected at a time)


Each complete domain can have many layers of clustering / segmentation methods, but for visualization methods like coloring points, it can only do one? But you can still color any number of the segmentation methods (e.g. filling the segments)? 

If it's infeasible to render multiple "tabs" in some way, then 


and can create any number of coverage_field layers,


Additional windows / tabs for coverage_field? I'm considering something like how Hydrus Network is able to have multiple tabs that you can pull away and look at whenever, but I'm concerned about performance. If multiple processes running is more ideal for this over tabs, then maintaining the separate embedding tracker project is necessary to track first seens across hydrus selection criteria then updating the file-based representations. 

It's also important to have file-based representations of the complete domains + clusters / segmentation data, since these are potentially very large and file-based loading insists upon running updating processing somewhat separately for performance and also facilitates sharing. First seen data can be treated the same, but is more dependent on the separate hydrus embedding tracker project since that does require maintaining a persistent dataset that can be precisely edited. The complete domain is also tracked and updated, so maybe not strictly file-based? But definitely clustering and so on definitely should be file-based.


I'm also curious if the project could feasibly load multiple complete domains into different "tabs". But due to the size of the complete domains, any additional tabs that also use the same domain should refer to the same loaded domain, just with different layering options. Discuss performance potential here. This is primarily because I'm curious about if it'd be more optimal to have one large database for one program with multiple views, or whether I should instead have multiple separate processes that work with a separate embedding tracker to "populate" representations as requested. This would permit more modular loading of these very large datasets for visualization.
