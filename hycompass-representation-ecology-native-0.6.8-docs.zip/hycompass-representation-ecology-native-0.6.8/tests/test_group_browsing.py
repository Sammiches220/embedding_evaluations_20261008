"""Batch browsing, cached audit estimates, larger subset plots and independent failures."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from dataclasses import replace
import numpy as np
import pytest
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication
from ecology.demo import demo
from ecology.store import Store,Token,Cancelled
from ecology.instruments import generate,generate_many,plan
from ecology.bulk import payload_fields,resource_preset
from ecology.group_views import checked
from ecology.jobs import Jobs
from ecology.native import MapWidget

@pytest.fixture(scope='module')
def root(tmp_path_factory):
    root=demo(tmp_path_factory.mktemp('groups')/'workspace',n=1200,generate_results=False);s=Store(root)
    generate(s,'shared-base',['geometry','probe_metrics','feature_distribution','source_support'])
    return root

@pytest.fixture(scope='module')
def app():return QApplication.instance() or QApplication([])

@pytest.fixture
def widget(root,app):
    jobs=Jobs(root);w=MapWidget(root,'shared-base',jobs,lambda *_:None);w.resize(1500,1000);w.show();app.processEvents();w.set_lens('prediction');w.evidence.setCurrentWidget(w.prediction_panel);w.feature.setCurrentText('broad');w.dimension.setCurrentText('1');w.account.setCurrentIndex(w.account.findData('broad'));w.load_names(['probe_metrics','feature_distribution','source_support']);app.processEvents()
    yield w
    w.dispose();w.close();jobs.close();app.processEvents()


def test_cached_audit_estimate_dimensions_and_io(root):
    s=Store(root);p=plan(s,'shared-base',['source_support'])
    assert p['dimensions']==12 and p['context_cap']==288
    assert p['compute_state']=='already_saved' and p['total_missing_work']==0
    assert p['saved_payload_bytes']>0 and p['load_verification_bytes']>0
    a,m=s.artifact('shared-base','source_support')
    assert a['norm_counts'].sum()==m['measurements']['rows']
    assert len(a['rank_variance'])<=12 and a['occurrences'].sum()>0
    assert m['source_revision']==s.read('shared-base')['domain_revision']


def test_metadata_budget_preserves_active_group_and_reports_omissions(root):
    s=Store(root);a,m=s.artifact('shared-base','probe_metrics');targets=list(m['targets']);dims=[1,2,4,8]
    all_names,omitted,size=payload_fields(m,targets,dims,('broad','1'),None,100_000_000)
    assert not omitted and 'category__q8__local__prediction' in all_names
    active_names,_,minimum=payload_fields(m,['broad'],[1],('broad','1'),None,100_000_000)
    names,omitted,size=payload_fields(m,targets,dims,('broad','1'),None,minimum)
    assert omitted and 'broad__q1__broad__prediction' in names and size<=minimum
    assert 'category__q8__local__prediction' not in names


def test_broad_default_checklists_and_population_support(widget,app,monkeypatch):
    w=widget;assert set(checked(w.target_checks))==set(w.definition['settings']['features'])
    assert set(checked(w.dimension_checks))=={'1','2','4','8'}
    a,m=w.loaded['probe_metrics'];assert 'category__q8__local__prediction' in a
    before=w.store.membership(w.key).copy();kept=w.selected_rows.copy()
    monkeypatch.setattr(w.jobs,'submit',lambda *_args,**_kwargs:pytest.fail('tab changed dispatched compute'))
    for tab in (w.targets_tab,w.population_tab,w.subset_tab,w.audit_tab,w.availability_tab,w.batch_tab):
        w.prediction_subtabs.setCurrentWidget(tab);app.processEvents();w.refresh_group_views()
    population=w.loaded['feature_distribution'][1];assert population['support']['question_members']==960
    assert population['summaries']['broad']['known']>len(w.landscape.rows)*5
    w.prediction_subtabs.setCurrentWidget(w.population_tab);app.processEvents();assert len(w.population_figure.axes)==2
    assert sum(p.get_height() for p in w.population_figure.axes[0].patches)==population['summaries']['broad']['known']
    np.testing.assert_array_equal(w.store.membership(w.key),before);np.testing.assert_array_equal(w.selected_rows,kept)
    w.batch_target_preset.setCurrentText('Boolean + category targets');w.apply_target_preset();assert set(checked(w.target_checks))=={'flag','category'}
    w.batch_resource_preset.setCurrentText('Prediction + population');w.apply_resource_preset();assert 'feature_distribution' in w.checked_names() and 'source_support' in w.checked_names()


def test_bulk_case_presets_are_larger_than_the_list_and_explicit(widget,app):
    w=widget;w.prediction_subtabs.setCurrentWidget(w.cases_tab);w.refresh_navigation();assert w.prediction_cases.rowCount()==50
    before=w.selected_rows.copy();w.check_cases(True);np.testing.assert_array_equal(w.selected_rows,before)
    w.keep_checked_cases();assert len(w.selected_rows)==50
    w.case_preset.setCurrentText('All supported in displayed subset');w.keep_item_preset();assert len(w.selected_rows)>50
    w.case_preset.setCurrentText('All frozen map members');w.keep_item_preset();assert len(w.selected_rows)==960
    assert w.definition['n_members']==960


def test_rendered_subtabs_and_live_audit_feedback(widget,app,tmp_path):
    w=widget;w.estimate_source_audit();assert 'None' not in w.source_note.text() and 'Already saved' in w.source_note.text() and 'Zero NEW compute' in w.source_note.text()
    w.prepare_source_audit();assert not w.jobs.busy(w.key);assert 'Loaded / measured' in w.source_note.text()
    assert w.prediction_subtabs.count()==9
    for name,tab in [('targets',w.targets_tab),('population',w.population_tab),('audits',w.audit_tab),('batch',w.batch_tab)]:
        w.prediction_subtabs.setCurrentWidget(tab);w.refresh_navigation();app.processEvents();w.grab().save(str(tmp_path/(name+'.png')))
        assert w.prediction_subtabs.height()>220 and w.screen_prepare.height()==23
    w.prediction_subtabs.setCurrentWidget(w.audit_tab);w.audit_view.setCurrentIndex(1);w.refresh_group_views();assert len(w.audit_figure.axes)==2
    assert 'zero' in w.audit_state.text()


def test_continue_family_failures_and_cancellation(tmp_path,monkeypatch):
    root=demo(tmp_path/'continue',90,False);s=Store(root)
    import ecology.instruments as instruments
    original=instruments.FUNCTIONS['source_support']
    def broken(*_):raise ValueError('fixture source audit unavailable')
    monkeypatch.setitem(instruments.FUNCTIONS,'source_support',broken)
    result=generate_many(s,'shared-base',['source_support','feature_distribution'])
    assert 'source_support' in result['failed'] and 'feature_distribution' in result['completed']
    assert s.artifact_path('shared-base','feature_distribution').exists()
    assert s.artifact_path('shared-base','neighbors').exists()
    jobs=Jobs(root)
    try:
        future=jobs.submit('shared-base',['source_support','feature_distribution'],continue_on_error=True);outcome=future.result(timeout=30)
        assert outcome['failed'] and jobs.inspect(future.job_id)['state']=='partial'
    finally:jobs.close()
    token=Token();token.cancel()
    with pytest.raises(Cancelled):generate_many(s,'shared-base',['source_support','feature_distribution'],token)


def test_union_cases_keeps_target_scales_separate(root):
    from ecology.bulk import union_error_cases
    s=Store(root);payload=s.artifact('shared-base','probe_metrics');rows,report=union_error_cases(payload,['broad','category'],[1,2],['broad','local'])
    assert report['available_groups']==8 and report['unavailable_groups']==0
    assert len(rows)>14 and np.isin(rows,payload[0]['anchor_rows']).all()
    arrays,meta=payload;scaled={**arrays,'broad__q1__broad__loss':arrays['broad__q1__broad__loss']*1e6}
    other,_=union_error_cases((scaled,meta),['broad','category'],[1,2],['broad','local']);np.testing.assert_array_equal(rows,other)


def test_subtab_toolbar_requirements_follow_visuals(widget):
    w=widget;w.prediction_subtabs.setCurrentWidget(w.audit_tab)
    assert w.current_requirements()[1]==['geometry','source_support']
    w.prediction_subtabs.setCurrentWidget(w.population_tab)
    assert w.current_requirements()[1]==['geometry','feature_distribution']
    w.prediction_subtabs.setCurrentWidget(w.batch_tab)
    assert set(w.current_requirements()[1])==set(w.checked_names())


def test_missing_audit_reports_real_work_without_none(root):
    p=plan(Store(root),'shared-distorted',['source_support'])
    assert p['dimensions']==12 and p['total_missing_work']>0
    assert 'source_support' in p['missing'] and p['temporary_ram_estimate_bytes']>0
