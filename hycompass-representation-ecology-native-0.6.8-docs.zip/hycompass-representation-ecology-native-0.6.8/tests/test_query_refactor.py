from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace

import numpy as np
import pytest

from model.query import FeatureProvider, PointQueryEngine, QueryError


@dataclass
class SelectionSpec:
    domain: str
    kind: str = "mask"
    mask: str = "selection_mask"


@dataclass
class ClusteringSpec:
    domain: str
    projection: str | None
    labels: str


@dataclass
class FieldSpec:
    projection: str
    field: str


@dataclass
class SegmentationSpec:
    projection: str
    labels: str


@dataclass
class CoverageFieldSpec:
    projection: str
    frames: str
    timeline: str | None = None


class FakeSession:
    def __init__(self) -> None:
        self.manifest = SimpleNamespace(
            selections={
                "named": SelectionSpec("d", mask="selection_named"),
                "all": SelectionSpec("d", kind="all", mask="unused"),
            },
            clusterings={
                "clusters": ClusteringSpec("d", "p", "clusters_named"),
            },
            densities={"density": FieldSpec("p", "density_grid")},
            segmentations={"segments": SegmentationSpec("p", "segment_grid")},
            coverage_fields={
                "static": CoverageFieldSpec("p", "explore_static"),
                "temporal": CoverageFieldSpec("p", "explore_temporal", timeline="t"),
            },
        )
        self.arrays = {
            "selection_named": np.array([0, 1, 1, 0, 1, 0], dtype=np.uint8),
            "clusters_named": np.array([1, 1, 2, 2, 3, 3], dtype=np.int32),
            "density_grid": np.array([[0.1, 0.7], [0.9, 0.3]], dtype=np.float32),
            "segment_grid": np.array([[1, 2], [3, 4]], dtype=np.int32),
            "explore_static": np.array([[0.2, 0.8], [0.5, 0.1]], dtype=np.float32),
            "explore_temporal": np.array(
                [
                    [[0.0, 0.1], [0.2, 0.3]],
                    [[0.4, 0.5], [0.6, 0.7]],
                    [[0.8, 0.9], [1.0, 0.95]],
                ],
                dtype=np.float32,
            ),
        }

    def array(self, key: str) -> np.ndarray:
        return self.arrays[key]


class FakeView:
    def __init__(self) -> None:
        self.session = FakeSession()
        self.n = 6
        self.domain_id = "d"
        self.projection_id = "p"
        self.spec = SimpleNamespace(timeline="t")
        self.positions = np.array(
            [
                [0.0, 0.0],
                [1.0, 0.0],
                [0.0, 1.0],
                [1.0, 1.0],
                [0.5, 0.5],
                [np.nan, np.nan],
            ],
            dtype=np.float32,
        )
        self.selection_mask = np.array([1, 0, 1, 0, 1, 0], dtype=np.uint8)
        self.cluster = np.array([9, 9, 8, 8, 7, 7], dtype=np.int32)
        self.normalized_timeline = np.array([0.0, 0.2, 0.4, 0.6, 0.8, 1.0], dtype=np.float32)
        self.current_timeline = 0.5
        self.current_coverage_field_threshold = 0.5
        self.item_ids = np.array(["a", "b", "c", "d", "e", "f"])

    def grid_sample_safe(self, grid: np.ndarray, rows: np.ndarray):
        # Deterministic 2x2 sampling for the fixture; the last row is invalid.
        mapping = np.array(
            [
                [0, 0],
                [0, 1],
                [1, 0],
                [1, 1],
                [1, 1],
                [0, 0],
            ],
            dtype=np.int64,
        )
        coords = mapping[rows]
        valid = rows != 5
        return coords[:, 0], coords[:, 1], valid

    def coverage_field_progress_for(self, spec, current: float) -> float:
        return current

    def item_id(self, row: int) -> str:
        return str(self.item_ids[row])

    def row_timestamp(self, row: int):
        return 1000 + row

    def row_observed(self, row: int, current: float) -> bool:
        return bool(self.normalized_timeline[row] <= current)


@pytest.fixture
def view() -> FakeView:
    return FakeView()


def test_public_import_identity_is_preserved() -> None:
    assert PointQueryEngine.__module__ == "model.query"
    assert FeatureProvider.__module__ == "model.query"
    assert QueryError.__module__ == "model.query"


def test_default_query_filters_non_projected_rows(view: FakeView) -> None:
    engine = PointQueryEngine(view)
    expected = np.array([0, 1, 2, 3, 4], dtype=np.uint32)
    np.testing.assert_array_equal(engine.query(None), expected)
    np.testing.assert_array_equal(engine.query({}), expected)
    np.testing.assert_array_equal(engine.query({"op": "all"}), expected)


def test_logical_and_leaf_semantics(view: FakeView) -> None:
    engine = PointQueryEngine(view)
    expr = {
        "op": "and",
        "args": [
            {"feature": "selection", "asset": "active", "cmp": "member"},
            {"feature": "row", "cmp": "in", "values": [0, 2, 3, 4]},
            {
                "op": "not",
                "arg": {"feature": "cluster", "asset": "clusters", "cmp": "==", "value": 2},
            },
        ],
    }
    np.testing.assert_array_equal(engine.query(expr), np.array([0, 4], dtype=np.uint32))


def test_density_percentile_uses_full_population(view: FakeView) -> None:
    engine = PointQueryEngine(view)
    expr = {"feature": "density", "asset": "density", "cmp": ">=", "percentile": 50}
    candidates = np.array([0, 1], dtype=np.uint32)
    # Full finite sampled values are [0.1, 0.7, 0.9, 0.3, 0.3]; median=0.3.
    np.testing.assert_array_equal(engine.query(expr, candidate_rows=candidates), np.array([1], dtype=np.uint32))


def test_segmentation_coverage_field_and_timeline(view: FakeView) -> None:
    engine = PointQueryEngine(view)
    np.testing.assert_array_equal(
        engine.query({"feature": "segmentation", "asset": "segments", "cmp": "in", "values": [3, 4]}),
        np.array([2, 3, 4], dtype=np.uint32),
    )
    np.testing.assert_array_equal(
        engine.query({"feature": "coverage_field", "asset": "static", "cmp": "inside", "threshold": 0.5}),
        np.array([1, 2], dtype=np.uint32),
    )
    np.testing.assert_array_equal(
        engine.query({"feature": "timeline", "cmp": "observed"}),
        np.array([0, 1, 2], dtype=np.uint32),
    )


def test_resolve_rows_preserves_first_occurrence_order(view: FakeView) -> None:
    engine = PointQueryEngine(view)
    result = engine.resolve_rows(rows=[4, 2, 4], item_ids=["b", "c", "b"])
    np.testing.assert_array_equal(result, np.array([4, 2, 1], dtype=np.uint32))


def test_feature_provider_preserves_dynamic_wire_shape(view: FakeView) -> None:
    provider = FeatureProvider(view)
    items = provider.records(
        np.array([0, 1], dtype=np.uint32),
        [
            "x",
            "timeline",
            "selection:named",
            "cluster:clusters",
            "density:density",
            "segmentation:segments",
            "coverage_field:static",
        ],
    )

    assert items[0] == {
        "row": 0,
        "item_id": "a",
        "x": 0.0,
        "y": 0.0,
        "timestamp": 1000,
        "observed_now": True,
        "selection:named": False,
        "cluster:clusters": 1,
        "density:density": pytest.approx(0.1),
        "segmentation:segments": 1,
        "coverage_field:static": pytest.approx(0.2),
    }
    assert "y" in items[1]  # requesting only x historically emits both x and y


def test_feature_provider_rejects_malformed_feature(view: FakeView) -> None:
    with pytest.raises(QueryError, match="needs kind:asset"):
        FeatureProvider(view).records(np.array([0], dtype=np.uint32), ["unknown"])


def test_very_large_flat_expression_is_structurally_supported(view: FakeView) -> None:
    engine = PointQueryEngine(view)
    expr = {
        "op": "and",
        "args": [
            {"feature": "row", "cmp": ">=", "value": 0}
            for _ in range(20_000)
        ],
    }
    np.testing.assert_array_equal(engine.query(expr), np.arange(6, dtype=np.uint32))


def test_deep_expression_does_not_depend_on_python_recursion(view: FakeView) -> None:
    expr = {"feature": "row", "cmp": "==", "value": 0}
    depth = 5_000
    for _ in range(depth):
        expr = {"op": "not", "arg": expr}

    result = PointQueryEngine(view).query(expr)
    expected = np.array([0], dtype=np.uint32) if depth % 2 == 0 else np.array([1, 2, 3, 4, 5], dtype=np.uint32)
    np.testing.assert_array_equal(result, expected)


def test_later_logical_children_are_still_evaluated(view: FakeView) -> None:
    # No short-circuit: the invalid second child must still raise, as before.
    expr = {
        "op": "and",
        "args": [
            {"feature": "row", "cmp": "==", "value": -1},
            {"feature": "density", "asset": "missing", "cmp": ">", "value": 0},
        ],
    }
    with pytest.raises(QueryError, match="unknown/incompatible density"):
        PointQueryEngine(view).query(expr)
