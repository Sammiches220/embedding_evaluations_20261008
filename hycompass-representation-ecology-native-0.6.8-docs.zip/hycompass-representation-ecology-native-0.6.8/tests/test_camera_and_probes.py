import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from types import SimpleNamespace
import numpy as np
import pytest
from PySide6.QtWidgets import QApplication
from ecology.demo import demo
from ecology.jobs import Jobs
from ecology.store import Store
from ecology.instruments import generate
from ecology.native import MapWidget
from ecology.probes import metric_summary

@pytest.fixture(scope='module')
def app():return QApplication.instance() or QApplication([])

@pytest.fixture(scope='module')
def root(tmp_path_factory):
    root=demo(tmp_path_factory.mktemp('camera')/'demo',n=120,generate_results=False);s=Store(root);generate(s,'shared-base',['geometry','directions','reconstruction','probe_metrics','feature_audit']);return root

@pytest.fixture
def view(app,root):
    jobs=Jobs(root);w=MapWidget(root,'shared-base',jobs,lambda *_:None);w.reload(['geometry','directions','reconstruction','probe_metrics','feature_audit']);w.resize(1550,1150);w.show();app.processEvents();w.mode.setChecked(False);w.landscape.camera_pan[:]=0;w.landscape.zoom=1;w.landscape.redraw();w.landscape.canvas.draw()
    yield w
    w.dispose();w.close();jobs.close()


def test_2d_pan_zoom_keep_observer_and_data_fixed(view):
    l=view.landscape;xy=l.arrays['xy'].copy();observer=l.position.copy();before=np.array(l.ax.get_xlim());l.pan_pixels(55,25);after=np.array(l.ax.get_xlim());assert not np.array_equal(before,after);assert np.diff(before)==pytest.approx(np.diff(after));l.canvas.draw()
    event=SimpleNamespace(button='up',inaxes=l.ax,xdata=float(l.position[0]),ydata=float(l.position[1]));old_width=np.diff(l.ax.get_xlim());l._scroll(event);assert np.diff(l.ax.get_xlim())<old_width
    np.testing.assert_array_equal(xy,l.arrays['xy']);np.testing.assert_array_equal(observer,l.position)


def test_3d_zoom_keeps_full_mesh_bounds_and_pan_can_reach_sides(view):
    l=view.landscape;view.mode.setChecked(True);l.canvas.draw();before=np.array(l.ax.get_xlim());vertices=l.arrays['xy'].copy();observer=l.position.copy()
    assert l.ax.bbox.width/l.canvas.width()>.9
    # Equal changes in projected x/y map to equal pixel distances, not stretching.
    origin=l.ax.transData.transform([0.,0.]);px=l.ax.transData.transform([.01,0.]);py=l.ax.transData.transform([0.,.01]);assert np.linalg.norm(px-origin)==pytest.approx(np.linalg.norm(py-origin),rel=1e-6)
    l._scroll(SimpleNamespace(button='up',inaxes=l.ax,xdata=0.,ydata=0.));l.canvas.draw();np.testing.assert_allclose(before,l.ax.get_xlim());assert l.zoom>1
    l.pan_pixels(200,70);l.canvas.draw();assert not np.array_equal(before,l.ax.get_xlim());assert np.diff(before)==pytest.approx(np.diff(l.ax.get_xlim()))
    np.testing.assert_array_equal(vertices,l.arrays['xy']);np.testing.assert_array_equal(observer,l.position);assert l.colorbar is not None
    l.ax.view_init(20,55);view.contrast.setValue(1.3);assert l.ax.azim==55 and l.ax.elev==20


def test_lasso_2d_and_projected_3d_modify_canonical_kept_membership(view):
    l=view.landscape;seen=[];l.selected.connect(lambda rows:seen.append(rows.copy()))
    for three_d in [False,True]:
        view.mode.setChecked(three_d);l.canvas.draw();ids,pixels=l.projected_pixels();valid=np.flatnonzero(np.isfinite(pixels).all(1));p=pixels[valid[len(valid)//2]];rect=np.array([p+[-14,-14],p+[14,-14],p+[14,14],p+[-14,14]])
        l.select_lasso(rect);assert len(seen[-1])>0 and int(l.rows[ids[valid[len(valid)//2]]]) in seen[-1];assert np.array_equal(np.sort(view.selected_rows),np.sort(seen[-1]))
        previous=view.selected_rows.copy();l.select_lasso(rect,'shift');assert np.all(np.isin(previous,view.selected_rows));l.select_lasso(rect,'control');assert not np.any(np.isin(previous,view.selected_rows))
    l.set_mouse_mode('Lasso');assert l.mouse_mode=='Lasso'


def test_color_scale_tracks_scalar_category_and_contrast(view):
    l=view.landscape;view.set_lens('feature');view.feature.setCurrentText('broad');assert l.colorbar is not None;old=l.colorbar.mappable.get_clim();view.contrast.setValue(2);new=l.colorbar.mappable.get_clim();assert new[1]==pytest.approx(old[1]/2)
    view.feature.setCurrentText('category');assert len(l.colorbar.get_ticks())==3;names=[t.get_text() for t in l.colorbar.ax.get_yticklabels()];assert 'Lower band' in names
    assert l.legend_canvas is not l.canvas


def test_actual_direction_scores_match_complete_spectrum(root):
    s=Store(root);g,_=s.artifact('shared-base','geometry');d,_=s.artifact('shared-base','directions');scores=d['direction_scores'];assert scores.shape[1]==g['neighbors'].shape[1] and scores.shape[2]>3
    energy=np.sum(scores.astype(float)**2,axis=1);ratios=energy/energy.sum(1,keepdims=True);np.testing.assert_allclose(ratios,g['spectrum'][:,:ratios.shape[1]],atol=1e-6)
    np.testing.assert_allclose(scores.mean(1),0,atol=1e-7)


def test_standard_metrics_truth_and_missing_support():
    perfect=metric_summary(np.array([0.,1.,2.]),np.array([0.,1.,2.]),np.ones(3),'numeric');assert perfect['mae']==0 and perfect['rmse']==0 and perfect['r2']==1
    poor=metric_summary(np.array([0.,1.,2.]),np.full(3,10.),np.ones(3),'numeric');assert poor['r2']<0 and poor['mae_gain']<0
    binary=metric_summary(np.array([0.,1.,0.,1.]),np.array([.1,.9,.2,.8]),np.full(4,.5),'boolean');assert binary['accuracy']==1 and binary['roc_auc']==1 and binary['brier']==pytest.approx(.025)
    category=metric_summary(np.array([0.,1.,2.]),np.eye(3),np.full((3,3),1/3),'category');assert category['accuracy']==1 and category['brier']==0 and category['macro_f1']==1
    assert metric_summary(np.array([np.nan]),np.array([1.]),np.array([0.]),'numeric')['n']==0
    assert metric_summary(np.array([0.,0.]),np.array([.1,.2]),np.full(2,.5),'boolean')['roc_auc'] is None


def test_replayed_probe_mae_and_brier_match_saved_losses(root):
    s=Store(root);a,_=s.artifact('shared-base','reconstruction');pred,meta=s.artifact('shared-base','probe_metrics')
    for r in meta['metrics']:
        if r['scope']!='Matched broad/local held-out support' or not r['n']:continue
        name=r['feature'];q=r['dimension'];account=r['account'];b=a[f'{name}__q{q}__broad'];local=a[f'{name}__q{q}__local'];mask=np.isfinite(b)&np.isfinite(local);expected=a[f'{name}__q{q}__{account}'][mask].mean();assert r.get('mae',r.get('brier'))==pytest.approx(expected,abs=2e-6)


def test_profiles_pair_anatomy_group_tables_and_help(view,app):
    p=view.evidence;view.evidence.setCurrentIndex(1);p.geometry_tabs.setCurrentIndex(1);p.refresh();assert p.geometry_canvas.minimumHeight()>300 and len(p.geometry_fig.axes)>3
    p.draw_anatomy();assert len(p.anatomy_fig.axes)==7 and len([ax for ax in p.anatomy_fig.axes if ax.name=='3d'])==2
    p.draw_direction_ribbons();assert len(p.direction_fig.axes)==2 and all(len(ax.lines)>1 for ax in p.direction_fig.axes)
    p.setCurrentIndex(3);p.refresh();assert p.regression_probes.rowCount()>0 and p.classification_probes.rowCount()>0
    p.setCurrentIndex(5);p.values_family.setCurrentIndex(1);p.values_feature.setCurrentText('broad');p.refresh();assert p.visible_value_keys==['feature/broad']
    assert p.scale_split.count()==2;p.scale_split.setSizes([100,300]);assert p.journey_split.count()==2
    view.open_reference();app.processEvents();text=view.reference_dialog.browser.toPlainText();assert 'Brier' in text and 'Lasso' in text;view.reference_dialog.search.setText('Brier');view.reference_dialog.find_next();assert 'Brier' in view.reference_dialog.browser.textCursor().selectedText();view.reference_dialog.close()


def test_compact_layout_and_contextual_sidebar(view,app):
    from types import SimpleNamespace
    p=view.evidence;p.setCurrentIndex(1);p.geometry_tabs.setCurrentIndex(0);p.refresh();app.processEvents()
    cards=p.compact_geometry.cards
    assert len(cards)==4 and p.geometry_tabs.count()==3
    assert cards['variation']['keys']==['geometry/effective_dimension','geometry/hidden_two','geometry/radius_dimension']
    axis=cards['variation']['fig'].axes[0]
    p.compact_geometry.pick(SimpleNamespace(inaxes=axis))
    assert view.field.currentText()=='geometry/effective_dimension'
    assert 'Independent neighbor variation'==view.interpretation_title.text()
    assert 'Median here:' in view.interpretation_reading.text()
    view.set_selection(np.array([1,3]));assert '2 canonical items kept' in view.interpretation_context.text()
    p.setCurrentIndex(2);p.refresh();app.processEvents()
    assert 'Left: full spectra' in view.interpretation_context.text()
    assert p.anatomy_canvas.minimumHeight()==430
    for row,name in enumerate(['Here','Ahead']):
        for col,kind in enumerate(['spectrum','hull','ribbon']):
            spec=p.anatomy_axes[name][kind].get_subplotspec()
            assert spec.rowspan.start==row and spec.colspan.start==col
        i=p.anatomy_indices[row]
        if i is not None:
            assert len(p.anatomy_axes[name]['spectrum'].patches)==len(view.landscape.arrays['spectrum'][i])
            assert len(p.anatomy_axes[name]['ribbon'].lines)==p.anatomy_scores[i].shape[0]+1
    assert p.anatomy_covariance_ax.get_subplotspec().colspan.stop==3
    view.set_lens('feature');view.feature.setCurrentText('category');assert 'Codes identify categories' in view.interpretation_body.text()
    view.unload();assert 'not available' in view.interpretation_title.text()
