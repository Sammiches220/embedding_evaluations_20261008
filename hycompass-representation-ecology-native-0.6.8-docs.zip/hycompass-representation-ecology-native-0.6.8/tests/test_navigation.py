"""Meaningful semantic and rendered coordination checks for current-format results."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from dataclasses import replace
import json
import numpy as np
import pytest
from ecology.navigation import Selection,resolve,compare_resolved,cases,resolve_saved
from ecology.source_support import sample_measurements
from ecology.store import Store,Token,Cancelled
from ecology.instruments import generate
from ecology.demo import demo

@pytest.fixture(scope='module')
def workspace(tmp_path_factory):
    root=demo(tmp_path_factory.mktemp('nav')/'demo',120,False);store=Store(root);generate(store,'shared-base',['geometry','probe_metrics','source_support']);return root


def fixture_payload(kind='numeric'):
    truth=np.array([0.,1.,1.,np.nan]);known=np.isfinite(truth)
    prediction=np.array([.1,.6,.2,.7]);base=np.ones(4)*.5
    if kind=='category':prediction=np.c_[1-prediction,prediction];base=np.c_[1-base,base]
    loss=np.abs(truth-prediction) if kind=='numeric' else (truth-prediction)**2 if kind=='boolean' else 2*(truth-prediction[:,1])**2
    a=dict(anchor_rows=np.array([4,1,9,3]),t__observed=truth,t__known=known,t__q1__broad__prediction=prediction,t__q1__baseline__prediction=base,t__q1__broad__loss=loss)
    m=dict(result_signature='frozen',definition_revision='map',targets=dict(t=dict(kind=kind,revision='truth',units='m' if kind=='numeric' else 'score',cardinality=2 if kind=='category' else None,labels={'0':dict(name='No'),'1':dict(name='Yes')})),metrics=[dict(feature='t',account='broad',dimension=1)],evaluation=dict(kind='held_out',verified=True,folds=3,groups='g',collection_revision='c'),collection_revision='c',domain_revision='d')
    return a,m

@pytest.mark.parametrize('kind',['numeric','boolean','category'])
def test_typed_views_and_subset_metrics(kind):
    payload=fixture_payload(kind);s=Selection('map','t',measurement='prediction');r=resolve(s,payload)
    assert r.reason is None and r.available.sum()==4
    assert r.rendering==('categorical' if kind=='category' else 'probability' if kind=='boolean' else 'value')
    observed=resolve(replace(s,measurement='observed'),payload);assert observed.available.sum()==3
    subset=resolve(replace(s,measurement='error',subset='here'),payload,[1,9]);assert subset.summary['measured']==2 and subset.summary['metrics']['n']==2
    assert subset.summary['metrics'].get('roc_auc') is None
    empty=resolve(replace(s,measurement='error'),payload,[]);assert empty.summary['measured']==0 and empty.summary['mean_measurement'] is None
    assert resolve(replace(s,target='unknown'),payload).reason
    assert resolve(replace(s,dimension=99),payload).reason
    assert resolve(replace(s,result_signature='stale'),payload).reason
    if kind!='numeric':
        score=resolve(replace(s,measurement='observed_score'),payload);log=resolve(replace(s,measurement='log_loss'),payload)
        assert score.available.sum()==3 and np.isfinite(log.values[log.available]).all()
    assert len(cases(subset))==2


def test_paired_canonical_support_sign_and_mismatches():
    a,m=fixture_payload();left=resolve(Selection('map','t'),(a,m));b={k:np.asarray(v)[[2,0,1,3]] for k,v in a.items()};b['t__q1__broad__loss']=b['t__q1__broad__loss']/2
    right=resolve(Selection('map','t'),(b,m));paired=compare_resolved(left,right);assert paired['n_shared']==3 and paired['mean_improvement']>0
    expected=np.nanmean(a['t__q1__broad__loss'])/2;assert paired['mean_improvement']==pytest.approx(expected)
    bad={**m,'targets':{'t':{**m['targets']['t'],'revision':'changed'}}};r=resolve(Selection('map','t'),(b,bad))
    with pytest.raises(ValueError,match='target'):compare_resolved(left,r)
    bad={**m,'evaluation':{**m['evaluation'],'verified':False}}
    with pytest.raises(ValueError):compare_resolved(left,resolve(Selection('map','t'),(b,bad)))
    ca,cm=fixture_payload('category');cb={**cm,'targets':{'t':{**cm['targets']['t'],'labels':{'0':{'name':'Yes'},'1':{'name':'No'}}}}}
    with pytest.raises(ValueError):compare_resolved(resolve(Selection('map','t'),(ca,cm)),resolve(Selection('map','t'),(ca,cb)))


def test_persisted_packages_and_no_source_targets(workspace,tmp_path):
    from ecology.packages import export_package,import_package
    store=Store(workspace);package=tmp_path/'view.zip';export_package(store,'shared-base',package,'viewing');dest=tmp_path/'imported';import_package(package,dest);portable=Store(dest)
    for target in ('broad','flag','category'):
        for measurement in ('prediction','error','observed'):
            result=resolve_saved(portable,Selection('shared-base',target,measurement=measurement));assert result.reason is None and result.available.any()
    # Predictions/losses remain inspectable even if observed support arrays were omitted.
    a,m=store.artifact('shared-base','probe_metrics');a={k:v for k,v in a.items() if not k.endswith(('__observed','__known'))}
    assert resolve(Selection('shared-base','broad',measurement='prediction'),(a,m)).available.any()
    assert resolve(Selection('shared-base','broad',measurement='observed'),(a,m)).reason


def test_diagnostics_exactness_scope_and_budget():
    vectors=np.array([[1.,0],[1.,0],[2.,0],[0,0],[np.nan,1],[0,1]])
    m=sample_measurements(vectors,Token());assert m['non_finite']==1 and m['finite_near_zero']==1
    assert m['exact_source']['repeated_rows']==1 and m['exact_unit_normalized']['repeated_rows']==2
    assert m['rank']['support']==4 and 'sample-only' in m['scope']
    with pytest.raises(ValueError):sample_measurements(np.ones((8193,2)),Token())
    token=Token();token.cancel()
    with pytest.raises(Cancelled):sample_measurements(vectors,token)


def test_actual_prediction_widgets(workspace,monkeypatch,tmp_path):
    from PySide6.QtWidgets import QApplication
    from ecology.native import MapWidget
    from ecology.jobs import Jobs
    app=QApplication.instance() or QApplication([]);jobs=Jobs(workspace);w=MapWidget(workspace,'shared-base',jobs,lambda *_:None)
    w.resize(1500,1000);w.show();app.processEvents()
    # No fitting/generation from any navigation actions.
    monkeypatch.setattr(jobs,'submit',lambda *_:pytest.fail('implicit generation'))
    try:
        w.set_lens('prediction');w.evidence.setCurrentWidget(w.prediction_panel);w.feature.setCurrentText('broad');w.dimension.setCurrentText('1');w.account.setCurrentIndex(w.account.findData('broad'));w.load_names(['probe_metrics']);app.processEvents()
        assert w.resolved_measurement.reason is None
        before=w.selected_rows.copy();w.prediction_cases.selectRow(0);np.testing.assert_array_equal(before,w.selected_rows)
        r=w.resolved_measurement;indices=np.intersect1d(w.landscape.rows,r.rows,return_indices=True);np.testing.assert_allclose(w.landscape.values[indices[1]],r.values[indices[2]],equal_nan=True)
        for name in ('flag','category'):
            w.feature.setCurrentText(name);w.load_names(['probe_metrics']);w.prediction_measure.setCurrentIndex(w.prediction_measure.findData('prediction'));app.processEvents()
            assert w.resolved_measurement.reason is None
            assert w.landscape.categorical==(name=='category')
            if name=='flag':
                w.contrast.setValue(2);assert w.landscape.colorbar.mappable.get_clim()==(0.,1.);w.contrast.setValue(1)
        w.prediction_measure.setCurrentIndex(w.prediction_measure.findData('error'));i=next(i for i in range(w.compare_variant.count()) if (w.compare_variant.itemData(i) or {}).get('account')=='local' and (w.compare_variant.itemData(i) or {}).get('dimension')==1);w.compare_variant.setCurrentIndex(i);app.processEvents()
        assert w.resolved_measurement.reason is None and 'n_shared' in w.resolved_measurement.summary
        w.prediction_subset.setCurrentIndex(w.prediction_subset.findData('kept'));w.set_selection(np.array([],np.int64));w.update_evidence();assert w.resolved_measurement.summary['n_shared']==0
        w.source_box.setChecked(True);w.load_names(['source_support']);app.processEvents();assert 'participation ratio' in w.source_text.toPlainText()
        assert w.reference_button.height()<45 and w.screen_prepare.height()==23 and w.landscape.height()>=220
        w.grab().save(str(tmp_path/'actual-widgets.png'))
    finally:w.dispose();w.close();jobs.close();app.processEvents()


def test_undefined_constant_and_zero_baseline_metrics():
    from ecology.probes import metric_summary
    constant=metric_summary(np.ones(4),np.ones(4),np.ones(4),'numeric');assert constant['r2'] is None and constant['baseline_mae']==0
    single_category=metric_summary(np.zeros(4),np.ones((4,1)),np.ones((4,1)),'category');assert single_category['log_loss']==0 and single_category['roc_auc'] is None
    one_class=metric_summary(np.zeros(4),np.ones(4)*.2,np.zeros(4),'boolean');assert one_class['roc_auc'] is None and one_class['brier_skill'] is None


def test_saved_audit_denominator_and_local_external_scoring(workspace):
    from ecology.results import register_result
    store=Store(workspace);a,m=store.artifact('shared-base','source_support');neighbors,_=store.artifact('shared-base','neighbors')
    counts=a['occurrences'];assert len(counts)==len(neighbors['context_rows']) and int(counts.sum())==neighbors['neighbors'].size
    assert m['neighbor_occurrences']['zero_occurrences']==int((counts==0).sum())
    d=store.read('shared-base');rows=store.membership('shared-base')[:6];ids=store.catalog.load('assets/ids.npy')[rows]
    descriptor=register_result(store,'shared-base',item_ids=ids,predictions=np.full(6,.4),target='flag',kind='boolean',scope='held_out',provenance='test producer',expected_revision=d['revision'])
    result=resolve_saved(store,Selection('shared-base','flag',component=descriptor['component'],account='external',dimension=0))
    assert result.reason is None and 'baseline_brier' not in result.summary['metrics']
    assert result.provenance['protocol']['verified'] is False


def test_navigation_api_uses_same_saved_contract(workspace):
    from fastapi.testclient import TestClient
    from api.app import create_app
    from api.runtime import RuntimeState
    from model.workspace.session import WorkspaceSession
    with TestClient(create_app(WorkspaceSession(workspace),RuntimeState())) as client:
        response=client.post('/ecology/navigation/resolve',json={'selection':{'map_id':'shared-base','target':'category','measurement':'prediction'},'subset_rows':[]})
        assert response.status_code==200,response.text
        body=response.json();assert body['rendering']=='categorical' and body['summary']['measured']==0 and body['selection']['protocol']=='held_out'
        response=client.post('/ecology/navigation/resolve',json={'selection':{'map_id':'shared-base','target':'category','result_signature':'wrong'}})
        assert response.status_code==200 and 'revision changed' in response.json()['reason']
