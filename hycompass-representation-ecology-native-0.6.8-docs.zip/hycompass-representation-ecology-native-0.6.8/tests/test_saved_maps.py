import base64
import io
import json
import os
import time
from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

from ecology.cards import (export_html, import_card, local_match, make_card, preset_rows,
                           read_card, saved_evidence, write_card)
from ecology.catalog import atomic_json
from ecology.demo import demo
from ecology.footprints import (FootprintUnavailable, Footprints, aggregate, footprint_rgba,
                                validate_reverse)
from ecology.store import Store
from model.workspace import WorkspaceSession


@pytest.fixture
def project(tmp_path):
    return demo(tmp_path / "source", n=90, generate_results=False)


def datasets(root):
    session = WorkspaceSession(root)
    return [session.build_view(spec) for spec in session.views()]


def test_aggregate_disjoint_overlap_boundary_and_missing():
    positions = np.array([[0, 0], [1, 1], [.5, .5], [np.nan, 0]])
    reverse = np.array([0, 1, -1, 3, 2])
    validate_reverse(np.array([0, 1, 4, 3]), reverse, 4, 5)
    with pytest.raises(ValueError, match="reverse"):
        validate_reverse(np.array([0, 1, 4, 3]), np.array([0, 1, 2, 3, 2]), 4, 5)
    first, present, projected = aggregate(np.arange(4), reverse, positions, (0, 1, 0, 1), 8)
    second, _, _ = aggregate(np.array([1, 4]), reverse, positions, (0, 1, 0, 1), 8)
    assert (present, projected) == (3, 2)
    assert list(zip(*np.nonzero(first))) == [(0, 0), (7, 7)]
    assert list(zip(*np.nonzero(second))) == [(4, 4), (7, 7)]


def test_projection_and_correspondence_revisions(project):
    store = Store(project)
    base, distorted = datasets(project)
    config = store.read("shared-base")["settings"]
    full = store.create("Full", "base", np.arange(90), config)["id"]
    empty_projection = store.create("Missing coordinate", "base", [0], config)["id"]
    worker = Footprints()
    try:
        original = worker.request(base, full).result(10)
        cross = worker.request(distorted, full).result(10)
        assert (original.members, original.present, original.projected) == (90, 90, 89)
        assert (cross.members, cross.present, cross.projected) == (90, 72, 71)
        assert original.projection != cross.projection
        points = footprint_rgba(original, fill=False, boundary=False)
        assert np.count_nonzero(points[..., 3]) == np.count_nonzero(original.counts)
        narrow = footprint_rgba(original, radius=1, points=False)
        wide = footprint_rgba(original, radius=12, points=False)
        assert np.count_nonzero(wide[..., 3]) > np.count_nonzero(narrow[..., 3])
        assert not footprint_rgba(original, fill=False, boundary=False, points=False).any()
        assert worker.request(base, empty_projection).result(10).projected == 0
        store.rename(full, "A new title")
        assert worker.request(base, full).result(10) is original
        assert len(worker.mappings) == 2

        store.catalog.register_domain("base", "items")
        remapped = worker.request(base, full).result(10)
        assert remapped is not original and remapped.projection != original.projection
        path = project / "assets/base-positions.npy"
        moved = np.array(base.positions)
        moved[1] = (-1.8, 1.8)
        temp = path.with_name("replacement.npy")
        np.save(temp, moved)
        os.replace(temp, path)
        with pytest.raises(FootprintUnavailable, match="Stale projection"):
            worker.request(base, full).result(10)
        refreshed = worker.request(datasets(project)[0], full).result(10)
        assert refreshed.projection != remapped.projection
        assert not np.array_equal(refreshed.counts, remapped.counts)
        (store.folder(full) / "membership.npy").unlink()
        with pytest.raises(FileNotFoundError):
            worker.request(datasets(project)[0], full).result(10)
    finally:
        worker.executor.shutdown()


def test_portable_cards(project, tmp_path):
    demo_source = Path(__file__).resolve().parents[1] / "demo_workspace"
    store = Store(demo_source)
    definition = store.read("upper-base")
    anchors, findings = saved_evidence(store, definition["id"])
    assert anchors > 0 and findings
    definition["description"] = "<script>alert(1)</script>"
    worker = Footprints()
    try:
        footprint = worker.request(datasets(demo_source)[0], definition["id"]).result(10)
    finally:
        worker.executor.shutdown()
    card = make_card(definition, footprint, anchors=anchors, findings=findings[:1])
    html = tmp_path / "card.html"
    export_html(card, html)
    page = html.read_text()
    assert "data:image/png;base64," in page and "<script>" not in page and "&lt;script&gt;" in page
    assert card["findings"][0]["scope"] in page
    path = tmp_path / "card.json"
    atomic_json(path, card)
    assert read_card(path) == card
    assert local_match(store, card) == definition["id"]
    anchors, findings, overview, charts, features = saved_evidence(
        store, "shared-base", include_overview=True, include_charts=True, include_features=True)
    rows = preset_rows(findings, "Broad overview")
    assert 2 < len(rows) <= 24
    assert {findings[row]["result"].split("/")[0] for row in rows} >= {
        "geometry", "source_support", "feature_distribution", "reconstruction"}
    assert all(findings[row]["result"].startswith("feature_distribution/")
               for row in preset_rows(findings, "Target distributions"))
    report = make_card(store.read("shared-base"), anchors=anchors,
                       findings=[findings[row] for row in sorted(rows)], overview=overview)
    report_path = tmp_path / "overview.json"
    write_card(report, report_path)
    assert read_card(report_path) == report
    export_html(report, html, charts)
    page = html.read_text()
    assert "Saved result inventory" in page
    assert "Configured targets" in page
    assert '<svg viewBox=' in page and "Values and provenance" in page
    assert "How the graph connects" in page
    assert "Can you reach the rest of this neighborhood?" in page
    assert "How is this region organized?" in page
    assert "What can we say about the items?" in page
    assert "What survives a change of view?" in page
    assert "What can the representation recover?" in page
    assert page.count('<svg viewBox=') >= 15
    assert "broad account</h3>" in page and "local account</h3>" in page
    export_html(report, html, charts, features=features)
    consolidated = html.read_text()
    assert consolidated.count('id="features"') == 1
    assert 'id="models"' not in consolidated and 'id="targets"' not in consolidated
    assert "Where do predicted distances miss?" in consolidated
    assert "How quickly does local variation fall away?" in consolidated
    assert "Distribution of broad" in consolidated  # embedded in the feature explorer
    assert "Distribution of broad</h3>" not in consolidated
    assert "broad account</h3>" not in consolidated
    assert 'class="tile"' not in consolidated
    counts = [item for item in findings if item["target"] == "category"
              and item["metric"].startswith("Count for code")]
    selected_counts = {**report, "findings": counts,
                       "overview": {**report["overview"], "modules": []}}
    export_html(selected_counts, html, charts)
    assert "Selected distribution counts" in html.read_text()
    assert '<svg viewBox=' not in html.read_text()
    assert import_card(project, report_path) == report
    assert local_match(store, {**card, "revision": "old"}) is None
    assert local_match(Store(project), card) is None
    assert import_card(project, path) == import_card(project, path)
    assert len(list((project / "map-cards").glob("*.json"))) == 2
    other = Store(project)
    assert other.read("upper-base")["revision"] != card["revision"]
    other.delete("upper-base")
    assert local_match(other, card) is None

    blank = make_card(Store(project).read("shared-base"))
    assert blank["findings"] == [] and blank["anchors"] is None and blank["projection"] is None
    export_html(blank, html)
    assert "Location unavailable" in html.read_text()
    for invalid in ({**card, "version": True}, {**card, "png": "not PNG"},
                    {**card, "projected": card["members"] + 1},
                    {**card, "findings": [{**card["findings"][0], "value": 10**400}]}):
        path.write_text(json.dumps(invalid))
        with pytest.raises(ValueError):
            read_card(path)
    oversized_png = io.BytesIO()
    Image.new("RGB", (257, 1)).save(oversized_png, format="PNG")
    atomic_json(path, {**card, "png": base64.b64encode(oversized_png.getvalue()).decode("ascii")})
    with pytest.raises(ValueError, match="PNG"):
        read_card(path)
    path.write_bytes(b" " * (512 * 1024 + 1))
    with pytest.raises(ValueError, match="exceeds"):
        read_card(path)


def test_population_sidebar_and_existing_map_tab(project, monkeypatch):
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    from ui.main_window import MainWindow

    app = QApplication.instance() or QApplication([])
    store = Store(project)
    projection = store.catalog.manifest.projections["base"]
    store.catalog.manifest.projections["alternate"] = replace(projection, id="alternate")
    store.catalog.manifest.save()
    definition = store.read("shared-base")
    store.create("Same domain other projection", "base", store.membership("shared-base"),
                 {**definition["settings"], "projection": "alternate"})
    store.create("Map-local PCA", "base", store.membership("shared-base"),
                 {**definition["settings"], "projection": None})
    window = MainWindow(WorkspaceSession(project))
    view = window._current()
    panel = view.saved_maps
    assert not panel.enabled.isChecked()
    assert view.map.saved_footprint is None
    view._set_working_selection(np.array([2, 3], dtype=np.uint32))
    view.set_highlights(np.array([4], dtype=np.uint32))
    view.map.camera.zoom = 2.5

    def settle(current):
        deadline = time.monotonic() + 5
        while current.pending is not None and time.monotonic() < deadline:
            app.processEvents()
            time.sleep(.005)
        assert current.pending is None

    try:
        panel.activate("upper-base")
        assert panel.list.count() == 3
        assert "Same domain other projection" not in [panel.list.item(i).text() for i in range(panel.list.count())]
        panel.activate("shared-base")
        settle(panel)
        assert view.map.saved_footprint is not None
        assert "Same items / base" == panel.preview.title.text()
        assert len(panel.visible_checks()) == 2
        assert all(panel.ready[key][0] is not None for key in panel.visible_checks())
        from PySide6.QtCore import Qt
        panel.list.currentItem().setCheckState(Qt.CheckState.Unchecked)
        assert view.map.saved_footprint is not None and len(panel.visible_checks()) == 1
        panel.list.currentItem().setCheckState(Qt.CheckState.Checked)
        settle(panel)
        panel.open_map()
        opened = window.tabs.currentWidget()
        assert opened.key == "shared-base"
        panel.open_map()
        assert window.tabs.currentWidget() is opened and window.tabs.count() == 2
        panel.enabled.setChecked(False)
        assert view.map.saved_footprint is None
        assert view.selected_rows.tolist() == [2, 3]
        assert view.highlight_rows.tolist() == [4]
        assert view.map.camera.zoom == 2.5

        definition = Store(project).read("shared-base")
        panel.activate("shared-base", {"id": "wrong projection"}, definition["revision"])
        settle(panel)
        assert view.map.saved_footprint is not None  # the other checked map is still visible
        assert panel.ready["shared-base"][0] is None
        assert "differs" in panel.preview.details.text()
        panel.activate("shared-base")
        settle(panel)
        panel.radius.setValue(13)
        assert panel.pending is None
        other = view.session.views()[1]
        window._reconfigure(view, replace(other, id=view.spec.id))
        changed = window._current()
        assert changed.map.saved_footprint is None
        settle(changed.saved_maps)
        assert changed.saved_maps.list.count() == 1
        assert changed.saved_maps.radius.value() == 13
        assert changed.map.saved_footprint is None
        changed.saved_maps.activate("shared-distorted")
        settle(changed.saved_maps)
        assert changed.map.saved_footprint is not None
        assert "distorted" in changed.saved_maps.preview.details.text()
    finally:
        window.close()


def test_card_dialog_presets_and_filter(monkeypatch, tmp_path):
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication, QFileDialog
    from ui.panels.saved_maps import CardDialog

    app = QApplication.instance() or QApplication([])
    root = Path(__file__).resolve().parents[1] / "demo_workspace"
    dialog = CardDialog(Store(root), "shared-base", datasets(root)[0], None)
    try:
        dialog.evidence.result(10)
        dialog.pending.result(10)
        dialog.finish()
        assert dialog.card["png"] and dialog.card["findings"] == []
        initial = dialog.checked_findings()
        assert len(initial) > 2
        dialog.finding_search.setText("never matches anything")
        assert dialog.checklist.item(0).isHidden()
        assert dialog.checked_findings() == initial
        dialog.preset.setCurrentText("Clear findings")
        assert not dialog.checked_findings()
        dialog.checklist.item(0).setCheckState(Qt.CheckState.Checked)
        assert len(dialog.checked_entries("module")) == 1
        assert not dialog.checked_findings()
        dialog.checklist.item(1).setCheckState(Qt.CheckState.Checked)
        assert len(dialog.checked_findings()) == 1
        path = tmp_path / "compact.png"
        monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *args: (str(path), ""))
        dialog.export("card")
        with Image.open(path) as image:
            assert image.format == "PNG" and image.size == (1200, 1212)
            assert len(image.getcolors(100000)) > 50
        app.processEvents()
    finally:
        dialog.close()


def test_geometry_only_card_keeps_measurements_and_sections(project, monkeypatch):
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication
    from ecology.instruments import generate
    from ui.panels.saved_maps import CardDialog

    store = Store(project)
    generate(store, "shared-base", ["geometry"])
    app = QApplication.instance() or QApplication([])
    dialog = CardDialog(store, "shared-base", datasets(project)[0], None)
    try:
        dialog.evidence.result(10)
        dialog.pending.result(10)
        dialog.finish()
        assert {item["name"] for item in dialog.checked_entries("module")} >= {"geometry", "neighbors"}
        assert dialog.checklist.count() > 10
        assert dialog.checked_findings()
        card = {**dialog.card, "version": 2, "findings": [],
                "overview": {**dialog.overview, "modules": dialog.checked_entries("module")}}
        path = project / "geometry-report.html"
        export_html(card, path, dialog.charts)
        page = path.read_text()
        assert page.count('<svg viewBox=') >= 7
        assert "How quickly does local variation fall away?" in page
        assert "How far away is the available support?" in page
        dialog.preset.setCurrentText("Geometry and support")
        before = dialog.checked_findings()
        dialog.show_measurements.setChecked(False)
        assert dialog.checked_findings() == before
        assert all(dialog.checklist.item(i).isHidden() for i in range(dialog.checklist.count())
                   if "finding" in dialog.checklist.item(i).data(Qt.ItemDataRole.UserRole))
        app.processEvents()
    finally:
        dialog.close()


def test_feature_report_reads_saved_evidence_and_escapes_data(tmp_path):
    from ecology.feature_report import FeatureEvidence, feature_section

    root = Path(__file__).resolve().parents[1] / "demo_workspace"
    _, _, _, _, features = saved_evidence(
        Store(root), "shared-base", include_overview=True, include_features=True)
    broad = next(item for item in features if item["name"] == "broad")
    assert broad["coverage"] and broad["associations"] and broad["distributions"]
    assert any(series[1] == "MAE" and len(series[-1]) > 1 for series in broad["series"])
    assert len({tuple(row[:4]) for row in broad["series"]}) == len(broad["series"])

    collector = FeatureEvidence({})
    name = "</script><script>alert(1)</script>"
    for index in range(400):
        collector.add(f"{name}-{index}", "reconstruction--batch/signature", "MAE", "broad",
                      "held-out", 2, 0.5, 12, "numeric")
    payload = collector.payload()
    assert len(payload) == 400
    section = feature_section(payload)
    assert name not in section
    assert section.count("<script") == 2
    assert 'id="fx-data"' in section
    blank = make_card(Store(root).read("shared-base"))
    path = tmp_path / "feature-report.html"
    export_html(blank, path, features=payload)
    assert "Feature representation and reconstruction" in path.read_text()
    export_html(blank, path)
    assert 'id="fx-data"' not in path.read_text()
