import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import numpy as np
from ecology.reading import FAMILIES,compact_families,reading_for


def test_compact_groups_use_available_evidence_and_active_scale():
    fields={'geometry/effective_dimension':[], 'geometry/radius':[], 'compression/pca_q2_jaccard':[], 'compression/pca_q4_jaccard':[]}
    groups=compact_families(fields,'4')
    assert [g['title'] for g in groups]==[f[1] for f in FAMILIES]
    assert groups[2]['keys']==[]
    assert groups[3]['keys']==['compression/pca_q4_jaccard']
    assert all(k in fields for g in groups for k in g['keys'])


def test_reading_respects_units_categories_missing_and_signed_gain():
    values=np.array([0.,1.,np.nan,1.])
    boolean=reading_for('feature/flag',values,[0,1],[3],feature_kind='boolean')
    assert '0.5 (n=2)' in boolean['reading'] and 'Missing is different from false' in boolean['reading']
    category=reading_for('feature/group',values,[0,1],[3],feature_kind='category',labels={'0':{'name':'Apple'},'1':{'name':'Pear'}})
    assert 'Apple: 1; Pear: 1' in category['reading'] and 'Median' not in category['reading']
    gain=reading_for('reconstruction/target__q2__gain',np.array([-.2,.1]),[0],[1],feature_kind='numeric')
    assert 'negative values mean it performs worse' in gain['body'] and 'MAE' in gain['body'] and 'Mean here' in gain['reading']
    missing=reading_for(None,None,[],[])
    assert 'not a zero' in missing['body']
    empty=reading_for('geometry/radius',values,[],[])
    assert 'not enough finite support' in empty['reading']
