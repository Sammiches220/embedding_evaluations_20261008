import json
import os
import shutil
from pathlib import Path
import numpy as np
import pytest
from ecology.catalog import Catalog,correspondence,array_digest
from ecology.store import Store,Token,Cancelled,Residency
from ecology.demo import demo
from ecology.instruments import generate,resolve,geometry,plan
from ecology.comparison import compare,controlled_pair
from ecology.kernels import accessibility as acc

@pytest.fixture(scope='module')
def source(tmp_path_factory):
    return demo(tmp_path_factory.mktemp('ecology')/'demo',n=120,generate_results=False)

@pytest.fixture
def store(tmp_path,source):
    target=tmp_path/'workspace';shutil.copytree(source,target);return Store(target)


def test_shuffled_partial_correspondence():
    f,r=correspondence(np.array([10,11,12,13]),np.array([13,10,12]))
    assert f.tolist()==[3,0,2] and r.tolist()==[1,-1,2,0]
    for c,e in [([1,1],[1]),([1,2],[1,1]),([1,2],[3])]:
        with pytest.raises(ValueError):correspondence(np.array(c),np.array(e))


def test_mapping_validation_and_known_id_roundtrip(store):
    c=store.catalog;f,r=c.correspondence_maps('distorted');rows=np.arange(20)
    canonical=c.to_collection('distorted',rows);present,domain=c.to_domain('base',canonical)
    ids=c.load(c.manifest.domains['distorted'].item_ids)[rows]
    np.testing.assert_array_equal(np.sort(ids),c.load(c.manifest.domains['base'].item_ids)[domain])
    path=c.resolve(c.raw['domains']['base']['reverse']);np.save(path,np.full(c.n('items'),-1,np.int64));c._maps.clear()
    with pytest.raises(ValueError):c.correspondence_maps('base')


def test_frozen_membership_and_display_eligibility(store):
    d=store.read('shared-base');ctx=resolve(store,'shared-base')
    assert len(store.membership(d['id']))==d['n_members']
    assert ctx['support']['valid_anchors']==len(store.membership(d['id']))
    # Population has a valid vector with no finite display coordinates.
    new=store.create('all','base',np.arange(store.catalog.n('items')),{'anchors':120,'context_cap':120,'k':8,'projection':'base'})
    ctx=resolve(store,new['id']);assert ctx['support']['finite_display_anchors']==119
    assert ctx['n']==120 and new['n_members']==120


def test_incremental_generation_restart_and_reuse(store):
    generate(store,'shared-base',['geometry']);folder=store.artifact_path('shared-base','geometry');before=(folder/'spectrum.npy').stat().st_mtime_ns
    generate(Store(store.catalog.root),'shared-base',['routes']);assert (folder/'spectrum.npy').stat().st_mtime_ns==before
    reopened=Store(store.catalog.root);a,m=reopened.artifact('shared-base','geometry');assert a['spectrum'].shape[0]>0
    d=reopened.read('shared-base');cfg={**d['settings'],'dimensions':[1,2]}
    extra=reopened.create('different reconstruction dimensions',d['domain'],reopened.membership(d['id']),cfg)
    generate(reopened,extra['id'],['geometry']);_,meta=reopened.artifact(extra['id'],'geometry')
    assert meta['reused_from']=='shared-base'
    with pytest.raises(ValueError):reopened.delete_artifact('shared-base','geometry')
    reopened.delete_artifact('shared-base','routes');reopened.delete_artifact('shared-base','geometry')
    assert not folder.exists()


def test_cancel_and_failed_publication(store):
    t=Token();t.cancel()
    with pytest.raises(Cancelled):generate(store,'shared-base',['geometry'],t)
    assert not store.artifact_path('shared-base','geometry').exists()
    d=store.read('shared-base');key=store.create('unsupported no features','base',store.membership(d['id']),{'features':[]})['id']
    with pytest.raises(ValueError):generate(store,key,['reconstruction'])
    assert store.status(key)['reconstruction']['status']=='failed'
    assert not store.artifact_path(key,'reconstruction').exists()


def test_source_revision_and_presentation_labels(store):
    c=store.catalog;generate(store,'shared-base',['geometry']);signature=store.signature('shared-base','geometry')
    path=c.resolve(c.raw['features']['category']['labels']);labels=json.loads(path.read_text());labels['labels']['0']['name']='Renamed';path.write_text(json.dumps(labels))
    assert c.labels('category')['0']['name']=='Renamed';store.validate('shared-base');assert signature==store.signature('shared-base','geometry')
    source=c.resolve(c.manifest.domains['base'].embeddings);vectors=np.load(source,mmap_mode='r+');vectors[0,0]+=1;vectors.flush();del vectors
    with pytest.raises(ValueError,match='Stale dependency'):store.validate('shared-base')


def test_same_size_explicit_reregistration_invalidates(store):
    c=store.catalog;c.register_domain('base','items');fresh=Store(c.root)
    with pytest.raises(ValueError,match='revision'):fresh.validate('shared-base')


def test_unknown_false_zero_and_category_zero_distinct(store):
    c=store.catalog
    for key in ['broad','flag','category']:
        v,known=c.feature(key,np.arange(c.n('items')));assert not known[0];assert np.any(known&(v==0)) if key!='broad' else True
    v=np.zeros(c.n('items'),np.int16);p=c.root/'assets/bad.npy';np.save(p,v)
    with pytest.raises(ValueError):c.register_feature('bad','items','category','assets/bad.npy','assets/category-valid.npy',cardinality=0)


def test_group_protocol_numeric_matches_actual_130_fixture():
    data=np.load(Path(__file__).parent/'fixtures/accessibility_130.npz');meta=json.loads((Path(__file__).parent/'fixtures/accessibility_130.json').read_text())
    result=acc.analyze(data['x'],{'signal':data['target']},data['groups'],meta['settings'],meta['seed'])
    for q,fields in result['views']['signal'].items():
        for k,value in fields.items():np.testing.assert_allclose(value,data['q'+q+'_'+k],rtol=1e-6,atol=1e-6,equal_nan=True)
    assert result['selections']==meta['selections']
    fold=acc.fold_ids(data['groups'],3)
    for group in np.unique(data['groups']):assert len(np.unique(fold[data['groups']==group]))==1
    assert any(np.nanmin(fields['gain'])<0 for fields in result['views']['signal'].values())


def test_geometry_spectrum_matches_actual_130_fixture():
    data=np.load(Path(__file__).parent/'fixtures/spectra_130.npz');x=data['x'];n=len(x)
    ctx=dict(x=x,n=n,cfg={'k':8},xy=x[:,:2],anchors=np.arange(n),rows=np.arange(n),support={},provenance='fixture')
    from ecology.instruments import neighbors
    from types import SimpleNamespace
    product=neighbors(ctx,None,None,Token(),lambda *_:None)
    arrays,meta=geometry(ctx,SimpleNamespace(artifact=lambda *_:product),None,Token(),lambda *_:None)
    np.testing.assert_allclose(arrays['spectrum'],data['spectrum'],atol=1e-6)
    np.testing.assert_allclose(arrays['effective_dimension'],data['effective'],atol=1e-5)


def test_controlled_pair_and_changed_selection(store):
    ids=np.arange(store.catalog.n('items'));pair=controlled_pair(store,'matched','base','distorted',ids,{'anchors':64,'context_cap':96,'k':8})
    generate(store,pair['a'],['geometry']);generate(store,pair['b'],['geometry'])
    result=compare(store,pair['a'],pair['b']);assert result['measured_overlap']==64 and result['context_matched']
    assert pair['excluded']==24;assert result['changed_factors']==['embedding']
    generate(store,'upper-base',['geometry']);result=compare(store,pair['a'],'upper-base');assert 'question population' in result['changed_factors']


def test_context_boundary_changes_and_filtration_monotonic(store):
    generate(store,'upper-base',['geometry']);generate(store,'upper-within',['geometry'])
    a,_=store.artifact('upper-base','geometry');b,_=store.artifact('upper-within','geometry')
    assert len(a['context_rows'])>len(b['context_rows']);assert not np.allclose(a['radius'],b['radius'])
    labels=a['filtration_labels'];counts=[len(np.unique(v)) for v in labels];assert counts==sorted(counts,reverse=True)
    for left,right in zip(labels,labels[1:]):
        for component in np.unique(left):assert len(np.unique(right[left==component]))==1


def test_real_classification_baselines_and_matched_gains(store):
    generate(store,'shared-base',['reconstruction']);a,m=store.artifact('shared-base','reconstruction')
    assert any(k.startswith('flag__') for k in a) and any(k.startswith('category__') for k in a)
    baseline=a['flag__q1__baseline'];assert np.nanmin(baseline)>=0 and np.nanmax(baseline)<=1
    records=[r for r in m['classification'] if 'matched_gain' in r and r['n_matched']]
    for r in records:assert r['matched_gain']==pytest.approx(r['matched_broad_mean']-r['local_mean'])
    assert all(r['loss'].startswith('multiclass') for r in records if r['feature']=='category')
    # No category-code regression magnitudes: categorical priors sum to one.
    for account in m['classification_accounts']:
        if account['feature']=='category':assert sum(account['prior'])==pytest.approx(1)


def test_ram_and_work_guards_and_disk_lifetime(store):
    d=store.create('over budget','base',np.arange(100),{'max_work':1,'anchors':64,'context_cap':100})
    assert plan(store,d['id'])['over_budget']
    with pytest.raises(ValueError,match='Over budget'):generate(store,d['id'],['geometry'])
    cache=Residency(100);cache.put('one',np.zeros(10,np.float64));cache.put('two',np.zeros(5,np.float64));assert 'one' not in cache.cache
    cache.pins.add('two')
    with pytest.raises(ValueError):cache.put('three',np.zeros(10,np.float64))
    generate(store,'shared-base',['geometry']);size=store.disk_bytes('shared-base');cache.clear();assert store.disk_bytes('shared-base')==size


def test_api_canonical_mapping_and_features(store):
    from fastapi.testclient import TestClient
    from api.app import create_app
    from api.runtime import RuntimeState
    from model.workspace.session import WorkspaceSession
    client=TestClient(create_app(WorkspaceSession(store.catalog.root),RuntimeState()))
    r=client.post('/ecology/correspondence',json={'source_domain':'distorted','target_domain':'base','rows':[0,1,2]});assert r.status_code==200;body=r.json();assert len(body['item_ids'])==3
    r=client.post('/ecology/features',json={'collection':'items','collection_rows':[0,1,2],'features':['flag','category']});assert r.status_code==200 and r.json()['columns']['flag'][0] is None
    assert client.get('/ecology/maps/shared-base/plan').status_code==200


def test_frozen_accounts_evaluate_without_refit(store):
    generate(store,'shared-base',['reconstruction']);d=store.read('shared-base')
    cfg={**d['settings'],'reference_map':d['id']}
    new=store.create('evaluate saved reference',d['domain'],store.membership(d['id']),cfg)
    generate(store,new['id'],['reference_evaluation'])
    original,_=store.artifact(d['id'],'reconstruction');evaluation,meta=store.artifact(new['id'],'reference_evaluation')
    for name in ['broad','flag','category']:
        for q in [1,2,4,8]:
            for field in ['broad','local','baseline','gain']:
                key=f'{name}__q{q}__{field}';np.testing.assert_allclose(evaluation[key],original[key],atol=2e-5,equal_nan=True)
    assert meta['reference']==d['id']


def test_typed_source_queries_keep_unknown_separate(store):
    from ecology.selection import query
    c=store.catalog;rows=np.arange(c.n('items'))
    known=query(c,'items',rows,'flag','known');unknown=query(c,'items',rows,'flag','unknown');false=query(c,'items',rows,'flag','eq',0)
    assert not len(np.intersect1d(false,unknown));assert len(known)+len(unknown)==len(rows)
    with pytest.raises(ValueError):query(c,'items',rows,'category','gt',0)


def test_cancel_running_and_stale_revision_publication(store):
    token=Token()
    def progress(stage,fraction):
        if stage=='spectra':token.cancel()
    with pytest.raises(Cancelled):generate(store,'shared-base',['geometry'],token,progress)
    assert store.status('shared-base')['geometry']['status']=='cancelled'
    assert not store.artifact_path('shared-base','geometry').exists()
    def stale(stage,fraction):
        if stage=='spectra':
            path=store.folder('shared-base')/'definition.json';d=json.loads(path.read_text());d['revision']='new-revision';path.write_text(json.dumps(d))
    with pytest.raises(ValueError,match='modified'):generate(store,'shared-base',['geometry'],progress=stale)
    assert not store.artifact_path('shared-base','geometry').exists()


def test_compression_is_distinct_and_camera_independent(store):
    generate(store,'shared-base',['compression']);a,m=store.artifact('shared-base','compression')
    assert 'projection_neighbor_jaccard' in a and 'pca_q2_residual_fraction' in a
    assert np.nanmean(a['pca_q8_residual_fraction'])<np.nanmean(a['pca_q1_residual_fraction'])


def test_bounded_near_shortest_routes_and_degenerate_hulls():
    from ecology.kernels.geometry import sparse_graph
    from ecology.kernels.route_set import route_set
    from ecology.kernels.neighborhood_hull import neighborhood_hull
    graph=sparse_graph(4,np.array([[0,1],[1,3],[0,2],[2,3]]),np.ones(4));routes=route_set(graph,0,3,limit=2)
    assert len(routes['paths'])==2 and routes['entropy_bits']==pytest.approx(1)
    assert neighborhood_hull(dict(offsets=np.zeros((12,3)),spectrum=[0,0,0]))['triangles']==[]
