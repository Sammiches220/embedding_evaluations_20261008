from pathlib import Path
import json
import zipfile
import numpy as np
import pytest
from ecology.demo import demo
from ecology.store import Store,Token
from ecology.instruments import generate,dependency_order,nearest
from ecology.packages import export_package,import_package,attach_package
from ecology.results import register_result

@pytest.fixture
def store(tmp_path):return Store(demo(tmp_path/'source',n=90,generate_results=False))

def test_rename_duplicate_and_signature_identity(store):
    generate(store,'shared-base',['geometry']);d=store.read('shared-base');sig=store.signature(d['id'],'geometry')
    renamed=store.rename(d['id'],'Renamed',d['metadata_revision'])
    assert renamed['revision']==d['revision'];assert store.artifact(d['id'],'geometry')[1]['result_signature']==sig
    with pytest.raises(ValueError,match='conflict'):store.rename(d['id'],'Again',d['metadata_revision'])
    copy=store.duplicate(d['id'],'Copy');assert copy['id']!=d['id'];assert copy['revision']==d['revision'];assert store.reusable(copy['id'],'geometry')==d['id']
    store.catalog.raw['collections']['items']['revision']='different'
    store.catalog.save();assert store.signature(d['id'],'geometry')==sig

def test_missing_targets_do_not_block_geometry(store):
    generate(store,'shared-base',['geometry']);store.catalog.resolve(store.catalog.raw['features']['broad']['values']).unlink()
    assert store.artifact('shared-base','geometry')[0]['xy'].shape[1]==2
    generate(store,'shared-base',['routes'])
    with pytest.raises(ValueError,match='Missing'):generate(store,'shared-base',['reconstruction'])

def test_portable_saved_view_without_sources(store,tmp_path):
    generate(store,'shared-base',['geometry']);package=tmp_path/'map.hcmap';export_package(store,'shared-base',package,'viewing')
    installed=tmp_path/'relocated';report=import_package(package,installed);s=Store(installed)
    assert report['capabilities']['view']['geometry']['available'];assert not report['capabilities']['compute']['geometry']['available']
    assert s.artifact('shared-base','geometry')[0]['anchor_rows'].shape==store.artifact('shared-base','geometry')[0]['anchor_rows'].shape
    with pytest.raises(ValueError,match='new'):import_package(package,installed)

def test_full_package_recompute_and_attach(store,tmp_path):
    generate(store,'shared-base',['geometry']);view=tmp_path/'view.hcmap';full=tmp_path/'full.hcmap'
    export_package(store,'shared-base',view,'viewing');export_package(store,'shared-base',full,'full')
    installed=tmp_path/'installed';import_package(view,installed);result=attach_package(full,installed);assert result['attached']>0
    s=Store(installed);assert s.capabilities('shared-base')['compute']['reconstruction']['available'];generate(s,'shared-base',['reconstruction'])

def test_checksum_tamper_is_transactional(store,tmp_path):
    p=tmp_path/'map.hcmap';export_package(store,'shared-base',p,'definition');bad=tmp_path/'bad.hcmap'
    with zipfile.ZipFile(p) as src,zipfile.ZipFile(bad,'w') as dst:
        for name in src.namelist():
            data=src.read(name)
            if name.startswith('payload/') and data.startswith(b'\x93NUMPY'):data=data[:-1]+bytes([data[-1]^1])
            dst.writestr(name,data)
    with pytest.raises(ValueError,match='checksum'):import_package(bad,tmp_path/'failed')
    assert not (tmp_path/'failed').exists()

def test_traversal_rejected(store,tmp_path):
    p=tmp_path/'bad.hcmap'
    with zipfile.ZipFile(p,'w') as z:z.writestr('../escape','x')
    with pytest.raises(ValueError,match='Unsafe'):import_package(p,tmp_path/'bad')

def test_neighbors_order_and_ties(store):
    x=np.array([[0.,0.],[1,0],[-1,0],[0,1],[0,-1]])
    distances,indices=nearest(x,x[:1],2,Token(),np.array([0]));assert indices.tolist()==[[1,2]]
    assert dependency_order(['probe_metrics'])==['reconstruction','probe_metrics']
    assert dependency_order(['geometry'])==['resolved_support','neighbors','geometry']
    generate(store,'shared-base',['neighborhood_agreement']);a,m=store.artifact('shared-base','neighborhood_agreement');assert 'flag__same_class_fraction' in a

def test_external_unknown_ids_and_missing_targets(store):
    d=store.read('shared-base');rows=store.membership(d['id'])[:4];ids=store.catalog.load('assets/ids.npy')[rows]
    for f in store.catalog.raw['features'].values():store.catalog.resolve(f['values']).unlink()
    store.catalog.resolve(store.catalog.manifest.domains['base'].embeddings).unlink()
    result=register_result(store,d['id'],item_ids=ids,predictions=np.ones(4)*.4,target='novel',kind='boolean',scope='external',provenance='test producer',expected_revision=d['revision'])
    assert result['metrics_verified'] is False;assert store.artifact(d['id'],result['component'])[0]['predictions'].shape==(4,)

def test_reference_consumers_block_delete(store):
    cfg=store.read('shared-base')['settings'];store.create('consumer','base',store.membership('shared-base'),{**cfg,'reference_map':'shared-base'},key='consumer')
    with pytest.raises(ValueError,match='referenced'):store.delete('shared-base')
    with pytest.raises(ValueError,match='dependent'):store.delete_artifact('shared-base','reconstruction')

def test_no_workspace_conversion(store):
    from model.workspace.manifest import WorkspaceManifest
    with pytest.raises(ValueError,match='Unsupported workspace'):WorkspaceManifest(store.catalog.root,{'format_version':3})

def test_saved_neighbor_derivation_without_embeddings(store):
    generate(store,'shared-base',['neighbors']);store.catalog.resolve(store.catalog.manifest.domains['base'].embeddings).unlink()
    generate(store,'shared-base',['neighborhood_agreement']);assert store.artifact_path('shared-base','neighborhood_agreement').exists()

def test_source_only_distribution(store):
    store.catalog.resolve(store.catalog.manifest.domains['base'].embeddings).unlink()
    generate(store,'shared-base',['feature_distribution']);assert store.artifact('shared-base','feature_distribution')[1]['summaries']['flag']['known']>0

def test_reconstruction_batches_survive_cancel_and_resume(store):
    from ecology.instruments import resolve,reconstruction
    from ecology.batches import target_batches,read_batch
    from ecology.store import Cancelled
    for i in range(9):store.catalog.register_feature('extra'+str(i),'items','numeric','assets/broad.npy','assets/broad-valid.npy')
    cfg={**store.read('shared-base')['settings'],'features':['extra'+str(i) for i in range(9)]}
    d=store.create('Batched','base',store.membership('shared-base'),cfg)
    token=Token()
    def cancel(stage,value):
        if stage=='target batches':token.cancel()
    with pytest.raises(Cancelled):generate(store,d['id'],['reconstruction'],token,cancel)
    batches=target_batches(store,d['id']);assert len(batches)==2
    assert read_batch(store,d['id'],'reconstruction',batches[0]) is not None
    batch_component=next(n for n in store.components(d['id']) if '--' in n);assert store.artifact(d['id'],batch_component)[1]['target_batch']==batches[0]
    assert not store.artifact_path(d['id'],'reconstruction').exists()
    generate(store,d['id'],['reconstruction']);aa,mm=store.artifact(d['id'],'reconstruction');assert len(mm['target_batches'])==2
    ctx=resolve(store,d['id'],instrument='reconstruction');expected,_=reconstruction(ctx,store,d['id'],Token(),lambda *_:None)
    for name,a in expected.items():np.testing.assert_allclose(aa[name],a,rtol=1e-6,atol=1e-6,equal_nan=True)

def test_api_job_and_external_result_contract(store):
    from fastapi.testclient import TestClient
    from api.app import create_app
    from api.runtime import RuntimeState
    from model.workspace.session import WorkspaceSession
    from ecology.jobs import get_jobs
    with TestClient(create_app(WorkspaceSession(store.catalog.root),RuntimeState())) as client:
        d=store.read('shared-base')
        assert client.get('/ecology/explorations').status_code==404
        assert client.post('/ecology/maps/shared-base/jobs',json=dict(map_revision='wrong',instruments=['geometry'])).status_code==409
        response=client.post('/ecology/maps/shared-base/jobs',json=dict(map_revision=d['revision'],instruments=['geometry']));assert response.status_code==200,response.text
        job_id=response.json()['id'];jobs=get_jobs(store.catalog.root)
        if 'shared-base' in jobs.tasks:jobs.tasks['shared-base'][0].result(timeout=30)
        record=client.get('/ecology/jobs/'+job_id).json();assert record['state']=='succeeded'
        assert client.get('/ecology/maps/shared-base/capabilities').json()['view']['geometry']['available']
        a,m=store.artifact('shared-base','geometry');r=client.get('/ecology/maps/shared-base/results/geometry/arrays/anchor_rows',params=dict(signature=m['result_signature']));assert r.status_code==200 and r.content.startswith(b'\x93NUMPY')
        jobs.close()

def test_external_variants_are_independent(store):
    d=store.read('shared-base');rows=store.membership(d['id'])[:4];ids=store.catalog.load('assets/ids.npy')[rows]
    one=register_result(store,d['id'],item_ids=ids,predictions=np.ones(4)*.4,target='flag',kind='boolean',scope='external',provenance='one',expected_revision=d['revision'])
    two=register_result(store,d['id'],item_ids=ids,predictions=np.ones(4)*.7,target='flag',kind='boolean',scope='held_out',provenance='two',expected_revision=d['revision'])
    assert one['component']!=two['component']
    assert store.artifact(d['id'],one['component'])[1]['result_signature']!=store.artifact(d['id'],two['component'])[1]['result_signature']

def test_saved_view_ui_and_selective_residency(store,tmp_path):
    import os
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtWidgets import QApplication
    from ecology.native import MapWidget
    from ecology.jobs import Jobs
    from ecology.manager import MapManager
    app=QApplication.instance() or QApplication([])
    generate(store,'shared-base',['geometry','reconstruction','probe_metrics']);path=tmp_path/'view.hcmap';export_package(store,'shared-base',path,'viewing');dest=tmp_path/'view';import_package(path,dest)
    jobs=Jobs(dest);w=MapWidget(dest,'shared-base',jobs,lambda *_:None)
    assert 'geometry' in w.loaded and 'reconstruction' not in w.loaded
    assert w.landscape.arrays is not None
    w.reload(['reconstruction']);assert 'reconstruction' in w.loaded
    manager=MapManager(dest,lambda _:None,jobs);assert manager.table.rowCount()==1
    w.browse_results();w.load_names(['probe_metrics']);w.show();app.processEvents();assert w.grab().width()>0;assert w.evidence.currentWidget()==w.prediction_panel and w.resolved_measurement.reason is None
    manager.close();w.dispose();w.close();jobs.close();app.processEvents()


def test_target_only_layer_attachment(store,tmp_path):
    generate(store,'shared-base',['geometry'])
    viewing=tmp_path/'v.hcmap';targets=tmp_path/'t.hcmap';export_package(store,'shared-base',viewing,'viewing');export_package(store,'shared-base',targets,'targets')
    dest=tmp_path/'installed';import_package(viewing,dest);assert attach_package(targets,dest)['attached']>0
    assert Store(dest).catalog.feature('flag',np.array([1]))[1][0]


def test_concurrent_catalog_writes_conflict(store):
    from ecology.catalog import Catalog
    first=Catalog(store.catalog.root);second=Catalog(store.catalog.root)
    first.register_feature('one','items','numeric','assets/broad.npy','assets/broad-valid.npy')
    with pytest.raises(ValueError,match='revision conflict'):second.register_feature('two','items','numeric','assets/broad.npy','assets/broad-valid.npy')
    assert 'one' in Catalog(store.catalog.root).raw['features']


def test_writer_conflicts_do_not_block_ui_and_jobs_record_failure(store):
    import threading
    from ecology.locking import workspace_writer
    from ecology.jobs import Jobs
    jobs=Jobs(store.catalog.root);held=threading.Event();release=threading.Event()
    def owner():
        with workspace_writer(store.catalog.root):held.set();release.wait(10)
    thread=threading.Thread(target=owner);thread.start();assert held.wait(5)
    try:
        with pytest.raises(ValueError,match='active writer'):store.rename('shared-base','Blocked')
        future=jobs.submit('shared-base',['geometry'])
        with pytest.raises(ValueError,match='active writer'):future.result(timeout=5)
        assert jobs.inspect(future.job_id)['state']=='failed'
    finally:release.set();thread.join();jobs.close()
