import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import numpy as np
import pytest
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from ecology.demo import demo
from ecology.store import Store
from ecology.instruments import generate,plan
from ecology.jobs import Jobs
from ecology.native import MapWidget
from ecology.evidence import ribbon_samples,finite_stats

@pytest.fixture(scope='module')
def app():return QApplication.instance() or QApplication([])

@pytest.fixture(scope='module')
def workspace(tmp_path_factory):
    root=demo(tmp_path_factory.mktemp('guide')/'workspace',n=120,generate_results=False);store=Store(root)
    generate(store,'shared-base',['geometry','reconstruction','feature_audit','discrepancy']);return root

@pytest.fixture
def widget(app,workspace):
    jobs=Jobs(workspace);w=MapWidget(workspace,'shared-base',jobs,lambda *args:'Linked open views');w.reload(['geometry','reconstruction','feature_audit','discrepancy']);w.resize(1500,1000);w.show();app.processEvents();w.mode.setChecked(False)
    yield w
    w.dispose();w.close();jobs.close()


def test_arrow_keys_never_translate_and_move_avoids_scene_rebuild(widget):
    l=widget.landscape;l.velocity[:]=0;l.keys={Qt.Key.Key_Up};before=l.position.copy();look=l.look_distance;l._move(.02);np.testing.assert_array_equal(before,l.position);assert l.look_distance>look
    l.keys={Qt.Key.Key_Down};look=l.look_distance;l._move(.02);np.testing.assert_array_equal(before,l.position);assert l.look_distance<look
    l.keys={Qt.Key.Key_Left};yaw=l.yaw;l._move(.02);assert l.yaw>yaw;np.testing.assert_array_equal(before,l.position)
    calls=[];original=l.redraw;l.redraw=lambda:calls.append('rebuilt');l.keys={Qt.Key.Key_W};first=None
    for i in range(25):
        l._move(.016)
        if i==0:first=np.linalg.norm(l.velocity)
    assert np.linalg.norm(l.position-before)>0 and np.linalg.norm(l.velocity)>first and not calls
    l.keys.clear();l.redraw=original


def test_time_based_movement_is_consistent(widget):
    l=widget.landscape;start=l.position.copy();yaw=l.yaw
    positions=[]
    for dt,n in [(.01,100),(.02,50)]:
        l.position=start.copy();l.velocity[:]=0;l.turn_velocity=0;l.yaw=yaw;l.keys={Qt.Key.Key_W}
        for _ in range(n):l._move(dt)
        positions.append(l.position.copy())
    assert np.linalg.norm(positions[0]-positions[1])<l.span*.003
    l.keys.clear()


def test_continuous_filtration_and_saved_values_unchanged(widget):
    l=widget.landscape;before=l.arrays['spectrum'].copy();counts=[]
    for value in [0,317,599,1000]:
        widget.filtration.setValue(value);widget.apply_filtration();counts.append(len(np.unique(l.component_labels)))
        assert widget.filtration_radius==pytest.approx(float(l.arrays['lengths'].max())*value/1000)
    assert counts==sorted(counts,reverse=True);np.testing.assert_array_equal(before,l.arrays['spectrum'])
    widget.keep_component();assert len(widget.selected_rows)>0 and np.array_equal(l.highlights,widget.selected_rows)


def test_selection_pick_kept_and_persistence(widget):
    from matplotlib.backend_bases import MouseEvent
    l=widget.landscape;l.canvas.draw();valid=np.flatnonzero(np.isfinite(l.arrays['xy']).all(1)&np.isfinite(l.values));i=valid[0];point=l.ax.transData.transform(l.arrays['xy'][i]);event=MouseEvent('button_press_event',l.canvas,*point,button=1)
    l._click(event);assert int(l.rows[i]) in widget.selected_rows
    selected=widget.selected_rows.copy();widget.save_navigation();assert np.array_equal(np.load(widget.store.folder(widget.key)/'kept_selection.npy'),selected)
    widget.evidence.setCurrentIndex(6);widget.evidence.refresh();assert widget.evidence.selection_table.rowCount()==len(selected)
    assert 'canonical items kept' in widget.selection_info.text()


def test_full_question_audit_and_budget(workspace):
    store=Store(workspace);arrays,meta=store.artifact('shared-base','feature_audit');rows=store.membership('shared-base');c=store.catalog
    for name,summary in meta['features'].items():
        values,known=c.feature(name,rows);assert summary['known']==int(known.sum());assert summary['missing']==int((~known).sum());assert summary['question_rows']==len(rows)
        if summary['kind']=='numeric':
            assert summary['mean']==pytest.approx(float(values[known].mean()),abs=1e-6)
            assert summary['std']==pytest.approx(float(values[known].std()),abs=1e-6)
            assert sum(summary['histogram']['counts'])==int(known.sum())
        else:assert sum(summary['counts'])==int(known.sum())
    estimate=plan(store,'shared-base',['feature_audit']);assert estimate['source_feature_read_estimate_bytes']==0 and estimate['total_missing_work']==0
    d=store.duplicate('shared-base','Audit estimate')
    # Reuse avoids computation but copies the saved payload; feature scans are unnecessary.
    estimate=plan(store,d['id'],['feature_audit']);assert estimate['reusable']['feature_audit']=='shared-base'
    assert len(meta['feature_associations'])==10


def test_evidence_tabs_values_distributions_and_scale(widget,app):
    panel=widget.evidence
    for index in range(panel.count()):panel.setCurrentIndex(index);panel.refresh();app.processEvents()
    assert panel.geometry.rowCount()>=4 and panel.audit_table.rowCount()==5 and panel.associations.rowCount()>10
    panel.scale_scope.setCurrentIndex(3);panel.draw_scale(widget.landscape.attention(),widget.landscape.attention(True))
    assert panel.scale_table.rowCount()==4 and panel.transfer_table.rowCount()>0 and panel.account_table.rowCount()>0
    panel.setCurrentIndex(5);panel.values_family.setCurrentIndex(5);panel.refresh();assert panel.exact_table.rowCount()==len(widget.fields)
    widget.set_lens('feature');widget.feature.setCurrentText('category');assert widget.landscape.categorical
    widget.set_lens('prediction');widget.feature.setCurrentText('broad');assert widget.navigation_selection.target=='broad' and widget.navigation_selection.component=='probe_metrics';assert 'unloaded' in widget.prediction_status.text() or 'not generated' in widget.prediction_status.text()
    assert not widget.field.isVisible() and 'Broad Ridge' in [widget.account.itemText(i) for i in range(widget.account.count())]


def test_ribbon_breaks_unknowns_and_components():
    xy=np.array([[0.,0],[.01,0],[1.,0],[1.01,0]]);values=np.array([0.,1.,9.,10.]);labels=np.array([0,0,1,1])
    t,mid,low,high,n=ribbon_samples(xy,values,np.zeros(2),0,.03,12,labels)
    assert np.isnan(mid).any();assert np.all(low[np.isfinite(mid)]<=mid[np.isfinite(mid)]);assert np.all(high[np.isfinite(mid)]>=mid[np.isfinite(mid)])
    assert finite_stats([np.nan])['n']==0


def test_detached_population_linking(app,workspace):
    from ui.main_window import MainWindow,DetachedViewWindow
    from model.workspace import WorkspaceSession
    from api.runtime import RuntimeState
    session=WorkspaceSession(workspace);runtime=RuntimeState();window=MainWindow(session,runtime);spec=session.views()[0].clone(new_id='test-detached',title='Detached population')
    detached=DetachedViewWindow(session,spec,runtime);window._detached.append(detached)
    message=window._highlight_collection('items',np.array([1,3,7]));assert detached.view.highlight_rows.tolist()==[1,3,7];assert 'Detached population' in message
    detached.close();window._highlight_collection('items',np.array([5]));assert detached.view.highlight_rows.tolist()==[1,3,7];window.close()


def test_compute_loaded_and_unloaded_feedback(widget):
    widget.refresh_status();assert widget.analysis_table.rowCount()>=8
    widget.unload();widget.refresh_status();assert not widget.loaded and widget.store.artifact_path(widget.key,'feature_audit').exists()
    assert all(widget.analysis_table.item(i,2).text()=='No' for i in range(widget.analysis_table.rowCount()))
    widget.reload(['feature_audit']);widget.refresh_status();assert 'feature_audit' in widget.loaded;assert 'No models were refitted' in widget.feedback.text()
    widget.expand_chart(True);assert widget.evidence.isHidden() and widget.sidebar.isHidden();widget.expand_chart(False);assert not widget.evidence.isHidden()
