"""Screen preparation is explicit, additive, and independent of inspect selectors."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import json
import numpy as np
import pytest
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from ecology.demo import demo
from ecology.store import Store
from ecology.jobs import Jobs
from ecology.native import MapWidget
from ecology.instruments import generate,plan,REGISTRY
from ecology.resources import screen_requirements

@pytest.fixture(scope='module')
def app():return QApplication.instance() or QApplication([])

@pytest.fixture
def widget(tmp_path,app):
    root=demo(tmp_path/'workspace',n=90,generate_results=False);s=Store(root);generate(s,'shared-base',['geometry','directions','routes'])
    jobs=Jobs(root);w=MapWidget(root,'shared-base',jobs,lambda *_:None)
    yield w
    w.dispose();w.close();jobs.close();app.processEvents()

def test_bulk_check_all_and_retained_checks(widget):
    w=widget;w.check_all();assert len(w.checked_names())==len(REGISTRY)-1 # no frozen reference in this map
    w.refresh_status();assert 'reference_evaluation' not in w.checked_names()
    w.load_checked();assert {'geometry','directions','routes'}<=set(w.loaded)
    assert 'Not computed yet' in w.feedback.text()
    w.refresh_status();assert all(w.analysis_table.item(i,0).checkState()==Qt.CheckState.Checked for i,n in enumerate(REGISTRY) if n in w.checked_names())
    w.unload_checked();assert not w.loaded
    w.check_none();assert w.checked_names()==[];w.prepare_checked();assert 'Check at least one' in w.feedback.text()

def test_switching_tabs_never_loads_or_computes_implicitly(widget):
    w=widget;assert set(w.loaded)=={'geometry'}
    w.evidence.setCurrentIndex(2);assert 'directions' not in w.loaded
    assert 'load' in w.resource_title.text();assert not w.jobs.busy(w.key)
    w.screen_prepare.click();assert 'directions' in w.loaded;assert not w.jobs.busy(w.key)
    w.evidence.setCurrentIndex(1);assert 'compute' in w.resource_title.text()

def test_prepare_screen_job_remembers_resources_after_dropdown_change(widget):
    w=widget;w.evidence.setCurrentIndex(3);w.evidence.audit_tabs.setCurrentIndex(1)
    w.prepare_screen();future=w.generation_future;assert future is not None
    w.instrument.setCurrentIndex(w.instrument.findData('routes'));future.result(timeout=30);w.refresh_status()
    assert 'feature_audit' in w.loaded and 'routes' not in w.loaded
    assert not w.store.artifact_path(w.key,'reconstruction').exists()

def test_additive_loading_and_selective_unload(widget):
    w=widget;w.set_checked(['routes']);w.load_checked();assert {'geometry','routes'}<=set(w.loaded)
    w.set_checked(['directions']);w.load_checked();assert {'geometry','routes','directions'}<=set(w.loaded)
    w.unload_checked();assert 'routes' in w.loaded and 'directions' not in w.loaded
    w.set_checked(['routes']);w.unload_checked();assert set(w.loaded)=={'geometry'}
    w.unload();assert not w.loaded;assert 'load' in w.resource_title.text()

def test_requirements_follow_nested_probe_tab_and_reference():
    title,needs=screen_requirements(3,3);assert needs==['geometry','probe_metrics']
    assert 'reference_evaluation' in screen_requirements(4,reference=True)[1]
    assert 'reconstruction' not in screen_requirements(4,reference=True)[1]
    assert {'geometry','directions'}==set(screen_requirements(2)[1])

def test_compact_group_button_prepares_only_that_group(widget):
    w=widget;w.evidence.setCurrentIndex(1);w.evidence.refresh()
    w.evidence.compact_geometry.cards['access']['prepare'].click()
    assert 'routes' in w.loaded;assert 'compression' not in w.loaded;assert not w.jobs.busy(w.key)

def test_complexity_plan_has_closure_symbol_key_and_cached_actions(widget):
    result=plan(widget.store,widget.key,['directions']);data=result['complexity']
    assert list(data['components'])==['resolved_support','neighbors','geometry','directions']
    assert 'A R D' in data['components']['neighbors']['time']
    assert data['components']['directions']['requested_action']=='saved'
    assert data['symbols']['R'].startswith('valid sampled context')
    assert data['saved_loading']['time']=='O(V + M)'
    json.dumps(result)
    widget.set_checked(['directions']);assert 'O(' in widget.cost.text()

def test_retry_saved_loading_after_viewer_budget_failure(widget):
    w=widget;w.evidence.setCurrentIndex(2);w.cache.max_bytes=1;w.load_screen()
    assert w.load_errors and w.screen_load.isEnabled() and w.screen_prepare.isEnabled()
    w.cache.max_bytes=64_000_000;w.screen_prepare.click()
    assert {'geometry','directions'}<=set(w.loaded)
    assert not w.jobs.busy(w.key)
