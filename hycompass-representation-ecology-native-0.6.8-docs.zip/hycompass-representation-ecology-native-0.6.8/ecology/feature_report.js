(() => {
  "use strict";
  const get = id => document.getElementById(id);
  const features = JSON.parse(get("fx-data").textContent);
  const size = 24;
  let page = 0;
  let active = -1;
  let matches = [];
  const format = new Intl.NumberFormat(undefined, {maximumSignificantDigits: 6});
  const fmt = value => value == null ? "—" : format.format(value);
  const human = value => String(value).replaceAll("_", " ");
  const coverage = item => {
    const [known, missing] = item.coverage[0] || [0, 0];
    return known + missing > 0 ? known / (known + missing) : null;
  };
  const svgNS = "http://www.w3.org/2000/svg";

  function node(tag, text) {
    const element = document.createElement(tag);
    if (text != null) element.textContent = text;
    return element;
  }
  function option(select, value, text) {
    const item = node("option", text);
    item.value = value;
    select.append(item);
  }
  function table(headers, rows) {
    const wrapper = node("div");
    wrapper.className = "table-wrap";
    const result = node("table");
    const top = result.createTHead().insertRow();
    headers.forEach(title => {
      const cell = node("th", title);
      cell.scope = "col";
      top.append(cell);
    });
    const body = result.createTBody();
    rows.forEach(row => {
      const tr = body.insertRow();
      row.forEach(value => tr.append(node("td", value)));
    });
    wrapper.append(result);
    return wrapper;
  }
  function plot(points, metric, {xLabel = "Retained dimensions", kind = "line"} = {}) {
    const valid = points.filter(row => row[0] != null);
    if (!valid.length || (kind === "line" && valid.length < 2)) return null;
    function element(name, attrs, text) {
      const part = document.createElementNS(svgNS, name);
      for (const [key, value] of Object.entries(attrs)) part.setAttribute(key, value);
      if (text != null) part.textContent = text;
      return part;
    }
    const xs = valid.map(row => row[0]), ys = valid.map(row => row[1]);
    const xMin = Math.min(...xs), xMax = Math.max(...xs);
    const yMin = kind === "line" ? Math.min(...ys) : 0;
    const yMax = Math.max(...ys);
    const x = value => 69 + 485 * (value - xMin) / (xMax - xMin || 1);
    const y = value => yMin === yMax ? (kind === "line" ? 100 : 176) : 176 - 155 * (value - yMin) / (yMax - yMin);
    const svg = element("svg", {viewBox: "0 0 580 224", role: "img", "aria-label": metric + " by " + xLabel});
    svg.append(element("path", {d: "M69 21V176H554", fill: "none", stroke: "#64838e"}));
    if (yMin < 0 && yMax > 0) {
      svg.append(element("path", {d: "M69 " + y(0) + "H554", stroke: "#64838e", "stroke-dasharray": "4 4"}));
    }
    if (kind === "line") {
      svg.append(element("polyline", {
        points: valid.map(([a, b]) => x(a) + "," + y(b)).join(" "),
        stroke: "#73dfce", "stroke-width": 2, fill: "none"
      }));
      for (const [dimension, value, count] of valid) {
        const dot = element("circle", {cx: x(dimension), cy: y(value), r: 4, fill: "#ffd38a"});
        dot.append(element("title", {}, dimension + " dimensions · " + fmt(value) + " · n " + fmt(count)));
        svg.append(dot);
      }
    } else {
      const step = 485 / valid.length;
      valid.forEach(([bin, value], i) => {
        const bar = element("rect", {x: 69 + (i + 0.08) * step, y: y(value),
          width: step * 0.84, height: 176 - y(value), fill: "#73dfce"});
        bar.append(element("title", {}, fmt(bin) + " · " + fmt(value)));
        svg.append(bar);
        if (kind === "categories" && valid.length <= 12) {
          svg.append(element("text", {x: 69 + (i + 0.5) * step, y: 195, fill: "#a7bebd",
            "font-size": 13, "text-anchor": "middle"}, fmt(bin)));
        }
      });
    }
    for (const [x, y, text, align] of [
      [5, 25, fmt(yMax), "start"], [5, 176, yMin === yMax ? "" : fmt(yMin), "start"],
      [69, 195, kind === "categories" ? "" : fmt(xMin), "start"],
      [554, 195, kind === "categories" ? "" : fmt(xMax), "end"],
      [310, 216, xLabel, "middle"]
    ]) svg.append(element("text", {x, y, fill: "#a7bebd", "font-size": 13, "text-anchor": align}, text));
    return svg;
  }

  function showFeature(index) {
    active = index;
    const detail = get("fx-detail");
    detail.replaceChildren();
    if (index < 0) {
      detail.append(node("p", "No features match the current filters."));
      return;
    }
    const item = features[index];
    detail.append(node("h3", item.name), node("p", human(item.kind)));
    if (item.coverage.length) {
      detail.append(node("h4", "Observed values in frozen membership"));
      const [known, missing] = item.coverage[0];
      const total = known + missing;
      if (total > 0) {
        const track = node("div");
        track.className = "track";
        track.setAttribute("aria-hidden", "true");
        const share = node("i");
        share.style.width = 100 * known / total + "%";
        track.append(share);
        detail.append(track, node("small", fmt(100 * known / total) + "% observed in the first saved summary"));
      }
      detail.append(table(["Known", "Missing", "Saved result"], item.coverage.map(([known, missing, result]) =>
        [fmt(known), fmt(missing), result])));
    }
    if (item.distributions.length || item.plots?.length) {
      const distribution = node("details");
      distribution.append(node("summary", "Saved distribution"));
      distribution.addEventListener("toggle", () => {
        if (!distribution.open || distribution.children.length > 1) return;
        const plottedCounts = new Set();
        for (const saved of item.plots || []) {
          distribution.append(node("h4", saved.title), node("p", saved.scope), node("code", saved.result));
          const chart = plot(saved.samples, saved.y, {xLabel: saved.x, kind: saved.kind});
          if (chart) distribution.append(chart);
          distribution.append(table([saved.x, saved.y], saved.samples.map(row => row.map(fmt))));
          if (saved.kind === "categories") plottedCounts.add(saved.result);
        }
        const remaining = item.distributions.filter(([name, , result]) =>
          !(name.startsWith("Category code ") && plottedCounts.has(result)));
        if (remaining.length) distribution.append(table(["Statistic", "Value", "Saved result"],
          remaining.map(([name, value, result]) => [name, fmt(value), result])));
      });
      detail.append(distribution);
    }
    if (item.associations.length) {
      detail.append(node("h4", "Association with measured geometry"));
      detail.append(table(["Geometry measure", "Statistic", "Value", "Support", "Saved result"],
        item.associations.map(([geometry, statistic, value, count, result]) =>
          [human(geometry), statistic, fmt(value), fmt(count), result])));
    }
    if (!item.series.length) return;
    detail.append(node("h4", "Reconstruction and evaluation"));
    const controls = node("div");
    controls.className = "feature-controls";
    const metricLabel = node("label", "Metric");
    const metric = node("select");
    metricLabel.append(metric);
    const seriesLabel = node("label", "Account, evaluation scope and result");
    const series = node("select");
    seriesLabel.append(series);
    controls.append(metricLabel, seriesLabel);
    const evidence = node("div");
    detail.append(controls, evidence);
    for (const name of new Set(item.series.map(row => row[1]))) option(metric, name, name);
    function showSeries() {
      const [result, name, account, scope, points] = item.series[Number(series.value)];
      evidence.replaceChildren(node("p", human(account) + " · " + scope), node("code", result));
      const chart = plot(points, name);
      if (chart) evidence.append(chart);
      evidence.append(table(["Dimensions", name, "Measured support"], points.map(row => row.map(fmt))));
    }
    function updateSeries() {
      series.replaceChildren();
      item.series.forEach(([result, name, account, scope], index) => {
        if (name === metric.value) option(series, index, human(account) + " · " + scope + " · " + result);
      });
      showSeries();
    }
    metric.addEventListener("change", updateSeries);
    series.addEventListener("change", showSeries);
    updateSeries();
  }

  function renderList() {
    const list = get("fx-list");
    const start = page * size;
    list.replaceChildren();
    for (const index of matches.slice(start, start + size)) {
      const item = features[index];
      const button = node("button");
      const share = coverage(item);
      const note = [human(item.kind), share === null ? null : fmt(share * 100) + "% observed",
        item.series.length ? "evaluation" : null].filter(Boolean).join(" · ");
      button.append(node("span", item.name), node("small", note));
      button.type = "button";
      button.setAttribute("aria-pressed", String(index === active));
      button.addEventListener("click", () => {
        showFeature(index);
        for (const previous of list.querySelectorAll('[aria-pressed="true"]')) previous.setAttribute("aria-pressed", "false");
        button.setAttribute("aria-pressed", "true");
      });
      list.append(button);
    }
    get("fx-page").textContent = matches.length ? (start + 1) + "–" + Math.min(start + size, matches.length) + " of " + matches.length : "0 matches";
    get("fx-prev").disabled = page === 0;
    get("fx-next").disabled = start + size >= matches.length;
  }
  function filter() {
    const query = get("fx-search").value.trim().toLowerCase();
    const kind = get("fx-kind").value, evidence = get("fx-evidence").value;
    matches = [];
    features.forEach((item, i) => {
      if (item.name.toLowerCase().includes(query) && (!kind || item.kind === kind) &&
          (!evidence || item[evidence].length)) matches.push(i);
    });
    const order = get("fx-sort").value;
    if (order !== "name") {
      matches.sort((a, b) => {
        const left = coverage(features[a]), right = coverage(features[b]);
        if (left === null || right === null) return Number(left === null) - Number(right === null);
        return order === "low" ? left - right : right - left;
      });
    }
    page = 0;
    showFeature(matches[0] ?? -1);
    renderList();
  }
  for (const kind of [...new Set(features.map(item => item.kind))].sort()) option(get("fx-kind"), kind, human(kind));
  get("fx-search").addEventListener("input", filter);
  get("fx-kind").addEventListener("change", filter);
  get("fx-evidence").addEventListener("change", filter);
  get("fx-sort").addEventListener("change", filter);
  for (const [id, step] of [["fx-prev", -1], ["fx-next", 1]]) {
    get(id).addEventListener("click", () => {
      page += step;
      showFeature(matches[page * size]);
      renderList();
    });
  }
  filter();
})();
