"""Structural asymptotic bounds for the implemented bounded exact kernels.

Counts describe declared support, not the full corpus unless explicitly stated.
Numeric byte/work estimates remain separate from these conservative bounds.
"""

SYMBOLS={
 'N':'canonical collection rows (correspondence universe)',
 'M':'frozen map membership rows',
 'A':'valid sampled evaluation anchors',
 'R':'valid sampled context rows, including anchors',
 'D':'embedding dimensions',
 'k':'neighbor count',
 'T':'selected typed targets',
 'C':'expanded target channels (category columns included)',
 'F':'held-out folds',
 'Q':'retained-dimension variants',
 'q':'largest retained dimension',
 'G':'router regions',
 'I':'bounded KMeans iterations, including its fixed restart factor',
 'S':'stability repeats',
 'E':'anchor graph edges, at most O(A k)',
 'L':'filtration levels',
 'B':'processing block rows (distance search currently 32)',
 'P':'sampled discrepancy pairs, O(A k)',
 'H':'route endpoints (at most 8)',
 'K':'enumerated routes per endpoint (at most 6 including the cap probe)',
 'V':'bytes in selected persisted payloads',
}

# Incremental family costs: shared resolution and prerequisite costs are listed
# separately in report(), preventing a hidden second kNN cost for geometry.
COSTS={
 'source_support':('O(R D min(R,D) + R D log R + A k)','O(R D + min(R,D)²)','O(R)', 'Explicit bounded sample scan, exact sorted duplicate groups on source and unit-normalized coordinates, centered unit covariance participation ratio, saved-neighbor occurrence counts, persisted norm bins, singular-energy spectrum and exact group-size arrays. Refuses above 8192 rows or 512 dimensions; no corpus audit.'),
 'resolved_support':('O(N + M log M + R log R + R D + A D min(A,D))','O(N + M + R D + D min(A,D))','O(A + R)', 'Includes current row joins/sampling, vector gathering and the current scoped display PCA. Resolution is shared within a job; dense normalized vectors are not persisted.'),
 'neighbors':('O(A R D + A R + A k log k + A² D)','O(B R + A k)','O(A k + R)', 'Exact context and independent anchor searches; partial selection and deterministic boundary ties. Excludes the shared normalized context buffer.'),
 'geometry':('O(A k D min(k,D) + E log A + L (A + E))','O(k D + k² + A k + L A)','O(A k + L A + R)', 'Tangent SVDs plus mutual graph/filtration; uses saved neighbors. Fixed filtration policies bound L.'),
 'directions':('O(A k D min(k,D))','O(k D + A k min(k,D))','O(A k min(k,D))', 'Complete tangent direction scores, separate from saved three-axis hull offsets.'),
 'reconstruction':('O(F (T+1) R D min(R,D) + F Q G (R q² + q³ + R q C) + I R D G)','O(R D + D min(R,D) + R C + F Q G q C)','O(A Q T + F (T+1) D q + F Q G q C)', 'Conservative full-SVD/Ridge upper bound for the fixed account family, including repeated target-batch/classification PCA. Actual numeric transforms share exact fold support. Checkpoints plus combined output can duplicate payloads.'),
 'reference_evaluation':('O(F Q (A D q T + A G q C))','O(A D + A C + D q + G q C)','O(A Q T)', 'Frozen account replay and target scoring; no fitting. Saved source account payloads are additional referenced storage.'),
 'probe_metrics':('O(F Q (A D q T + A G q C) + Q T A log A)','O(A D + A Q C + C²)','O(A Q C + Q T C²)', 'Frozen account replay, predictions/loss fields, metric sorting (including AUC) and confusion tables; reconstruction is a prerequisite, not a new fit here.'),
 'feature_audit':('O(M T + A T² log A + A T log A)','O(B T + A T + A T²)','O(T + T² + A T)', 'Full-membership typed distributions plus anchor-scoped target/geometry associations. Numeric histograms have two passes. Fixed geometry-channel/histogram counts are suppressed.'),
 'feature_distribution':('O(M T)','O(B + T)','O(T)', 'Streaming source-only summaries and fixed-bin histograms; two numeric passes; no embedding resolution.'),
 'neighborhood_agreement':('O(T (R log R + A k))','O(R + A k)','O(A T)', 'Includes current np.unique sorting of known context class frequencies, plus typed local agreement; no vector gathering or kNN recomputation when neighbors are saved.'),
 'discrepancy':('O(P D + F (P T² + T³ + P T log P))','O(P D + P T + T²)','O(P + A)', 'Endpoint-pair distances, train-only median imputation and small Ridge models. Pair endpoint accumulation is O(P + A).'),
 'stability':('O(S (R D + A R D + A R + A k log k))','O(R D + B R + S A + A k)','O(S A)', 'Perturbation and context-resampling searches are new exact measurements; both use bounded distance blocks.'),
 'compression':('O(R D min(R,D) + Q (A R q + A R + A k log k))','O(R D + D min(R,D) + R q + B R)','O(D q + A Q)', 'Context-fitted full PCA plus new retained/display neighbor measurements; source/display agreement adds the analogous two-dimensional search.'),
 'routes':('O(H K A (E + A log A))','O(A + E + K A + K A²)','O(A + H K A)', 'Conservative Yen simple-route enumeration bound, including candidate-path storage, beyond the linear articulation/deletion pass. H and K are fixed small caps; route cost is not constant.'),
}


def report(names,estimate=None):
    from .instruments import dependency_order
    ordered=dependency_order(names);estimate=estimate or {};cached=set(estimate.get('cached',[]));reuse=estimate.get('reusable',{})
    rows={}
    for name in ordered:
        time,space,disk,note=COSTS[name]
        state='saved' if name in cached else 'reuse copy' if reuse.get(name) else 'compute'
        rows[name]=dict(time=time,peak_space=space,persistent_space=disk,requested_action=state,note=note)
    return dict(symbols=SYMBOLS,components=rows,requested_components=list(names),compute_closure=ordered,
        note='Conservative algorithmic bounds over declared support. Each family excludes prerequisite kernels and the shared input buffer unless noted. Job time sums missing computed families plus one shared resolution; peak RAM includes simultaneously live inputs/outputs and the largest scratch allocation, not a sum of scratch bounds. These are not wall-time forecasts.',
        shared_resolution=dict(time=COSTS['resolved_support'][0],peak_space=COSTS['resolved_support'][1],note='The current implementation resolves/gathers again for separate vector-dependent jobs, even when support is already persisted. Source-only summaries, saved-neighbor agreement and routes do not require this gather.'),
        navigation=dict(time='O(A C + A log A) scoring; O(A log A) canonical comparison join and bounded case sorting',peak_space='O(A C + C²), cached scalar resolutions ≤ 4 MB',persistent_space='O(1)',note='No vector scan or replay during selection. Explicit target/dimension loading verifies selected saved-array bytes only. Observer subset summaries throttled at 160 ms, cached by result signature and canonical subset.'),
        saved_loading=dict(time='O(V + M)',peak_space='O(V)',persistent_space='O(1) additional',note='Full payload verification, copied viewer arrays and membership validation. Reading metadata and bounded source fingerprints is additional. Reuse copies consume O(V) new disk; loading does not compute kernels.'),
        current_counts={k:estimate.get(v) for k,v in {'M':'question_members','A':'evaluation_anchor_cap','R':'context_cap','D':'dimensions','T':'features'}.items()})


def format_text(data):
    lines=[]
    for name,row in data['components'].items():
        lines.append(name.replace('_',' ')+': time '+row['time']+' · RAM '+row['peak_space']+' · saved '+row['persistent_space']+' ['+row['requested_action']+']')
    lines.append('Saved loading: time O(V + M), viewer RAM O(V). V = selected payload bytes. Kernel bounds apply to missing computations only.')
    lines.append('Symbols: '+'; '.join(k+' = '+v for k,v in data['symbols'].items())+'.')
    lines.append(data['note'])
    return '\n'.join(lines)
