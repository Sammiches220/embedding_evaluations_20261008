"""Metadata-only bulk presets and bounded saved-payload selection."""
from .instruments import REGISTRY


def resource_preset(name,definition):
    features=bool(definition['settings']['features']);reference=bool(definition['settings'].get('reference_map'))
    families={
        'All applicable':list(REGISTRY),
        'Prediction + population':['geometry','probe_metrics','feature_distribution','source_support','neighborhood_agreement'],
        'Geometry + audits':['geometry','directions','compression','stability','routes','source_support'],
        'Saved map preset':definition['settings'].get('instruments',['geometry']),
    }
    target_families={'reconstruction','probe_metrics','feature_audit','feature_distribution','neighborhood_agreement','discrepancy'}
    return [n for n in families[name] if (features or n not in target_families) and (n!='reference_evaluation' or reference)]


def payload_fields(metadata,targets,dimensions,active,comparison,byte_budget):
    """Prioritize active target/dimension, then complete checked groups within budget.

    Atomic groups contain all saved accounts for one target/dimension and its
    observed support. No partial class matrices. This does not open any payload.
    """
    schemas=metadata['arrays'];chosen={n for n in ('anchor_rows','context_rows') if n in schemas};used=sum(schemas[n].get('bytes',0) for n in chosen);omitted=[]
    groups=[active]
    if comparison:groups.append(comparison)
    groups.extend((t,str(q)) for t in sorted(targets) for q in sorted(dimensions,key=int))
    seen=set()
    for target,q in groups:
        pair=(target,str(q))
        if pair in seen:continue
        seen.add(pair)
        names={n for n in schemas if n in (target+'__observed',target+'__known') or n.startswith(f'{target}__q{q}__')}
        extra=names-chosen;cost=sum(schemas[n].get('bytes',0) for n in extra)
        if used+cost>byte_budget:omitted.append(pair);continue
        chosen.update(names);used+=cost
    return chosen,omitted,used


def union_error_cases(payload,targets,dimensions,accounts,fraction=.1):
    """Union each checked variant's worst-loss fraction; never mix target loss units."""
    import math
    import numpy as np
    arrays,metadata=payload;rows=arrays['anchor_rows'];selected=[];used=0;missing=0
    for target in targets:
        for q in dimensions:
            for account in accounts:
                key=f'{target}__q{q}__{account}__loss' if account!='baseline' else f'{target}__q{q}__broad__baseline_loss'
                loss=arrays.get(key)
                if loss is None:missing+=1;continue
                valid=np.flatnonzero(np.isfinite(loss));used+=1
                order=valid[np.lexsort((rows[valid],-loss[valid]))];selected.extend(rows[order[:math.ceil(len(order)*fraction)]])
    return np.unique(np.asarray(selected,np.int64)),dict(available_groups=used,unavailable_groups=missing,policy='Union of top loss fraction independently within each variant; raw units are never pooled')
