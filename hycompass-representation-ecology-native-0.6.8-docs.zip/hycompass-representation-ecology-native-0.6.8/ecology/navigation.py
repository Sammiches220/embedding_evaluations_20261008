"""Pure saved-result navigation. No source reads, fitting, or implicit array fallback.

Payloads are supplied by the bounded viewer (or explicit CLI/API loading).
"""
from dataclasses import dataclass, replace, asdict
import numpy as np
from .catalog import digest
from .probes import metric_summary

MEASUREMENTS={
 'observed':('Observed value','mean','target'),
 'prediction':('Prediction','mean prediction','target'),
 'error':('Error','mae / brier','loss'),
 'residual':('Signed residual','mean residual','signed'),
 'squared_error':('Squared error','rmse','loss'),
 'gain':('Improvement over training baseline','mean baseline loss − model loss','signed'),
 'class':('Predicted class','class counts','categorical'),
 'correct':('Correct prediction','accuracy','categorical'),
 'observed_score':('Observed-class score','mean observed-class score','probability'),
 'margin':('Winning-class margin','mean margin','probability'),
 'log_loss':('Log-loss contribution','log_loss','loss'),
}

@dataclass(frozen=True)
class Selection:
    map_id:str
    target:str
    component:str='probe_metrics'
    account:str='broad'
    dimension:int=1
    measurement:str='error'
    subset:str='all'
    result_signature:str|None=None
    map_revision:str|None=None
    target_revision:str|None=None
    kind:str|None=None
    protocol:str|None=None
    support_identity:str|None=None
    aggregate:str|None=None
    comparison:dict|None=None
    comparison_policy:str='paired loss A minus B'

@dataclass
class Resolved:
    selection:Selection
    rows:np.ndarray
    values:np.ndarray
    available:np.ndarray
    kind:str
    units:str
    rendering:str
    labels:dict
    provenance:dict
    summary:dict
    reason:str|None=None


def target_snapshot(catalog,name):
    f=catalog.raw['features'][name]
    return dict(kind=f['kind'],revision=f['revision'],units=f.get('units','target units' if f['kind']=='numeric' else 'score'),cardinality=f.get('cardinality'),labels=catalog.labels(name))


def context_snapshot(store,key):
    d=store.read(key)
    return dict(membership=d['membership_digest'],domain=d['domain_revision'],context=d['settings']['context'],anchors=d['settings']['anchors'],context_cap=d['settings']['context_cap'],seed=d['settings']['seed'])

def protocol_snapshot(store,key,kind='held_out'):
    d=store.read(key)
    return dict(kind=kind,verified=True,folds=d['settings']['folds'],groups=d['groups_stamp'],collection_revision=d['collection_revision'],assignment='group fold_ids v1',reference=d['settings'].get('reference_map'))


def variants(metadata):
    """Metadata-only index; duplicate aggregate records do not duplicate variants."""
    if metadata.get('origin')=='external':return [(metadata['target'],'external',0)]
    records=metadata.get('metrics',[])
    result={(r['feature'],r['account'],int(r['dimension'])) for r in records}
    if metadata.get('evaluation',{}).get('kind')=='held_out':result|={(r['feature'],'baseline',int(r['dimension'])) for r in records}
    return sorted(result)


def resolve(selection,payload,subset_rows=None):
    a,m=payload;s=selection
    rows=np.asarray(a.get('anchor_rows',[]),np.int64)
    def unavailable(reason):
        return Resolved(s,rows,np.full(len(rows),np.nan),np.zeros(len(rows),bool),'unknown','','loss',{},dict(signature=m.get('result_signature')),dict(result_rows=len(rows),measured=0),reason)
    if s.result_signature and s.result_signature!=m.get('result_signature'):return unavailable('Pinned result revision changed; select the current saved result explicitly.')
    if s.map_revision and s.map_revision!=m.get('definition_revision'):return unavailable('Pinned map revision changed.')
    spec=m.get('targets',{}).get(s.target)
    if spec is None:return unavailable('Target is absent from this saved result.')
    if s.target_revision and s.target_revision!=spec['revision']:return unavailable('Target revision differs from the pinned selection.')
    kind=spec['kind'];external=m.get('origin')=='external'
    prefix=f'{s.target}__q{s.dimension}__{s.account}__'
    if (s.target,s.account,s.dimension) not in variants(m):return unavailable('This account/dimension is not saved for the selected target.')
    pred=a.get('predictions' if external else prefix+'prediction')
    truth=a.get(s.target+'__observed');known=a.get(s.target+'__known')
    if truth is not None:
        truth=np.asarray(truth,float).copy();truth[~np.asarray(known,bool)]=np.nan
    base=a.get(f'{s.target}__q{s.dimension}__baseline__prediction')
    labels=spec.get('labels',{})
    rendering='loss';units=spec.get('units','target units');name=s.measurement
    if pred is not None:
        pred=np.asarray(pred,float).copy()
        if pred.shape[0]!=len(rows):return unavailable('Prediction support shape mismatch.')
        if kind=='category' and (pred.ndim!=2 or pred.shape[1]!=spec.get('cardinality')):return unavailable('Class-score columns do not match the declared codebook.')
        if external:pred[~np.asarray(a['prediction_known'],bool)]=np.nan
    field=None
    if name=='observed':field=truth;rendering='categorical' if kind!='numeric' else 'value'
    elif name=='prediction':
        field=np.argmax(pred,axis=1).astype(float) if pred is not None and kind=='category' else pred
        if kind=='category' and pred is not None:field[~np.isfinite(pred).all(1)]=np.nan
        rendering='categorical' if kind=='category' else 'probability' if kind=='boolean' else 'value'
    elif name in ('error','gain','residual','squared_error','correct','class'):
        suffix=dict(error='loss',gain='baseline_gain',residual='signed_residual',squared_error='squared_error',correct='correct',**{'class':'predicted_class'})[name]
        field=a.get(prefix+suffix)
        if s.account=='baseline' and name=='error':field=a.get(f'{s.target}__q{s.dimension}__broad__baseline_loss')
        if s.component=='reference_evaluation':
            root=f'{s.target}__q{s.dimension}__'
            if name=='error':field=a.get(root+s.account)
            elif name=='gain' and s.account in ('broad','local') and root+'baseline' in a:field=a[root+'baseline']-a[root+s.account]
        rendering='signed' if name in ('gain','residual') else 'categorical' if name in ('class','correct') else 'loss'
    elif name in ('observed_score','margin','log_loss') and pred is not None and kind!='numeric':
        prob=np.c_[1-pred,pred] if kind=='boolean' else pred
        if name=='margin':
            ordered=np.sort(prob,axis=1);field=ordered[:,-1]-ordered[:,-2] if prob.shape[1]>1 else ordered[:,0];rendering='probability'
        elif truth is not None:
            valid=np.isfinite(truth)&(truth>=0)&(truth<prob.shape[1]);field=np.full(len(rows),np.nan);ii=np.flatnonzero(valid);field[ii]=prob[ii,truth[ii].astype(int)]
            if name=='log_loss':
                safe=np.clip(prob,1e-12,1);safe/=safe.sum(1,keepdims=True);field[ii]=-np.log(safe[ii,truth[ii].astype(int)])
            else:rendering='probability'
    if field is None:return unavailable('Required saved observations/predictions/measurement are unavailable. Prepare this result explicitly.')
    field=np.asarray(field,float).copy()
    if field.shape!=(len(rows),):return unavailable('Selected measurement is not a semantic scalar field.')
    valid=np.isfinite(field);subset=np.ones(len(rows),bool) if subset_rows is None else np.isin(rows,subset_rows)
    total=int(valid.sum());field[~subset]=np.nan;available=valid&subset
    summary=dict(result_rows=len(rows),total_supported=total,subset_rows=int(subset.sum()),measured=int(available.sum()),excluded=int(subset.sum()-available.sum()),outside_subset=int((~subset).sum()))
    summary['mean_measurement']=float(field[available].mean()) if available.any() and rendering!='categorical' else None
    if truth is not None and pred is not None:
        # Recompute the combined subset metric from predictions, never fold averages.
        use=subset&np.isfinite(truth)
        summary['metrics']=metric_summary(truth[use],pred[use],base[use] if base is not None else pred[use],kind)
        if base is None:
            for k in ('baseline_mae','mae_gain','baseline_brier','brier_skill','baseline_accuracy'):summary['metrics'].pop(k,None)
        for record in summary['metrics'].get('per_class',[]):record['label']=labels.get(str(record['code']),{}).get('name',str(record['code']))
    if name=='error':units=units if kind=='numeric' else 'binary Brier' if kind=='boolean' else 'multiclass Brier (sum over classes)'
    elif name=='squared_error':units=units+'²'
    elif name in ('log_loss',):units='nats; clip [1e-12,1], then normalize class scores'
    elif kind!='numeric':units='class' if rendering=='categorical' else 'score [0,1]' if rendering=='probability' else 'Brier difference'
    if kind=='boolean' and name=='observed' or name=='correct':labels={'0':{'name':'False'},'1':{'name':'True'}}
    elif name=='class' and kind=='boolean':labels={'0':{'name':'False'},'1':{'name':'True'}}
    protocol=m.get('evaluation',dict(kind=m.get('scope','unknown'),verified=False))
    s=replace(s,result_signature=m.get('result_signature'),map_revision=m.get('definition_revision'),target_revision=spec['revision'],kind=kind,protocol=protocol['kind'],support_identity=digest(rows.tolist()),aggregate=('mae' if kind=='numeric' else 'brier') if name=='error' else MEASUREMENTS[name][1])
    provenance=dict(signature=m.get('result_signature'),target=spec,protocol=protocol,domain=m.get('domain_revision'),context=m.get('map_context'),collection=m.get('collection_revision'),producer_claims=m.get('metrics') if external else None,log_policy='clip [1e-12,1], row normalize')
    return Resolved(s,rows,field,available,kind,units,rendering,labels,provenance,summary)


def compare_resolved(left,right):
    """Loss A − loss B. Same target/protocol alone is insufficient."""
    if left.reason or right.reason:raise ValueError(left.reason or right.reason)
    if left.selection.measurement!='error' or right.selection.measurement!='error':raise ValueError('Comparison requires the named Error view (loss A − loss B).')
    semantics=lambda r:{k:r.provenance['target'].get(k) for k in ('kind','revision','units','cardinality','labels')}
    if semantics(left)!=semantics(right):raise ValueError('Incompatible target semantics/revision/codebook.')
    for field in ('protocol','collection'):
        if left.provenance.get(field)!=right.provenance.get(field):raise ValueError('Incompatible '+field+' semantics/revision.')
    if not left.provenance['protocol'].get('verified'):raise ValueError('External protocol claims are unverified; loss comparison is unavailable.')
    if left.selection.target!=right.selection.target:raise ValueError('Different target identities.')
    rows,ia,ib=np.intersect1d(left.rows,right.rows,return_indices=True)
    good=left.available[ia]&right.available[ib];rows=rows[good];ia=ia[good];ib=ib[good]
    values=left.values[ia]-right.values[ib]
    return dict(rows=rows,values=values,n_a=int(left.available.sum()),n_b=int(right.available.sum()),n_shared=len(rows),total_supported_a=left.summary.get('total_supported'),total_supported_b=right.summary.get('total_supported'),result_rows_a=len(left.rows),result_rows_b=len(right.rows),loss_a=float(left.values[ia].mean()) if len(rows) else None,loss_b=float(right.values[ib].mean()) if len(rows) else None,mean_improvement=float(values.mean()) if len(rows) else None,sign='loss A − loss B; positive favors B',changed_context=left.provenance.get('domain')!=right.provenance.get('domain') or left.provenance.get('context')!=right.provenance.get('context'))


def cases(result,limit=50):
    ids=np.flatnonzero(result.available)
    # Categorical codes have no error magnitude; order those by canonical ID.
    ids=ids[np.argsort(result.rows[ids],kind='stable')] if result.rendering=='categorical' else ids[np.lexsort((result.rows[ids],-np.abs(result.values[ids])))]
    return ids[:limit]


def resolve_saved(store,selection,subset_rows=None):
    """Explicit CLI/REST read; verify only required saved target/dimension arrays."""
    import json
    s=selection;m=json.loads((store.artifact_path(s.map_id,s.component)/'metadata.json').read_text())
    names={n for n in m['arrays'] if n in ('anchor_rows','context_rows','predictions','prediction_known',s.target+'__observed',s.target+'__known') or n.startswith(f'{s.target}__q{s.dimension}__')}
    return resolve(s,store.artifact(s.map_id,s.component,array_names=names),subset_rows)
