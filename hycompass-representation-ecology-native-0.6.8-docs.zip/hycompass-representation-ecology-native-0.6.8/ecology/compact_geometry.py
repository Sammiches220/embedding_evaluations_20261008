"""Compact contextual families over unchanged saved measurement arrays."""
import numpy as np
from PySide6.QtCore import Signal,Qt
from PySide6.QtWidgets import QWidget,QVBoxLayout,QGridLayout,QFrame,QLabel,QPushButton
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from .reading import FAMILIES,compact_families

class CompactGeometry(QWidget):
    measurementPicked=Signal(str)
    def __init__(self,owner):
        super().__init__();self.owner=owner;self.grid=QGridLayout(self);self.grid.setContentsMargins(5,5,5,5);self.grid.setSpacing(10);self.cards={}
        for j,(key,title,_,note) in enumerate(FAMILIES):
            card=QFrame();card.setObjectName('geometryFamilyCard');card.setStyleSheet('#geometryFamilyCard {background:#1b2734;border:1px solid #3c5266;border-radius:5px;}');layout=QVBoxLayout(card);layout.setContentsMargins(10,8,10,8)
            heading=QLabel(title);heading.setWordWrap(True);heading.setFixedHeight(36);heading.setStyleSheet('font-size:11pt;font-weight:600;color:#dce9f3');layout.addWidget(heading)
            fig=Figure(facecolor='#1b2734');view=FigureCanvasQTAgg(fig);view.setFixedHeight(150);layout.addWidget(view)
            caption=QLabel(note);caption.setWordWrap(True);caption.setFixedHeight(42);caption.setStyleSheet('font-size:8pt;color:#acbdcb');layout.addWidget(caption)
            needs=['geometry']+{'access':['routes'],'stress':['stability']}.get(key,[])
            prepare=QPushButton('Compute / load this group');prepare.setMaximumHeight(25);prepare.clicked.connect(lambda _,ns=needs:self.owner.prepare_names(ns));layout.addWidget(prepare)
            fig.canvas.mpl_connect('button_press_event',self.pick);self.grid.addWidget(card,j//2,j%2);self.cards[key]=dict(widget=card,title=heading,fig=fig,canvas=view,note=caption,keys=[],prepare=prepare,needs=needs)
    def pick(self,event):
        key=getattr(event.inaxes,'_field_key',None)
        if key:self.measurementPicked.emit(key)
    def clear(self):
        for card in self.cards.values():card['keys']=[];card['fig'].clear();card['canvas'].draw_idle()
    def refresh(self,owner,here,ahead):
        from .evidence import label,ribbon_samples,finite_stats
        l=owner.landscape
        for card in self.cards.values():
            saved=all((owner.store.artifact_path(owner.key,n)/'metadata.json').exists() for n in card['needs']);loaded=all(n in owner.loaded for n in card['needs'])
            card['prepare'].setText('Loaded · reload group' if loaded else 'Load this group' if saved else 'Compute + load this group');card['prepare'].setEnabled(not owner.jobs.busy(owner.key));card['prepare'].setToolTip('Required resources: '+', '.join(card['needs'])+'. Prerequisites are included automatically.')
        if l.arrays is None:self.clear();return
        labels=l.component_labels if l.component_labels is not None else l.arrays['filtration_labels'][-1]
        for family in compact_families(owner.fields,owner.dimension.currentText()):
            card=self.cards[family['id']];fig=card['fig'];fig.clear();keys=family['keys'];card['keys']=keys;card['canvas'].setFixedHeight(max(58,len(keys)*44+18))
            if not keys:
                ax=fig.add_subplot(111);ax.set_axis_off();ax.text(.03,.5,'No matching measurement computed / loaded',transform=ax.transAxes,color='#a8bdce',fontsize=8)
            for j,key in enumerate(keys):
                ax=fig.add_subplot(len(keys),1,j+1);ax.set_facecolor('#1b2734');ax._field_key=key;v=owner.fields[key];t,mid,_,_,_=ribbon_samples(l.arrays['xy'],v,l.position,l.yaw,l.radius,l.look_distance,labels)
                ax.plot(t,mid,color='#73bec9',lw=1.25);a,b=finite_stats(v[here]),finite_stats(v[ahead]);fa=f"{a['median']:.4g}" if a['n'] else '—';fb=f"{b['median']:.4g}" if b['n'] else '—'
                for x,stats,color in [(0,a,'#ffdb6e'),(l.radius*l.look_distance,b,'#ff9970')]:
                    ax.axvline(x,color=color,lw=.55,alpha=.7)
                    if stats['n']:ax.scatter([x],[stats['median']],s=15,color=color,zorder=5)
                ax.text(.0,1.08,label(key),transform=ax.transAxes,color='#d4e4ef',fontsize=7.5,va='bottom')
                ax.text(1.,1.08,fa+' → '+fb,transform=ax.transAxes,color='#efcf8a',fontsize=8,ha='right',va='bottom')
                ax.set_axis_off();ax.margins(y=.2)
            fig.subplots_adjust(left=.025,right=.98,bottom=.04,top=.64 if len(keys)==1 else .80,hspace=1.0);card['canvas'].draw_idle()
