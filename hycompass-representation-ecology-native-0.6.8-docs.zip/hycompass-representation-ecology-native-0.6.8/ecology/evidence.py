"""Native field-guide evidence. Every summary states its measured support."""
import csv
import math
import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QTabWidget,QLabel,QTableWidget,QTableWidgetItem,QHeaderView,QSplitter,QComboBox,QPushButton,QApplication,QFileDialog)
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg

NAMES={'effective_dimension':'Covariance dimensions','hidden_two':'Variance hidden by two axes','radius':'Neighborhood radius','radius_dimension':'Radius-growth dimension','discrepancy':'Feature → geometry residual','perturbation_jaccard':'Perturbation stability','resampling_jaccard':'Reference resampling stability','deletion_damage':'Fixed-graph deletion damage','projection_neighbor_jaccard':'Display-neighbor agreement','broad':'Broad account error','local':'Local account error','gain':'Broad − local gain','baseline':'Baseline error','selected':'Validation-selected error'}
TITLES={'directions':'Direction ribbons','probe_metrics':'Held-out probe metrics','geometry':'Geometry','feature':'Source feature','discrepancy':'Explanation gap','reconstruction':'Reconstruction','compression':'Change of scale','stability':'Stability','routes':'Routes','reference_evaluation':'Frozen reference','feature_audit':'Feature audit','source_support':'Source and support','resolved_support':'Sampling support','neighbors':'Exact neighbor tables','neighborhood_agreement':'Neighbor target agreement','feature_distribution':'Target distributions'}

def label(key):
    group,_,tail=key.partition('/')
    if '__q' in tail:
        feature,rest=tail.split('__q',1);dim,measure=rest.split('__',1);return f'{feature} · {NAMES.get(measure,measure)} · {dim} directions'
    if tail.startswith('pca_q'):
        dim,measure=tail[5:].split('_',1);return f'{dim} directions · '+('neighbor agreement' if measure=='jaccard' else 'discarded vector energy')
    return NAMES.get(tail,tail.replace('_',' ')) if group!='feature' else tail

def finite_stats(values):
    values=np.asarray(values,float);v=values[np.isfinite(values)]
    if not len(v):return dict(n=0,mean=None,median=None,std=None,min=None,max=None,q25=None,q75=None)
    return dict(n=len(v),mean=float(v.mean()),median=float(np.median(v)),std=float(v.std()),min=float(v.min()),max=float(v.max()),q25=float(np.quantile(v,.25)),q75=float(np.quantile(v,.75)))

def ribbon_samples(xy,values,position,yaw,radius,look,labels,mean=False):
    t=np.linspace(-radius,radius*(look+1),48);direction=np.array([math.cos(yaw),math.sin(yaw)]);points=position+t[:,None]*direction
    med=np.full(len(t),np.nan);low=med.copy();high=med.copy();support=np.zeros(len(t),int);components=np.full(len(t),-1,int)
    for i,p in enumerate(points):
        ids=np.flatnonzero((np.linalg.norm(xy-p,axis=1)<=radius)&np.isfinite(values))
        if not len(ids):continue
        codes,counts=np.unique(labels[ids],return_counts=True);component=codes[counts.argmax()];ids=ids[labels[ids]==component]
        v=values[ids];med[i]=v.mean() if mean else np.median(v);low[i],high[i]=np.quantile(v,[.25,.75]);support[i]=len(ids);components[i]=component
    # Do not draw a connecting segment across a graph-component transition.
    breaks=np.r_[False,(components[1:]!=components[:-1])&(components[1:]>=0)&(components[:-1]>=0)]
    med[breaks]=np.nan;low[breaks]=np.nan;high[breaks]=np.nan
    return t,med,low,high,support


class Table(QTableWidget):
    def __init__(self,headers):
        super().__init__(0,len(headers));self.setHorizontalHeaderLabels(headers);self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive);self.horizontalHeader().setStretchLastSection(True);self.setAlternatingRowColors(True);self.setSortingEnabled(False);self.setStyleSheet('QTableWidget {background:#18212d;alternate-background-color:#243241;color:#e3ecf6;gridline-color:#3a4b5e;selection-background-color:#376f8c;}')
        self.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers);self.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectItems)
    def fill(self,rows):
        self.setRowCount(len(rows))
        for i,row in enumerate(rows):
            for j,v in enumerate(row):
                text='—' if v is None or isinstance(v,(float,np.floating)) and not np.isfinite(v) else f'{float(v):.8g}' if isinstance(v,(float,np.floating)) else str(v)
                item=QTableWidgetItem(text);item.setToolTip(repr(v));self.setItem(i,j,item)
        self.resizeColumnsToContents()
    def keyPressEvent(self,event):
        if event.key()==Qt.Key.Key_C and event.modifiers()&Qt.KeyboardModifier.ControlModifier:
            selected=self.selectedIndexes()
            if selected:
                rows=sorted({i.row() for i in selected});cols=sorted({i.column() for i in selected});QApplication.clipboard().setText('\n'.join('\t'.join(self.item(r,c).text() if self.item(r,c) else '' for c in cols) for r in rows));return
        super().keyPressEvent(event)


def canvas():
    fig=Figure(facecolor='#161d27');view=FigureCanvasQTAgg(fig);return fig,view

def style(ax,title):
    ax.set_facecolor('#161d27');ax.tick_params(colors='#a8bdce',labelsize=8);ax.set_title(title,color='#e1ebf5',fontsize=10);ax.grid(alpha=.13)


class EvidencePanel(QTabWidget):
    def __init__(self,owner):
        super().__init__();self.owner=owner;self.dirty=True;self.currentChanged.connect(lambda *_:self.refresh());self.currentChanged.connect(lambda *_:owner.update_interpretation())
        self.journey=QWidget();jl=QVBoxLayout(self.journey);self.scope_note=QLabel('Yellow = here · coral = ahead · shaded ribbon = local interquartile spread, not confidence. Empty support and graph boundaries break traces.');self.scope_note.setWordWrap(True);jl.addWidget(self.scope_note)
        self.journey_fig,self.journey_canvas=canvas();self.direction_fig,self.direction_canvas=canvas();self.journey_canvas.setMinimumHeight(170);self.direction_canvas.setMinimumHeight(150);self.journey_split=QSplitter(Qt.Orientation.Vertical);self.journey_split.addWidget(self.journey_canvas);self.journey_split.addWidget(self.direction_canvas);self.journey_split.setSizes([260,190]);jl.addWidget(self.journey_split);self.addTab(self.journey,'Here → ahead')
        self.geometry=Table(['Measurement','Here median','Here n','Ahead median','Ahead n','Δ ahead − here']);self.geometry.cellClicked.connect(self.map_geometry);self.geometry_tabs=QTabWidget();self.geometry_fig,self.geometry_canvas=canvas();from PySide6.QtWidgets import QScrollArea
        from .compact_geometry import CompactGeometry
        self.compact_geometry=CompactGeometry(owner);compact_scroll=QScrollArea();compact_scroll.setWidgetResizable(True);compact_scroll.setWidget(self.compact_geometry);self.geometry_tabs.addTab(compact_scroll,'Compact groups');self.compact_geometry.measurementPicked.connect(lambda key:self.owner.field.setCurrentText(key));self.geometry_tabs.currentChanged.connect(lambda *_:self.refresh())
        geometry_scroll=QScrollArea();geometry_scroll.setWidgetResizable(True);geometry_scroll.setWidget(self.geometry_canvas);self.geometry_tabs.addTab(geometry_scroll,'Profiles & endpoints');self.geometry_tabs.addTab(self.geometry,'Values & deltas');self.addTab(self.geometry_tabs,'Geometry in context');self.geometry_canvas.mpl_connect('button_press_event',self.map_geometry_profile)
        self.anatomy_fig,self.anatomy_canvas=canvas();self.anatomy_canvas.setMinimumHeight(430);anatomy_scroll=QScrollArea();anatomy_scroll.setWidgetResizable(True);anatomy_scroll.setWidget(self.anatomy_canvas);self.addTab(anatomy_scroll,'Shapes & spectra')
        self.audit=QWidget();al=QVBoxLayout(self.audit);self.audit_note=QLabel();self.audit_note.setWordWrap(True);al.addWidget(self.audit_note)
        self.audit_table=Table(['Feature','Type','Known / cohort','Missing','Cohort mean / positive share','Cohort spread','Here','Ahead','Δ','Observed n (here / ahead)','Cohort min','Cohort max','Provenance','Matched prediction n','Broad MAE / Brier','Regional MAE / Brier','Broad − regional gain']);self.audit_tabs=QTabWidget();self.audit_tabs.addTab(self.audit_table,'Summary & prediction evidence');al.addWidget(self.audit_tabs,1)
        self.audit_fig,self.audit_canvas=canvas();self.audit_tabs.addTab(self.audit_canvas,'Distributions');self.associations=Table(['Feature A','Feature B / geometry','Statistic','Value','Paired n']);self.audit_tabs.addTab(self.associations,'Associations');self.regression_probes=Table(['Feature','Model','PCs','Held-out n','MAE ↓','RMSE ↓','R² ↑','Baseline MAE','MAE gain ↑']);self.classification_probes=Table(['Feature','Type','Model','PCs','Held-out n','Accuracy ↑','Balanced acc. ↑','Macro F1 ↑','ROC-AUC ↑','Log loss ↓','Brier ↓','Baseline Brier','Brier skill ↑']);self.audit_tabs.addTab(self.regression_probes,'Regression probes');self.audit_tabs.addTab(self.classification_probes,'Classification probes');self.probe_legend=QLabel('Held-out matched anchors · gray = unavailable · teal = lower error / positive skill · coral = worse than baseline. Raw metric values and support are shown; scales are metric-specific.');self.probe_legend.setWordWrap(True);al.addWidget(self.probe_legend);from .probe_views import scale_key_html
        self.probe_scale=QLabel(scale_key_html());self.probe_scale.setWordWrap(True);al.addWidget(self.probe_scale);self.addTab(self.audit,'Feature audit')
        self.scale=QWidget();sl=QVBoxLayout(self.scale);sr=QHBoxLayout();sr.addWidget(QLabel('Evaluation region'));self.scale_scope=QComboBox();self.scale_scope.addItems(['Here','Ahead','Kept selection','All measured anchors']);self.scale_scope.currentTextChanged.connect(lambda *_:self.refresh());sr.addWidget(self.scale_scope);sl.addLayout(sr)
        self.scale_fig,self.scale_canvas=canvas();self.scale_split=QSplitter(Qt.Orientation.Vertical);self.scale_split.addWidget(self.scale_canvas);sl.addWidget(self.scale_split,1);self.scale_table=Table(['Feature / dimension','Matched n','Broad error','Local error','Baseline','Broad − local gain']);self.scale_values=QTabWidget();self.scale_values.addTab(self.scale_table,'Matched values & deltas');self.scale_split.addWidget(self.scale_values);self.scale_split.setSizes([240,200])
        self.account_table=Table(['Fold','Chosen account','Directions','Validation error','Validation support']);self.scale_values.addTab(self.account_table,'Validation choices');self.transfer_table=Table(['Feature','Training region','Test region','Retained directions','Held-out MAE','Test n']);self.scale_values.addTab(self.transfer_table,'Transfer values');self.addTab(self.scale,'What survives scale?')
        self.exact=QWidget();el=QVBoxLayout(self.exact);self.exact_note=QLabel('Exact summaries over measured anchors only. Δ = ahead mean − here mean. Missing values are omitted, never zero. Click a row to map it. Ctrl+C copies selected cells.');self.exact_note.setWordWrap(True);el.addWidget(self.exact_note)
        filters=QHBoxLayout();self.values_family=QComboBox();self.values_family.addItems(['Geometry & stability','Source features','Reconstruction probes','Compression','Routes','All measurements']);self.values_feature=QComboBox();self.values_feature.addItems(['All features']+owner.definition['settings']['features']);filters.addWidget(self.values_family);filters.addWidget(self.values_feature);el.addLayout(filters);self.values_family.currentIndexChanged.connect(lambda _:self.refresh());self.values_feature.currentIndexChanged.connect(lambda _:self.refresh());self.visible_value_keys=[]
        self.exact_table=Table(['Channel','Here n','Here mean','Here median','Ahead n','Ahead mean','Ahead median','Δ mean','All measured mean']);self.value_tabs=QTabWidget();self.value_tabs.addTab(self.exact_table,'Here / ahead summaries');el.addWidget(self.value_tabs)
        raw=QWidget();raw_layout=QVBoxLayout(raw);self.anchor_filter=QComboBox();self.anchor_filter.addItems(['All measured anchors','Here','Ahead','Kept selection']);self.anchor_filter.currentIndexChanged.connect(lambda _:self.refresh());raw_layout.addWidget(self.anchor_filter);self.anchor_group=QComboBox();self.anchor_group.addItems(['Overview','Geometry','Source features','Reconstruction probes']);self.anchor_group.currentIndexChanged.connect(lambda _:self.refresh());raw_layout.addWidget(self.anchor_group);self.anchor_note=QLabel();raw_layout.addWidget(self.anchor_note);self.anchor_table=Table(['Canonical ID']);raw_layout.addWidget(self.anchor_table);self.value_tabs.addTab(raw,'Item values');self.value_tabs.currentChanged.connect(lambda _:self.refresh())
        self.exact_table.cellClicked.connect(self.map_row);self.addTab(self.exact,'Values & deltas')
        self.selection=QWidget();sel=QVBoxLayout(self.selection);self.selection_note=QLabel();self.selection_note.setWordWrap(True);sel.addWidget(self.selection_note)
        self.selection_table=Table(['Canonical ID','Collection row','Displayed value','x','y']);sel.addWidget(self.selection_table);self.addTab(self.selection,'Kept selection')
    def map_geometry(self,row,column):
        keys=[k for k in self.owner.fields if not k.startswith(('feature/','reconstruction/','reference_evaluation/'))]
        if row<len(keys):self.owner.field.setCurrentText(keys[row])
    def map_row(self,row,column):
        keys=self.visible_value_keys
        if row<len(keys):self.owner.field.setCurrentText(keys[row])
    def refresh(self):
        w=self.owner;l=w.landscape
        if l.arrays is None:return
        here=l.attention();ahead=l.attention(True);tab=self.currentIndex()
        if tab==0:self.draw_journey(here,ahead)
        elif tab==1:
            rows=[]
            for key,v in w.fields.items():
                if key.startswith('feature/') or key.startswith(('reconstruction/','reference_evaluation/')):continue
                a,b=finite_stats(v[here]),finite_stats(v[ahead]);rows.append([label(key),a['median'],a['n'],b['median'],b['n'],b['median']-a['median'] if a['n'] and b['n'] else None])
            self.geometry.fill(rows)
            if self.geometry_tabs.currentIndex()==0:self.compact_geometry.refresh(w,here,ahead)
            elif self.geometry_tabs.currentIndex()==1:self.draw_geometry_profiles(here,ahead)
        elif tab==2:self.draw_anatomy()
        elif tab==3:self.draw_audit(here,ahead)
        elif tab==4:self.draw_scale(here,ahead)
        elif tab==5:
            rows=[]
            self.visible_value_keys=self.filtered_value_keys()
            for key in self.visible_value_keys:
                v=w.fields[key];a,b,total=finite_stats(v[here]),finite_stats(v[ahead]),finite_stats(v);categorical=key.startswith('feature/') and w.store.catalog.raw['features'][key.split('/',1)[1]]['kind']=='category'
                rows.append([label(key),a['n'],None if categorical else a['mean'],None if categorical else a['median'],b['n'],None if categorical else b['mean'],None if categorical else b['median'],b['mean']-a['mean'] if a['n'] and b['n'] and not categorical else None,None if categorical else total['mean']])
            self.exact_table.fill(rows);self.draw_anchor_values(here,ahead)
        else:self.draw_selection()
        w.update_interpretation()
    def draw_journey(self,here,ahead):
        w=self.owner;l=w.landscape;self.journey_fig.clear();feature=w.feature.currentText();source=w.fields.get('feature/'+feature);gap=w.fields.get('discrepancy/discrepancy');geom=w.fields.get('geometry/'+w.geometry_metric.currentData(),w.fields.get('geometry/effective_dimension'))
        labels=l.component_labels if l.component_labels is not None else l.arrays['filtration_labels'][l.filtration_index]
        lanes=[('Geometry · '+label('geometry/'+str(w.geometry_metric.currentData())),geom,False),('Observed feature · '+feature,source,False),('Explanation gap · signed chord residual',gap,False)]
        for i,(title,values,mean) in enumerate(lanes):
            ax=self.journey_fig.add_subplot(1,3,i+1);style(ax,title)
            if values is None:ax.text(.1,.5,'Not computed / loaded',transform=ax.transAxes,color='white');continue
            if i==1:
                kind=w.store.catalog.raw['features'][feature]['kind']
                if kind=='category':
                    known=values[np.isfinite(values)];code=int(np.bincount(known.astype(int)).argmax()) if len(known) else 0;values=np.where(np.isfinite(values),(values==code).astype(float),np.nan);title+=' · share of '+w.store.catalog.labels(feature).get(str(code),{}).get('name',str(code));ax.set_title(title,color='white',fontsize=9);mean=True
                elif kind=='boolean':mean=True
            t,mid,low,high,n=ribbon_samples(l.arrays['xy'],values,l.position,l.yaw,l.radius,l.look_distance,labels,mean)
            ax.plot(t,mid,color='#68cbb6',lw=1.5);ax.fill_between(t,low,high,color='#68cbb6',alpha=.22);ax.axvline(0,color='#ffdb6e',lw=1);ax.axvline(l.radius*l.look_distance,color='#ff9970',lw=1);ax.set_xlabel('Projected distance along view',color='#a8bdce',fontsize=8)
        self.journey_fig.subplots_adjust(left=.045,right=.985,bottom=.21,top=.85,wspace=.3);self.journey_canvas.draw_idle();self.draw_direction_ribbons()
    def anchors_here_ahead(self):
        l=self.owner.landscape;xy=l.arrays['xy'];ids=np.flatnonzero(np.isfinite(xy).all(1));out=[]
        for ahead in [False,True]:
            p=l.position+np.array([math.cos(l.yaw),math.sin(l.yaw)])*l.radius*l.look_distance if ahead else l.position
            i=ids[np.argmin(np.linalg.norm(xy[ids]-p,axis=1))] if len(ids) else None
            out.append(int(i) if i is not None and np.linalg.norm(xy[i]-p)<=l.radius else None)
        return out
    def draw_direction_ribbons(self):
        l=self.owner.landscape;self.direction_fig.clear();data=self.owner.loaded.get('directions');indices=self.anchors_here_ahead();scores=data[0]['direction_scores'] if data else None
        amp=max([float(np.max(np.abs(scores[i]))) for i in indices if i is not None]+[1e-12]) if scores is not None else 1
        for col,(name,i,color) in enumerate(zip(['Here','Ahead'],indices,['#ffdb6e','#ff9970'])):
            ax=self.direction_fig.add_subplot(1,2,col+1);style(ax,name+' · unfolded PCA direction ribbons')
            if scores is None:ax.text(.05,.5,'Compute Direction ribbons to show actual neighbor PC scores',color='white',transform=ax.transAxes,fontsize=9);continue
            if i is None:ax.text(.05,.5,'No supported neighborhood',color='white',transform=ax.transAxes);continue
            values=scores[i];x=np.arange(1,values.shape[1]+1)
            for row in values:ax.plot(x,row,color=color,alpha=.32,lw=.85)
            ax.axhline(0,color='#8595a5',lw=.5);ax.set_ylim(-amp*1.08,amp*1.08);ax.set_xlabel('Local PCA direction · one line per measured neighbor',color='#a8bdce',fontsize=8);ax.set_ylabel('Centered chord score',color='#a8bdce',fontsize=8)
        self.direction_fig.subplots_adjust(left=.06,right=.985,bottom=.26,top=.82,wspace=.3);self.direction_canvas.draw_idle()
    def draw_geometry_profiles(self,here,ahead):
        w=self.owner;l=w.landscape;keys=[k for k in w.fields if not k.startswith(('feature/','reconstruction/','reference_evaluation/'))];self.geometry_fig.clear();rows=max(1,math.ceil(len(keys)/2));self.geometry_canvas.setMinimumHeight(rows*160);labels=l.component_labels if l.component_labels is not None else l.arrays['filtration_labels'][-1]
        for j,key in enumerate(keys):
            v=w.fields[key];ax=self.geometry_fig.add_subplot(rows,2,j+1);style(ax,label(key));ax._field_key=key
            t,mid,lo,hi,n=ribbon_samples(l.arrays['xy'],v,l.position,l.yaw,l.radius,l.look_distance,labels);ax.plot(t,mid,color='#76bdc9',lw=1.2);ax.fill_between(t,lo,hi,color='#76bdc9',alpha=.12)
            a,b=finite_stats(v[here]),finite_stats(v[ahead]);fa=f"{a['median']:.5g}" if a['n'] else '—';fb=f"{b['median']:.5g}" if b['n'] else '—'
            for x,summary,color in [(0,a,'#ffdb6e'),(l.radius*l.look_distance,b,'#ff9970')]:
                ax.axvline(x,color=color,lw=.7)
                if summary['n']:ax.scatter([x],[summary['median']],color=color,s=24,zorder=5)
            ax.text(.01,.93,f"Here {fa} (n={a['n']})",transform=ax.transAxes,color='#ffdb6e',fontsize=8,va='top');ax.text(.99,.93,f"Ahead {fb} (n={b['n']})",transform=ax.transAxes,color='#ff9970',fontsize=8,va='top',ha='right')
            ax.margins(y=.3)
        self.geometry_fig.subplots_adjust(left=.07,right=.98,bottom=.035,top=.975,hspace=.65,wspace=.32);self.geometry_canvas.draw_idle()
    def map_geometry_profile(self,event):
        key=getattr(event.inaxes,'_field_key',None)
        if key:self.owner.field.setCurrentText(key)
    def draw_anatomy(self):
        l=self.owner.landscape;self.anatomy_fig.clear();indices=self.anchors_here_ahead();self.anatomy_indices=indices
        from .kernels.neighborhood_hull import neighborhood_hull
        from mpl_toolkits.mplot3d.art3d import Poly3DCollection
        from matplotlib.ticker import MaxNLocator
        grid=self.anatomy_fig.add_gridspec(3,3,height_ratios=[1,1,.55],width_ratios=[1,.3,2.2]);radius=max([float(np.abs(l.arrays['offsets'][i]).max()) for i in indices if i is not None]+[1e-8]);directions=self.owner.loaded.get('directions');scores=directions[0]['direction_scores'] if directions else None
        amp=max([float(np.abs(scores[i]).max()) for i in indices if i is not None]+[1e-12]) if scores is not None else 1
        self.anatomy_axes={};self.anatomy_scores=scores
        for row,(name,i,color) in enumerate(zip(['Here','Ahead'],indices,['#ffdb6e','#ff9970'])):
            sp=self.anatomy_fig.add_subplot(grid[row,0]);cloud=self.anatomy_fig.add_subplot(grid[row,1],projection='3d');ribbon=self.anatomy_fig.add_subplot(grid[row,2]);self.anatomy_axes[name]=dict(spectrum=sp,hull=cloud,ribbon=ribbon)
            for ax,title in [(sp,name+' · complete local variance spectrum'),(cloud,name+' · PCA-3'),(ribbon,name+' · neighbor direction ribbons')]:style(ax,title);ax.title.set_fontsize(8);ax.tick_params(labelsize=6)
            sp.set_ylim(0,1);sp.set_ylabel('Variance fraction',color='#b0bec9',fontsize=7);sp.xaxis.set_major_locator(MaxNLocator(nbins=8,integer=True));sp.set_xlabel('All measured PCA directions',color='#b0bec9',fontsize=7)
            cloud.set_xlim(-radius,radius);cloud.set_ylim(-radius,radius);cloud.set_zlim(-radius,radius);cloud.set_box_aspect((1,1,1),zoom=2.05);cloud.set_proj_type('ortho');cloud.set_axis_off();cloud.view_init(elev=22,azim=-60)
            cloud.text2D(.5,-.04,f'Shared scale\n±{radius:.3g} chord',transform=cloud.transAxes,ha='center',color='#aabcca',fontsize=6)
            if i is None:
                for ax in [sp,ribbon]:ax.text(.04,.5,'No supported neighborhood',transform=ax.transAxes,color='#c2cbd3',fontsize=8)
                continue
            offset=l.arrays['offsets'][i];spectrum=l.arrays['spectrum'][i];sp.bar(np.arange(1,len(spectrum)+1),spectrum,color=[color if k<3 else '#ad8ac8' for k in range(len(spectrum))]);cloud.scatter(*offset.T,s=15,c=color,edgecolors='#edf4f7',linewidths=.3,depthshade=False);hull=neighborhood_hull(dict(offsets=offset,spectrum=spectrum))
            if hull['triangles']:cloud.add_collection3d(Poly3DCollection(offset[np.asarray(hull['triangles'])],facecolors=color,edgecolors=color,alpha=.24,linewidths=.65))
            if scores is None:ribbon.text(.04,.5,'Compute Direction ribbons',transform=ribbon.transAxes,color='#c2cbd3',fontsize=8)
            else:
                values=scores[i];x=np.arange(1,values.shape[1]+1)
                for neighbor in values:ribbon.plot(x,neighbor,color=color,alpha=.35,lw=.7)
                ribbon.axhline(0,color='#8595a5',lw=.5);ribbon.set_ylim(-amp*1.08,amp*1.08);ribbon.xaxis.set_major_locator(MaxNLocator(nbins=8,integer=True))
            ribbon.set_xlabel('Local PCA direction',color='#b0bec9',fontsize=7);ribbon.set_ylabel('Centered chord score',color='#b0bec9',fontsize=7);ribbon.yaxis.set_label_position('right')
        ax=self.anatomy_fig.add_subplot(grid[2,:]);self.anatomy_covariance_ax=ax;style(ax,'Here → ahead · covariance dimensions');ax.title.set_fontsize(8);ax.tick_params(labelsize=6)
        labels=l.component_labels if l.component_labels is not None else l.arrays['filtration_labels'][-1];v=l.arrays['effective_dimension'];t,mid,low,high,n=ribbon_samples(l.arrays['xy'],v,l.position,l.yaw,l.radius,l.look_distance,labels);ax.plot(t,mid,color='#76bdc9',lw=1.1);ax.fill_between(t,low,high,color='#76bdc9',alpha=.18)
        for x,ix,color in [(0,l.attention(),'#ffdb6e'),(l.radius*l.look_distance,l.attention(True),'#ff9970')]:
            a=finite_stats(v[ix]);ax.axvline(x,color=color,lw=.8)
            if a['n']:ax.scatter([x],[a['median']],color=color,s=18);ax.annotate(f"{a['median']:.4g}",(x,a['median']),xytext=(4,5),textcoords='offset points',color=color,fontsize=8)
        ax.margins(y=.3);self.anatomy_fig.subplots_adjust(left=.055,right=.965,bottom=.085,top=.94,hspace=.50,wspace=.08);self.anatomy_canvas.draw_idle()
    def filtered_value_keys(self):
        groups=[('geometry/','stability/'),('feature/',),('reconstruction/','reference_evaluation/'),('compression/',),('routes/',),tuple()];prefix=groups[self.values_family.currentIndex()];feature=self.values_feature.currentText();keys=[]
        for key in self.owner.fields:
            if prefix and not key.startswith(prefix):continue
            if feature!='All features' and key.startswith(('feature/','reconstruction/','reference_evaluation/')) and key.split('/',1)[1].split('__q',1)[0]!=feature:continue
            keys.append(key)
        return keys
    def draw_audit(self,here,ahead):
        from .probe_views import draw_probe_tables
        draw_probe_tables(self)
        w=self.owner;data=w.loaded.get('feature_audit');summaries=data[1]['features'] if data else {};rows=[]
        self.audit_note.setText('Full-cohort distributions are saved and loaded. Local readings use measured anchors only; associations are descriptive.' if data else 'Full-cohort audit has not been computed / loaded. Use Compute & storage → Feature audit. Here/ahead readings below remain available from measured source values.')
        for name in w.definition['settings']['features']:
            spec=w.store.catalog.raw['features'][name];values=w.fields.get('feature/'+name)
            if values is None:continue
            a,b=finite_stats(values[here]),finite_stats(values[ahead]);s=summaries.get(name,{})
            def local(ix):
                v=values[ix];v=v[np.isfinite(v)]
                if not len(v):return None
                if spec['kind']=='category':
                    dictionary=w.store.catalog.labels(name);return '; '.join(f"{dictionary.get(str(int(code)),{}).get('name',str(int(code)))}: {(v==code).sum()}" for code in np.unique(v))
                return float(v.mean())
            delta=(b['mean']-a['mean']) if a['n'] and b['n'] and spec['kind']!='category' else None
            reconstruction=w.loaded.get('reconstruction') or w.loaded.get('reference_evaluation');bn=ln=gain=None;matched_n=0
            if reconstruction:
                prediction_arrays=reconstruction[0];prefix=f'{name}__q{w.dimension.currentText()}__';bvals=prediction_arrays.get(prefix+'broad');lvals=prediction_arrays.get(prefix+'local')
                if bvals is not None and lvals is not None:
                    good=np.isfinite(bvals)&np.isfinite(lvals);matched_n=int(good.sum())
                    if matched_n:bn=float(bvals[good].mean());ln=float(lvals[good].mean());gain=bn-ln
            rows.append([name,spec['kind'],f"{s.get('known','—')} / {s.get('question_rows','—')}",s.get('missing'),s.get('mean',s.get('positive_fraction')),s.get('std'),local(here),local(ahead),delta,f"{a['n']} / {b['n']}",s.get('min'),s.get('max'),spec.get('provenance'),matched_n,bn,ln,gain])
        self.audit_table.fill(rows);self.audit_table.cellClicked.connect(self.audit_feature) if not getattr(self,'_audit_connected',False) else None;self._audit_connected=True
        feature=w.feature.currentText();values=w.fields.get('feature/'+feature);self.audit_fig.clear();ax=self.audit_fig.add_subplot(111);style(ax,feature+' · cohort / here / ahead distributions')
        if values is not None:
            spec=w.store.catalog.raw['features'][feature];s=summaries.get(feature,{})
            if spec['kind']=='numeric':
                known=values[np.isfinite(values)];edges=np.asarray(s['histogram']['edges']) if 'histogram' in s else np.histogram_bin_edges(known,bins=16) if len(known) else np.linspace(0,1,17)
                if 'histogram' in s:
                    counts=np.asarray(s['histogram']['counts']);ax.stairs(counts/max(1,counts.sum()),edges,color='#708298',label='Cohort (all known rows)',fill=True,alpha=.15)
                for ix,color,name in [(here,'#ffdb6e','Here'),(ahead,'#ff9970','Ahead')]:
                    v=values[ix];v=v[np.isfinite(v)];counts=np.histogram(v,edges)[0];ax.stairs(counts/max(1,len(v)),edges,color=color,label=f'{name} (n={len(v)})')
            else:
                codes=np.arange(spec.get('cardinality') or 2);dictionary=w.store.catalog.labels(feature);labels=[dictionary.get(str(int(i)),{}).get('name',str(int(i))) for i in codes]
                for offset,(ix,color,name) in enumerate([(here,'#ffdb6e','Here'),(ahead,'#ff9970','Ahead')]):
                    v=values[ix];v=v[np.isfinite(v)];counts=np.bincount(v.astype(int),minlength=len(codes));ax.bar(codes+(offset-.5)*.23,counts/max(1,len(v)),width=.23,color=color,label=f'{name} (n={len(v)})')
                if 'counts' in s:ax.plot(codes,np.asarray(s['counts'])/max(1,s['known']),'o',color='#a8c6e0',label='Cohort')
                ax.set_xticks(codes,labels)
            ax.set_ylabel('Known-row fraction',color='#a8bdce');ax.legend(fontsize=8)
        self.audit_fig.subplots_adjust(left=.08,right=.98,bottom=.22,top=.86);self.audit_canvas.draw_idle()
        relations=[]
        if data:
            for record in data[1]['geometry_associations']:relations.append([record['feature'],NAMES.get(record['geometry'],record['geometry']),record['method'],record['value'],record['n']])
            for record in data[1]['feature_associations']:relations.append([record['a'],record['b'],record['method'],record['value'],record['n']])
        self.associations.fill(relations)
    def audit_feature(self,row,column):
        names=self.owner.definition['settings']['features']
        if row<len(names):self.owner.feature.setCurrentText(names[row]);self.refresh()
    def draw_scale(self,here,ahead):
        w=self.owner;l=w.landscape;name=w.feature.currentText();data=w.loaded.get('reconstruction') or w.loaded.get('reference_evaluation');self.scale_fig.clear();curve=self.scale_fig.add_subplot(121);transfer=self.scale_fig.add_subplot(122);style(curve,'What survives the change of scale?');style(transfer,'Held-out region transfer · raw loss')
        rows=[];choices=[];transfer_rows=[]
        if data:
            arrays,meta=data;scope=[here,ahead,np.flatnonzero(np.isin(l.rows,getattr(w,'selected_rows',[]))),np.arange(len(l.rows))][self.scale_scope.currentIndex()];qs=w.definition['settings']['dimensions'];ys=[[],[],[]]
            for q in qs:
                prefix=f'{name}__q{q}__';b=arrays.get(prefix+'broad');local=arrays.get(prefix+'local');base=arrays.get(prefix+'baseline')
                if b is None or local is None:continue
                ix=scope[np.isfinite(b[scope])&np.isfinite(local[scope])];bv=float(b[ix].mean()) if len(ix) else None;lv=float(local[ix].mean()) if len(ix) else None;baseline=float(base[ix].mean()) if len(ix) and base is not None else None
                rows.append([f'{name} / {q}',len(ix),bv,lv,baseline,bv-lv if bv is not None else None]);ys[0].append(q);ys[1].append(bv if bv is not None else np.nan);ys[2].append(lv if lv is not None else np.nan)
            curve.plot(ys[0],ys[1],'-o',color='#8eb5ed',label='Broad',picker=6);curve.plot(ys[0],ys[2],'-o',color='#e5ba75',label='Local',picker=6);curve.set_xlabel('Retained directions · each dimension’s matched broad/local support',color='#b0bec9');kind=w.store.catalog.raw['features'][name]['kind'];curve.set_ylabel('MAE (target units)' if kind=='numeric' else 'Binary Brier' if kind=='boolean' else 'Multiclass Brier',color='#b0bec9');curve.legend(fontsize=8)
            numeric=meta.get('numeric',{});records=[r for r in numeric.get('transfer',[]) if r['feature']==name]
            if records:
                size=max(max(r['source_region'],r['target_region']) for r in records)+1;matrix=np.full((size,size),np.nan)
                for r in records:
                    matrix[r['source_region'],r['target_region']]=r['mae'];transfer_rows.append([name,r['source_region'],r['target_region'],r.get('dimension'),r['mae'],r['n']])
                image=transfer.imshow(np.ma.masked_invalid(matrix),cmap='viridis');self.scale_fig.colorbar(image,ax=transfer,fraction=.05);transfer.set_xlabel('Test region',color='#b0bec9');transfer.set_ylabel('Training region',color='#b0bec9')
            else:transfer.text(.05,.5,'No numeric transfer evidence for this target',color='white',transform=transfer.transAxes)
            for item in numeric.get('selections',[]):
                if item['feature']!=name:continue
                pick=item.get('selected') or {};choices.append([item['fold'],pick.get('account','No adequate account'),pick.get('dimension'),pick.get('validation_mae'),pick.get('validation_n')])
            for item in meta.get('classification',[]):
                if item.get('feature')==name and 'selected' in item:
                    pick=item.get('selected') or {};choices.append([item['fold'],pick.get('account','No adequate account'),pick.get('dimension'),pick.get('validation_loss'),pick.get('n_validation')])
        else:curve.text(.05,.5,'Compute / load reconstruction to compare accounts',color='white',transform=curve.transAxes)
        self.scale_table.fill(rows);self.account_table.fill(choices);self.transfer_table.fill(transfer_rows);self.scale_fig.subplots_adjust(left=.075,right=.97,bottom=.22,top=.85,wspace=.42);self.scale_canvas.draw_idle()
    def draw_anchor_values(self,here,ahead):
        w=self.owner;l=w.landscape
        scope=[np.arange(len(l.rows)),here,ahead,np.flatnonzero(np.isin(l.rows,w.selected_rows))][self.anchor_filter.currentIndex()];shown=scope[:2000]
        keys=['geometry/'+name for name in ['effective_dimension','hidden_two','radius','radius_dimension']] if self.anchor_group.currentIndex()==1 else []
        keys+=['feature/'+name for name in w.definition['settings']['features'] if self.values_feature.currentText() in ('All features',name)] if self.anchor_group.currentIndex()==2 else []
        prefix='reconstruction' if 'reconstruction' in w.loaded else 'reference_evaluation';keys+=[f'{prefix}/{w.feature.currentText()}__q{w.dimension.currentText()}__{name}' for name in ['broad','local','gain','baseline']] if self.anchor_group.currentIndex()==3 else [];keys=[k for k in keys if k in w.fields]
        headers=['Canonical ID','Collection row','Here','Ahead','Kept','Mapped value']+[label(k) for k in keys];self.anchor_table.setColumnCount(len(headers));self.anchor_table.setHorizontalHeaderLabels(headers)
        ids=w.store.catalog.load(w.store.catalog.collection(w.definition['collection'])['item_ids'])[l.rows[shown]];hs,as_,ks=set(here),set(ahead),set(w.selected_rows)
        records=[[item,int(l.rows[i]),i in hs,i in as_,int(l.rows[i]) in ks,l.values[i]]+[w.fields[k][i] for k in keys] for item,i in zip(ids,shown)]
        self.anchor_table.fill(records);self.anchor_note.setText(f'{len(shown):,} of {len(scope):,} measured anchors shown (display limit 2,000). Missing = unavailable, including held-out local support. Category columns are codes; names appear in Feature audit.')
    def draw_selection(self):
        w=self.owner;l=w.landscape;rows=np.asarray(getattr(w,'selected_rows',[]),np.int64);count=len(rows);shown=rows[:2000];ids=w.store.catalog.load(w.store.catalog.collection(w.definition['collection'])['item_ids'])[shown]
        lookup={int(r):i for i,r in enumerate(l.rows)};records=[]
        for row,item in zip(shown,ids):
            i=lookup.get(int(row));v=float(l.values[i]) if i is not None and np.isfinite(l.values[i]) else None;xy=l.arrays['xy'][i] if i is not None else [None,None];records.append([item,int(row),v,*xy])
        self.selection_note.setText(f'{count:,} canonical items kept. Showing first {len(shown):,}; export includes the entire kept set. Unmeasured/unprojected items remain in membership.');self.selection_table.fill(records)
