"""Offline and native workflows share definitions, instruments and contracts."""
import argparse
import json
from pathlib import Path
from .catalog import Catalog,clean
from .store import Store
from .instruments import REGISTRY,plan,generate
from .demo import demo
from .comparison import compare,controlled_pair


def main(argv=None):
    parser=argparse.ArgumentParser(description='HyCompass native representation ecology')
    parser.add_argument('--workspace',type=Path,default=Path('demo_workspace'))
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('demo');p.add_argument('--rows',type=int,default=360);p.add_argument('--no-generate',action='store_true')
    p=sub.add_parser('define');p.add_argument('--domain',required=True);p.add_argument('--membership',type=Path,required=True,help='Canonical collection-row .npy');p.add_argument('--settings',type=Path);p.add_argument('--title',default='Map')
    for cmd in ['plan','generate','inspect','open']:
        p=sub.add_parser(cmd);p.add_argument('map',nargs='?' if cmd=='open' else None);p.add_argument('--instruments',nargs='+',choices=list(REGISTRY),default=['geometry'])
        if cmd=='generate':p.add_argument('--continue-on-error',action='store_true')
    p=sub.add_parser('compare');p.add_argument('a');p.add_argument('b');p.add_argument('--instrument',default='geometry',choices=list(REGISTRY))
    p=sub.add_parser('controlled-pair');p.add_argument('a');p.add_argument('b');p.add_argument('--membership',type=Path,required=True);p.add_argument('--settings',type=Path);p.add_argument('--title',default='Controlled comparison')
    p=sub.add_parser('delete-artifact');p.add_argument('map');p.add_argument('instrument',choices=list(REGISTRY))
    p=sub.add_parser('register-collection');p.add_argument('name');p.add_argument('--ids',required=True);p.add_argument('--groups')
    p=sub.add_parser('register-domain');p.add_argument('domain');p.add_argument('collection')
    p=sub.add_parser('register-feature');p.add_argument('name');p.add_argument('collection');p.add_argument('--kind',required=True,choices=['numeric','boolean','category']);p.add_argument('--values',required=True);p.add_argument('--valid',required=True);p.add_argument('--labels');p.add_argument('--cardinality',type=int)
    p=sub.add_parser('serve');p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8765)
    p=sub.add_parser('resolve-navigation');p.add_argument('selection',type=Path,help='JSON selection contract; optional subset_rows')
    p=sub.add_parser('list-maps')
    p=sub.add_parser('capabilities');p.add_argument('map_id')
    p=sub.add_parser('rename');p.add_argument('map_id');p.add_argument('title')
    p=sub.add_parser('duplicate');p.add_argument('map_id');p.add_argument('title')
    p=sub.add_parser('delete-map');p.add_argument('map_id')
    p=sub.add_parser('delete-results');p.add_argument('map_id')
    p=sub.add_parser('export');p.add_argument('map_id');p.add_argument('destination',type=Path);p.add_argument('--profile',choices=['definition','viewing','embeddings','targets','full'],default='viewing')
    p=sub.add_parser('import-package');p.add_argument('package',type=Path);p.add_argument('destination',type=Path)
    p=sub.add_parser('attach-package');p.add_argument('package',type=Path)
    p=sub.add_parser('register-result');p.add_argument('map_id');p.add_argument('descriptor',type=Path,help='JSON with typed item_ids, predictions, target, kind, scope, provenance, expected_revision')
    args=parser.parse_args(argv)
    import numpy as np
    if args.command=='demo':print(demo(args.workspace,args.rows,not args.no_generate));return
    if args.command=='open':
        from main import main as app_main
        return app_main(['--workspace',str(args.workspace)]+(['--map',args.map] if args.map else []))
    if args.command.startswith('register-'):
        c=Catalog(args.workspace)
        if args.command=='register-collection':c.register_collection(args.name,args.ids,args.groups)
        elif args.command=='register-domain':c.register_domain(args.domain,args.collection)
        else:c.register_feature(args.name,args.collection,args.kind,args.values,args.valid,args.labels,args.cardinality)
        print('Registered');return
    if args.command=='serve':
        import uvicorn
        from api.app import create_app
        from api.runtime import RuntimeState
        from model.workspace import WorkspaceSession
        uvicorn.run(create_app(WorkspaceSession(args.workspace),RuntimeState()),host=args.host,port=args.port);return
    if args.command=='import-package':
        from .packages import import_package
        print(json.dumps(clean(import_package(args.package,args.destination)),indent=2));return
    store=Store(args.workspace)
    if args.command in ('list-maps','capabilities','rename','duplicate','delete-map','delete-results','export','attach-package','register-result'):
        from .packages import export_package,attach_package
        from .results import register_result
        if args.command=='list-maps':result=store.summaries()
        elif args.command=='capabilities':result=store.capabilities(args.map_id)
        elif args.command=='rename':result=store.rename(args.map_id,args.title)
        elif args.command=='duplicate':result=store.duplicate(args.map_id,args.title)
        elif args.command=='delete-map':result=store.delete(args.map_id)
        elif args.command=='delete-results':result=store.delete_results(args.map_id)
        elif args.command=='export':result=export_package(store,args.map_id,args.destination,args.profile)
        elif args.command=='attach-package':result=attach_package(args.package,args.workspace)
        else:result=register_result(store,args.map_id,**json.loads(args.descriptor.read_text()))
        print(json.dumps(clean(result),indent=2));return
    if args.command=='resolve-navigation':
        from .navigation import Selection,resolve_saved
        from dataclasses import asdict
        payload=json.loads(args.selection.read_text());result=asdict(resolve_saved(store,Selection(**payload['selection']),payload.get('subset_rows')))
    elif args.command=='define':result=store.create(args.title,args.domain,np.load(args.membership,allow_pickle=False),json.loads(args.settings.read_text()) if args.settings else None)
    elif args.command=='plan':result=plan(store,args.map,args.instruments)
    elif args.command=='generate':
        from .instruments import generate_many
        result=(generate_many if args.continue_on_error else generate)(store,args.map,args.instruments,progress=lambda s,f:print(f'{s}: {f:.0%}',flush=True))
    elif args.command=='inspect':result=dict(definition=store.read(args.map),status=store.status(args.map),disk_bytes=store.disk_bytes(args.map))
    elif args.command=='compare':result=compare(store,args.a,args.b,args.instrument)
    elif args.command=='controlled-pair':result=controlled_pair(store,args.title,args.a,args.b,np.load(args.membership,allow_pickle=False),json.loads(args.settings.read_text()) if args.settings else {})
    else:store.delete_artifact(args.map,args.instrument);result='Deleted'
    print(json.dumps(clean(result),indent=2))

if __name__=='__main__':main()
