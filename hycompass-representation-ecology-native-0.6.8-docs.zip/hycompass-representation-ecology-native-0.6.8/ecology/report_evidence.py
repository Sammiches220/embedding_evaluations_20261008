"""Small chart summaries of saved results for the offline report."""
import math
import re

import numpy as np

from .catalog import checksum

MAX_ARRAY_BYTES = 4 * 1024 * 1024

# Each entry names one saved field and keeps its own scale and support.
PROFILES = {
    "geometry": (
        ("effective_dimension", "How many directions matter nearby?", "Effective dimension",
         "A larger effective dimension means variation is spread across more local directions."),
        ("radius", "How far away is the available support?", "Kth-neighbor chord distance",
         "Larger distances mean reaching farther in the source embedding to find the same number of neighbors."),
        ("hidden_two", "What do two local axes leave out?", "Omitted variance fraction",
         "A larger fraction means two local PCA axes capture less of the neighborhood’s variation."),
        ("radius_dimension", "How quickly do neighborhoods grow?", "Radius-growth dimension",
         "This is a growth proxy measured from neighbor distances. It differs from the covariance-based dimension."),
    ),
    "stability": (
        ("perturbation_jaccard", "What survives coordinate perturbation?", "Neighbor overlap",
         "Each value is the saved mean overlap for an anchor across the declared perturbations."),
        ("resampling_jaccard", "What survives reference resampling?", "Neighbor overlap",
         "Each value is the saved mean overlap for an anchor across the tested reference subsamples."),
    ),
    "routes": (
        ("deletion_damage", "Where can the graph lose its routes?", "Disconnected-pair fraction",
         "Removing a high-impact anchor disconnects more pairs in the fixed saved graph."),
    ),
    "compression": (
        ("projection_neighbor_jaccard", "Does the display preserve neighbors?", "Neighbor overlap",
         "Higher overlap means the display retains more of the same eligible source-space neighbors."),
    ),
    "discrepancy": (
        ("residual", "Where do predicted distances miss?", "Signed chord residual",
         "Positive residuals mean observed pairs are farther apart than predicted. Negative values mean they are closer."),
    ),
}


def saved_charts(folder, component, meta, result):
    """Read only bounded, checksum-verified saved arrays and return small summaries."""
    schemas = meta.get("arrays", {})
    budget = MAX_ARRAY_BYTES * 4

    def load(name):
        nonlocal budget
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_.-]+", name):
            return None
        spec = schemas.get(name)
        if not spec:
            return None
        path = folder / (name + ".npy")
        try:
            size = path.stat().st_size
            if size > min(MAX_ARRAY_BYTES, budget) or size != spec["bytes"]:
                return None
            budget -= size
            if checksum(path) != spec["sha256"]:
                return None
            array = np.load(path, mmap_mode="r", allow_pickle=False)
            if list(array.shape) == spec["shape"] and str(array.dtype) == spec["dtype"] and array.dtype.kind in "fiu":
                return array
        except (OSError, ValueError, KeyError):
            pass
        return None

    def chart(title, scope, x, y, samples, *, kind="line"):
        return dict(title=title, scope=scope, x=x, y=y, samples=samples,
                    result=result, selections=[], kind=kind)

    out = []
    for name, title, units, description in PROFILES.get(component, ()):
        values = load(name)
        if values is None or values.ndim != 1:
            continue
        values = values[np.isfinite(values)]
        if not len(values):
            continue
        percentiles = np.arange(0, 101, 5)
        quantiles = np.quantile(values, percentiles / 100)
        out.append(chart(title, f"{description} Distribution over {len(values):,} finite saved values.",
                         "Percentile of saved values", units, list(zip(percentiles.tolist(), quantiles.tolist()))))

    if component == "geometry":
        spectrum = load("spectrum")
        if spectrum is not None and spectrum.ndim == 2 and spectrum.shape[1] >= 2:
            rows = spectrum[np.isfinite(spectrum).all(axis=1) & (spectrum.sum(axis=1) > 0.5)]
            if len(rows):
                energy = np.median(rows[:, :24], axis=0).tolist()
                out.append(chart("How quickly does local variation fall away?",
                                 f"Median variance share at each ranked local PCA axis across {len(rows):,} usable anchor spectra. Local axes can differ between anchors.",
                                 "Ranked local axis", "Median variance share", list(enumerate(energy, 1))))

    if component == "compression":
        for suffix, title, units in (
            ("jaccard", "Which neighbors survive compression?", "Median neighbor overlap"),
            ("residual_fraction", "How much vector variation is left behind?", "Median residual fraction"),
        ):
            samples = []
            for name in schemas:
                match = re.fullmatch(r"pca_q(\d+)_" + suffix, name)
                if match:
                    values = load(name)
                    if values is not None and values.ndim == 1:
                        finite = values[np.isfinite(values)]
                        if len(finite):
                            samples.append((int(match[1]), float(np.median(finite))))
            if len(samples) >= 2:
                out.append(chart(title, "Each point summarizes finite saved anchor measurements at one retained dimension. Support can vary.",
                                 "Retained dimensions", units, sorted(samples)))

    def histogram(counts, edges, title, scope, units, *, target=None):
        if (counts is not None and edges is not None and counts.ndim == edges.ndim == 1
                and 1 < len(counts) <= 64 and len(edges) == len(counts) + 1
                and np.isfinite(counts).all() and np.isfinite(edges).all()
                and np.all(counts >= 0) and np.all(edges[1:] > edges[:-1])):
            centers = (edges[:-1] / 2 + edges[1:] / 2).tolist()
            out.append({**chart(title, scope + " Each bar is one saved bin, shown at its center.",
                                units + " (bin center)", "Count", list(zip(centers, counts.tolist())), kind="bars"),
                        "target": target})

    if component == "feature_distribution":
        for target, row in list(meta.get("summaries", {}).items())[:12]:
            saved = row.get("histogram") or {}
            if saved:
                counts = load(saved.get("counts", {}).get("array_ref"))
                edges = load(saved.get("edges", {}).get("array_ref"))
                histogram(counts, edges, f"Distribution of {target}",
                          f"Known values within frozen membership (n={row['known']:,}).", target, target=target)
            categories = row.get("counts") or {}
            if categories:
                bins = []
                for code, value in categories.items():
                    try:
                        code = int(code)
                    except (TypeError, ValueError):
                        continue
                    if type(value) is int and value >= 0:
                        bins.append((code, value))
                if bins:
                    out.append({**chart(f"Category counts for {target}",
                                        f"Counts over known frozen members (n={row['known']:,}). Codes identify categories and have no numeric distance.",
                                        "Category code", "Count", sorted(bins), kind="categories"),
                                "target": target})
    if component == "source_support":
        histogram(load("norm_counts"), load("norm_edges"), "How large are the sampled source vectors?",
                  "Source-vector norms from the saved resolved-context sample.", "Source L2 norm")
    return [item for item in out if all(math.isfinite(y) for _, y in item["samples"])]
