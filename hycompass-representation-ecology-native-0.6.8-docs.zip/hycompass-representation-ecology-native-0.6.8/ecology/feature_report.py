"""Collect saved per-feature evidence for the offline explorer."""
from collections import defaultdict
import json
import math
from pathlib import Path

METRICS = {
    "mae": "MAE", "rmse": "RMSE", "r2": "R²", "baseline_mae": "Baseline MAE",
    "mae_gain": "MAE gain", "accuracy": "Accuracy", "balanced_accuracy": "Balanced accuracy",
    "macro_f1": "Macro F1", "roc_auc": "ROC AUC", "log_loss": "Log loss",
    "brier": "Brier", "baseline_brier": "Baseline Brier", "brier_skill": "Brier skill",
}


def numeric(value):
    return type(value) in (int, float) and math.isfinite(value)


class FeatureEvidence:
    def __init__(self, kinds):
        self.kinds = kinds
        self.features = {}
        self.series = defaultdict(dict)
        self.final_targets = set()

    def entry(self, name, kind=None):
        if not isinstance(name, str) or not name:
            return None
        item = self.features.setdefault(name, dict(name=name, kind=None, coverage=[], associations=[], distributions=[]))
        if item["kind"] in (None, "unknown"):
            item["kind"] = kind or self.kinds.get(name) or "unknown"
        return item

    def add(self, name, result, metric, account, scope, dimension, value, support, kind=None):
        if not numeric(value) or (dimension is not None and not numeric(dimension)):
            return
        if self.entry(name, kind) is not None:
            self.series[name].setdefault((result, metric, account, scope), {})[dimension] = [
                dimension, value, support if numeric(support) else None]

    def ingest(self, component, result, meta):
        family = component.split("--", 1)[0]
        if family in ("feature_audit", "feature_distribution"):
            field = "features" if family == "feature_audit" else "summaries"
            for name, row in meta.get(field, {}).items():
                known, missing = row.get("known"), row.get("missing")
                if numeric(known) and numeric(missing):
                    item = self.entry(name, row.get("kind"))
                    if item is not None:
                        item["coverage"].append([known, missing, result])
                        for key, title in (("mean", "Mean"), ("std", "Standard deviation"),
                                           ("min", "Minimum"), ("max", "Maximum"),
                                           ("positive_fraction", "Positive share")):
                            if numeric(row.get(key)):
                                item["distributions"].append([title, row[key], result])
                        counts = row.get("counts", {})
                        if isinstance(counts, dict):
                            for code, count in counts.items():
                                if code != "array_ref" and numeric(count):
                                    item["distributions"].append([f"Category code {code} count", count, result])
            for row in meta.get("geometry_associations", []):
                if numeric(row.get("value")) and (item := self.entry(row.get("feature"))) is not None:
                    support = row.get("n")
                    item["associations"].append([row["geometry"], row["method"], row["value"],
                                                 support if numeric(support) else None, result])

        if family == "reconstruction":
            targets = set()
            for row in meta.get("numeric", {}).get("summaries", []):
                name, measure = row.get("feature"), row.get("measure")
                if name in self.final_targets or measure not in ("broad", "local", "baseline", "gain"):
                    continue
                region = row.get("region", -1)
                scope = "Saved held-out sampled reference"
                scope += " · pooled regions" if region == -1 else f" · region {region}"
                if measure == "gain":
                    scope += " · paired finite losses"
                metric = "MAE gain (broad − local)" if measure == "gain" else "MAE"
                self.add(name, result, metric, measure, scope, row.get("dimension"),
                         row.get("mean"), row.get("n"), "numeric")
                if numeric(row.get("mean")):
                    targets.add(name)
            for row in meta.get("classification", []):
                name, metric = row.get("feature"), row.get("loss")
                if name in self.final_targets or not metric:
                    continue
                scope = f'Saved held-out fold {row.get("fold", "?")}'
                for field, account, support, matched in (
                    ("broad_mean", "broad", "n_test", False), ("baseline", "baseline", "n_test", False),
                    ("matched_broad_mean", "broad", "n_matched", True),
                    ("local_mean", "local", "n_matched", True), ("matched_gain", "gain", "n_matched", True),
                ):
                    label = metric + " gain (broad − local)" if account == "gain" else metric
                    self.add(name, result, label, account, scope + (" · matched" if matched else " · broad support"),
                             row.get("dimension"), row.get(field), row.get(support))
                    if numeric(row.get(field)):
                        targets.add(name)
            if component == "reconstruction":
                self.final_targets.update(targets)

        if family == "probe_metrics":
            for row in meta.get("metrics", []):
                for key, metric in METRICS.items():
                    self.add(row.get("feature"), result, metric, row.get("account") or "saved model",
                             row.get("scope") or meta.get("scope") or "Saved evaluation",
                             row.get("dimension"), row.get(key), row.get("n"), row.get("kind"))

        if family == "reference_evaluation":
            for row in meta.get("summaries", []):
                name = row.get("feature")
                metric = {"numeric": "MAE", "boolean": "Brier",
                          "category": "Multiclass Brier"}.get(self.kinds.get(name), "Saved loss")
                for account in ("broad", "local", "gain"):
                    label = metric + " gain (broad − local)" if account == "gain" else metric
                    self.add(name, result, label, account, "Frozen reference · matched evaluation support",
                             row.get("dimension"), row.get(account), row.get("n_matched"))

        if family.startswith("external"):
            for metric, value in meta.get("metrics", {}).items():
                self.add(meta.get("target"), result, metric, "external",
                         f'{meta.get("scope", "External")} · unverified producer metric',
                         None, value, None, meta.get("kind"))

    def payload(self):
        out = []
        for name, feature in sorted(self.features.items(), key=lambda pair: pair[0].casefold()):
            curves = []
            for identity, points in self.series[name].items():
                ordered = sorted(points.values(), key=lambda point: (point[0] is None, point[0] or 0))
                curves.append([*identity, ordered])
            if feature["coverage"] or feature["associations"] or curves:
                out.append({**feature, "series": curves})
        return out


def feature_section(features):
    if not features:
        return ""
    # Inert JSON inside a script tag must never contain a literal HTML delimiter.
    data = json.dumps(features, ensure_ascii=True, allow_nan=False, separators=(",", ":"))
    data = data.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    script = Path(__file__).with_name("feature_report.js").read_text(encoding="utf-8")
    return f"""<section id="features"><p class="kicker">Feature explorer · {len(features):,} saved features</p>
<h2>Feature representation and reconstruction</h2>
<p class="lede">Start with coverage: how many frozen members have an observed value? Geometry associations describe how measured anchors vary. Reconstruction asks a separate question: how well do saved probes recover a target at different retained dimensions?</p>
<p class="lede">Read one metric at a time. Lower error usually means better recovery on the stated support. An association, a held-out score, and an external claim carry different evidence. Blank support means the saved result did not report it.</p>
<div class="feature-controls">
<label>Find a feature <input id="fx-search" type="search" placeholder="Search feature names"></label>
<label>Feature type <select id="fx-kind"><option value="">All types</option></select></label>
<label>Evidence <select id="fx-evidence"><option value="">Any evidence</option><option value="coverage">Coverage</option><option value="associations">Geometry associations</option><option value="series">Reconstruction / evaluation</option></select></label>
<label>Sort by <select id="fx-sort"><option value="name">Name</option><option value="low">Lowest observed coverage</option><option value="high">Highest observed coverage</option></select></label>
</div>
<div id="fx-list" class="feature-list"></div>
<div class="feature-controls"><button type="button" id="fx-prev">Previous</button><span id="fx-page" aria-live="polite"></span><button type="button" id="fx-next">Next</button></div>
<div id="fx-detail" class="plot" aria-live="polite"></div>
<noscript><p>The feature explorer requires local JavaScript. The static report is available below.</p></noscript>
<script id="fx-data" type="application/json">{data}</script><script>{script}</script>
</section>"""
