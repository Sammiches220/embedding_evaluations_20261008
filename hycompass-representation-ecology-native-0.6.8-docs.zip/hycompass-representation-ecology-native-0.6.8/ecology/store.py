"""Immutable experiment definitions, atomic artifact publication and bounded residency."""
from __future__ import annotations
from collections import OrderedDict
from pathlib import Path
import json
import os
import shutil
import threading
import uuid
import numpy as np
from .catalog import Catalog, atomic_json, digest, rows_checked, stamp, array_digest, checksum
from .locking import mutation

DEFAULTS=dict(anchors=192,context_cap=768,k=12,seed=42,context='selection',dimensions=[1,2,4,8],
              folds=3,regions=3,min_train=8,repeats=3,max_ram_bytes=256_000_000,max_work=500_000_000,
              max_output_bytes=64_000_000,max_seconds=120,features=[],projection=None,reference_map=None,instruments=['geometry'])


def encode_metadata(metadata,arrays):
    """Deduplicate frozen numerical transforms outside JSON, including across targets."""
    import hashlib
    arrays=dict(arrays);lookup={}
    def identity(a):return (str(a.dtype),a.shape,hashlib.sha256(a.tobytes()).hexdigest())
    for name,a in arrays.items():lookup[identity(np.asarray(a))]=name
    fields={'components','mean','coefficients','coef','intercept','prior','centers'}
    def encode(value,key=None):
        if isinstance(value,np.ndarray) or key in fields and isinstance(value,(list,tuple)) and len(value):
            a=np.asarray(value)
            if a.dtype.kind in 'fiu':
                ident=identity(a);name=lookup.get(ident)
                if name is None:
                    index=0
                    while 'transform_'+str(index) in arrays:index+=1
                    name='transform_'+str(index);lookup[ident]=name;arrays[name]=a
                return {'array_ref':name}
        if isinstance(value,dict):return {k:encode(v,k) for k,v in value.items() if k!='arrays'}
        if isinstance(value,(list,tuple)):return [encode(v) for v in value]
        return value
    return encode(metadata),arrays


def decode_metadata(metadata,arrays):
    if isinstance(metadata,dict):
        if set(metadata)=={'array_ref'}:return arrays[metadata['array_ref']]
        return {k:decode_metadata(v,arrays) if k!='arrays' else v for k,v in metadata.items()}
    if isinstance(metadata,list):return [decode_metadata(v,arrays) for v in metadata]
    return metadata


class Cancelled(Exception): pass


class Token:
    def __init__(self): self.event=threading.Event(); self.deadline=None
    def cancel(self): self.event.set()
    def check(self):
        import time
        if self.event.is_set(): raise Cancelled('Cancelled at bounded checkpoint')
        if self.deadline is not None and time.monotonic()>self.deadline: raise Cancelled('Time budget reached at checkpoint')


class Residency:
    def __init__(self,max_bytes=64_000_000): self.max_bytes=max_bytes; self.cache=OrderedDict(); self.pins=set()
    @property
    def nbytes(self): return sum(v.nbytes for v in self.cache.values())
    def put(self,key,value):
        if value.nbytes>self.max_bytes: raise ValueError('Artifact exceeds residency budget')
        old=self.cache.pop(key,None); self.cache[key]=value
        while self.nbytes>self.max_bytes:
            victim=next((k for k in self.cache if k not in self.pins and k!=key),None)
            if victim is None:
                self.cache.pop(key)
                if old is not None:self.cache[key]=old
                raise ValueError('Pinned cache exceeds budget; unpin or unload')
            self.cache.pop(victim)
    def clear(self): self.cache.clear(); self.pins.clear()


class Store:
    def __init__(self,root):
        self.catalog=Catalog(root); self.root=self.catalog.root/'maps'; self.root.mkdir(exist_ok=True)
    def folder(self,key):
        if not key or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in key): raise ValueError('Invalid map ID')
        return self.root/key
    def definitions(self):
        return [self.read(p.parent.name) for p in sorted(self.root.glob('*/definition.json'))]
    def read(self,key):
        d=json.loads((self.folder(key)/'definition.json').read_text())
        if d.get('format_version')!=1:raise ValueError('Unsupported map definition format')
        if d.get('revision')!=digest({k:v for k,v in d.items() if k not in ('id','title','revision')}):raise ValueError('Map analytical definition was modified')
        p=self.folder(key)/'map.json'
        if p.exists():
            metadata=json.loads(p.read_text());d.update({k:metadata[k] for k in ('title','description','tags','metadata_revision')})
        return d
    @mutation
    def create(self,title,domain,membership,settings=None,*,key=None):
        c=self.catalog; d=c.raw['domains'][domain]; c.validate_sources(domain)
        rows=rows_checked(membership,c.n(d['collection']))
        if not len(rows): raise ValueError('Empty question population')
        cfg={**DEFAULTS,**(settings or {})}
        if set(cfg)-set(DEFAULTS): raise ValueError('Unknown map settings')
        from .instruments import REGISTRY
        if not isinstance(cfg['instruments'],list) or any(n not in REGISTRY for n in cfg['instruments']):raise ValueError('Invalid instrument preset')
        for k in ['anchors','context_cap','k','folds','regions','min_train','max_ram_bytes','max_work','max_output_bytes','max_seconds']:
            if type(cfg[k]) is not int or cfg[k]<1: raise ValueError('Invalid '+k)
        if cfg['context'] not in ('selection','reference') or cfg['context_cap']<cfg['anchors'] or cfg['k']>=cfg['anchors'] or not 3<=cfg['folds']<=10 or not 1<=cfg['regions']<=32 or not 0<=cfg['repeats']<=32: raise ValueError('Invalid context, neighborhood, fold or repeat budget')
        if len(cfg['features'])>16 or any(c.raw['features'][f]['collection']!=d['collection'] for f in cfg['features']): raise ValueError('Feature collection mismatch or >16 active features')
        if not cfg['dimensions'] or len(cfg['dimensions'])>12 or any(type(q) is not int or q<1 for q in cfg['dimensions']): raise ValueError('Invalid retained dimensions')
        reference_revision=None
        if cfg['reference_map']:
            ref=self.validate(cfg['reference_map'])
            if ref['domain']!=domain:raise ValueError('Reference must use same embedding domain')
            reference_revision=ref['revision']
        key=key or uuid.uuid4().hex[:12]; folder=self.folder(key)
        if folder.exists():raise ValueError('Map exists; create a new definition revision')
        folder.mkdir(); np.save(folder/'membership.npy',rows)
        definition=dict(format_version=1,reference_revision=reference_revision,id=key,title=title,domain=domain,collection=d['collection'],membership='membership.npy',n_members=len(rows),
            membership_digest=array_digest(rows),settings=cfg,domain_revision=d['revision'],collection_revision=c.collection(d['collection'])['revision'],
            feature_revisions={f:c.raw['features'][f]['revision'] for f in cfg['features']},groups_stamp=stamp(c.resolve(c.collection(d['collection'])['groups'])) if c.collection(d['collection']).get('groups') else None,
            projection_stamp=stamp(c.resolve(c.manifest.projections[cfg['projection']].positions)) if cfg['projection'] else None)
        definition['revision']=digest({k:v for k,v in definition.items() if k not in ('id','title')}); atomic_json(folder/'definition.json',definition)
        atomic_json(folder/'status.json',{}); atomic_json(folder/'map.json',dict(title=title,description='',tags=[],metadata_revision=uuid.uuid4().hex)); return self.read(key)
    def membership(self,key): return np.load(self.folder(key)/'membership.npy',mmap_mode='r',allow_pickle=False)
    def validate(self,key,instrument=None,*,view=False):
        instrument='external' if instrument and instrument.startswith('external_') else instrument
        d=self.read(key);c=self.catalog;c.raw=json.loads(c.path.read_text());c._catalog_revision=digest(c.raw)
        if array_digest(self.membership(key))!=d['membership_digest']:raise ValueError('Frozen membership was modified')
        if d['domain_revision']!=c.raw['domains'][d['domain']]['revision'] or d['collection_revision']!=c.collection(d['collection'])['revision']:raise ValueError('Stale collection/domain revision')
        target=instrument in ('reconstruction','discrepancy','reference_evaluation','feature_audit','probe_metrics','neighborhood_agreement','feature_distribution') or instrument is None
        def check(path,expected):
            p=c.resolve(path)
            if not p.exists():
                if view:return
                raise ValueError('Missing dependency: '+path)
            if stamp(p)!=expected:raise ValueError('Stale dependency: '+path)
        if instrument not in ('feature_distribution','neighborhood_agreement','external','routes'):
            for path,expected in c.raw['domains'][d['domain']]['source_stamps'].items():check(path,expected)
        if instrument in (None,'reconstruction','discrepancy','reference_evaluation','probe_metrics'):
            g=c.collection(d['collection']).get('groups')
            if g:check(g,d['groups_stamp'])
        if instrument in (None,'geometry','compression'):
            p=d['settings']['projection']
            if p:check(c.manifest.projections[p].positions,d['projection_stamp'])
        if target:
            for f,r in d['feature_revisions'].items():
                if r!=c.raw['features'][f]['revision']:raise ValueError('Stale feature registration')
                for path,expected in c.raw['features'][f]['source_stamps'].items():check(path,expected)
        if instrument in (None,'reference_evaluation') and d['settings'].get('reference_map'):
            ref=self.read(d['settings']['reference_map'])
            if ref['revision']!=d['reference_revision']:raise ValueError('Stale frozen reference')
            if instrument=='reference_evaluation' and not (self.artifact_path(ref['id'],'reconstruction')/'metadata.json').exists():raise ValueError('Missing frozen reconstruction reference')
        return d
    def capabilities(self,key):
        from .instruments import REGISTRY
        result={}
        for name in REGISTRY:
            try:self.validate(key,name); result[name]=dict(available=True,reason=None)
            except (ValueError,KeyError,OSError) as exc:result[name]=dict(available=False,reason=str(exc))
        saved={}
        for name in self.components(key):
            if not (self.artifact_path(key,name)/'metadata.json').exists():continue
            try:self.artifact(key,name);saved[name]=dict(available=True)
            except (ValueError,KeyError,OSError) as exc:saved[name]=dict(available=False,reason=str(exc))
        return dict(compute=result,view=saved)
    def status(self,key): return json.loads((self.folder(key)/'status.json').read_text())
    @mutation
    def set_status(self,key,instrument,**state):
        status=state.get('status','not_generated')
        state.update(execution={'generated':'succeeded','generated_sampled':'succeeded','not_generated':'not requested'}.get(status,status),persistence='valid' if status in ('generated','generated_sampled') else 'absent',coverage='sampled' if status=='generated_sampled' else 'complete for declared support' if status=='generated' else 'unsupported')
        s=self.status(key); state={**(s.get(instrument,{}) if status!='not_generated' else {}),**state}; s[instrument]=state; atomic_json(self.folder(key)/'status.json',s)
    def artifact_path(self,key,instrument):
        if '--' in instrument:
            family,signature=instrument.split('--',1)
            if family!='reconstruction' or len(signature)!=24 or any(c not in '0123456789abcdef' for c in signature):raise ValueError('Invalid batch component ID')
            return self.folder(key)/'batches'/family/signature
        if not instrument or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in instrument):raise ValueError('Invalid component ID')
        return self.folder(key)/instrument
    def artifact(self,key,instrument,array_names=None):
        if '--' in instrument:
            folder=self.artifact_path(key,instrument);batch=json.loads((folder/'metadata.json').read_text());family,signature=instrument.split('--',1)
            self.validate(key,family,view=True)
            from .batches import read_batch
            expected=digest(dict(parent=self.signature(key,family),targets=batch['targets']))
            if expected!=signature or batch['family']!=family:raise ValueError('Stale batch component')
            arrays,meta=read_batch(self,key,family,batch['targets'])
            return arrays,{**meta,'component_version':1,'result_signature':signature,'definition_revision':self.read(key)['revision'],'target':', '.join(batch['targets']),'target_batch':batch['targets'],'arrays':batch['arrays'],'scope':'Group-held-out target batch; see saved protocol'}
        self.validate(key,instrument,view=True); p=self.artifact_path(key,instrument)
        meta=json.loads((p/'metadata.json').read_text())
        if meta['definition_revision']!=self.read(key)['revision']:raise ValueError('Stale artifact')
        if meta['result_signature']!=self.expected_signature(key,instrument,meta):raise ValueError('Stale artifact dependencies')
        arrays={}
        for name,spec in meta.get('arrays',{}).items():
            if array_names is not None and name not in array_names:continue
            if name in ('','.','..') or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.' for c in name):raise ValueError('Invalid array ID')
            f=p/(name+'.npy')
            if checksum(f)!=spec['sha256']:raise ValueError('Corrupt artifact payload: '+name)
            a=np.load(f,mmap_mode='r',allow_pickle=False)
            if list(a.shape)!=spec['shape'] or str(a.dtype)!=spec['dtype']:raise ValueError('Artifact array schema mismatch')
            arrays[name]=a
        return arrays,decode_metadata(meta,arrays)
    def signature(self,key,instrument):
        instrument='external' if instrument.startswith('external_') else instrument
        d=self.read(key); cfg=d['settings']
        common=['anchors','context_cap','k','seed','context']
        extra={'geometry':[],'reconstruction':['features','dimensions','folds','regions','min_train'],
               'discrepancy':['features','folds'],'stability':['repeats'],'routes':[],'reference_evaluation':['features','reference_map'],'compression':['dimensions'],'feature_audit':['features'],'directions':[],'source_support':[],'resolved_support':[],'neighbors':[],'neighborhood_agreement':['features'],'feature_distribution':['features'],'external':[],'probe_metrics':['features','dimensions','folds','regions','min_train']}[instrument]
        features=d['feature_revisions'] if instrument in ('reconstruction','discrepancy','reference_evaluation','feature_audit','probe_metrics','neighborhood_agreement','feature_distribution') else {}
        return digest(dict(instrument=instrument,kernel_revision=4 if instrument=='source_support' else 3 if instrument in ('probe_metrics','reference_evaluation','resolved_support','source_support','external') else 2,collection=d['collection'],collection_revision=d['collection_revision'],membership=d['membership_digest'],domain=d['domain_revision'],
            settings={k:cfg[k] for k in common+extra},features=features,groups=d['groups_stamp'] if instrument in ('reconstruction','discrepancy','probe_metrics') else None,
            projection=d['projection_stamp'] if instrument in ('geometry','compression') else None,
            dependencies={n:self.signature(key,n) for n in __import__('ecology.instruments',fromlist=['REGISTRY']).REGISTRY[instrument].dependencies} if instrument!='external' else {},
            reference=(self.artifact(d['settings']['reference_map'],'reconstruction')[1]['result_signature'] if instrument=='reference_evaluation' and d['settings']['reference_map'] else None)))
    def result_index(self,rebuild=False):
        path=self.catalog.root/'result-index.json'
        if path.exists() and not rebuild:return json.loads(path.read_text())
        index={}
        for d in self.definitions():
            for name in self.components(d['id']):
                if '--' in name:continue
                meta=json.loads((self.artifact_path(d['id'],name)/'metadata.json').read_text())
                index.setdefault(meta['result_signature'],[]).append([d['id'],name])
        return index
    def reusable(self,key,instrument):
        signature=self.signature(key,instrument)
        for donor,name in self.result_index().get(signature,[]):
            if donor==key or name!=instrument:continue
            try:
                _,meta=self.artifact(donor,name)
                if meta['result_signature']==signature:return donor
            except (ValueError,KeyError,OSError):continue
        return None
    @mutation
    def publish(self,key,instrument,arrays,metadata,token):
        d=self.validate(key,instrument)
        if metadata.get('origin_revision',d['revision'])!=d['revision']:raise ValueError('Stale job: definition revision changed during generation')
        metadata,arrays=encode_metadata(metadata,arrays)
        temp=self.folder(key)/('.pending-'+uuid.uuid4().hex)
        payload=sum(np.asarray(a).nbytes for a in arrays.values())
        if payload+self.disk_bytes(key)>d['settings']['max_output_bytes']:raise ValueError('Output byte budget exceeded before writing')
        temp.mkdir();used=self.disk_bytes(key)
        try:
            for name,a in arrays.items():
                if name in ('','.','..') or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_. ' for c in name) or ' ' in name:raise ValueError('Invalid array ID')
                token.check();path=temp/(name+'.npy');np.save(path,a,allow_pickle=False);used+=path.stat().st_size
                if used>d['settings']['max_output_bytes']:raise ValueError('Output byte budget exceeded during write')
            schemas={name:dict(shape=list(np.asarray(a).shape),dtype=str(np.asarray(a).dtype),bytes=(temp/(name+'.npy')).stat().st_size,sha256=checksum(temp/(name+'.npy'))) for name,a in arrays.items()}
            atomic_json(temp/'metadata.json',{**metadata,'component_version':1,'arrays':schemas,'definition_revision':d['revision'],'result_signature':self.expected_signature(key,instrument,{**metadata,'arrays':schemas})})
            size=sum(p.stat().st_size for p in temp.iterdir())
            if self.disk_bytes(key)>d['settings']['max_output_bytes']:raise ValueError('Output byte budget exceeded')
            token.check(); self.validate(key,instrument)
            target=self.artifact_path(key,instrument)
            if target.exists():raise ValueError('Artifact already exists; explicitly delete before regeneration')
            os.replace(temp,target)
            index=self.result_index();signature=self.expected_signature(key,instrument,{**metadata,'arrays':schemas});entry=[key,instrument]
            if entry not in index.setdefault(signature,[]):index[signature].append(entry)
            atomic_json(self.catalog.root/'result-index.json',index)
            support=metadata.get('support',{});sampled=support.get('valid_anchors',0)<support.get('question_members',0)
            self.set_status(key,instrument,status='generated_sampled' if sampled else 'generated',bytes=size,definition_revision=d['revision'],support=support)
        finally:
            if temp.exists():shutil.rmtree(temp)
    @mutation
    def delete_artifact(self,key,instrument):
        from .instruments import REGISTRY
        if '--' in instrument:
            family,_=instrument.split('--',1)
            if self.artifact_path(key,family).exists():raise ValueError('Completed combined result consumes this batch; delete the family result first')
            shutil.rmtree(self.artifact_path(key,instrument));return
        if instrument not in REGISTRY and not instrument.startswith('external_') and instrument!='external':raise ValueError('Unknown instrument')
        dependents=[n for n,s in REGISTRY.items() if instrument in s.dependencies and self.artifact_path(key,n).exists()]
        if instrument=='reconstruction':dependents += [d['id']+'/reference_evaluation' for d in self.definitions() if d['settings'].get('reference_map')==key]
        if dependents:raise ValueError('Delete dependent artifacts first: '+', '.join(dependents))
        shutil.rmtree(self.artifact_path(key,instrument),ignore_errors=True)
        shutil.rmtree(self.folder(key)/'batches'/instrument,ignore_errors=True)
        self.set_status(key,instrument,status='not_generated')
    def disk_bytes(self,key):return sum(p.stat().st_size for p in self.folder(key).rglob('*') if p.is_file())
    @mutation
    def save_navigation(self,key,state):atomic_json(self.folder(key)/'navigation.json',state)
    def navigation(self,key):
        p=self.folder(key)/'navigation.json';return json.loads(p.read_text()) if p.exists() else {}

    @mutation
    def rename(self,key,title,expected_revision=None,description=None,tags=None):
        d=self.read(key)
        if expected_revision is not None and d['metadata_revision']!=expected_revision:raise ValueError('Map metadata revision conflict')
        if not title.strip():raise ValueError('Map title cannot be empty')
        m={k:d[k] for k in ('title','description','tags','metadata_revision')}
        m.update(title=title,metadata_revision=uuid.uuid4().hex)
        if description is not None:m['description']=description
        if tags is not None:m['tags']=tags
        atomic_json(self.folder(key)/'map.json',m);return self.read(key)
    @mutation
    def duplicate(self,key,title):
        d=self.read(key);result=self.create(title,d['domain'],self.membership(key),d['settings'])
        return self.rename(result['id'],title,result['metadata_revision'],d['description'],d['tags'])
    def deletion_preview(self,key):
        consumers=[d['id'] for d in self.definitions() if d['settings'].get('reference_map')==key]
        return dict(map_id=key,reclaimable_bytes=self.disk_bytes(key),dependent_maps=consumers,retained_sources=True)
    @mutation
    def delete_results(self,key):
        consumers=self.deletion_preview(key)['dependent_maps']
        if consumers and (self.artifact_path(key,'reconstruction').exists() or (self.folder(key)/'batches'/'reconstruction').exists()):raise ValueError('Reconstruction is referenced by: '+', '.join(consumers))
        from .instruments import REGISTRY,dependency_order
        for name in reversed(dependency_order(list(REGISTRY))):
            if self.artifact_path(key,name).exists() or (self.folder(key)/'batches'/name).exists():self.delete_artifact(key,name)
        for name in self.components(key):
            if name.startswith('external'):self.delete_artifact(key,name)
    @mutation
    def delete(self,key):
        preview=self.deletion_preview(key)
        if preview['dependent_maps']:raise ValueError('Map is referenced by: '+', '.join(preview['dependent_maps']))
        if any(s.get('status') in ('running','queued') for s in self.status(key).values()):raise ValueError('Cancel work and wait for completion before deleting map')
        shutil.rmtree(self.folder(key));return preview
    def summaries(self):
        out=[]
        for d in self.definitions():
            states=self.status(d['id']);out.append(dict(id=d['id'],title=d['title'],domain=d['domain'],revision=d['revision'],n_members=d['n_members'],results=sum((self.artifact_path(d['id'],n)/'metadata.json').exists() for n in states),stored_result_bytes=sum(v.get('bytes',0)+v.get('batch_bytes',0) for v in states.values()),status=states))
        return out

    def components(self,key):
        return [p.parent.name for p in sorted(self.folder(key).glob('*/metadata.json'))]+['reconstruction--'+p.parent.name for p in sorted((self.folder(key)/'batches'/'reconstruction').glob('*/metadata.json'))]

    def expected_signature(self,key,instrument,metadata):
        base=self.signature(key,instrument)
        if instrument.startswith('external'):
            return digest(dict(base=base,descriptor={k:metadata.get(k) for k in ('target','target_revision','targets','evaluation','collection_revision','domain_revision','kind','scope','provenance','result_id','ordered_support_digest')},arrays=metadata['arrays']))
        return base
