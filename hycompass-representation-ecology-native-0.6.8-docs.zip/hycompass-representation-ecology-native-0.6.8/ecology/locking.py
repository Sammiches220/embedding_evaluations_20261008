"""One cooperative writer per workspace, including separate CLI processes."""
from contextlib import contextmanager
from functools import wraps
from pathlib import Path
import threading

_locks={}
_guard=threading.Lock()
_local=threading.local()

@contextmanager
def workspace_writer(root):
    root=Path(root).resolve();root.mkdir(parents=True,exist_ok=True);key=str(root)
    with _guard: lock=_locks.setdefault(key,threading.RLock())
    if not lock.acquire(blocking=False):raise ValueError('Workspace has an active writer; retry after the current job completes')
    try:
        held=getattr(_local,'held',set())
        if key in held:
            yield;return
        with (root/'.writer.lock').open('a+b') as stream:
            try:
                if __import__('os').name=='nt':
                    import msvcrt
                    stream.seek(0);stream.write(b'0');stream.flush();stream.seek(0)
                    msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except OSError as exc:raise ValueError('Workspace has another active writer') from exc
            _local.held=held|{key}
            try:yield
            finally:
                _local.held=held
                if __import__('os').name=='nt':
                    stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
                else:fcntl.flock(stream,fcntl.LOCK_UN)

    finally:lock.release()

def mutation(fn):
    @wraps(fn)
    def wrapped(self,*args,**kwargs):
        root=self.catalog.root if hasattr(self,'catalog') else self.root
        with workspace_writer(root):return fn(self,*args,**kwargs)
    return wrapped
