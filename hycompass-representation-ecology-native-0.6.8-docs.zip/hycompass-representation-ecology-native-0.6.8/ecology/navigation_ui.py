"""Coordinated prediction lens: one resolver drives map, cases and evidence."""
from dataclasses import replace,asdict
import json
import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,QComboBox,QLabel,QGroupBox,QPushButton,QTableWidget,QTableWidgetItem,QPlainTextEdit,QSplitter,QCompleter)
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from .navigation import Selection,resolve,variants,MEASUREMENTS,cases,compare_resolved,Resolved
from .catalog import clean
from .group_views import GroupViews


def table(headers):
    t=QTableWidget(0,len(headers));t.setHorizontalHeaderLabels(headers);t.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers);t.verticalHeader().hide();return t


def fill(t,rows):
    t.setRowCount(len(rows))
    for i,row in enumerate(rows):
        for j,v in enumerate(row):t.setItem(i,j,QTableWidgetItem('undefined' if v is None else f'{v:.5g}' if isinstance(v,float) else str(v)))
    t.resizeColumnsToContents()
    for i in range(t.columnCount()):t.setColumnWidth(i,min(260,t.columnWidth(i)))


class NavigationControls(GroupViews):
    def setup_navigation(self,guide_layout):
        self.navigation_selection=None;self.resolved_measurement=None;self.navigation_index={};self._nav_updating=False;self._resolved_cache={}
        self.feature.setEditable(True);self.feature.setInsertPolicy(QComboBox.InsertPolicy.NoInsert);self.feature.completer().setFilterMode(Qt.MatchFlag.MatchContains);self.feature.completer().setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.prediction_controls=QGroupBox('Saved prediction');form=QFormLayout(self.prediction_controls)
        self.target_type=QComboBox();self.target_type.addItems(['All types','numeric','boolean','category']);self.target_availability=QComboBox();self.target_availability.addItems(['All targets','Saved results','Loaded results']);filters=QHBoxLayout();filters.addWidget(self.target_type);filters.addWidget(self.target_availability);form.addRow('Target filter',filters)
        self.result_module=QComboBox();self.prediction_measure=QComboBox()
        for key,(text,_,__) in MEASUREMENTS.items():self.prediction_measure.addItem(text,key)
        self.prediction_measure.setCurrentIndex(self.prediction_measure.findData('error'))
        self.prediction_subset=QComboBox()
        for text,key in [('All measured anchors','all'),('Here','here'),('Ahead','ahead'),('Kept selection','kept')]:self.prediction_subset.addItem(text,key)
        self.compare_variant=QComboBox();self.compare_variant.addItem('No comparison',None)
        for title,widget in [('Result',self.result_module),('Display',self.prediction_measure),('Subset',self.prediction_subset),('Compare B',self.compare_variant)]:form.addRow(title,widget)
        self.prediction_status=QLabel();self.prediction_status.setWordWrap(True);form.addRow(self.prediction_status)
        guide_layout.insertWidget(4,self.prediction_controls);self.prediction_controls.hide()
        from PySide6.QtWidgets import QSizePolicy
        for combo in (self.target_type,self.target_availability,self.result_module,self.prediction_measure,self.prediction_subset,self.compare_variant):combo.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Fixed);combo.setMinimumWidth(70)
        self.target_type.currentIndexChanged.connect(self.filter_navigation_targets);self.target_availability.currentIndexChanged.connect(self.filter_navigation_targets)
        self.result_module.currentIndexChanged.connect(self.navigation_module_changed)
        for w in (self.prediction_measure,self.prediction_subset,self.compare_variant):w.currentIndexChanged.connect(self.refresh_navigation)
        self.source_box=QGroupBox('Source and support');self.source_box.setCheckable(True);self.source_box.setChecked(False);vl=QVBoxLayout(self.source_box);self.source_body=QWidget();body=QVBoxLayout(self.source_body);body.setContentsMargins(0,0,0,0);self.source_text=QPlainTextEdit();self.source_text.setReadOnly(True);self.source_text.setFixedHeight(230);body.addWidget(self.source_text)
        actions=QHBoxLayout();self.source_estimate=QPushButton('Estimate sample audit');self.source_compute=QPushButton('Prepare sample audit');actions.addWidget(self.source_estimate);actions.addWidget(self.source_compute);body.addLayout(actions);self.source_note=QLabel();self.source_note.setWordWrap(True);body.addWidget(self.source_note);vl.addWidget(self.source_body);self.source_body.hide();self.source_box.toggled.connect(self.source_body.setVisible)
        self.source_visuals=QPushButton('Open visual audits');self.source_visuals.clicked.connect(self.open_audit_visuals);body.addWidget(self.source_visuals)
        self.source_estimate.clicked.connect(self.estimate_source_audit);self.source_compute.clicked.connect(self.prepare_source_audit);guide_layout.insertWidget(5,self.source_box)
        # This evidence panel is part of the existing lens and shares all selections.
        self.prediction_panel=QWidget();pl=QVBoxLayout(self.prediction_panel);self.prediction_summary=QLabel('Select a saved target/result.');self.prediction_summary.setWordWrap(True);pl.addWidget(self.prediction_summary)
        self.prediction_figure=Figure(facecolor='#161d27');self.prediction_canvas=FigureCanvasQTAgg(self.prediction_figure);self.prediction_cases=table(['Canonical row','Measurement','Item ID'])
        self.protocol_label=QLabel();self.protocol_label.setWordWrap(True);pl.addWidget(self.protocol_label)
        self.classification_details=QPlainTextEdit();self.classification_details.setReadOnly(True)
        self.navigation_overview=table(['Target / type','Known / result rows','Variant','State']);self.navigation_overview.cellClicked.connect(self.select_overview_cell)
        self.setup_group_views()
        self.evidence.addTab(self.prediction_panel,'Prediction evidence');self.evidence.currentChanged.connect(lambda *_:self.refresh_navigation())
        self.evidence.scale_canvas.mpl_connect('pick_event',self.pick_navigation_dimension)

    def rebuild_navigation_index(self):
        self.navigation_index={}
        for name in self.store.components(self.key):
            if name not in ('probe_metrics','reference_evaluation') and not name.startswith('external_'):continue
            try:
                # Metadata only: no checksumming / opening every payload on target search.
                m=json.loads((self.store.artifact_path(self.key,name)/'metadata.json').read_text());self.navigation_index[name]=m
            except (OSError,ValueError):continue
        old=self.result_module.currentData();self.result_module.blockSignals(True);self.result_module.clear()
        for component in dict.fromkeys(['probe_metrics',*self.navigation_index]):self.result_module.addItem(component.replace('_',' '),component)
        index=self.result_module.findData(old)
        if old and index<0:self.result_module.addItem('Unavailable result: '+old,old);index=self.result_module.count()-1
        self.result_module.setCurrentIndex(max(0,index));self.result_module.blockSignals(False)
        self.filter_navigation_targets();self.navigation_module_changed();self.refresh_source_support()

    def filter_navigation_targets(self,*_):
        current=self.feature.currentText();self.feature.blockSignals(True);self.feature.clear()
        names=set(self.definition['settings']['features'])
        for m in self.navigation_index.values():names.update(m.get('targets',{}))
        for name in sorted(names):
            spec=self.store.catalog.raw['features'].get(name,{})
            kind=spec.get('kind') or next((m['targets'][name]['kind'] for m in self.navigation_index.values() if name in m.get('targets',{})),'unknown')
            saved=[c for c,m in self.navigation_index.items() if name in m.get('targets',{})]
            if self.target_type.currentIndex() and self.target_type.currentText()!=kind:continue
            if self.target_availability.currentIndex()==1 and not saved:continue
            if self.target_availability.currentIndex()==2 and not any(c in self.loaded for c in saved):continue
            self.feature.addItem(name);self.feature.setItemData(self.feature.count()-1,f'{kind} · {len(saved)} saved result modules; '+next((f"observed known {m['targets'][name].get('known_result_anchors','not measured')} / {m['targets'][name].get('result_anchors','not measured')} result anchors" for m in self.navigation_index.values() if name in m.get('targets',{})),'observed support not measured'),Qt.ItemDataRole.ToolTipRole)
        if self.feature.findText(current)>=0:self.feature.setCurrentText(current)
        elif current:self.feature.setEditText(current) # retain explicit unavailable choice
        self.feature.blockSignals(False);self.navigation_module_changed()

    def navigation_module_changed(self,*_):
        if self._nav_updating:return
        self._nav_updating=True
        try:
            component=self.result_module.currentData();m=self.navigation_index.get(component,{})
            old=self.compare_variant.currentData();self.compare_variant.blockSignals(True);self.compare_variant.clear();self.compare_variant.addItem('No comparison',None)
            # Comparison choices are metadata; no payload is loaded by selection.
            for c,meta in self.navigation_index.items():
                for target,account,q in variants(meta):
                    if target==self.feature.currentText():self.compare_variant.addItem(f'{c} · {account} · {q} PCs',dict(component=c,account=account,dimension=q))
            found=self.compare_variant.findData(old)
            if old and found<0:self.compare_variant.addItem('Unavailable comparison (retained)',old);found=self.compare_variant.count()-1
            self.compare_variant.setCurrentIndex(max(0,found));self.compare_variant.blockSignals(False)
            # Do not substitute another account or dimension. Availability remains explicit.
        finally:self._nav_updating=False
        self.refresh_navigation()

    def refresh_navigation(self,*_):
        if self._nav_updating or self._reloading or not hasattr(self,'landscape'):return
        self.refresh_source_support()
        if self._lens!='prediction':return
        l=self.landscape
        if l.rows is None:return
        component=self.result_module.currentData() or 'probe_metrics';target=self.feature.currentText()
        try:q=int(self.dimension.currentText())
        except ValueError:q=0
        selection=Selection(self.key,target,component,self.account.currentData(),q,self.prediction_measure.currentData(),self.prediction_subset.currentData())
        subset=None if selection.subset=='all' else self.selected_rows if selection.subset=='kept' else l.rows[l.attention(selection.subset=='ahead')]
        self.navigation_selection=selection
        payload=self.loaded.get(component)
        if payload is None:
            state='saved / unloaded' if component in self.navigation_index else 'not generated'
            self.prediction_status.setText(f'{state}: use Load saved or Prepare. Generation prepares the configured target/dimension family.');self.prediction_summary.setText(self.prediction_status.text());self.resolved_measurement=None;l.values=np.full(len(l.rows),np.nan);l.categorical=False;l.redraw();self.fill_navigation_overview();self.refresh_group_views();return
        from .catalog import array_digest
        cache_key=(selection.target,selection.component,selection.account,selection.dimension,selection.measurement,selection.subset,payload[1].get('result_signature'),array_digest(np.asarray(subset,np.int64)) if subset is not None else 'all')
        result=self._resolved_cache.get(cache_key)
        if result is None:
            result=resolve(selection,payload,subset)
            size=result.values.nbytes+result.rows.nbytes+result.available.nbytes
            if size<=1_000_000:
                while len(self._resolved_cache)>=4:self._resolved_cache.pop(next(iter(self._resolved_cache)))
                self._resolved_cache[cache_key]=result
        # Comparison failure must not mutate a cached primary result.
        result=replace(result,values=result.values.copy(),available=result.available.copy());self.navigation_selection=result.selection;self.resolved_measurement=result
        compare=self.compare_variant.currentData();paired=None
        if compare:
            other=self.loaded.get(compare['component'])
            try:
                if other is None:raise ValueError('Comparison B is saved/unloaded; Load saved explicitly.')
                b=resolve(replace(selection,component=compare['component'],account=compare['account'],dimension=compare['dimension'],measurement='error'),other,subset)
                paired=compare_resolved(result,b)
                self.navigation_selection=replace(result.selection,comparison=compare)
                self.resolved_measurement=result=Resolved(self.navigation_selection,paired['rows'],paired['values'],np.isfinite(paired['values']),result.kind,result.units,'signed',{},result.provenance,paired)
            except ValueError as exc:
                result.reason=str(exc);result.values[:]=np.nan;result.available[:]=False
        l.values=np.full(len(l.rows),np.nan);_,ia,ib=np.intersect1d(l.rows,result.rows,return_indices=True);l.values[ia]=result.values[ib]
        l.categorical=result.rendering=='categorical';l.probability=result.rendering=='probability';l.force_signed=result.rendering=='signed';l.color_limit=1. if result.rendering=='probability' else None
        spec=payload[1].get('targets',{}).get(target,{})
        l.category_labels=result.labels;l.category_colors=[]
        if l.categorical:
            import matplotlib
            count=2 if selection.measurement=='correct' or result.kind=='boolean' else spec.get('cardinality') or 1
            l.category_colors=[result.labels.get(str(code),{}).get('color',matplotlib.colormaps['tab20'](code%20)) for code in range(count)]
        title='Loss A − loss B (positive favors B)' if paired else MEASUREMENTS[selection.measurement][0]
        l.color_label=f'{target} · {title} · {result.units}';self._display_key='navigation/'+target;l.redraw()
        protocol=result.provenance.get('protocol',{});protocol_text=protocol.get('kind','unknown')+(' · unverified producer claim' if not protocol.get('verified') else '')
        summary=result.summary
        text=result.reason or (f"{summary.get('measured',summary.get('n_shared',0)):,} supported in {selection.subset} · {summary.get('excluded',0):,} excluded / unavailable · {summary.get('total_supported',summary.get('n_a',0)):,} total supported / {len(payload[0]['anchor_rows']):,} result rows")
        known=spec.get('known_result_anchors');denom=spec.get('result_anchors')
        if known is not None:text=f'{result.kind} · observed known {known:,} / {denom:,} result anchors; missing {denom-known:,}.\n'+text
        if paired:text=f"{paired['n_shared']:,} shared in {selection.subset}; A {paired['n_a']:,}, B {paired['n_b']:,} supported. Total A {paired['total_supported_a']:,}/{paired['result_rows_a']:,}, B {paired['total_supported_b']:,}/{paired['result_rows_b']:,} result anchors."
        self.prediction_status.setText(text);self.map_reading.setText(l.color_label+'\n'+text);self.protocol_label.setText('Protocol: '+protocol_text+'; observer movement changes only the displayed subset.')
        metrics=summary.get('metrics',{});compact={k:v for k,v in metrics.items() if k not in ('confusion','per_class','label_policy')}
        format_value=lambda v:'undefined' if v is None else f'{v:.4g}' if isinstance(v,(int,float)) else str(v)
        if paired:
            metric_text=f"Paired support: A {paired['n_a']:,} · B {paired['n_b']:,} · shared {paired['n_shared']:,}. Loss A {format_value(paired['loss_a'])} · loss B {format_value(paired['loss_b'])} · mean improvement {format_value(paired['mean_improvement'])}."
            if paired['changed_context']:metric_text+=' Embedding/context also changed.'
        else:
            metric_text=' · '.join(f'{k.replace("_"," ")} {format_value(v)}' for k,v in compact.items() if k not in ('n','observed_classes'))
            if not metric_text:metric_text='Mean active measurement: '+format_value(summary.get('mean_measurement'))+'; aggregate scoring requires saved observations, predictions and baseline.'
        self.prediction_summary.setText(result.reason or f'{target} ({result.kind}) · {selection.account} · {q} PCs · {title}\n{text}\n{metric_text}')
        details=dict(classes=result.labels,confusion=metrics.get('confusion'),per_class=metrics.get('per_class'),policy=metrics.get('label_policy'),log_policy=result.provenance.get('log_policy'))
        self.classification_details.setPlainText(json.dumps(clean(details),indent=2,ensure_ascii=False))
        self.fill_navigation_overview()
        if self.evidence.currentWidget()==self.prediction_panel:
            self.draw_prediction_evidence(result)
            self.refresh_group_views()
        self.update_resource_context()

    def draw_prediction_evidence(self,result):
        self.prediction_figure.clear();ax=self.prediction_figure.add_subplot(111);ax.set_facecolor('#161d27');ax.tick_params(colors='#bfcddd',labelsize=8);values=result.values[result.available]
        if len(values):
            if result.rendering=='categorical':
                codes,counts=np.unique(values,return_counts=True);ax.bar([result.labels.get(str(int(c)),{}).get('name',str(int(c))) for c in codes],counts,color='#80b5cf')
            else:ax.hist(values,bins=min(24,max(1,int(np.sqrt(len(values))))),color='#80b5cf')
        else:ax.text(.1,.5,result.reason or 'No supported observations in this subset',transform=ax.transAxes,color='white',wrap=True)
        ax.set_title('Active measurement · displayed subset',color='white',fontsize=10);ax.set_xlabel(result.units,color='#bfcddd');self.prediction_figure.tight_layout();self.prediction_canvas.draw_idle()
        ids=cases(result);self._prediction_case_rows=result.rows[ids]
        catalog=self.store.catalog;collection=self.definition['collection'];item_ids=catalog.load(catalog.collection(collection)['item_ids'])
        selected={int(self.prediction_cases.item(i,0).text()) for i in range(self.prediction_cases.rowCount()) if self.prediction_cases.item(i,0).checkState()==Qt.CheckState.Checked}
        signature=(result.selection.target,result.selection.measurement,result.selection.component,result.selection.dimension,result.selection.account,tuple(self._prediction_case_rows))
        if signature!=self._case_signature:selected=set()
        self._case_signature=signature
        fill(self.prediction_cases,[[int(result.rows[i]),result.labels.get(str(int(result.values[i])),{}).get('name',str(int(result.values[i]))) if result.rendering=='categorical' else float(result.values[i]),item_ids[result.rows[i]]] for i in ids])
        for row in range(self.prediction_cases.rowCount()):
            item=self.prediction_cases.item(row,0);item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable);item.setCheckState(Qt.CheckState.Checked if int(item.text()) in selected else Qt.CheckState.Unchecked)

    def keep_prediction_cases(self):
        result=self.resolved_measurement
        if result is not None:self.set_selection(result.rows[cases(result)])

    def fill_navigation_overview(self):
        target=self.feature.currentText();kind=self.store.catalog.raw['features'].get(target,{}).get('kind')
        entries=[(c,n,account,q) for c,m in self.navigation_index.items() for n,account,q in variants(m) if m.get('targets',{}).get(n,{}).get('kind')==kind]
        names=sorted({n for c,n,account,q in entries});columns=sorted({(c,account,q) for c,n,account,q in entries});self._overview_cells={}
        self.navigation_overview.setColumnCount(len(columns)+1);self.navigation_overview.setHorizontalHeaderLabels(['Target / '+str(kind)]+[f'{c} · {account} · {q} PCs' for c,account,q in columns])
        rows=[]
        for row,name in enumerate(names):
            values=[name]
            for col,(component,account,q) in enumerate(columns,1):
                m=self.navigation_index[component];record=next((r for r in m.get('metrics',[]) if isinstance(r,dict) and r.get('feature')==name and r.get('account')==account and r.get('dimension')==q and 'n' in r),{}) if isinstance(m.get('metrics'),list) else {}
                if (component,name,account,q) not in entries:values.append('not generated');continue
                resident=self.loaded.get(component)
                expected='predictions' if component.startswith('external_') else f'{name}__q{q}__{account}' if component=='reference_evaluation' else f'{name}__q{q}__{account}__prediction'
                state='loaded' if resident and expected in resident[0] else 'saved / unloaded'
                if component in getattr(self,'load_errors',{}):state='stale / missing dependency'
                denominator=m.get('support',{}).get('valid_anchors');count=record.get('n')
                if count is not None and denominator is not None and count<denominator:state+=' · partial'
                metric='mae' if kind=='numeric' else 'brier';value=record.get(metric)
                score=f'{metric} {value:.4g}' if value is not None else 'statistically undefined' if metric in record else 'not measured'
                values.append(f'{score} · {count if count is not None else "?"}/{denominator} result anchors · {state}')
                self._overview_cells[(row,col)]=(component,name,account,q)
            rows.append(values)
        if not rows:
            self.navigation_overview.setColumnCount(2);self.navigation_overview.setHorizontalHeaderLabels(['Target','State']);rows=[[target,'not generated; Prepare configured family explicitly']]
        fill(self.navigation_overview,rows)

    def select_overview_cell(self,row,column):
        choice=self._overview_cells.get((row,column))
        if choice is None:return
        component,target,account,q=choice;self._nav_updating=True
        try:
            for control,value,bydata in [(self.feature,target,False),(self.result_module,component,True),(self.account,account,True),(self.dimension,str(q),False)]:
                control.blockSignals(True);control.setCurrentIndex(control.findData(value) if bydata else control.findText(value));control.blockSignals(False)
        finally:self._nav_updating=False
        self.navigation_module_changed()

    def pick_navigation_dimension(self,event):
        artist=event.artist
        if not hasattr(artist,'get_xdata') or not len(event.ind):return
        q=int(artist.get_xdata()[event.ind[0]]);account='broad' if artist.get_label()=='Broad' else 'local'
        self._nav_updating=True
        self.dimension.setCurrentText(str(q));self.account.setCurrentIndex(self.account.findData(account));self._nav_updating=False
        self.set_lens('prediction')

    def estimate_source_audit(self):
        from .instruments import plan
        try:
            p=plan(self.store,self.key,['source_support']);dims=p['dimensions'];rows=p['context_cap']
            if not p['missing']:
                text=f"Already saved: {rows:,} rows × {dims} coordinates. Zero NEW compute; {p['saved_payload_bytes']/1024**2:.3f} MiB saved payload / checksum I/O to load. Use Prepare / load audit to inspect measured plots."
            else:
                text=f"Missing audit work: {rows:,} rows × {dims} coordinates; RAM ≈ {p['temporary_ram_estimate_bytes']/1024**2:.2f} MiB; additional output ≈ {p['output_estimate_bytes']/1024**2:.2f} MiB; {p['total_missing_work']:,} operations (structural, not seconds)."
                if p['over_budget']:text+=' Cannot compute: '+str(p.get('scope_refusal') or 'declared RAM/work/output budget exceeded')
            self.source_note.setText(text);self.audit_estimate_text.setText(text);self.audit_estimate_text.show();self._show_audit_estimate=True
        except Exception as exc:self.source_note.setText('Estimate unavailable: '+str(exc));self.audit_estimate_text.setText(self.source_note.text());self.audit_estimate_text.show()

    def refresh_source_support(self):
        if not hasattr(self,'source_text'):return
        support=next((m.get('support',{}) for _,m in self.loaded.values() if 'embedding_available' in m.get('support',{})),{})
        member=support.get('question_members',self.definition['n_members']);available=support.get('embedding_available')
        text=f"Map membership: {member:,}. Missing embedding coverage: {member-available if available is not None else 'not measured'} / {member:,}. Source revision: {self.definition['domain_revision']}.\n"
        for label,key in [('Non-finite sampled vectors','non_finite_sampled_vectors'),('Finite near-zero sampled vectors (L2 ≤ 1e-8)','finite_near_zero_sampled_vectors')]:text+=f"{label}: {support.get(key,'not measured')} / {support.get('sampled_vector_rows','not measured')} sampled anchor/context vectors.\n"
        audit=self.loaded.get('source_support')
        if audit:
            m=audit[1];v=m['measurements'];o=m['neighbor_occurrences'];text+=f"\nSample-only valid context: {v['rows']:,} rows; source revision {m['source_revision']}.\nEquality: exact coordinates, signed zeros equal. Source duplicates: {v['exact_source']['repeated_rows']} repeated rows, {v['exact_source']['groups']} groups, largest {v['exact_source']['largest_group']}.\nAfter individual unit normalization: {v['exact_unit_normalized']['repeated_rows']} repeated rows, {v['exact_unit_normalized']['groups']} groups, largest {v['exact_unit_normalized']['largest_group']}. Neither is a near-duplicate measure.\nCentered unit-vector covariance participation ratio: {v['rank']['value']} on {v['rank']['support']} valid sampled rows.\nSaved search: {o['query_count']} queries / {o['candidate_count']} candidates (including {o['zero_occurrences']} with zero occurrences). Occurrences median {o['median']:.3g}, p95 {o['p95']:.3g}, max {o['max']}; Herfindahl concentration {o['herfindahl']:.4g}.\nSample-only measurements cannot establish or rule out a corpus-wide issue."
        else:text+='Exact duplicates, covariance participation ratio and neighbor occurrences: not measured / not loaded. Request the bounded sample audit explicitly.'
        self.source_text.setPlainText(text)
