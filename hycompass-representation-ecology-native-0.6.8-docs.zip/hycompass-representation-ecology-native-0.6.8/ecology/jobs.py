"""Shared bounded workspace worker with pinned revisions and durable job records."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from queue import Queue, Full, Empty
import json
import threading
import uuid
from .store import Store,Token,Cancelled
from .catalog import atomic_json
from .instruments import generate,generate_many,dependency_order
from .locking import workspace_writer

_services={}
_services_lock=threading.Lock()

def get_jobs(root):
    key=str(Path(root).resolve())
    with _services_lock:
        if key not in _services or _services[key].closed:_services[key]=Jobs(root)
        return _services[key]

class Jobs:
    def __init__(self,root):
        self.root=Path(root);self.executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='ecology');self.tasks={};self.events=Queue(maxsize=128);self.progress={};self.records={};self.lock=threading.RLock();self.listeners=[];self.closed=False
        folder=self.root/'jobs';folder.mkdir(exist_ok=True)
        with workspace_writer(self.root):
            store=Store(root)
            for d in store.definitions():
                for name,state in store.status(d['id']).items():
                    if state.get('status') in ('queued','running'):store.set_status(d['id'],name,status='interrupted',error='Worker stopped before completion; saved components remain reusable')
            for path in sorted(folder.glob('*.json'),key=lambda p:p.stat().st_mtime)[-256:]:
                r=json.loads(path.read_text())
                if r['state'] in ('queued','running'):
                    r['state']='interrupted';atomic_json(path,r)
                self.records[r['id']]=r
    def _record(self,record):
        self.records[record['id']]=record;atomic_json(self.root/'jobs'/(record['id']+'.json'),record)
        for callback in self.listeners:
            try:callback(record.copy())
            except Exception:pass
    def submit(self,key,names,expected_revision=None,continue_on_error=False):
        with self.lock:
            if self.closed:raise ValueError('Worker is closed')
            if len(self.tasks)>=8:raise ValueError('Worker queue is full (8 jobs)')
            if self.busy(key):raise ValueError('This map already has queued/running work')
            names=dependency_order(names);store=Store(self.root);revision=store.read(key)['revision']
            if expected_revision is not None and revision!=expected_revision:raise ValueError('Map revision conflict')
            token=Token();job_id=uuid.uuid4().hex
            record=dict(id=job_id,map_id=key,map_revision=revision,components=names,continue_on_error=continue_on_error,state='queued',progress=0.)
            self._record(record)
            def run_locked():
                with workspace_writer(self.root):
                    try:
                        if store.read(key)['revision']!=revision:raise ValueError('Pinned map revision changed')
                        for name in names:
                            if not store.artifact_path(key,name).exists():store.set_status(key,name,status='queued',job_id=job_id)
                        record['state']='running';self._record(record)
                        def report(stage,fraction):
                            self.progress[key]=(stage,fraction)
                            try:self.events.put_nowait((key,stage,fraction))
                            except Full:
                                try:self.events.get_nowait()
                                except Empty:pass
                                self.events.put_nowait((key,stage,fraction))
                            record.update(stage=stage,progress=fraction)
                        result=(generate_many if continue_on_error else generate)(store,key,names,token,report)
                        if continue_on_error:record.update(state='partial' if result['failed'] else 'succeeded',progress=1.,**result)
                        else:record.update(state='succeeded',progress=1.,completed=result)
                        self.progress[key]=('complete',1.)
                        return result
                    except Exception as exc:
                        record.update(state='cancelled' if isinstance(exc,Cancelled) else 'failed',error=str(exc));self.progress[key]=('error',str(exc))
                        for name in names:
                            if store.status(key).get(name,{}).get('status') in ('queued','running'):store.set_status(key,name,status=record['state'],error=str(exc))
                        raise
                    finally:
                        self._record(record)
                        try:self.events.put_nowait((key,record['state'],record.get('error','')))
                        except Full:pass
            def run():
                try:return run_locked()
                except Exception as exc:
                    if record['state']=='queued':record.update(state='failed',error=str(exc));self._record(record)
                    raise
            future=self.executor.submit(run);future.job_id=job_id;self.tasks[key]=(future,token)
            def finish(f):
                with self.lock:
                    if self.tasks.get(key,(None,))[0] is f:self.tasks.pop(key,None)
            future.add_done_callback(finish);return future
    def inspect(self,job_id):
        return dict(self.records[job_id])
    def cancel_job(self,job_id):
        record=self.records[job_id]
        if record['state'] in ('queued','running'):self.cancel(record['map_id'])
        return self.inspect(job_id)
    def cancel(self,key):
        entry=self.tasks.get(key)
        if entry is not None:entry[1].cancel()
    def busy(self,key):
        entry=self.tasks.get(key);return entry is not None and not entry[0].done()
    def close(self):
        self.closed=True
        for f,t in list(self.tasks.values()):t.cancel()
        self.executor.shutdown(wait=False,cancel_futures=False)
