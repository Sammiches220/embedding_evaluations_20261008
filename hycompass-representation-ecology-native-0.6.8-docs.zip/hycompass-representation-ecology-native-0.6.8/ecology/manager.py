"""Saved map manager; population views remain independent tabs."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLineEdit,QTableWidget,QTableWidgetItem,QPushButton,QPlainTextEdit,QInputDialog,QMessageBox,QFileDialog,QComboBox
from .store import Store
from .packages import export_package,import_package,attach_package,PROFILES
import json

class MapManager(QDialog):
    def __init__(self,root,open_map,jobs,parent=None,*,dataset=None,show_population=None):
        super().__init__(parent);self.store=Store(root);self.open_map=open_map;self.jobs=jobs;self.setWindowTitle('Maps');self.resize(1050,650)
        self.dataset = dataset
        self.show_population = show_population
        layout=QVBoxLayout(self);self.search=QLineEdit();self.search.setPlaceholderText('Find a map by title or embedding');layout.addWidget(self.search)
        self.table=QTableWidget(0,6);self.table.setHorizontalHeaderLabels(['Title','Embedding','Members','Results','Saved MiB','Map ID']);self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows);self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection);self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers);layout.addWidget(self.table)
        bar=QHBoxLayout();layout.addLayout(bar)
        for label,action in [('Open',self.open),('Rename',self.rename),('Edit card note',self.edit_note),('Duplicate definition',self.duplicate),('Unload',self.unload),('Delete results',self.delete_results),('Delete map',self.delete_map)]:
            b=QPushButton(label);b.clicked.connect(lambda _,a=action:self.perform(a));bar.addWidget(b)
        bar=QHBoxLayout();layout.addLayout(bar);self.profile=QComboBox();self.profile.addItems(PROFILES);self.profile.setCurrentText('viewing');bar.addWidget(self.profile)
        for label,action in [('Export package',self.export),('Import package',self.import_new),('Attach exact layers',self.attach),('Map card…',self.card),('Imported cards…',self.cards)]:
            b=QPushButton(label);b.clicked.connect(lambda _,a=action:self.perform(a));bar.addWidget(b)
        self.detail=QPlainTextEdit();self.detail.setReadOnly(True);layout.addWidget(self.detail);self.search.textChanged.connect(self.refresh);self.table.itemSelectionChanged.connect(self.describe);self.table.doubleClicked.connect(lambda _:self.perform(self.open));self.refresh()
    def perform(self,fn):
        try:fn();self.refresh()
        except Exception as exc:QMessageBox.warning(self,'Maps',str(exc))
    def key(self):
        row=self.table.currentRow()
        if row<0:raise ValueError('Select a map first')
        return self.table.item(row,5).text()
    def refresh(self):
        selected=self.table.item(self.table.currentRow(),5).text() if self.table.currentRow()>=0 else None
        self.table.blockSignals(True);rows=[r for r in self.store.summaries() if self.search.text().lower() in (r['title']+' '+r['domain']).lower()];self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate([r['title'],r['domain'],f"{r['n_members']:,}",r['results'],f"{r['stored_result_bytes']/1024**2:.2f}",r['id']]):self.table.setItem(i,j,QTableWidgetItem(str(v)))
            if r['id']==selected:self.table.selectRow(i)
        self.table.resizeColumnsToContents();self.table.blockSignals(False)
    def describe(self):
        try:
            capabilities=self.store.capabilities(self.key());preview=self.store.deletion_preview(self.key());lines=['Computation availability']
            for name,state in capabilities['compute'].items():lines.append(name.replace('_',' ').capitalize()+': '+('Ready' if state['available'] else state.get('reason','Unavailable')))
            lines+=['','Saved result availability']
            for name,state in capabilities['view'].items():lines.append(name.replace('_',' ')+': '+('Viewable' if state['available'] else state.get('reason','Unavailable')))
            lines+=['',f"Deleting this map would reclaim {preview['reclaimable_bytes']/1024**2:.2f} MiB of files. Shared sources are retained."]
            if preview['dependent_maps']:lines.append('Deletion blocked by referencing maps: '+', '.join(preview['dependent_maps']))
            self.detail.setPlainText('\n'.join(lines))
        except Exception as exc:self.detail.setPlainText(str(exc))
    def open(self):self.open_map(self.key())
    def rename(self):
        key=self.key();d=self.store.read(key);title,ok=QInputDialog.getText(self,'Rename map','Title',text=d['title'])
        if ok:
            self.store.rename(key,title,d['metadata_revision'])
            parent=self.parent()
            if hasattr(parent,'tabs'):
                for i in range(parent.tabs.count()):
                    w=parent.tabs.widget(i)
                    if getattr(w,'key',None)==key:w.definition=self.store.read(key);w.map_title.setText(title);parent.tabs.setTabText(i,title)
    def duplicate(self):self.store.duplicate(self.key(),self.store.read(self.key())['title']+' copy')
    def unload(self):
        parent=self.parent()
        if hasattr(parent,'tabs'):
            for i in range(parent.tabs.count()):
                w=parent.tabs.widget(i)
                if getattr(w,'key',None)==self.key():w.unload()
    def _idle(self):
        if self.jobs.busy(self.key()):raise ValueError('Cancel this map’s job and wait for completion first')
    def delete_results(self):
        self._idle();key=self.key()
        if QMessageBox.question(self,'Delete results',f'Delete all saved results for {key}? The map definition and sources are retained.')==QMessageBox.StandardButton.Yes:self.unload();self.store.delete_results(key)
    def delete_map(self):
        self._idle();key=self.key();preview=self.store.deletion_preview(key)
        if preview['dependent_maps']:raise ValueError('Referenced by: '+', '.join(preview['dependent_maps']))
        if QMessageBox.question(self,'Delete map',f"Delete {key} and reclaim {preview['reclaimable_bytes']/1024**2:.2f} MiB? Shared sources are retained.")==QMessageBox.StandardButton.Yes:
            self.unload();parent=self.parent()
            if hasattr(parent,'tabs'):
                for i in reversed(range(parent.tabs.count())):
                    w=parent.tabs.widget(i)
                    if getattr(w,'key',None)==key:w.timer.stop();parent.tabs.removeTab(i);w.deleteLater()
            self.store.delete(key)
    def export(self):
        path,_=QFileDialog.getSaveFileName(self,'Export map package',self.key()+'.hcmap','HyCompass map (*.hcmap)')
        if path:export_package(self.store,self.key(),path,self.profile.currentText())
    def import_new(self):
        path,_=QFileDialog.getOpenFileName(self,'Import package','','HyCompass map (*.hcmap)')
        if not path:return
        destination,_=QFileDialog.getSaveFileName(self,'New workspace directory')
        if destination:
            result=import_package(path,destination);self.detail.setPlainText('Imported workspace: '+destination+'\n'+json.dumps(result,indent=2))
    def attach(self):
        path,_=QFileDialog.getOpenFileName(self,'Attach exact layers','','HyCompass map (*.hcmap)')
        if path:attach_package(path,self.store.catalog.root)

    def card(self):
        from ui.panels.saved_maps import CardDialog
        key = self.key()
        dataset = self.dataset(self.store.read(key)) if callable(self.dataset) else self.dataset
        CardDialog(self.store,key,dataset,self).exec()

    def cards(self):
        from ui.panels.saved_maps import CardBrowser
        dialog = CardBrowser(self.store,self.open_map,self.show_population,self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.accept()

    def edit_note(self):
        key = self.key()
        definition = self.store.read(key)
        note, ok = QInputDialog.getMultiLineText(
            self, "Map card note", "Question, motivation or context", definition.get("description", ""))
        if ok:
            if len(note) > 4096:
                raise ValueError("A card note can contain at most 4,096 characters")
            self.store.rename(key, definition["title"], definition["metadata_revision"], description=note)
