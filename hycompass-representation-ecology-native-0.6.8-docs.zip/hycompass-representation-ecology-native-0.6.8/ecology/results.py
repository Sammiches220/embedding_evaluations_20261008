"""Durable external predictions using typed canonical IDs and explicit evaluation scope."""
import numpy as np
from .catalog import correspondence,array_digest
from .store import Token
from .locking import workspace_writer

SCOPES=('in_sample','held_out','external','unknown')

def register_result(store,key,*,item_ids,predictions,target,kind,scope,provenance,expected_revision,known=None,metrics=None,result_id=None):
    with workspace_writer(store.catalog.root):
        d=store.read(key)
        if d['revision']!=expected_revision:raise ValueError('Map revision conflict')
        if scope not in SCOPES:raise ValueError('Explicit supported evaluation scope required')
        if kind not in ('numeric','boolean','category'):raise ValueError('Unsupported target kind')
        if not provenance or not target:raise ValueError('Target and producer provenance are required')
        ids=np.asarray(item_ids);pred=np.asarray(predictions)
        if ids.ndim!=1 or len(ids)>100000 or pred.shape[0]!=len(ids) or pred.dtype.kind not in 'fiu':raise ValueError('Invalid bounded prediction support')
        collection_ids=store.catalog.load(store.catalog.collection(d['collection'])['item_ids']);rows,_=correspondence(collection_ids,ids)
        if np.any(~np.isin(rows,store.membership(key))):raise ValueError('Prediction IDs fall outside map membership')
        mask=np.ones(len(ids),bool) if known is None else np.asarray(known)
        if mask.shape!=(len(ids),) or mask.dtype.kind not in 'bu':raise ValueError('Invalid prediction knownness')
        mask=mask.astype(bool)
        if not np.isfinite(pred[mask]).all():raise ValueError('Known predictions must be finite')
        if kind in ('numeric','boolean') and pred.ndim!=1:raise ValueError('Scalar predictions required')
        if kind=='boolean' and np.any((pred[mask]<0)|(pred[mask]>1)):raise ValueError('Boolean scores must lie in [0,1]')
        if kind=='category' and (pred.ndim!=2 or not 1<=pred.shape[1]<=64 or np.any(pred[mask]<0) or not np.allclose(pred[mask].sum(1),1)):raise ValueError('Category scores require normalized class probabilities (up to 64 classes)')
        spec=store.catalog.raw['features'].get(target)
        if spec and (spec['collection']!=d['collection'] or spec['kind']!=kind or kind=='category' and spec['cardinality']!=pred.shape[1]):raise ValueError('Target schema mismatch')
        order=np.argsort(rows);arrays=dict(anchor_rows=rows[order],predictions=pred[order],prediction_known=mask[order])
        from .navigation import target_snapshot
        snapshot=target_snapshot(store.catalog,target) if spec else dict(kind=kind,revision=None,units='producer units unknown',cardinality=pred.shape[1] if kind=='category' else None,labels={})
        descriptor=dict(result_format=2,targets={target:snapshot},evaluation=dict(kind=scope,verified=False,producer=provenance),domain_revision=d['domain_revision'],collection_revision=d['collection_revision'],origin='external',target=target,kind=kind,scope=scope,provenance=provenance,metrics=metrics or {},metrics_verified=False,support=dict(question_members=d['n_members'],valid_anchors=int(mask.sum()),prediction_rows=len(rows)),ordered_support_digest=array_digest(rows[order]),target_revision=spec['revision'] if spec else None,metric_policy='Imported metrics are producer claims; no held-out equivalence inferred')
        if spec:
            # Explicit bounded import may verify scoring against locally registered truth.
            truth,truth_known=store.catalog.feature(target,rows[order]);predicted=pred[order].astype(float).copy();predicted[~mask[order]]=np.nan
            arrays[target+'__observed']=np.where(truth_known,truth,np.nan);arrays[target+'__known']=truth_known
            valid=truth_known&mask[order];prefix=f'{target}__q0__external__'
            if kind=='numeric':
                residual=truth-predicted;loss=np.abs(residual);arrays[prefix+'signed_residual']=np.where(valid,residual,np.nan);arrays[prefix+'squared_error']=np.where(valid,residual**2,np.nan)
            elif kind=='boolean':loss=(truth-predicted)**2
            else:
                observed=np.eye(pred.shape[1])[np.where(truth_known,truth,0).astype(int)];loss=np.sum((observed-predicted)**2,1)
            arrays[prefix+'loss']=np.where(valid,loss,np.nan)
            if kind!='numeric':
                hard=(predicted>=.5).astype(float) if kind=='boolean' else np.argmax(predicted,1).astype(float)
                arrays[prefix+'predicted_class']=np.where(valid,hard,np.nan);arrays[prefix+'correct']=np.where(valid,hard==truth,np.nan)
            snapshot.update(known_result_anchors=int(truth_known.sum()),result_anchors=len(rows))
            descriptor['local_scoring']=dict(target_revision=spec['revision'],n=int(valid.sum()),note='Loss verified locally; producer evaluation protocol remains unverified. No training baseline imported.')
        result_id=result_id or __import__('uuid').uuid4().hex[:12]
        component='external_'+result_id
        store.artifact_path(key,component)
        descriptor.update(result_id=result_id,component=component)
        store.publish(key,component,arrays,descriptor,Token());return descriptor

def result_descriptors(store,key):
    from .instruments import REGISTRY
    out=[]
    for name in store.components(key):
        if not (store.artifact_path(key,name)/'metadata.json').exists():continue
        arrays,meta=store.artifact(key,name)
        out.append(dict(component=name,signature=meta['result_signature'],scope=meta.get('scope','see protocol'),target=meta.get('target'),support=meta.get('support',{}),arrays=meta['arrays'],origin=meta.get('origin','built-in'),metrics_verified=meta.get('metrics_verified',not name.startswith('external'))))
    return out
