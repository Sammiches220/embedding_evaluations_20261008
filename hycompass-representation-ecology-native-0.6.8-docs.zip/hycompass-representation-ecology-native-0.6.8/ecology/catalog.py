"""Canonical collection rows above HyCompass domains. Registration is explicit."""
from __future__ import annotations
import hashlib
import json
import os
import uuid
import re
from pathlib import Path
import numpy as np


def atomic_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp-' + uuid.uuid4().hex)
    temp.write_text(json.dumps(clean(value), indent=2, allow_nan=False) + '\n')
    os.replace(temp, path)


def clean(value):
    if isinstance(value, np.ndarray): return clean(value.tolist())
    if isinstance(value, np.generic): return clean(value.item())
    if isinstance(value, float) and not np.isfinite(value): return None
    if isinstance(value, dict): return {str(k): clean(v) for k,v in value.items()}
    if isinstance(value, (list, tuple)): return [clean(v) for v in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(clean(value), sort_keys=True).encode()).hexdigest()[:24]


def array_digest(a):
    h=hashlib.sha256()
    for start in range(0,len(a),65536): h.update(np.ascontiguousarray(a[start:start+65536]).tobytes())
    return h.hexdigest()


_stamp_cache={}

def stamp(path):
    """Portable bounded fingerprint. Source immutability + explicit registration is authoritative.

    Small files are hashed fully; large files hash length and first/last 64 KiB.
    This is a change sentinel, not a full checksum of large assets.
    """
    path=Path(path);s=path.stat();key=(str(path.resolve()),s.st_size,s.st_mtime_ns)
    if key in _stamp_cache:return _stamp_cache[key]
    h=hashlib.sha256();h.update(str(s.st_size).encode())
    with path.open('rb') as stream:
        h.update(stream.read(65536))
        if s.st_size>65536:stream.seek(max(65536,s.st_size-65536));h.update(stream.read(65536))
    result=[s.st_size,h.hexdigest()]
    if len(_stamp_cache)>4096:_stamp_cache.clear()
    _stamp_cache[key]=result;return result


def rows_checked(rows, n):
    a = np.asarray(rows)
    if a.ndim != 1 or a.dtype.kind not in 'iu' or (len(a) and (a.min()<0 or a.max()>=n)):
        raise ValueError('Expected integer rows within the declared universe')
    return np.unique(a.astype(np.int64))


def correspondence(collection_ids, embedding_ids):
    c, e = np.asarray(collection_ids), np.asarray(embedding_ids)
    if c.ndim != 1 or e.ndim != 1 or c.dtype.kind not in 'iuUS' or e.dtype.kind not in 'iuUS':
        raise ValueError('IDs must be one-dimensional integer or fixed string arrays')
    if c.dtype.kind in 'iu' and e.dtype.kind not in 'iu' or c.dtype.kind in 'US' and e.dtype.kind not in 'US':
        raise ValueError('ID types must agree; implicit coercion is ambiguous')
    if len(np.unique(c))!=len(c) or len(np.unique(e))!=len(e): raise ValueError('Duplicate item IDs')
    order = np.argsort(c); pos = np.searchsorted(c[order], e)
    if np.any(pos>=len(c)) or not np.array_equal(c[order[pos]],e): raise ValueError('Embedding contains unknown IDs')
    forward = order[pos].astype(np.int64)
    reverse = np.full(len(c), -1, np.int64); reverse[forward] = np.arange(len(e))
    return forward, reverse


from .locking import mutation


class Catalog:
    """Small extension catalog references existing domain/projection assets; never copies vectors."""
    def __init__(self, root):
        from model.workspace.manifest import WorkspaceManifest
        self.root = Path(root).resolve(); self.manifest = WorkspaceManifest.load(self.root)
        self.path = self.root/'ecology.json'
        self.raw = json.loads(self.path.read_text()) if self.path.exists() else dict(version=2, collections={}, domains={}, features={})
        if self.raw['version']!=2: raise ValueError('Unsupported ecology catalog')
        self._maps = {}
        self._catalog_revision=digest(self.raw) if self.path.exists() else None

    def resolve(self,p): return self.manifest.resolve(p)
    def load(self,p): return np.load(self.resolve(p), mmap_mode='r', allow_pickle=False)
    @mutation
    def save(self):
        current=digest(json.loads(self.path.read_text())) if self.path.exists() else None
        if current!=self._catalog_revision:raise ValueError('Catalog revision conflict; reload before writing')
        atomic_json(self.path,self.raw);self._catalog_revision=digest(self.raw)
    def relative(self,p): return self.manifest.relative_or_absolute(Path(p))
    def collection(self,key): return self.raw['collections'][key]
    def n(self,key): return len(self.load(self.collection(key)['item_ids']))

    def valid_id(self,key):
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}",key):raise ValueError("Use a compact alphanumeric asset ID with . _ or -")

    @mutation
    def register_collection(self,key,item_ids,groups=None):
        self.valid_id(key)
        ids = self.load(item_ids)
        correspondence(ids,ids)
        if groups:
            g=self.load(groups)
            if g.shape!=ids.shape or g.dtype.kind not in 'iu': raise ValueError('Groups must be row-aligned integer IDs')
        self.raw['collections'][key]=dict(item_ids=item_ids,groups=groups,revision=uuid.uuid4().hex)
        self.save()

    @mutation
    def register_domain(self,domain,collection):
        self.valid_id(domain)
        spec=self.manifest.domains[domain]
        ids=self.load(spec.item_ids); vectors=self.load(spec.embeddings)
        if vectors.ndim!=2 or len(vectors)!=len(ids) or vectors.dtype.kind not in 'fiu': raise ValueError('Invalid vector alignment')
        f,r=correspondence(self.load(self.collection(collection)['item_ids']),ids)
        folder=self.root/'identity'; folder.mkdir(exist_ok=True)
        fp=folder/(domain+'-to-collection.npy'); rp=folder/(domain+'-from-collection.npy')
        np.save(fp,f); np.save(rp,r)
        paths=[spec.item_ids,spec.embeddings,self.collection(collection)['item_ids']]
        self.raw['domains'][domain]=dict(collection=collection,forward=self.relative(fp),reverse=self.relative(rp),
            source_stamps={p:stamp(self.resolve(p)) for p in paths},revision=uuid.uuid4().hex)
        self.save()

    def correspondence_maps(self,domain):
        if domain not in self._maps:
            d=self.raw['domains'][domain]; f,r=self.load(d['forward']),self.load(d['reverse'])
            n=self.n(d['collection']); m=len(self.load(self.manifest.domains[domain].item_ids))
            if f.shape!=(m,) or r.shape!=(n,) or f.dtype.kind not in 'iu' or r.dtype.kind not in 'iu' or np.any(f<0) or np.any(f>=n) or not np.array_equal(r[f],np.arange(m)) or np.any(r<-1) or np.any(r>=m):
                raise ValueError('Invalid stored correspondence map')
            if np.count_nonzero(r>=0)!=m: raise ValueError('Duplicate reverse map entries')
            self._maps[domain]=(f,r)
        return self._maps[domain]

    def to_collection(self,domain,rows):
        f,_=self.correspondence_maps(domain); return f[rows_checked(rows,len(f))]
    def to_domain(self,domain,collection_rows):
        _,r=self.correspondence_maps(domain); rows=rows_checked(collection_rows,len(r)); mapped=r[rows]
        return rows[mapped>=0],mapped[mapped>=0]
    def validate_sources(self,domain):
        d=self.raw['domains'][domain]
        for p,s in d['source_stamps'].items():
            if stamp(self.resolve(p))!=s: raise ValueError('Stale source: '+p+'; explicitly re-register domain and create a new map')

    @mutation
    def register_feature(self,key,collection,kind,values,valid,labels=None,cardinality=None,provenance='source'):
        self.valid_id(key)
        if kind not in ('numeric','boolean','category'): raise ValueError('Unsupported feature type')
        a,b=self.load(values),self.load(valid); n=self.n(collection)
        if a.shape!=(n,) or b.shape!=(n,) or a.dtype.kind not in 'fiu b'.replace(' ','') or b.dtype.kind not in 'bu' or np.any((b!=0)&(b!=1)): raise ValueError('Invalid typed feature/knownness arrays')
        known=b.astype(bool)
        if kind=='numeric' and not np.isfinite(a[known]).all(): raise ValueError('Nonfinite known numeric feature')
        if kind=='boolean' and np.any((a[known]!=0)&(a[known]!=1)): raise ValueError('Boolean must be 0/1')
        if kind=='category' and (a.dtype.kind not in 'iu' or cardinality is None or not 1<=cardinality<=64 or np.any(a[known]<0) or np.any(a[known]>=cardinality)): raise ValueError('Category code/cardinality invalid (max 64)')
        self.raw['features'][key]=dict(collection=collection,kind=kind,values=values,valid=valid,labels=labels,cardinality=cardinality,provenance=provenance,
            revision=uuid.uuid4().hex,source_stamps={p:stamp(self.resolve(p)) for p in [values,valid]})
        self.save()

    def feature(self,key,rows):
        f=self.raw['features'][key]
        for p,s in f['source_stamps'].items():
            if stamp(self.resolve(p))!=s: raise ValueError('Stale feature: '+key)
        return np.asarray(self.load(f['values'])[rows]), np.asarray(self.load(f['valid'])[rows],bool)
    def labels(self,key):
        f=self.raw['features'][key]
        if f.get('labels') and not self.resolve(f['labels']).exists():return {}
        if f.get('labels') and self.resolve(f['labels']).stat().st_size>1_000_000:raise ValueError('Label dictionary exceeds 1 MB')
        return json.loads(self.resolve(f['labels']).read_text()).get('labels',{}) if f.get('labels') else {}
    def group_values(self,collection,rows):
        p=self.collection(collection).get('groups'); return self.load(p)[rows] if p else np.asarray(rows)


def checksum(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
