"""Small, inert saved-map snapshots shared by native previews and offline exports."""
from collections import defaultdict
import base64
import io
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image
from scipy.ndimage import binary_dilation

from .catalog import atomic_json, digest
from .locking import workspace_writer
from .card_report import render_report
from .report_evidence import saved_charts
from .feature_report import FeatureEvidence

MAX_CARD = 512 * 1024
MAX_IMAGE = 256
MAX_FINDINGS = 96
MAX_MODULES = 64
PRESETS = ("Broad overview", "Target distributions", "Model evaluation", "Geometry and support",
           f"First {MAX_FINDINGS} findings", "Clear findings")


def preset_rows(findings, preset):
    if preset == "Clear findings":
        return set()
    if preset == "Broad overview":
        groups = defaultdict(dict)
        ordered_rows = sorted(enumerate(findings), key=lambda pair: pair[1]["target"] == "Measurement support")
        for index, item in ordered_rows:
            module = item["result"].split("/", 1)[0].split("--", 1)[0]
            groups[module].setdefault(item["target"], index)
        ordered = [iter(group.values()) for group in groups.values()]
        selected = set()
        while ordered and len(selected) < 24:
            remaining = []
            for group in ordered:
                row = next(group, None)
                if row is not None:
                    selected.add(row)
                    remaining.append(group)
                if len(selected) == 24:
                    break
            ordered = remaining
        return selected
    prefixes = {"Target distributions": ("feature_distribution",),
                "Model evaluation": ("reconstruction", "probe_metrics", "reference_evaluation", "discrepancy"),
                "Geometry and support": ("geometry", "source_support")}
    selected = [index for index, item in enumerate(findings)
                if item["result"].startswith(prefixes.get(preset, ("",)))]
    return set(selected[:MAX_FINDINGS])


def preview_png(footprint):
    # Light member cells over cool field bands. All colors encode map support.
    distance = footprint.distance[::-1]
    field = np.exp(-0.5 * (distance / 6) ** 2)
    bands = np.where(field >= 0.38, np.floor(6 * field) / 6, 0)
    background = np.array([13, 26, 35])
    teal = np.array([55, 177, 161])
    pixels = (background + bands[..., None] * (teal - background)).astype(np.uint8)
    occupied = footprint.counts[::-1] > 0
    edges = binary_dilation(occupied) & ~occupied
    pixels[edges] = (pixels[edges].astype(np.uint16) + (255, 211, 138)) // 2
    pixels[occupied] = (255, 211, 138)
    image = Image.fromarray(pixels)
    xmin, xmax, ymin, ymax = footprint.bounds
    ratio = (xmax - xmin) / (ymax - ymin)
    image = image.resize((max(1, round(MAX_IMAGE * min(1, ratio))),
                          max(1, round(MAX_IMAGE * min(1, 1 / ratio)))),
                         Image.Resampling.BOX)
    output = io.BytesIO()
    image.save(output, format="PNG")
    return base64.b64encode(output.getvalue()).decode("ascii")


def make_card(definition, footprint=None, *, status="Location unavailable",
              anchors=None, findings=(), overview=None):
    card = dict(version=1, map_id=definition["id"], revision=definition["revision"],
                title=definition["title"].strip()[:256] or definition["id"], embedding=definition["domain"],
                note=definition.get("description", "")[:4096],
                members=definition["n_members"], anchors=anchors, findings=list(findings),
                location=status, projection=None, present=None, projected=None, png=None)
    if overview is not None:
        card.update(version=2, overview=overview)
    if footprint is not None:
        if footprint.projected:
            location = "Saved member points and coverage field"
        else:
            location = "Zero projected members"
        card.update(projection=footprint.projection, present=footprint.present,
                    projected=footprint.projected, location=location,
                    png=preview_png(footprint) if footprint.projected else None)
    validate_card(card)
    return card


def validate_card(card):
    def require(valid):
        if not valid:
            raise ValueError("Invalid or unsupported saved-map card")

    def string(value, limit, *, empty=False):
        return isinstance(value, str) and (empty or bool(value.strip())) and len(value) <= limit

    def count(value):
        return type(value) is int and 0 <= value <= 2**63 - 1

    def number(value):
        return (type(value) is float and math.isfinite(value)
                or type(value) is int and abs(value) <= 2**63 - 1)

    fields = {"version", "map_id", "revision", "title", "embedding", "note", "members",
              "anchors", "findings", "location", "projection", "present", "projected", "png"}
    require(isinstance(card, dict) and type(card.get("version")) is int
            and card["version"] in (1, 2))
    if card["version"] == 2:
        fields.add("overview")
    require(card.keys() == fields)
    if card["version"] == 2:
        overview = card["overview"]
        require(isinstance(overview, dict) and overview.keys() == {"definition", "modules"})
        require(string(overview["definition"], 2048))
        require(isinstance(overview["modules"], list) and len(overview["modules"]) <= MAX_MODULES)
        for module in overview["modules"]:
            require(isinstance(module, dict) and module.keys() == {"name", "result", "scope", "anchors"})
            require(string(module["name"], 128) and string(module["result"], 128)
                    and string(module["scope"], 512, empty=True)
                    and (module["anchors"] is None or count(module["anchors"])))
    for field, limit in (("map_id", 80), ("revision", 64), ("title", 256),
                         ("embedding", 256), ("note", 4096), ("location", 512)):
        require(string(card[field], limit, empty=field == "note"))
    require(count(card["members"]))
    require(card["anchors"] is None or count(card["anchors"]))
    findings = card["findings"]
    require(isinstance(findings, list) and len(findings) <= (2 if card["version"] == 1 else MAX_FINDINGS))
    for finding in findings:
        require(isinstance(finding, dict) and
                finding.keys() == {"target", "metric", "value", "scope", "result"})
        require(all(string(finding[field], 512) for field in ("target", "metric", "scope", "result")))
        require(number(finding["value"]))
    projection = card["projection"]
    if projection is None:
        require(card["present"] is None and card["projected"] is None and card["png"] is None)
        return card
    require(isinstance(projection, dict) and projection.keys() == {"id", "domain", "bounds", "fingerprint"})
    require(all(string(projection[field], 256) for field in ("id", "domain", "fingerprint")))
    bounds = projection["bounds"]
    require(isinstance(bounds, list) and len(bounds) == 4 and all(map(number, bounds))
            and bounds[0] < bounds[1] and bounds[2] < bounds[3])
    require(count(card["present"]) and count(card["projected"])
            and card["projected"] <= card["present"] <= card["members"])
    if card["projected"] == 0:
        require(card["png"] is None)
    else:
        require(string(card["png"], MAX_CARD // 2 if card["version"] == 2 else MAX_CARD - 16384))
        try:
            raw = base64.b64decode(card["png"], validate=True)
            with Image.open(io.BytesIO(raw), formats=["PNG"]) as image:
                require(0 < image.width <= MAX_IMAGE and 0 < image.height <= MAX_IMAGE
                        and not getattr(image, "is_animated", False))
                image.load()
        except (ValueError, OSError, Image.DecompressionBombError) as exc:
            raise ValueError("Invalid saved-map card PNG") from exc
    return card


def read_card(path):
    with Path(path).open("rb") as stream:
        data = stream.read(MAX_CARD + 1)
    if len(data) > MAX_CARD:
        raise ValueError("Saved-map card exceeds 512 KiB")
    return validate_card(json.loads(data))


def write_card(card, path):
    validate_card(card)
    size = len(json.dumps(card, indent=2, allow_nan=False).encode("utf-8")) + 1
    if size > MAX_CARD:
        raise ValueError("The overview is over 512 KiB. Uncheck some findings.")
    atomic_json(path, card)


def import_card(root, path):
    card = read_card(path)
    key = digest(card)
    with workspace_writer(root):
        destination = Path(root) / "map-cards" / (key + ".json")
        if not destination.exists():
            atomic_json(destination, card)
    return card


def local_match(store, card):
    try:
        definition = store.read(card["map_id"])
    except (OSError, ValueError, KeyError):
        return None
    if definition["revision"] == card["revision"]:
        return definition["id"]
    return None


def card_details(card):
    lines = [f'{card["embedding"]} · {card["members"]:,} members']
    if card["projection"] is not None:
        projection = card["projection"]["id"]
        lines.append(f'{projection} · {card["projected"]:,} projected')
    else:
        lines.append(card["location"])
    if card["projection"] is not None and not card["projected"]:
        lines.append(card["location"])
    if card["note"]:
        note = " ".join(card["note"].split())
        if len(note) > 160:
            note = note[:157].rstrip() + "…"
        lines.extend(("", note))
    return "\n".join(lines)


def report_details(card):
    lines = []
    overview = card.get("overview")
    if overview:
        lines.extend(("Map definition", overview["definition"], "", "Saved result inventory"))
        if not overview["modules"]:
            lines.append("No saved results")
        for module in overview["modules"]:
            support = f' · {module["anchors"]:,} measured anchors' if module["anchors"] is not None else ""
            lines.append(f'{module["name"]} · {module["result"]}{support}')
            if module["scope"]:
                lines.append(module["scope"])
        lines.append("")
    if card["findings"]:
        lines.append(f'Selected findings ({len(card["findings"])})')
    for finding in card["findings"]:
        lines.extend(("", f'{finding["target"]} · {finding["metric"]} = {finding["value"]:.6g}',
                      finding["scope"], f'Saved result {finding["result"]}'))
    return "\n".join(lines)


def export_html(card, path, charts=(), *, features=()):
    validate_card(card)
    selected = {(row["result"], row["target"], row["metric"], row["scope"])
                for row in card["findings"]}
    modules = {f'{row["name"]}/{row["result"]}' for row in card.get("overview", {}).get("modules", [])}
    related = [chart for chart in charts
               if chart["result"] in modules or selected.intersection(chart["selections"])]
    Path(path).write_text(render_report(card, related, features=features), encoding="utf-8")


def saved_evidence(store, key, *, include_overview=False, include_charts=False, include_features=False):
    """Read saved result headers only. Keep each metric tied to its saved scope."""
    definition = store.read(key)
    anchors = None
    findings = []
    modules = []
    charts = []
    features = FeatureEvidence({name: spec.get("kind") for name, spec in
                                store.catalog.raw["features"].items()}) if include_features else None
    metrics = ("balanced_accuracy", "accuracy", "macro_f1", "roc_auc", "r2",
               "mae", "rmse", "brier_skill", "mean", "median")

    def finding(target, metric, value, scope, result):
        if (isinstance(target, str) and target.strip() and isinstance(scope, str)
                and scope.strip() and type(value) in (int, float) and math.isfinite(value)):
            findings.append(dict(target=target[:512], metric=metric[:512], value=value,
                                 scope=scope[:512], result=result))

    def add_chart(target, metric, title, scope, x, y, samples, result, finding_scopes):
        if not include_charts:
            return
        ordered = {}
        for xx, yy in samples:
            if all(type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in (xx, yy)):
                ordered[xx] = yy
        points = sorted(ordered.items())
        if len(points) > 48:
            points = [points[i * (len(points) - 1) // 47] for i in range(48)]
        if len(points) >= 2:
            charts.append(dict(selections=[(result, target, metric, item) for item in finding_scopes],
                               title=title, scope=scope, target=target,
                               x=x, y=y, samples=points, result=result))

    for component in store.components(key):
        try:
            meta = json.loads((store.artifact_path(key, component) / "metadata.json").read_text())
            signature = meta.get("result_signature")
            if "--" in component:
                family, batch_signature = component.split("--", 1)
                signature = digest(dict(parent=store.signature(key, family), targets=meta["targets"]))
                if signature != batch_signature or meta["family"] != family or meta["signature"] != signature:
                    continue
            elif (meta["definition_revision"] != definition["revision"]
                  or signature != store.expected_signature(key, component, meta)):
                continue
        except (OSError, KeyError, ValueError):
            continue
        result = f'{component}/{signature}'
        if features is not None:
            features.ingest(component, result, meta.get("result", {}) if "--" in component else meta)
        if component == "reconstruction":
            curves = defaultdict(list)
            for row in meta.get("numeric", {}).get("summaries", []):
                if row.get("region") == -1 and row.get("measure") in ("broad", "local"):
                    scope = (f'Group-held-out sampled reference · {row["measure"]} account'
                             f' · dimension {row["dimension"]} · n={row["n"]}')
                    finding(row["feature"], "MAE", row["mean"], scope, result)
                    curves[(row["feature"], row["measure"])].append((row["dimension"], row["mean"], scope))
            for (target, account), rows in curves.items():
                samples = [(dimension, mean) for dimension, mean, _ in rows]
                add_chart(target, "MAE", f"{target} · {account} account",
                          "Group-held-out sampled reference. Each point is a saved MAE at that dimension; support can vary.",
                          "Retained dimensions", "Mean absolute error", samples, result,
                          [scope for _, _, scope in rows])
            fold_curves = defaultdict(list)
            for row in meta.get("classification", []):
                if row.get("broad_mean") is not None:
                    scope = (f'Group-held-out sampled reference · broad account · fold {row["fold"]}'
                             f' · dimension {row["dimension"]} · n={row["n_test"]}')
                    finding(row["feature"], row["loss"], row["broad_mean"], scope, result)
                    fold_curves[(row["feature"], row["loss"], row["fold"])].append(
                        (row["dimension"], row["broad_mean"], scope))
            for (target, loss, fold), rows in fold_curves.items():
                add_chart(target, loss, f"{target} · broad account, fold {fold}",
                          "Saved held-out classification loss within one fold. Lower loss means better predictions on that support.",
                          "Retained dimensions", loss,
                          [(dimension, mean) for dimension, mean, _ in rows], result,
                          [scope for _, _, scope in rows])
        if component == "feature_distribution":
            for target, row in meta.get("summaries", {}).items():
                scope = f'Frozen membership · n={definition["n_members"]}'
                finding(target, "known", row.get("known"), scope, result)
                finding(target, "missing", row.get("missing"), scope, result)
                known_scope = f'Known values in frozen membership · n={row["known"]}'
                finding(target, "mean", row.get("mean"), known_scope, result)
                counts = row.get("counts", {})
                if counts:
                    labels = {}
                    feature = store.catalog.raw["features"].get(target)
                    if feature and feature["revision"] == definition["feature_revisions"].get(target):
                        try:
                            labels = store.catalog.labels(target)
                        except (OSError, ValueError, KeyError):
                            pass
                    for code, value in counts.items():
                        item = labels.get(code)
                        name = item.get("name") if isinstance(item, dict) else item
                        metric = f"Count for code {code}"
                        named = isinstance(name, str) and bool(name.strip())
                        if named:
                            metric += f" · {name.strip()}"
                        scope = known_scope + " · names from the workspace codebook" if named else known_scope
                        finding(target, metric, value, scope, result)
        if component == "geometry":
            filtration = meta.get("filtration", {})
            levels = filtration.get("levels") or []
            if levels:
                sample_levels = [levels[i] for i in sorted({0, len(levels)//2, len(levels)-1})]
                scopes = []
                for sample in reversed(sample_levels):
                    sample_scope = f'{filtration.get("scope", "Saved filtration")} · radius {sample["radius"]:.5g}'
                    scopes.append(sample_scope)
                    for metric, field in (("Components", "components"), ("Largest component", "largest"),
                                          ("Candidate edges admitted", "edges")):
                        finding("Mutual neighbor graph", metric, sample.get(field), sample_scope, result)
                for metric, field, title in (
                    ("Components", "components", "How the graph connects"),
                    ("Largest component", "largest", "How much can the largest region reach?"),
                    ("Candidate edges admitted", "edges", "How quickly do connections appear?"),
                ):
                    add_chart("Mutual neighbor graph", metric, title,
                              filtration.get("scope", "Saved mutual-neighbor filtration"),
                              "Filtration radius", metric,
                              [(row["radius"], row[field]) for row in levels if field in row], result, scopes)
        if include_charts:
            charts.extend(saved_charts(store.artifact_path(key, component), component, meta, result))
        if component == "source_support":
            sample = meta.get("measurements", {})
            rank = sample.get("rank", {})
            finding("Source coordinates", "Valid sampled rows", sample.get("valid"), sample.get("scope"), result)
            finding("Source coordinates", rank.get("statistic", "Participation ratio"),
                    rank.get("value"), sample.get("scope"), result)
        support = meta.get("support", {})
        support_scope = support.get("scope") or meta.get("scope") or "Saved result support"
        for field, metric in (("valid_anchors", "Measured anchors"), ("context_rows", "Context rows"),
                              ("embedding_available", "Members with embeddings"),
                              ("finite_display_anchors", "Anchors with display coordinates")):
            finding("Measurement support", metric, support.get(field), support_scope, result)
        count = support.get("valid_anchors")
        if type(count) is int and count >= 0:
            anchors = max(anchors or 0, count)
        scope = meta.get("scope") or meta.get("protocol") or meta.get("graph_scope") or ""
        if not scope:
            from .instruments import REGISTRY
            instrument = REGISTRY.get(component.split("--", 1)[0])
            scope = instrument.question if instrument is not None else ""
        if len(modules) < MAX_MODULES:
            modules.append(dict(name=component[:128], result=signature,
                                scope=scope[:512] if isinstance(scope, str) else "",
                                anchors=count if type(count) is int and count >= 0 else None))
        for field in ("records", "summaries", "metrics"):
            records = meta.get(field, [])
            if not isinstance(records, list):
                continue
            for row in records:
                if not isinstance(row, dict):
                    continue
                target = row.get("feature") or row.get("target") or row.get("name")
                if component == "discrepancy" and row.get("status") == "held_out":
                    target = "Held-out pair distances"
                scope = row.get("scope") or meta.get("scope")
                if not isinstance(target, str) or not isinstance(scope, str):
                    continue
                context = [str(row[name]) for name in ("account", "dimension", "fold") if row.get(name) is not None]
                if context:
                    scope = scope + " · " + " / ".join(context)
                for metric in metrics:
                    value = row.get(metric)
                    finding(target, metric, value, scope, result)
    if not include_overview:
        return anchors, findings
    settings = definition["settings"]
    targets = ", ".join(settings.get("features", [])) or "none"
    dimensions = ", ".join(map(str, settings.get("dimensions", [])))
    definition_summary = (f'Collection {definition["collection"]} · revision {definition["revision"]}\n'
                          f'Context {settings.get("context")} · neighbors {settings.get("k")} · '
                          f'dimensions {dimensions}\n'
                          f'Coordinates {settings.get("projection") or "Scoped PCA-2"}\n'
                          f'Configured targets {targets}')
    overview = dict(definition=definition_summary[:2048], modules=modules)
    if include_features:
        return anchors, findings, overview, charts, features.payload()
    if include_charts:
        return anchors, findings, overview, charts
    return anchors, findings, overview
