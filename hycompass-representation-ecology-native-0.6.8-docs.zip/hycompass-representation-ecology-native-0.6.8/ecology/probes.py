"""Standard held-out ML metrics from frozen fold models; no refitting or test selection."""
import numpy as np
from sklearn.metrics import roc_auc_score
from .kernels.accessibility import fold_ids,labels,unit


def metric_summary(truth,prediction,baseline,kind):
    y=np.asarray(truth);p=np.asarray(prediction);b=np.asarray(baseline)
    good=np.isfinite(y)&np.isfinite(p) if p.ndim==1 else np.isfinite(y)&np.isfinite(p).all(1)
    good&=np.isfinite(b) if b.ndim==1 else np.isfinite(b).all(1)
    y=y[good];p=p[good];b=b[good];result=dict(n=len(y))
    if not len(y):return result
    if kind=='numeric':
        residual=y-p;mae=float(np.abs(residual).mean());base=float(np.abs(y-b).mean());variance=float(np.sum((y-y.mean())**2))
        result.update(mae=mae,rmse=float(np.sqrt(np.mean(residual**2))),r2=float(1-np.sum(residual**2)/variance) if len(y)>1 and variance>1e-15 else None,baseline_mae=base,mae_gain=base-mae)
    else:
        prob=np.c_[1-p,p] if kind=='boolean' else p;bp=np.c_[1-b,b] if kind=='boolean' else b
        classes=prob.shape[1];yi=y.astype(int);hard=(p>=.5).astype(int) if kind=='boolean' else np.argmax(prob,1);prior_hard=np.argmax(bp,1)
        recalls=[np.mean(hard[yi==c]==c) for c in np.unique(yi)];f1=[]
        for c in np.unique(yi):
            tp=np.sum((yi==c)&(hard==c));fp=np.sum((yi!=c)&(hard==c));fn=np.sum((yi==c)&(hard!=c));f1.append(2*tp/max(1,2*tp+fp+fn))
        observed=np.eye(classes)[yi];brier=float(np.mean((yi-p)**2)) if kind=='boolean' else float(np.mean(np.sum((observed-p)**2,1)));bb=float(np.mean((yi-b)**2)) if kind=='boolean' else float(np.mean(np.sum((observed-b)**2,1)))
        safe=np.clip(prob,1e-12,1);safe/=safe.sum(1,keepdims=True)
        auc=None
        if kind=='boolean' and len(np.unique(yi))==2:auc=float(roc_auc_score(yi,p))
        elif kind=='category' and len(np.unique(yi))==classes and classes>2:auc=float(roc_auc_score(yi,prob,average='macro',multi_class='ovr'))
        elif kind=='category' and classes==2 and len(np.unique(yi))==2:auc=float(roc_auc_score(yi,prob[:,1]))
        confusion=np.zeros((classes,classes),np.int64);np.add.at(confusion,(yi,hard),1)
        per_class=[]
        for code in range(classes):
            tp=int(confusion[code,code]);support=int(confusion[code].sum());predicted=int(confusion[:,code].sum())
            per_class.append(dict(code=code,support=support,precision=tp/predicted if predicted else None,recall=tp/support if support else None,f1=2*tp/(support+predicted) if support+predicted else None))
        result.update(confusion=confusion.tolist(),per_class=per_class,label_policy='Aggregate macro F1 over observed test labels; per-class table over all declared score columns')
        result.update(accuracy=float(np.mean(hard==yi)),balanced_accuracy=float(np.mean(recalls)),macro_f1=float(np.mean(f1)),roc_auc=auc,log_loss=float(-np.log(safe[np.arange(len(yi)),yi]).mean()),brier=brier,baseline_brier=bb,brier_skill=1-brier/bb if bb>1e-15 else None,baseline_accuracy=float(np.mean(prior_hard==yi)),observed_classes=len(np.unique(yi)))
    return result


def probe_metrics(ctx,store,key,token,progress):
    _,metadata=store.artifact(key,'reconstruction');d=ctx['definition'];c=store.catalog;rows=ctx['anchors'];x=unit(ctx['x'][:ctx['n']]);n=len(rows);fold=fold_ids(c.group_values(d['collection'],rows),ctx['cfg']['folds']);numeric=metadata['numeric'];centers=np.asarray(numeric['router']['centers']);region=labels(x,centers);transforms={r['fold']:r for r in numeric['transforms']};outputs={};records=[]
    targets={}
    from .navigation import target_snapshot,protocol_snapshot,context_snapshot
    for name in ctx['cfg']['features']:
        token.check();truth,known=c.feature(name,rows);kind=c.raw['features'][name]['kind'];classes=c.raw['features'][name].get('cardinality') or 1
        targets[name]={**target_snapshot(c,name),'known_result_anchors':int(known.sum()),'result_anchors':n}
        outputs[name+'__observed']=np.where(known,truth,np.nan).astype(np.float64)
        outputs[name+'__known']=known.astype(bool)
        for q in numeric['dimensions']:
            shape=(n,classes) if kind=='category' else (n,);broad=np.full(shape,np.nan);local=np.full(shape,np.nan);base=np.full(shape,np.nan)
            accounts=[a for a in numeric['accounts'] if a['feature']==name and a['dimension']==q] if kind=='numeric' else [a for a in metadata['classification_accounts'] if a['feature']==name and a['dimension']==q]
            for a in accounts:
                token.check();ix=np.flatnonzero((fold==a['fold'])&known)
                if not len(ix):continue
                t=transforms.get(a['fold']) if kind=='numeric' else a
                if t is None:continue
                z=(x[ix]-np.asarray(t['mean']))@np.asarray(t['components']).T;z=z[:,:q]
                def predict(model):
                    coef=np.asarray(model.get('coefficients',model.get('coef')));p=z@coef.T+np.asarray(model['intercept'])
                    if kind=='numeric':return p
                    p=np.clip(p,0,1)
                    if kind=='boolean':return p.reshape(-1)
                    total=p.sum(1,keepdims=True);return np.divide(p,total,out=np.broadcast_to(np.asarray(a['prior']),p.shape).copy(),where=total>1e-12)
                broad[ix]=predict(a['broad']);base[ix]=a['baseline'] if kind=='numeric' else np.asarray(a['prior']) if kind=='category' else float(a['prior'][0])
                for r,model in a['local'].items():
                    mask=region[ix]==int(r)
                    if mask.any():local[ix[mask]]=predict(model)[mask]
            for account,pred in [('broad',broad),('local',local)]:
                outputs[f'{name}__q{q}__{account}__prediction']=pred.astype(np.float32)
                prefix=f'{name}__q{q}__{account}__'
                finite=known & (np.isfinite(pred) if pred.ndim==1 else np.isfinite(pred).all(1))
                if kind=='numeric':
                    residual=truth-pred;loss=np.abs(residual);baseline_loss=np.abs(truth-base)
                    outputs[prefix+'signed_residual']=np.where(finite,residual,np.nan).astype(np.float32)
                    outputs[prefix+'squared_error']=np.where(finite,residual**2,np.nan).astype(np.float32)
                elif kind=='boolean':
                    loss=(truth-pred)**2;baseline_loss=(truth-base)**2
                    outputs[prefix+'predicted_class']=np.where(finite,pred>=.5,np.nan).astype(np.float32)
                    outputs[prefix+'correct']=np.where(finite,(pred>=.5)==truth,np.nan).astype(np.float32)
                else:
                    observed=np.eye(classes)[np.where(known,truth,0).astype(int)];loss=np.sum((observed-pred)**2,1);baseline_loss=np.sum((observed-base)**2,1)
                    outputs[prefix+'predicted_class']=np.where(finite,np.argmax(pred,1),np.nan).astype(np.float32)
                    outputs[prefix+'correct']=np.where(finite,np.argmax(pred,1)==truth,np.nan).astype(np.float32)
                outputs[prefix+'loss']=np.where(finite,loss,np.nan).astype(np.float32)
                outputs[prefix+'baseline_loss']=np.where(finite,baseline_loss,np.nan).astype(np.float32)
                outputs[prefix+'baseline_gain']=np.where(finite,baseline_loss-loss,np.nan).astype(np.float32)
                metrics=metric_summary(np.where(known,truth,np.nan),pred,base,kind)
                records.append(dict(feature=name,kind=kind,account=account,dimension=q,scope='Each model evaluated on its finite held-out anchor support',**metrics))
            matched=np.isfinite(broad)&np.isfinite(local) if broad.ndim==1 else np.isfinite(broad).all(1)&np.isfinite(local).all(1)
            for account,pred in [('broad',broad),('local',local)]:
                records.append(dict(feature=name,kind=kind,account=account,dimension=q,scope='Matched broad/local held-out support',**metric_summary(np.where(known&matched,truth,np.nan),pred,base,kind)))
            outputs[f'{name}__q{q}__baseline__prediction']=base.astype(np.float32)
        progress('Held-out metrics: '+name,1)
    return outputs,dict(map_context=context_snapshot(store,key),targets=targets,evaluation=protocol_snapshot(store,key),domain_revision=d['domain_revision'],collection_revision=d['collection_revision'],support=ctx['support'],metrics=records,
        protocol='Replay frozen outer-fold PCA/decoders using the original item group assignments. No refitting; no metric-based test-set account choice. Numeric MAE/RMSE/R²; classification accuracy, balanced accuracy, observed-class macro F1, AUC when defined, clipped log loss and original Brier convention.',
        units='Per-target units for regression errors; named standard ML metrics for classification. Category Brier is sum of squared class-probability errors. Missing/unsupported metrics are unavailable.',
        scope='Evaluation anchors, not full-cohort model performance. Broad/local comparisons use the explicitly matched support rows.')
