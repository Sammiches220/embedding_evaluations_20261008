"""Explicit bounded sample audit; never a claim about full-corpus vector quality."""
import numpy as np

MAX_ROWS=8192
MAX_DIMENSIONS=512

def sample_measurements(vectors,token):
    x=np.asarray(vectors)
    if len(x)>MAX_ROWS or x.shape[1]>MAX_DIMENSIONS:raise ValueError('Scoped audit refused: limit 8192 rows × 512 dimensions. Reduce context cap; full-corpus audits are not supported.')
    token.check();finite=np.isfinite(x).all(1);norm=np.zeros(len(x));norm[finite]=np.linalg.norm(x[finite].astype(float),axis=1);near=finite&(norm<=1e-8)
    good=x[finite&~near];token.check()
    def duplicates(a):
        # np.unique verifies exact values; no hashes, approximate merging or corpus dictionary.
        _,counts=np.unique(a,axis=0,return_counts=True);groups=counts[counts>1]
        return dict(repeated_rows=int(np.sum(groups-1)),groups=len(groups),largest_group=int(groups.max()) if len(groups) else 0),np.sort(groups)[::-1]
    raw,raw_sizes=duplicates(good);unit=good.astype(float)/np.linalg.norm(good.astype(float),axis=1,keepdims=True) if len(good) else good.astype(float)
    normalized,unit_sizes=duplicates(unit);token.check()
    centered=unit-unit.mean(0) if len(unit) else unit
    singular=np.linalg.svd(centered,compute_uv=False);token.check();energy=singular**2
    rank=float(energy.sum()**2/np.sum(energy**2)) if np.sum(energy**2)>1e-24 else None
    counts,edges=np.histogram(norm[finite],bins=32) if finite.any() else (np.zeros(32,dtype=int),np.linspace(0,1,33))
    return dict(plots=dict(norm_counts=counts,norm_edges=edges,rank_variance=energy,source_duplicate_sizes=raw_sizes,unit_duplicate_sizes=unit_sizes),rows=len(x),non_finite=int((~finite).sum()),finite_near_zero=int(near.sum()),valid=len(good),threshold=1e-8,norm='L2 on source float coordinates; <= threshold',exact_source=raw,exact_unit_normalized=normalized,equality='exact coordinate equality on finite nonzero sampled rows; signed zeros equal; not near-duplicate similarity',rank=dict(statistic='covariance participation ratio',value=rank,centered=True,normalization='individual unit L2',support=len(good)),scope='sample-only resolved context; cannot establish or rule out corpus-wide properties')

def source_support(ctx,store,key,token,progress):
    c=store.catalog;d=ctx['definition'];rows=ctx['rows'];vectors=c.load(c.manifest.domains[d['domain']].embeddings)
    # Validity exclusions were measured before normalization during resolution.
    if len(rows)>MAX_ROWS or vectors.shape[1]>MAX_DIMENSIONS:raise ValueError('Scoped audit budget refusal: maximum 8192 resolved rows and 512 dimensions; no full-corpus engine.')
    _,inverse=c.correspondence_maps(d['domain']);x=np.empty((len(rows),vectors.shape[1]),vectors.dtype)
    for start in range(0,len(rows),256):
        token.check();x[start:start+256]=vectors[inverse[rows[start:start+256]]];progress('Source/support sample scan',start/max(1,len(rows)))
    progress('Audit: exact duplicate groups and covariance spectrum',.45);measured=sample_measurements(x,token);progress('Audit: saved neighbor occurrences',.9);a,m=store.artifact(key,'neighbors');counts=np.bincount(np.asarray(a['neighbors']).ravel(),minlength=len(a['context_rows']))
    total=counts.sum();p=counts/total if total else counts
    occurrence=dict(candidate_count=len(counts),query_count=len(a['anchor_rows']),median=float(np.median(counts)),p95=float(np.quantile(counts,.95)),max=int(counts.max()) if len(counts) else 0,herfindahl=float(np.sum(p*p)),zero_occurrences=int((counts==0).sum()),scope='saved anchor-to-context search; includes zero-occurrence candidates; not corpus-wide hubness')
    plots=measured.pop('plots')
    return dict(occurrences=counts,**plots),dict(measurements=measured,neighbor_occurrences=occurrence,support=ctx['support'],source_revision=d['domain_revision'],scope=measured['scope'])
