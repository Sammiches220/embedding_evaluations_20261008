"""Fresh portable 360-item synthetic workspace; no large demonstration."""
from pathlib import Path
import json
import numpy as np
from scipy.ndimage import gaussian_filter
from model.workspace.assets import DomainSpec,ProjectionSpec,SelectionSpec,ClusteringSpec,DensitySpec,ViewSpec
from model.workspace.manifest import WorkspaceManifest
from .catalog import Catalog,atomic_json
from .store import Store
from .instruments import generate


def demo(root,n=360,generate_results=True):
    root=Path(root).resolve()
    if (root/'workspace.json').exists():raise ValueError('Demo target already contains a workspace')
    root.mkdir(parents=True,exist_ok=True);(root/'assets').mkdir(exist_ok=True)
    rng=np.random.default_rng(42);u=rng.uniform(-2,2,n);v=rng.uniform(-2,2,n);group=np.arange(n)//3
    latent=np.c_[u,v,u*v,np.sin(u*2),np.cos(v*2),np.ones(n)*2]
    x=np.c_[latent,rng.normal(0,.06,(n,6))].astype(np.float32)
    q,_=np.linalg.qr(rng.normal(size=(12,12)));xb=x@q
    # Controlled distortion plus 20% missing identity coverage and shuffled order.
    xb[:,0]+=rng.normal(0,.3,n);second=rng.permutation(n)[:int(n*.8)]
    np.save(root/'assets/ids.npy',np.arange(10000,10000+n,dtype=np.int64));np.save(root/'assets/groups.npy',group)
    manifest=WorkspaceManifest.empty(root)
    for name,vector,order in [('base',x,np.arange(n)),('distorted',xb,second)]:
        positions=np.c_[u,v].astype(np.float32)
        if name=='distorted':positions=np.c_[-v,u].astype(np.float32)
        positions=positions[order];positions[0]=np.nan # valid vector without display coordinates
        data={'vectors':vector[order].astype(np.float32),'ids':np.arange(10000,10000+n,dtype=np.int64)[order],
              'positions':positions,'clusters':(u[order]>0).astype(np.int32),'selection':(v[order]>-.5).astype(np.uint8)}
        for k,a in data.items():np.save(root/f'assets/{name}-{k}.npy',a)
        finite=np.flatnonzero(np.isfinite(positions).all(1));sort=finite[np.argsort(positions[finite,0])]
        np.save(root/f'assets/{name}-order.npy',sort.astype(np.uint32));np.save(root/f'assets/{name}-sorted.npy',positions[sort,0])
        counts,_,_=np.histogram2d(positions[finite,1],positions[finite,0],bins=64,range=[[-2,2],[-2,2]])
        density=gaussian_filter(counts,2);density/=max(1e-12,density.max());np.save(root/f'assets/{name}-density.npy',density.astype(np.float32))
        manifest.domains[name]=DomainSpec(name,1,f'assets/{name}-vectors.npy',f'assets/{name}-ids.npy',len(order),12)
        manifest.projections[name]=ProjectionSpec(name,name,f'assets/{name}-positions.npy',1,f'assets/{name}-order.npy',f'assets/{name}-sorted.npy',world_bounds=(-2,2,-2,2),method='synthetic latent coordinates; rotated in second embedding')
        manifest.clusterings[name]=ClusteringSpec(name,name,f'assets/{name}-clusters.npy',1,method='synthetic u>0; not evidence of semantic meaning')
        manifest.densities[name]=DensitySpec(name,name,f'assets/{name}-density.npy',method='small synthetic histogram')
        manifest.selections[name+'-upper']=SelectionSpec(name+'-upper',name,1,'mask',f'assets/{name}-selection.npy')
        manifest.views.append(ViewSpec('population-'+name,'Population: '+name,name,name,clustering=name,densities=[name]))
    manifest.save();c=Catalog(root);c.register_collection('items','assets/ids.npy','assets/groups.npy')
    c.register_domain('base','items');c.register_domain('distorted','items')
    features=dict(broad=(u+.05*rng.normal(size=n),'numeric'),contextual=(np.where(v>0,2*u,-2*u)+.05*rng.normal(size=n),'numeric'),noise=(rng.normal(size=n),'numeric'),flag=((u>0).astype(np.uint8),'boolean'),category=(np.digitize(v,[-.6,.6]).astype(np.int16),'category'))
    for name,(a,kind) in features.items():
        valid=np.ones(n,np.uint8);valid[::29]=0
        np.save(root/f'assets/{name}.npy',a.astype(np.float32) if kind=='numeric' else a);np.save(root/f'assets/{name}-valid.npy',valid)
        labels=None
        if kind=='category':
            labels='assets/category-labels.json';atomic_json(root/labels,dict(asset_id=name,labels={'0':dict(name='Lower band',color='#4477aa'),'1':dict(name='Middle band',color='#ddaa33'),'2':dict(name='Upper band',color='#aa4477')}))
        c.register_feature(name,'items',kind,f'assets/{name}.npy',f'assets/{name}-valid.npy',labels,3 if kind=='category' else None)
    store=Store(root);shared=np.sort(second);cfg=dict(anchors=144,context_cap=288,k=12,features=list(features),projection='base',context='selection',max_work=1_000_000_000,instruments=['geometry','reconstruction'])
    store.create('Same items / base','base',shared,{**cfg,'instruments':['geometry','reconstruction','discrepancy','stability','routes','compression','feature_audit','directions','probe_metrics','neighborhood_agreement','feature_distribution','source_support']},key='shared-base')
    store.create('Same items / distorted','distorted',shared,{**cfg,'projection':'distorted'},key='shared-distorted')
    store.create('Upper selection / base','base',np.flatnonzero(v>-.5),{**cfg,'context':'reference'},key='upper-base')
    store.create('Boundary within selection','base',np.flatnonzero(v>-.5),{**cfg,'context':'selection'},key='upper-within')
    np.save(root/'assets/overlapping-selection.npy',np.flatnonzero(u>-.5))
    if generate_results:
        for key in ['shared-base','shared-distorted','upper-base','upper-within']:
            generate(store,key,store.read(key)['settings']['instruments'])
        d=store.create('Upper selection / frozen shared reference','base',store.membership('upper-base'),{**cfg,'context':'reference','reference_map':'shared-base','instruments':['geometry','reference_evaluation']},key='upper-reference')
        generate(store,d['id'],d['settings']['instruments'])
    return root
