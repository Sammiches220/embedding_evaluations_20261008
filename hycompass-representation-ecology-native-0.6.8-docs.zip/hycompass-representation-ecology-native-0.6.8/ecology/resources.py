"""Visible-screen requirements and explicit multi-result viewer actions."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QSizePolicy
from .instruments import REGISTRY,dependency_order,plan

TARGETS={'reconstruction','reference_evaluation','feature_audit','probe_metrics','discrepancy','neighborhood_agreement','feature_distribution'}


def screen_requirements(tab,subtab=0,*,reference=False,lens='geometry',values_family=0):
    reconstruction='reference_evaluation' if reference else 'reconstruction'
    screens={
        0:('Here → ahead',['geometry','directions']),
        1:('Geometry in context',['geometry','stability','routes','compression']),
        2:('Shapes & spectra',['geometry','directions']),
        3:('Feature audit',['geometry','feature_audit']),
        4:('What survives scale?',['geometry',reconstruction]),
        5:('Values & deltas',['geometry']),
        6:('Kept selection',['geometry']),
    }
    title,names=screens.get(tab,screens[0]);names=list(names)
    if tab==3:
        if subtab==0:names.append(reconstruction)
        if subtab in (3,4):title='Held-out probe metrics';names=['geometry','probe_metrics']
    if tab==5:
        names += {0:['stability'],1:[],2:[reconstruction,'probe_metrics'],3:['compression'],4:['routes'],5:['stability','compression','routes','discrepancy',reconstruction,'probe_metrics']}.get(values_family,[])
    if lens=='gap':names.append('discrepancy')
    if lens=='prediction':names.append('probe_metrics')
    return title,list(dict.fromkeys(names))


class ResourceControls:
    def setup_resource_controls(self,layout):
        self._checked_resources={'geometry'};self._pending_load_names=None
        self.resource_bar=QWidget();bar=QHBoxLayout(self.resource_bar);bar.setContentsMargins(0,0,0,0);bar.setSpacing(4)
        self.resource_bar.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Fixed)
        self.screen_prepare=QPushButton('Prepare');self.screen_prepare.clicked.connect(self.prepare_screen)
        self.screen_load=QPushButton('Load saved');self.screen_load.clicked.connect(self.load_screen)
        self.screen_choose=QPushButton('Select');self.screen_choose.clicked.connect(self.select_screen)
        for button in (self.screen_prepare,self.screen_load,self.screen_choose):
            button.setFixedHeight(23);button.setSizePolicy(QSizePolicy.Policy.Fixed,QSizePolicy.Policy.Fixed)
            button.setStyleSheet('QPushButton { padding: 1px 5px; font-size: 9pt; }');bar.addWidget(button)
        self.screen_choose.setToolTip('Check this screen’s required resources in Compute / storage.')
        self.screen_load.setToolTip('Load available saved results for this screen without computing.')
        self.resource_title=QLabel();self.resource_title.setWordWrap(False);self.resource_title.setMinimumWidth(0)
        self.resource_title.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Fixed);bar.addWidget(self.resource_title,1)
        layout.addWidget(self.resource_bar,1)
    def checked_names(self):return [name for name in dict.fromkeys([*REGISTRY,*getattr(self,'navigation_index',{})]) if name in self._checked_resources]
    def can_select(self,name):
        saved=(self.store.artifact_path(self.key,name)/'metadata.json').exists()
        if saved:return True
        cfg=self.definition['settings']
        return not (name=='reference_evaluation' and not cfg.get('reference_map') or name in TARGETS and not cfg['features'])
    def set_checked(self,names):
        self._checked_resources={n for n in names if self.can_select(n)};self._last_status=None;self.refresh_status();self.inspect_plan()
        if hasattr(self,'sync_batch_resources'):self.sync_batch_resources()
    def check_all(self):self.set_checked(REGISTRY)
    def check_none(self):self.set_checked([])
    def check_preset(self):self.set_checked(self.definition['settings'].get('instruments',['geometry']))
    def resource_item_changed(self,item):
        if item.column()!=0:return
        name=item.data(Qt.ItemDataRole.UserRole)
        if not name:return
        if item.checkState()==Qt.CheckState.Checked:self._checked_resources.add(name)
        else:self._checked_resources.discard(name)
        self.inspect_plan()
    def current_requirements(self):
        title,names=screen_requirements(self.evidence.currentIndex(),self.evidence.audit_tabs.currentIndex(),reference=bool(self.definition['settings'].get('reference_map')),lens=self._lens,values_family=self.evidence.values_family.currentIndex())
        if self._lens=='prediction':
            component=self.result_module.currentData() or 'probe_metrics';names=['geometry',component]
            other=self.compare_variant.currentData()
            if other:names.append(other['component'])
            title='Saved prediction'
            if hasattr(self,'prediction_subtabs') and self.evidence.currentWidget()==self.prediction_panel:
                tab=self.prediction_subtabs.currentWidget()
                if tab==self.audit_tab:title,names='Source audits',['geometry','source_support']
                elif tab==self.population_tab:title,names='Full membership',['geometry','feature_distribution']
                elif tab in (self.targets_tab,self.availability_tab):title,names='Across checked targets',['geometry','probe_metrics']
                elif tab==self.batch_tab:title,names='Checked resource families',self.checked_names()
        return title,list(dict.fromkeys(names))
    def select_screen(self):
        _,names=self.current_requirements();self.set_checked(names);self.sidebar.setCurrentIndex(1)
    def update_resource_context(self,*_):
        if not hasattr(self,'screen_prepare') or not hasattr(self,'evidence'):return
        from .evidence import TITLES
        title,names=self.current_requirements();saved=[];missing=[];unloaded=[];invalid=[]
        for name in names:
            exists=(self.store.artifact_path(self.key,name)/'metadata.json').exists()
            if exists:
                saved.append(name)
                if name not in self.loaded:unloaded.append(name)
                elif self._lens=='prediction' and name==self.result_module.currentData():
                    result=getattr(self,'resolved_measurement',None)
                    if result is not None and result.reason and 'Required saved' in result.reason:unloaded.append(name)
            else:missing.append(name)
            if name in getattr(self,'load_errors',{}):invalid.append(name)
        busy=self.jobs.busy(self.key)
        blocked=any(n in TARGETS for n in names) and not self.definition['settings']['features']
        self.resource_title.setText('Working…' if busy else 'Ready' if not missing and not unloaded and not invalid else f'{len(missing)} compute · {len(unloaded)} load'+(f' · {len(invalid)} unavailable' if invalid else ''))
        label=lambda ns:', '.join(TITLES.get(n,n.replace('_',' ')) for n in ns)
        parts=['Needed here: '+label(names)+'.']
        if missing:parts.append('Compute: '+label(missing)+'.')
        if unloaded:parts.append('Already saved: '+label(unloaded)+'.')
        if invalid:parts.append('Unavailable/stale: '+label(invalid)+'. Check dependencies before regenerating.')
        if blocked:parts.append('This screen needs targets. Create a map with selected typed features.')
        parts.append('Prerequisites are included automatically. Switching tabs does not start computation.')
        self.resource_title.setToolTip(title+'\n'+' '.join(parts));self.screen_prepare.setEnabled(not busy and not blocked and (not invalid or not missing))
        self.screen_prepare.setText('Retry' if invalid and not missing else 'Load' if not missing else 'Prepare')
        self.screen_load.setEnabled(not busy and bool(saved))
        outcome=getattr(self,'_bulk_outcome',None)
        if outcome and outcome.get('failed'):
            self.resource_title.setText(self.resource_title.text()+f" · {len(outcome['failed'])} batch failures");self.resource_title.setToolTip(self.resource_title.toolTip()+'\nBatch feedback: '+'; '.join(f'{n}: {e}' for n,e in outcome['failed'].items()))
        if getattr(self,'_resource_action_error',None):
            self.resource_title.setText('Error · see tooltip');self.resource_title.setToolTip(self._resource_action_error+'\n'+title+'\n'+' '.join(parts))
        self.screen_prepare.setToolTip('Compute missing results and load this screen; validate and reuse existing saved results.\n'+' '.join(parts))
    def load_evidence_components(self,index):self.update_resource_context()
    def prepare_screen(self):
        if hasattr(self,'prediction_subtabs') and self.evidence.currentWidget()==self.prediction_panel and self.prediction_subtabs.currentWidget()==self.batch_tab:self.prepare_bulk_checked()
        else:self.prepare_names(self.current_requirements()[1])
    def load_screen(self):self.load_names(self.current_requirements()[1])
    def prepare_checked(self):self.prepare_names(self.checked_names())
    def load_checked(self):self.load_names(self.checked_names())
    def prepare_names(self,names):
        self._resource_action_error=None
        names=list(dict.fromkeys(names))
        if not names:self.notice('Check at least one resource first.');return
        try:
            builtin=[n for n in names if n in REGISTRY]
            unknown=[n for n in names if n not in REGISTRY and not (self.store.artifact_path(self.key,n)/'metadata.json').exists()]
            if unknown:raise ValueError('No generator for external result: '+', '.join(unknown))
            missing=[n for n in dependency_order(builtin) if not (self.store.artifact_path(self.key,n)/'metadata.json').exists()]
            if not missing:self.load_names(names);return
            estimate=plan(self.store,self.key,builtin)
            if estimate['over_budget']:raise ValueError('These resources exceed this map’s computation budget. Inspect the estimate or revise the map settings.')
            self._pending_load_names=list(dict.fromkeys(list(self.loaded)+names+['geometry']))
            self.generation_future=self.jobs.submit(self.key,builtin)
            self.notice('Queued required analyses and prerequisites. Completed results will load for the requested screen/resources.');self.refresh_status()
        except Exception as exc:self._pending_load_names=None;self.error(exc)
    def load_names(self,names):
        self._resource_action_error=None
        if not names:self.notice('Check at least one resource first.');return
        saved=[n for n in names if (self.store.artifact_path(self.key,n)/'metadata.json').exists()]
        missing=[n for n in names if n not in saved]
        if saved:self.reload(list(dict.fromkeys(list(self.loaded)+saved)))
        if missing:self.notice('Loaded available saved resources. Not computed yet: '+', '.join(missing)+'. Use Compute checked + load or the screen button.')
        elif not saved:self.notice('No saved resources selected.')
        if saved and hasattr(self,'bulk_feedback'):
            notes=' '.join(getattr(self,'residency_notes',[]));self.bulk_feedback.setText(f'Loaded {len(self.loaded)} resource families; {self.cache.nbytes/1024**2:.1f} MiB resident. '+notes)
        self.update_resource_context()
    def unload_checked(self):
        names=set(self.checked_names());remaining=[n for n in self.loaded if n not in names]
        if not names:self.notice('Check the resources you want to unload.');return
        if remaining:self.reload(remaining)
        else:self.unload()
        if 'geometry' in names and remaining:self.notice('Selected results unloaded. Geometry is retained as the display scaffold for other loaded results.')
        self.update_resource_context()

    def complexity_text(self,estimate):
        data=estimate['complexity'];names=data['requested_components'];lines=[]
        for name in names[:2]:
            row=data['components'][name];lines.append(name.replace('_',' ')+': time '+row['time']+'; peak RAM '+row['peak_space'])
        if len(names)>2:lines.append(f'+ {len(names)-2} more selected resources; full dependency bounds in Detailed cost estimate.')
        lines.append('A anchors · R context · D dimensions · k neighbors · T targets · C channels. Full symbol key and disk bounds: Detailed cost estimate.')
        return '\n'.join(lines)
