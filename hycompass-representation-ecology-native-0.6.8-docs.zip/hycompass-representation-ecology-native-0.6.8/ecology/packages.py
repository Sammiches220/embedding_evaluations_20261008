"""Versioned, streamed, checksum-verified map packages. No schema conversion."""
from pathlib import Path, PurePosixPath
import json
import os
import shutil
import tempfile
import zipfile
import numpy as np
from .catalog import atomic_json, checksum, clean
from .store import Store
from .locking import workspace_writer

PROFILES=('definition','viewing','embeddings','targets','full')
FORMAT='hycompass-map'
VERSION=1

def export_package(store,key,destination,profile='viewing'):
    if profile not in PROFILES:raise ValueError('Unknown package profile')
    destination=Path(destination).resolve()
    with workspace_writer(store.catalog.root):
        c=store.catalog;definitions={}
        def visit(k):
            if k in definitions:return
            definitions[k]=store.read(k)
            ref=definitions[k]['settings'].get('reference_map')
            if ref:visit(ref)
        visit(key)
        domains={d['domain'] for d in definitions.values()};collections={d['collection'] for d in definitions.values()}
        features={f for d in definitions.values() for f in d['settings']['features']};projections={d['settings']['projection'] for d in definitions.values()}-{None}
        raw=c.manifest.raw
        workspace=dict(format_version=c.manifest.FORMAT_VERSION,domains={k:raw['domains'][k] for k in domains},projections={k:raw['projections'][k] for k in projections})
        catalog=dict(version=2,collections={k:c.raw['collections'][k] for k in collections},domains={k:c.raw['domains'][k] for k in domains},features={k:c.raw['features'][k] for k in features})
        sources={};included=set()
        def source(path,include):
            if not path:return
            logical='assets/'+__import__('hashlib').sha256(path.encode()).hexdigest()[:20]+'-'+Path(path).name
            sources[path]=logical
            if include and c.resolve(path).exists():included.add(path)
        for k in collections:
            spec=catalog['collections'][k];source(spec['item_ids'],True);source(spec.get('groups'),profile in ('embeddings','targets','full'))
        for k in domains:
            spec=workspace['domains'][k];source(spec['item_ids'],True);source(spec['embeddings'],profile in ('embeddings','full'))
            source(catalog['domains'][k]['forward'],True);source(catalog['domains'][k]['reverse'],True)
        for k in projections:
            for field in ('positions','x_order','x_sorted'):
                source(workspace['projections'][k].get(field),profile in ('embeddings','full'))
            # Optional population assets are outside selected map closure.
            workspace['projections'][k]['selection']=None
        for k in features:
            for field in ('values','valid','labels'):source(catalog['features'][k].get(field),profile in ('targets','full'))
        def rewrite(value):
            if isinstance(value,str):return sources.get(value,value)
            if isinstance(value,list):return [rewrite(v) for v in value]
            if isinstance(value,dict):return {sources.get(k,k):rewrite(v) for k,v in value.items()}
            return value
        entries={};payloads={}
        def add(logical,path=None,data=None):
            if path is not None:
                h=checksum(path);size=Path(path).stat().st_size;payloads.setdefault(h,('file',Path(path)))
            else:
                data=(json.dumps(clean(data),indent=2,allow_nan=False)+'\n').encode();h=__import__('hashlib').sha256(data).hexdigest();size=len(data);payloads.setdefault(h,('bytes',data))
            entries[logical]=dict(blob='payload/'+h,sha256=h,bytes=size)
        add('workspace.json',data=rewrite(workspace));add('ecology.json',data=rewrite(catalog))
        for original in sorted(included):add(sources[original],c.resolve(original))
        from .instruments import REGISTRY
        for k,d in definitions.items():
            folder=store.folder(k)
            for name in ('definition.json','map.json','membership.npy','navigation.json','kept_selection.npy'):
                if (folder/name).exists():add('maps/'+k+'/'+name,folder/name)
            statuses={}
            if profile in ('viewing','full'):
                for instrument in store.components(k):
                    if '--' in instrument:continue
                    mp=store.artifact_path(k,instrument)/'metadata.json'
                    if not mp.exists():continue
                    arrays,meta=store.artifact(k,instrument)
                    add('maps/'+k+'/'+instrument+'/metadata.json',mp)
                    for name in meta['arrays']:add('maps/'+k+'/'+instrument+'/'+name+'.npy',mp.parent/(name+'.npy'))
                    statuses[instrument]=store.status(k).get(instrument,dict(status='generated'))
            if profile in ('viewing','full'):
                for component in store.components(k):
                    if '--' not in component:continue
                    arrays,meta=store.artifact(k,component);folder=store.artifact_path(k,component)
                    logical='maps/'+k+'/batches/reconstruction/'+component.split('--',1)[1]
                    add(logical+'/metadata.json',folder/'metadata.json')
                    for name in meta['arrays']:add(logical+'/'+name+'.npy',folder/(name+'.npy'))
            add('maps/'+k+'/status.json',data=statuses)
        manifest=dict(format=FORMAT,version=VERSION,producer='HyCompass 0.6.8',map_id=key,profile=profile,components=entries,omitted_layers=[sources[p] for p in sources if p not in included],referenced_bytes=sum(e['bytes'] for e in entries.values()),unique_bytes=sum(next(e['bytes'] for e in entries.values() if e['sha256']==h) for h in payloads))
        destination.parent.mkdir(parents=True,exist_ok=True)
        temp=destination.with_name(destination.name+'.pending')
        try:
            with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as archive:
                for h,(kind,value) in payloads.items():
                    if kind=='file':archive.write(value,'payload/'+h)
                    else:archive.writestr('payload/'+h,value)
                archive.writestr('package.json',json.dumps(manifest,indent=2))
            os.replace(temp,destination)
        finally:temp.unlink(missing_ok=True)
        return manifest

def _safe(path):
    p=PurePosixPath(path)
    if p.as_posix()!=path or p.is_absolute() or not p.parts or any(v in ('..','.') for v in p.parts) or '\\' in path or ':' in path:raise ValueError('Unsafe package path')
    return p

def import_package(package,destination,*,max_bytes=16*1024**3):
    """Install into a new workspace atomically; refuse collisions and unsafe arrays."""
    destination=Path(destination).resolve()
    if destination.exists():raise ValueError('Import destination must be new; existing workspaces are never overwritten')
    destination.parent.mkdir(parents=True,exist_ok=True)
    stage=Path(tempfile.mkdtemp(prefix='.map-install-',dir=destination.parent))
    try:
        with zipfile.ZipFile(package) as archive:
            infos=archive.infolist();names=[i.filename for i in infos]
            if len({n.casefold() for n in names})!=len(names):raise ValueError('Duplicate archive entries')
            for info in infos:
                _safe(info.filename)
                if (info.external_attr>>16)&0o170000==0o120000:raise ValueError('Package symlinks are forbidden')
            if sum(i.file_size for i in infos)>max_bytes:raise ValueError('Expanded package exceeds byte limit')
            info=archive.getinfo('package.json')
            if info.file_size>16*1024**2:raise ValueError('Package manifest exceeds limit')
            manifest=json.loads(archive.read('package.json'))
            if manifest.get('format')!=FORMAT or manifest.get('version')!=VERSION:raise ValueError('Unsupported package format')
            if manifest.get('required_extensions'):raise ValueError('Unsupported required extensions')
            if sum(e['bytes'] for e in manifest['components'].values())>max_bytes:raise ValueError('Installed package exceeds byte limit')
            for logical,e in manifest['components'].items():
                parts=_safe(logical).parts
                if logical not in ('workspace.json','ecology.json') and parts[0] not in ('assets','maps'):raise ValueError('Unknown installed component location')
                path=stage.joinpath(*parts);_safe(e['blob'])
                if archive.getinfo(e['blob']).file_size!=e['bytes']:raise ValueError('Component size mismatch')
                path.parent.mkdir(parents=True,exist_ok=True)
                with archive.open(e['blob']) as src,path.open('wb') as dst:shutil.copyfileobj(src,dst,1024*1024)
                if checksum(path)!=e['sha256']:raise ValueError('Component checksum mismatch')
                if path.suffix=='.npy':
                    a=np.load(path,mmap_mode='r',allow_pickle=False)
                    if a.dtype.hasobject:raise ValueError('Object arrays are forbidden')
                    del a
        # Every registered path must stay inside the declared package universe.
        declared=set(manifest['components'])|set(manifest['omitted_layers'])
        def declared_path(value):
            if value is None:return
            _safe(value)
            if value not in declared:raise ValueError('Undeclared source reference: '+value)
        from model.workspace.manifest import WorkspaceManifest
        wm=WorkspaceManifest.load(stage)
        for spec in wm.domains.values():
            declared_path(spec.embeddings);declared_path(spec.item_ids)
        for spec in wm.projections.values():
            for value in (spec.positions,spec.x_order,spec.x_sorted):declared_path(value)
        catalog=json.loads((stage/'ecology.json').read_text())
        for spec in catalog['collections'].values():
            declared_path(spec['item_ids']);declared_path(spec.get('groups'))
        for spec in catalog['domains'].values():
            declared_path(spec['forward']);declared_path(spec['reverse'])
            for value in spec['source_stamps']:declared_path(value)
        for spec in catalog['features'].values():
            for field in ('values','valid','labels'):declared_path(spec.get(field))
            for value in spec['source_stamps']:declared_path(value)
        store=Store(stage)
        for d in store.definitions():
            if len(store.membership(d['id']))!=d['n_members']:raise ValueError('Membership size mismatch')
            if __import__('ecology.catalog',fromlist=['array_digest']).array_digest(store.membership(d['id']))!=d['membership_digest']:raise ValueError('Membership checksum mismatch')
            members=store.membership(d['id']);universe=store.catalog.n(d['collection'])
            if members.dtype.kind not in 'iu' or members.ndim!=1 or len(members) and (members.min()<0 or members.max()>=universe or np.any(members[1:]<=members[:-1])):raise ValueError('Invalid canonical membership')
            for instrument in store.status(d['id']):
                arrays,meta=store.artifact(d['id'],instrument)
                if meta['result_signature']!=store.expected_signature(d['id'],instrument,meta):raise ValueError('Result dependency signature mismatch')
                if 'anchor_rows' in arrays:
                    anchors=arrays['anchor_rows']
                    if anchors.ndim!=1 or anchors.dtype.kind not in 'iu' or np.any(~np.isin(anchors,members)):raise ValueError('Invalid result support')
                if 'neighbors' in arrays:
                    ns=arrays['neighbors']
                    if ns.dtype.kind not in 'iu' or ns.ndim!=2 or np.any(ns<0) or np.any(ns>=len(arrays['context_rows'])):raise ValueError('Invalid neighbor support')
            for component in store.components(d['id']):
                if '--' in component:store.artifact(d['id'],component)
            # Available layers must satisfy their typed, aligned registration contract.
            for name,f in store.catalog.raw['features'].items():
                if store.catalog.resolve(f['values']).exists() and store.catalog.resolve(f['valid']).exists():
                    a=store.catalog.load(f['values']);known=store.catalog.load(f['valid'])
                    if a.shape!=(universe,) or known.shape!=(universe,) or known.dtype.kind not in 'bu' or np.any((known!=0)&(known!=1)):raise ValueError('Invalid target layer alignment/knownness')
                    values=a[known.astype(bool)]
                    if not np.isfinite(values).all():raise ValueError('Nonfinite known target layer')
                    if f['kind']=='boolean' and np.any((values!=0)&(values!=1)):raise ValueError('Invalid Boolean layer')
                    if f['kind']=='category' and (a.dtype.kind not in 'iu' or not 1<=f['cardinality']<=64 or np.any(values<0) or np.any(values>=f['cardinality'])):raise ValueError('Invalid category codebook')
        atomic_json(stage/'package-install.json',dict(format=FORMAT,version=VERSION,components=manifest['components'],omitted_layers=manifest['omitted_layers']))
        os.replace(stage,destination)
        return dict(map_id=manifest['map_id'],capabilities=Store(destination).capabilities(manifest['map_id']))
    finally:
        if stage.exists():shutil.rmtree(stage)

def attach_package(package,root,max_bytes=16*1024**3):
    """Attach exact missing immutable layers, never coerce identities or replace data."""
    root=Path(root).resolve()
    with tempfile.TemporaryDirectory() as temp:
        stage=Path(temp)/'workspace';import_package(package,stage,max_bytes=max_bytes)
        incoming=json.loads((stage/'package-install.json').read_text())
        existing=json.loads((root/'package-install.json').read_text())
        for logical,e in incoming['components'].items():
            if logical in ('workspace.json','ecology.json') or logical.startswith('maps/') and logical.endswith(('/definition.json','/membership.npy')):
                previous=existing['components'].get(logical)
                if previous is None or previous['sha256']!=e['sha256']:raise ValueError('Attachment identity/definition mismatch')
        with workspace_writer(root):
            additions=[]
            for logical,e in incoming['components'].items():
                if not logical.startswith('assets/'):continue
                target=root/logical
                if target.exists():
                    if checksum(target)!=e['sha256']:raise ValueError('Attachment conflicts with existing layer')
                elif logical in existing['omitted_layers']:additions.append((logical,e))
                else:raise ValueError('Undeclared attachment layer')
            # Manifest is the recovery record; exact layers are idempotent on retry.
            atomic_json(root/'attachment-pending.json',dict(additions=additions))
            for logical,e in additions:
                target=root/logical;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/logical,target.with_suffix('.pending'));os.replace(target.with_suffix('.pending'),target)
                existing['components'][logical]=e;existing['omitted_layers'].remove(logical)
            atomic_json(root/'package-install.json',existing);(root/'attachment-pending.json').unlink(missing_ok=True)
        return dict(attached=len(additions))
