"""Self-contained HTML presentation for a saved-map snapshot."""
from collections import defaultdict
from html import escape

from .reading import MEANINGS
from .feature_report import feature_section

STYLE = """
:root{color-scheme:dark;--ink:#edf5f3;--muted:#a7bebd;--bg:#0b141b;--panel:#12232c;
--line:#2b454d;--mint:#73dfce;--gold:#ffd38a;--blue:#97bdf6}
*{box-sizing:border-box} html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.55 system-ui,sans-serif}
main{max-width:1180px;margin:auto;padding:0 clamp(20px,5vw,64px) 60px}
a{color:var(--mint);text-underline-offset:4px} a:focus-visible,summary:focus-visible{outline:2px solid var(--gold);outline-offset:5px}
header{display:flex;justify-content:space-between;gap:18px;flex-wrap:wrap;padding:28px 0;border-bottom:1px solid var(--line)}
nav{display:flex;gap:18px;flex-wrap:wrap} h1,h2,h3,p{margin:0} h1{font-size:clamp(1.8rem,5vw,4.5rem);line-height:1.08;letter-spacing:-.045em;word-break:normal;overflow-wrap:break-word;margin:12px 0 0}
.report-title{padding-top:clamp(24px,5vw,48px)}
h2{font-size:clamp(1.65rem,3vw,2.55rem);letter-spacing:-.04em;line-height:1.15} h3{font-size:1.16rem}
.kicker{font-size:.72rem;letter-spacing:.15em;text-transform:uppercase;font-weight:750;color:var(--mint)}
.hero{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,58px);align-items:center;padding:24px 0 30px}
.note{color:var(--ink);white-space:pre-wrap;overflow-wrap:anywhere;font-size:1.08rem;margin-top:16px}
small,.muted,figcaption{color:var(--muted)} .lede{color:var(--muted);max-width:62ch;margin-top:10px}
figure{margin:0}.map{min-width:0;background:#0d1a23;border:1px solid var(--line);border-radius:18px;overflow:hidden}
.map-stage{min-height:230px;display:grid;place-items:center;padding:18px;background:radial-gradient(ellipse at 50% 30%,#173641,#0d1a23 72%)}
.map img{max-width:100%;width:min(100%,420px);height:auto;max-height:410px;object-fit:contain}
figcaption{border-top:1px solid var(--line);padding:12px 16px;font-size:.82rem}
.dot{color:var(--gold)}.field{color:var(--mint)} .legend{display:flex;gap:14px;flex-wrap:wrap}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:1px;background:var(--line);border:1px solid var(--line);border-radius:15px;overflow:hidden}
.stat{background:var(--panel);padding:14px 18px}.stat strong{display:block;font-size:clamp(1.25rem,3vw,2rem);font-variant-numeric:tabular-nums}
section{margin-top:52px;scroll-margin-top:16px}
.coverage{margin-top:12px}.track{height:7px;background:#263b49;border-radius:6px;overflow:hidden;display:flex}
.track i{display:block;background:var(--mint)}.track .unprojected{background:var(--blue)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,310px),1fr));gap:14px;margin-top:18px}
.plot,details{min-width:0;background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:16px 19px;overflow-wrap:anywhere}
.plot h3{margin-top:5px}
details{margin-top:12px} summary{cursor:pointer;color:var(--ink);font-weight:700}
details details{padding:10px 12px;background:#0d1b24} .chart-data{margin-top:8px}
.table-wrap{overflow-x:auto} table{width:100%;border-collapse:collapse;text-align:left;margin-top:8px;font-size:.91rem}
td,th{padding:8px;border-bottom:1px solid var(--line);vertical-align:top}
th{color:var(--muted)} td.value{white-space:nowrap;color:var(--gold);font-variant-numeric:tabular-nums}
code{font-size:.82em;overflow-wrap:anywhere;color:var(--blue)} pre{font:inherit;white-space:pre-wrap;overflow-wrap:anywhere}
svg{display:block;width:100%;height:auto;margin:12px 0 2px}
.reading{margin:14px 0;padding:10px 13px;border-left:3px solid var(--mint);background:#0d1b24;font-size:.88rem}.reading p{margin-top:5px}.reading strong{color:var(--mint)}
.feature-controls{display:flex;gap:12px;align-items:end;flex-wrap:wrap;margin:12px 0;color:var(--muted)}
.feature-controls label{min-width:0;max-width:100%;font-size:.88rem}
.feature-controls label select,.feature-controls label input{display:block;width:100%;max-width:450px}
.feature-controls button,.feature-controls select,.feature-controls input,.feature-list button{
  font:inherit;color:var(--ink);background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:6px 10px}
.feature-controls button,.feature-list button{cursor:pointer}.feature-controls button:disabled{opacity:.45;cursor:default}
.feature-list{display:grid;gap:5px;grid-template-columns:repeat(auto-fit,minmax(min(100%,175px),1fr))}
.feature-list button{text-align:left;overflow-wrap:anywhere}.feature-list small{display:block}.feature-list button[aria-pressed=true]{border-color:var(--mint);color:var(--mint)}
#fx-detail{margin-top:15px}#fx-detail h4{margin:18px 0 3px}#fx-detail svg{max-width:720px}
footer{border-top:1px solid var(--line);margin-top:48px;padding-top:14px;color:var(--muted)}
@media(max-width:720px){.hero{grid-template-columns:1fr;padding-top:20px}.map-stage{min-height:160px}}
@media print{body{background:white;color:black} .plot,.stat,details,.map{background:white;color:black}
:root{--muted:#33424a;--line:#bbc6cb;--mint:#116e62;--gold:#765011;--blue:#264879} a,summary{color:black}}
"""


# Use the explorer's distinction between what to notice and what the evidence supports.
GUIDE = {
    "geometry": ("Can you reach the rest of this neighborhood?",
                 "Watch the component count as the connection radius grows. A rapid drop means small increases in allowed distance join many pieces.",
                 "This follows the saved mutual-neighbor graph. Missing edges can hide routes outside the measured graph."),
    "reconstruction": ("Which distinctions survive compression?",
                       "Follow the held-out error as more directions are retained. A falling curve suggests the extra directions help recover this target.",
                       "Compare the same target, loss and support. Lower error describes these held-out items and does not identify a cause."),
    "feature_distribution": ("Who is represented here?",
                             "Compare known and missing rows before interpreting the category counts. Large groups can drive a map-wide pattern.",
                             "The bars show selected counts. Missing values are separate from recorded zeroes, and unselected categories may exist."),
    "source_support": ("How much usable evidence underlies the map?",
                       "Sample size and usable rows show how much evidence the source measurements could draw on.",
                       "The source checks describe the saved sample. A clean sample cannot rule out problems elsewhere."),
    "probe_metrics": ("Does the target hold up on held-out items?",
                      "Read the named metric alongside its scope. Error metrics and agreement metrics answer different questions.",
                      "Keep the target, evaluation support and reference baseline fixed when comparing scores."),
    "feature_audit": ("Where do the labels and geometry agree?",
                      "Look for features with useful coverage before interpreting their association with local geometry.",
                      "Associations describe the sampled support. Coverage and missingness can change the picture."),
    "reference_evaluation": ("Do the saved probes still work here?",
                             "Compare performance on this selection against its stated reference and support.",
                             "The saved probes stay frozen. A change in loss may reflect the changed mix of items."),
    "neighbors": MEANINGS["radius"],
    "directions": ("How do nearby items differ?",
                   "The saved local tangent directions describe how neighbors spread around each anchor.",
                   "The local coordinate basis can differ between anchors. A direction is not a named cause."),
    "resolved_support": ("Which items were available to measure?",
                         "Anchors are measured items. Context rows are the reference pool used to describe those items.",
                         "Neither count alone describes how representative the measurement is of the whole population."),
    "stability": MEANINGS["perturbation_jaccard"],
    "routes": MEANINGS["deletion_damage"],
    "discrepancy": MEANINGS["discrepancy"],
    "compression": MEANINGS["projection_neighbor_jaccard"],
}


def guide_note(module, compact=False):
    text = GUIDE.get(module)
    if text is None:
        return ""
    question, reading, limit = map(escape, text)
    boundary = "" if compact else f'<p class="muted">{limit}</p>'
    return f'<aside class="reading"><strong>{question}</strong><p>{reading}</p>{boundary}</aside>'


def family(result):
    return result.split("/", 1)[0].split("--", 1)[0]


def label(value):
    return escape(value.replace("_", " "))


def value_text(value):
    return f"{value:,}" if type(value) is int else f"{value:.6g}"


def finding_table(rows):
    cells = "".join(
        f'<tr><th scope="row">{label(row["metric"])}</th>'
        f'<td class="value">{value_text(row["value"])}</td>'
        f'<td>{escape(row["scope"])}<br><code>{escape(row["result"])}</code></td></tr>'
        for row in rows)
    return ('<div class="table-wrap"><table><thead><tr><th>Measure</th><th>Value</th>'
            '<th>Scope and saved result</th></tr></thead><tbody>' + cells + '</tbody></table></div>')


def line_plot(chart, explain):
    samples = chart["samples"]
    xs, ys = zip(*samples)
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(0, min(ys)), max(0, max(ys))
    kind = chart.get("kind", "line")
    left, right, top, bottom = 58, 385, 12, 118
    xspan = xmax - xmin or 1
    yspan = ymax - ymin or 1
    coords = [(left + (right-left) * (x-xmin)/xspan, bottom - (bottom-top)*((y-ymin)/yspan))
              for x, y in samples]
    tick_left, tick_right = value_text(xmin), value_text(xmax)
    tick_marks = ""
    zero = bottom - (bottom-top)*(-ymin/yspan)
    baseline = f'<path d="M{left} {zero:.2f}H{right}" stroke="#64838e"/>' if ymin < 0 < ymax else ""
    if kind != "line":
        step = (right - left) / len(samples)
        coords = [(left + step * (i + 0.5), y) for i, (_, y) in enumerate(coords)]
        bars = "".join(f'<rect x="{x-step*.43:.2f}" y="{y:.2f}" width="{step*.86:.2f}" '
                       f'height="{bottom-y:.2f}" fill="#73dfce"/>' for x, y in coords)
        if kind == "categories":
            tick_left, tick_right = "", ""
            if len(samples) <= 12:
                tick_marks = "".join(f'<text x="{x:.2f}" y="134" text-anchor="middle">{value_text(code)}</text>'
                                     for (x, _), (code, _) in zip(coords, samples))
    path = " ".join(f"{x:.2f},{y:.2f}" for x, y in coords)
    markers = "".join(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="3"/>' for x, y in coords)
    marks = (f'<polyline points="{path}" fill="none" stroke="#73dfce" stroke-width="2"/>'
             f'<g fill="#ffd38a">{markers}</g>') if kind == "line" else bars
    rows = "".join(f'<tr><td>{value_text(x)}</td><td>{value_text(y)}</td></tr>' for x, y in samples)
    x_label, y_label = escape(chart["x"]), escape(chart["y"])
    return (f'<figure class="plot"><p class="kicker">{label(family(chart["result"]))}</p>'
            f'<h3>{escape(chart["title"])}</h3><p class="lede">{escape(chart["scope"])}</p>'
            f'{guide_note(family(chart["result"])) if explain else ""}'
            f'<svg viewBox="0 0 406 155" role="img" aria-label="{y_label} by {x_label}">'
            f'<path d="M{left} {top}V{bottom}H{right}" fill="none" stroke="#64838e"/>'
            f'<path d="M{left} {top}H{right}" stroke="#35535d" stroke-dasharray="4 4"/>'
            f'{baseline}{marks}'
            f'<g fill="#a7bebd" font-size="12"><text x="4" y="17">{ymax:.4g}</text>'
            f'<text x="4" y="{bottom}">{ymin:.4g}</text><text x="{left}" y="134">{tick_left}</text>'
            f'<text x="{right}" y="134" text-anchor="end">{tick_right}</text>{tick_marks}'
            f'<text x="220" y="149" text-anchor="middle">{x_label}</text></g></svg>'
            f'<p class="muted">{y_label} · {len(samples)} saved samples</p>'
            f'<details class="chart-data"><summary>Values and provenance</summary>'
            f'<code>{escape(chart["result"])}</code><div class="table-wrap"><table>'
            f'<thead><tr><th>{x_label}</th><th>{y_label}</th></tr></thead><tbody>{rows}'
            '</tbody></table></div></details></figure>')


def distribution_plot(target, rows, explain):
    """Only chart selected counts sharing one saved result and scope."""
    largest = max(row["value"] for row in rows)
    bars = "".join(
        f'<p>{label(row["metric"])} <strong>{value_text(row["value"])}</strong></p>'
        f'<div class="track" aria-hidden="true"><i style="width:{100 * row["value"] / (largest or 1):.2f}%"></i></div>'
        for row in rows)
    return (f'<figure class="plot"><p class="kicker">Selected distribution counts</p>'
            f'<h3>{escape(target)}</h3>{guide_note("feature_distribution") if explain else ""}{bars}<p class="lede">Scale 0–{value_text(largest)} · '
            f'{escape(rows[0]["scope"])}</p><code>{escape(rows[0]["result"])}</code></figure>')


def select_highlights(findings):
    highlights = []
    highlighted = set()
    for row in sorted(findings, key=lambda item: item["target"] == "Measurement support"):
        module = family(row["result"])
        if module not in highlighted:
            highlights.append(row)
            highlighted.add(module)
        if len(highlights) == 3:
            break
    return highlights


def route_feature_charts(features, charts):
    """Give each chart one home, retaining static fallbacks without feature evidence."""
    by_name = {item["name"]: {**item, "plots": []} for item in features}
    static = []
    for chart in charts:
        target = chart.get("target")
        feature = by_name.get(target)
        module = family(chart["result"])
        if feature is not None and module == "feature_distribution":
            feature["plots"].append(chart)
        elif feature is not None and module == "reconstruction":
            metric = next((row[2] for row in chart.get("selections", ())), None)
            samples = set(map(tuple, chart["samples"]))
            if not any(result == chart["result"] and name == metric
                       and samples <= {(x, y) for x, y, _ in points}
                       for result, name, _, _, points in feature["series"]):
                static.append(chart)
        else:
            static.append(chart)
    return list(by_name.values()), static


def render_report(card, charts=(), *, features=()):
    title = escape(card["title"])
    projection = card["projection"]
    features, charts = route_feature_charts(features, charts)
    feature_names = {item["name"] for item in features}
    if card["png"]:
        map_body = (f'<img src="data:image/png;base64,{card["png"]}" width="256" '
                    'alt="Saved member cells and their coverage field in the population projection">')
        caption = (f'<span class="legend"><span><b class="dot">●</b> Member cells</span>'
                   f'<span><b class="field">◒</b> Coverage field</span></span>'
                   f'Full bounds of {escape(projection["id"])} · cell markers enlarged for legibility')
    else:
        map_body = f'<p class="muted">{escape(card["location"])}</p>'
        caption = "Spatial preview"
    stats = [(card["members"], "Frozen members")]
    if projection:
        stats.extend([(card["present"], "In this domain"), (card["projected"], "With coordinates")])
    if card["anchors"] is not None:
        stats.append((card["anchors"], "Measured anchors · max saved support"))
    counts = "".join(f'<div class="stat"><strong>{value_text(value)}</strong><small>{name}</small></div>'
                     for value, name in stats)
    coverage = ""
    if projection and card["members"]:
        total = card["members"]
        projected = 100 * card["projected"] / total
        missing_coordinates = 100 * (card["present"] - card["projected"]) / total
        outside = total - card["present"]
        coverage = (f'<div class="coverage"><div class="track" aria-hidden="true"><i style="width:{projected:.6f}%"></i>'
                    f'<i class="unprojected" style="width:{missing_coordinates:.6f}%"></i></div>'
                    f'<small>{projected:.1f}% projected · {card["present"]-card["projected"]:,} without coordinates '
                    f'· {outside:,} outside this domain</small></div>')
    note = f'<p class="note">{escape(card["note"])}</p>' if card["note"] else ""
    groups = defaultdict(lambda: defaultdict(list))
    distributions = defaultdict(list)
    for row in card["findings"]:
        module = family(row["result"])
        groups[module][row["target"]].append(row)
        metric = row["metric"]
        if module == "feature_distribution" and row["target"] not in feature_names and row["value"] >= 0:
            if metric in ("known", "missing") or metric.startswith("Count for code "):
                kind = "availability" if metric in ("known", "missing") else "category"
                distributions[(row["target"], row["result"], row["scope"], kind)].append(row)
    overview = card.get("overview", {})
    plot_groups = defaultdict(list)
    seen = set()
    for chart in charts:
        module = family(chart["result"])
        plot_groups[module].append(line_plot(chart, module not in seen))
        seen.add(module)
    for (target, _, _, _), rows in distributions.items():
        if len(rows) > 1 and not any(chart["title"] == f"Category counts for {target}" for chart in charts):
            plot_groups["feature_distribution"].append(
                distribution_plot(target, rows, "feature_distribution" not in seen))
            seen.add("feature_distribution")

    chapters = (
        ("shape", "How is this region organized?",
         ("geometry", "neighbors", "directions", "routes", "discrepancy") if features
         else ("geometry", "neighbors", "directions", "routes")),
        ("stress", "What survives a change of view?", ("stability", "compression", "source_support")),
        ("targets", "What can we say about the items?", ("feature_distribution", "feature_audit", "neighborhood_agreement")),
        ("models", "What can the representation recover?",
         ("reconstruction", "probe_metrics", "reference_evaluation") if features
         else ("reconstruction", "probe_metrics", "discrepancy", "reference_evaluation")),
    )
    chart_sections = []
    for chapter, title, families in chapters:
        # Interleave result families so one large module doesn't dominate the first screen.
        series = [plot_groups[module] for module in families if plot_groups[module]]
        plots = [series_row[index] for index in range(max(map(len, series), default=0))
                 for series_row in series if index < len(series_row)]
        if plots:
            front = "".join(plots[:6])
            extra = (f'<details><summary>Explore {len(plots)-6} more charts</summary>'
                     f'<div class="grid">{"".join(plots[6:])}</div></details>') if len(plots) > 6 else ""
            chart_sections.append((chapter, title, f'<div class="grid">{front}</div>{extra}'))
    grouped = "".join(
        f'<details><summary>{label(module).capitalize()} · {sum(map(len, targets.values()))}</summary>'
        + "".join(f'<details><summary>{escape(target)} · {len(rows)}</summary>{finding_table(rows)}</details>'
                  for target, rows in targets.items()) + '</details>'
        for module, targets in groups.items())
    findings_section = ""
    if grouped:
        findings_section = (
            '<section id="findings"><p class="kicker">Export selection</p>'
            f'<h2>Selected findings ({len(card["findings"])})</h2>'
            '<p class="lede">Exact measurements chosen for this export, grouped by result and target.'
            + (' Browse full saved per-feature evidence in the <a href="#features">feature explorer</a>.' if features else '')
            + f'</p>{grouped}</section>')
    modules = "".join(
        f'<tr><th scope="row">{label(row["name"])}</th><td>{escape(row["scope"]) or "—"}</td>'
        f'<td>{value_text(row["anchors"]) if row["anchors"] is not None else "—"}</td>'
        f'<td><code>{escape(row["result"])}</code></td></tr>' for row in overview.get("modules", []))
    inventory = ('<div class="table-wrap"><table><thead><tr><th>Result</th><th>Scope</th>'
                 '<th>Anchors</th><th>Signature</th></tr></thead><tbody>' + modules +
                 '</tbody></table></div>') if modules else '<p class="lede">No saved result inventory in this export.</p>'
    definition = f'<pre>{escape(overview["definition"])}</pre>' if overview else ""
    projection_details = ""
    if projection:
        xmin, xmax, ymin, ymax = map(value_text, projection["bounds"])
        projection_details = (f'<p>Extent · x [{xmin}, {xmax}], y [{ymin}, {ymax}]</p>'
                              f'<p>Projection fingerprint <code>{escape(projection["fingerprint"])}</code></p>')
    visual_section = ""
    if chart_sections:
        links = " · ".join(f'<a href="#{chapter}">{escape(title)}</a>' for chapter, title, _ in chart_sections)
        sections = "".join(f'<section id="{chapter}"><h2>{escape(title)}</h2>{body}</section>'
                           for chapter, title, body in chart_sections)
        visual_section = (f'<section id="visuals"><p class="kicker">Explore the evidence</p>'
                          f'<h2>Saved measurements</h2><p class="lede">{links}</p>'
                          f'<p class="lede">Start with the question you care about. Each chart shows a summary of saved evidence and links to its values and scope.</p></section>{sections}')

    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title} · HyCompass map</title><style>{STYLE}</style></head><body><main>
<header><span class="kicker">HyCompass / Saved map</span><nav aria-label="Report sections">
<a href="#map">Map</a>{'<a href="#visuals">Charts</a>' if visual_section else ''}
{'<a href="#features">Features</a>' if features else ''}
{'<a href="#findings">Findings</a>' if findings_section else ''}<a href="#source">Provenance</a></nav></header>
<div class="report-title" id="map"><p class="kicker">Map profile</p><h1>{title}</h1></div>
<div class="hero"><div><p class="lede">Embedding <b>{escape(card["embedding"])}</b></p>{note}
<p class="lede">The footprint shows where saved membership lands in the display projection.</p></div>
<figure class="map"><div class="map-stage">{map_body}</div><figcaption>{caption}</figcaption></figure></div>
<div class="stats">{counts}</div>{coverage}
{feature_section(features)}
{visual_section}
{findings_section}
<section id="source"><p class="kicker">Reproducibility</p><h2>Map provenance</h2>
<details><summary>Map definition and projection identity</summary>{definition}
<p>Map <code>{escape(card["map_id"])}</code> · revision <code>{escape(card["revision"])}</code></p>
{projection_details}
</details><details><summary>Saved result inventory</summary>{inventory}</details></section>
<footer>Frozen export from HyCompass · Saved membership and saved measurements</footer></main></body></html>"""
