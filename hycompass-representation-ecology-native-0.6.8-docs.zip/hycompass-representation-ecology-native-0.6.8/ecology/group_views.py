"""Checklist-driven visual browsing over saved groups; never fits on selection."""
import json
import math
import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,QPushButton,QListWidget,QListWidgetItem,QTabWidget,QSplitter,QGroupBox,QProgressBar,QAbstractItemView)
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from .bulk import resource_preset


def checked(widget):
    return [widget.item(i).data(Qt.ItemDataRole.UserRole) for i in range(widget.count()) if widget.item(i).checkState()==Qt.CheckState.Checked]


def checklist(items):
    widget=QListWidget();widget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
    for label,value in items:
        item=QListWidgetItem(label);item.setData(Qt.ItemDataRole.UserRole,value);item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable);item.setCheckState(Qt.CheckState.Checked);widget.addItem(item)
    return widget


def chart(parent):
    fig=Figure(facecolor='#161d27');canvas=FigureCanvasQTAgg(fig);parent.addWidget(canvas,1);return fig,canvas


def style(ax,title):
    ax.set_facecolor('#161d27');ax.tick_params(colors='#becddd',labelsize=8);ax.set_title(title,color='#e0ebf6',fontsize=9,pad=9)
    for spine in ax.spines.values():spine.set_color('#425369')


class GroupViews:
    def setup_group_views(self):
        self._group_draw_key=None;self._audit_requested=False;self._case_signature=None
        self.prediction_subtabs=QTabWidget();self.prediction_panel.layout().addWidget(self.prediction_subtabs,1)
        # Existing distribution, cases and details each get useful plot space.
        self.distribution_tab=QWidget();dist=QVBoxLayout(self.distribution_tab);dist.addWidget(self.prediction_canvas);self.prediction_subtabs.addTab(self.distribution_tab,'Distribution')
        self.subset_tab=QWidget();subset=QVBoxLayout(self.subset_tab);self.subset_figure,self.subset_canvas=chart(subset);self.subset_note=QLabel();self.subset_note.setWordWrap(True);subset.addWidget(self.subset_note);self.prediction_subtabs.addTab(self.subset_tab,'Subset visuals')
        self.targets_tab=QWidget();targets=QVBoxLayout(self.targets_tab);bar=QHBoxLayout();self.group_page=QComboBox();self.group_page.addItem('Targets 1–2',0);bar.addWidget(QLabel('Checked target groups'));bar.addWidget(self.group_page);self.group_scope_note=QLabel('Saved held-out anchors; own support at each dimension. Observer subset does not filter these saved aggregate curves.');self.group_scope_note.setWordWrap(True);bar.addWidget(self.group_scope_note,1);targets.addLayout(bar);self.group_figure,self.group_canvas=chart(targets);self.prediction_subtabs.addTab(self.targets_tab,'Across targets')
        self.population_tab=QWidget();population=QVBoxLayout(self.population_tab);self.population_note=QLabel('Full frozen map membership distributions, independent of sampled prediction support. Load / prepare Target distributions.');self.population_note.setWordWrap(True);population.addWidget(self.population_note);self.population_page=QComboBox();self.population_page.addItem('Targets 1–2',0);population.addWidget(self.population_page);self.population_page.currentIndexChanged.connect(self.population_page_changed);self.population_figure,self.population_canvas=chart(population);self.prediction_subtabs.addTab(self.population_tab,'Full membership')
        self.cases_tab=QWidget();case_layout=QVBoxLayout(self.cases_tab);case_bar=QHBoxLayout();self.case_preset=QComboBox();self.case_preset.addItems(['All supported in displayed subset','All measured anchors','Highest absolute measurement 10%','Union worst 10% per checked variant','Here and ahead','All frozen map members']);case_bar.addWidget(self.case_preset,1)
        keep=QPushButton('Keep preset');keep.clicked.connect(self.keep_item_preset);case_bar.addWidget(keep);case_layout.addLayout(case_bar)
        self.prediction_cases.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection);self.prediction_cases.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows);case_layout.addWidget(self.prediction_cases,1)
        actions=QHBoxLayout()
        for name,slot in [('Check all listed',lambda:self.check_cases(True)),('Clear checks',lambda:self.check_cases(False)),('Keep checked cases',self.keep_checked_cases),('Keep top 50 cases',self.keep_prediction_cases)]:
            b=QPushButton(name);b.clicked.connect(slot);actions.addWidget(b)
        case_layout.addLayout(actions);self.case_note=QLabel('Listed cases are bounded to 50. Bulk presets use the entire declared support; browsing never replaces kept items.');self.case_note.setWordWrap(True);case_layout.addWidget(self.case_note);self.prediction_subtabs.addTab(self.cases_tab,'Cases & keep')
        self.classification_tab=QWidget();classification=QVBoxLayout(self.classification_tab);self.classification_figure,self.classification_canvas=chart(classification);classification.addWidget(self.classification_details);self.classification_details.setMaximumHeight(120);self.prediction_subtabs.addTab(self.classification_tab,'Classification')
        self.audit_tab=QWidget();audit=QVBoxLayout(self.audit_tab);audit_bar=QHBoxLayout()
        for name,slot in [('Estimate audit',self.estimate_source_audit),('Prepare / load audit',self.prepare_source_audit),('Cancel work',self.cancel_work)]:
            b=QPushButton(name);b.clicked.connect(slot);audit_bar.addWidget(b)
        self.audit_view=QComboBox();self.audit_view.addItems(['Vector norms + covariance spectrum','Neighbor occurrences + duplicate groups']);self.audit_view.currentIndexChanged.connect(self.refresh_group_views);audit_bar.addWidget(self.audit_view,1)
        audit.addLayout(audit_bar);self.audit_state=QLabel();self.audit_state.setWordWrap(True);audit.addWidget(self.audit_state);self.audit_estimate_text=QLabel();self.audit_estimate_text.setWordWrap(True);self.audit_estimate_text.hide();audit.addWidget(self.audit_estimate_text);self.audit_progress=QProgressBar();self.audit_progress.setRange(0,100);self.audit_progress.setMaximumHeight(14);audit.addWidget(self.audit_progress);self.audit_figure,self.audit_canvas=chart(audit);self.prediction_subtabs.addTab(self.audit_tab,'Source audits')
        self.availability_tab=QWidget();availability=QVBoxLayout(self.availability_tab);availability.addWidget(self.navigation_overview);self.navigation_overview.setMaximumHeight(16777215);self.prediction_subtabs.addTab(self.availability_tab,'Availability')
        self.batch_tab=QWidget();batch=QVBoxLayout(self.batch_tab);top=QHBoxLayout();self.batch_target_preset=QComboBox();self.batch_target_preset.addItems(['All targets and dimensions','Numeric targets','Boolean + category targets','Current target only','None']);top.addWidget(self.batch_target_preset,1);button=QPushButton('Apply target preset');button.clicked.connect(self.apply_target_preset);top.addWidget(button);batch.addLayout(top)
        split=QSplitter();batch.addWidget(split,1)
        self.target_checks=checklist([(name,name) for name in self.definition['settings']['features']]);self.dimension_checks=checklist([(str(q)+' retained directions',str(q)) for q in self.definition['settings']['dimensions']]);self.account_checks=checklist([('Broad Ridge','broad'),('Regional Ridge','local'),('Training baseline','baseline')])
        for title,widget in [('Targets',self.target_checks),('Dimensions',self.dimension_checks),('Accounts to plot',self.account_checks)]:
            box=QGroupBox(title);vl=QVBoxLayout(box);vl.addWidget(widget);split.addWidget(box)
        row=QHBoxLayout();self.batch_resource_preset=QComboBox();self.batch_resource_preset.addItems(['All applicable','Prediction + population','Geometry + audits','Saved map preset']);row.addWidget(self.batch_resource_preset,1);apply=QPushButton('Apply resource preset');apply.clicked.connect(self.apply_resource_preset);row.addWidget(apply);row.addWidget(QLabel('Viewer RAM'));self.viewer_budget=QComboBox()
        for mb in (64,256,512,1024):self.viewer_budget.addItem(f'{mb} MiB',mb*1024**2)
        self.cache.max_bytes=self.viewer_budget.currentData();self.viewer_budget.currentIndexChanged.connect(self.set_viewer_budget);row.addWidget(self.viewer_budget);batch.addLayout(row)
        self.batch_resources=checklist([(n.replace('_',' '),n) for n in resource_preset('All applicable',self.definition)]);self.batch_resources.setMaximumHeight(140);batch.addWidget(self.batch_resources)
        row=QHBoxLayout()
        for name,slot in [('Compute checked · continue errors',self.prepare_bulk_checked),('Load checked',lambda:self.load_names(checked(self.batch_resources))),('Unload checked',self.unload_checked)]:
            b=QPushButton(name);b.clicked.connect(slot);row.addWidget(b)
        batch.addLayout(row);self.bulk_feedback=QLabel('Default: all configured targets, accounts and dimensions. Resource checkboxes share Compute / storage. Compute prepares full configured families; checks choose what to load and plot. Native budgets still apply per family.');self.bulk_feedback.setWordWrap(True);batch.addWidget(self.bulk_feedback);self.prediction_subtabs.addTab(self.batch_tab,'Checklists & presets')
        self._checked_resources=set(resource_preset('All applicable',self.definition));self.sync_batch_resources()
        self.batch_resources.itemChanged.connect(self.batch_resource_changed)
        for widget in (self.target_checks,self.dimension_checks,self.account_checks):widget.itemChanged.connect(self.group_checks_changed)
        self.group_page.currentIndexChanged.connect(self.refresh_group_views);self.prediction_subtabs.currentChanged.connect(self.refresh_navigation)
        self.group_canvas.mpl_connect('pick_event',self.pick_group_variant)

    def sync_batch_resources(self):
        if not hasattr(self,'batch_resources'):return
        self.batch_resources.blockSignals(True)
        for i in range(self.batch_resources.count()):
            item=self.batch_resources.item(i);item.setCheckState(Qt.CheckState.Checked if item.data(Qt.ItemDataRole.UserRole) in self._checked_resources else Qt.CheckState.Unchecked)
        self.batch_resources.blockSignals(False)

    def set_viewer_budget(self,*_):
        self.cache.max_bytes=self.viewer_budget.currentData();self.bulk_feedback.setText(f'Viewer budget {self.cache.max_bytes/1024**2:.0f} MiB; {self.cache.nbytes/1024**2:.1f} MiB currently resident. Use Load checked to rebuild residency. Analysis budgets are unchanged.')

    def batch_resource_changed(self,*_):self.set_checked(checked(self.batch_resources))

    def apply_resource_preset(self):
        self.set_checked(resource_preset(self.batch_resource_preset.currentText(),self.definition));self.bulk_feedback.setText(f'{len(self.checked_names())} resource families checked. Compute is explicit and retains completed results if another family fails.')

    def apply_target_preset(self):
        name=self.batch_target_preset.currentText();self.target_checks.blockSignals(True);self.dimension_checks.blockSignals(True)
        for i in range(self.target_checks.count()):
            item=self.target_checks.item(i);target=item.data(Qt.ItemDataRole.UserRole);kind=self.store.catalog.raw['features'].get(target,{}).get('kind');keep=name=='All targets and dimensions' or name=='Numeric targets' and kind=='numeric' or name=='Boolean + category targets' and kind in ('boolean','category') or name=='Current target only' and target==self.feature.currentText();item.setCheckState(Qt.CheckState.Checked if keep else Qt.CheckState.Unchecked)
        for i in range(self.dimension_checks.count()):self.dimension_checks.item(i).setCheckState(Qt.CheckState.Unchecked if name=='None' else Qt.CheckState.Checked)
        self.target_checks.blockSignals(False);self.dimension_checks.blockSignals(False);self.group_checks_changed()

    def group_checks_changed(self,*_):
        self._group_draw_key=None;self.update_group_pages();self.bulk_feedback.setText(f'{len(checked(self.target_checks))} targets × {len(checked(self.dimension_checks))} dimensions checked for loading / group plots. Use Load checked once; unavailable payloads remain labelled.');self.refresh_navigation()

    def update_group_pages(self):
        count=max(1,math.ceil(len(checked(self.target_checks))/2));current=self.group_page.currentIndex()
        if self.group_page.count()==count:
            if hasattr(self,'population_page'):self.population_page.blockSignals(True);self.population_page.setCurrentIndex(self.group_page.currentIndex());self.population_page.blockSignals(False)
            return
        self.group_page.blockSignals(True);self.group_page.clear()
        for i in range(count):self.group_page.addItem(f'Targets {i*2+1}–{min(len(checked(self.target_checks)),i*2+2)}',i)
        self.group_page.setCurrentIndex(min(current,count-1));self.group_page.blockSignals(False)
        self.population_page.blockSignals(True);self.population_page.clear()
        for i in range(count):self.population_page.addItem(self.group_page.itemText(i),i)
        self.population_page.setCurrentIndex(self.group_page.currentIndex());self.population_page.blockSignals(False)

    def population_page_changed(self,index):
        self.group_page.setCurrentIndex(index);self.refresh_group_views()

    def prepare_bulk_checked(self):
        from .instruments import REGISTRY
        names=checked(self.batch_resources)
        if not names:self.bulk_feedback.setText('No resource families checked.');return
        if self.jobs.busy(self.key):self.bulk_feedback.setText('A job is already running; cancel or wait for its feedback.');return
        # Import-only results have no generator, but may still be loaded.
        self._bulk_outcome=None
        self._pending_load_names=list(dict.fromkeys([*self.loaded,*names,'geometry']));self._audit_requested='source_support' in names
        try:
            self.generation_future=self.jobs.submit(self.key,[n for n in names if n in REGISTRY],continue_on_error=True)
            self.bulk_feedback.setText(f'Queued {len(names)} checked families; independent failures will be reported and later families still attempted.');self.notice(self.bulk_feedback.text());self.refresh_status()
        except Exception as exc:self._pending_load_names=None;self.error(exc);self.bulk_feedback.setText(str(exc))

    def open_audit_visuals(self):
        self.set_lens('prediction');self.evidence.setCurrentWidget(self.prediction_panel);self.prediction_subtabs.setCurrentWidget(self.audit_tab);self.refresh_group_views()

    def prepare_source_audit(self):
        self.open_audit_visuals();self._show_audit_estimate=False
        self._audit_requested=True;self.source_note.setText('Preparing audit: validating saved dependencies or queuing missing work…');self.prepare_names(['source_support']);self.update_audit_feedback()

    def update_audit_feedback(self):
        if not hasattr(self,'audit_state'):return
        audit=self.loaded.get('source_support');busy=self.jobs.busy(self.key);state=self.store.status(self.key).get('source_support',{})
        if busy:
            stage,value=self.jobs.progress.get(self.key,('Queued',0));text='Worker: '+stage;self.audit_progress.setValue(int(float(value)*100) if isinstance(value,(int,float)) else 0)
        elif audit:
            a,m=audit;text=f"Loaded / measured: {m['measurements']['rows']:,} resolved context rows × {self.store.catalog.manifest.domains[self.definition['domain']].dimensions} coordinates; {m['neighbor_occurrences']['query_count']:,} saved queries. Original audit {m.get('elapsed_seconds',0):.3f} s. Sample-only; zero is measured, unavailable is not measured.";self.audit_progress.setValue(100)
        elif state.get('status') in ('failed','cancelled','interrupted'):
            text=state['status'].capitalize()+': '+state.get('error','No completed measurement.');self.audit_progress.setValue(0)
        elif 'source_support' in self.navigation_audit_saved():text='Saved / unloaded. Load the audit to see measured plots; no new compute is needed.';self.audit_progress.setValue(0)
        else:text='Not measured. Estimate and Prepare explicitly; opening this subtab runs no scan.';self.audit_progress.setValue(0)
        if getattr(self,'_resource_action_error',None):text+=' Action feedback: '+self._resource_action_error
        self.audit_state.setText(text)
        if self._audit_requested and not getattr(self,'_show_audit_estimate',False):self.source_note.setText(text)

    def navigation_audit_saved(self):
        # Existence only, no payload verification on polling or tab changes.
        return ['source_support'] if (self.store.artifact_path(self.key,'source_support')/'metadata.json').exists() else []

    def check_cases(self,value):
        for row in range(self.prediction_cases.rowCount()):self.prediction_cases.item(row,0).setCheckState(Qt.CheckState.Checked if value else Qt.CheckState.Unchecked)

    def keep_checked_cases(self):
        rows=[int(self.prediction_cases.item(i,0).text()) for i in range(self.prediction_cases.rowCount()) if self.prediction_cases.item(i,0).checkState()==Qt.CheckState.Checked];self.set_selection(np.asarray(rows,np.int64))

    def keep_item_preset(self):
        r=self.resolved_measurement;l=self.landscape;name=self.case_preset.currentText()
        if name=='All frozen map members':rows=self.store.membership(self.key)
        elif name=='All measured anchors':rows=l.rows if l.rows is not None else []
        elif name=='Here and ahead':rows=l.rows[np.union1d(l.attention(),l.attention(True))] if l.rows is not None else []
        elif name=='Union worst 10% per checked variant':
            from .bulk import union_error_cases
            payload=self.loaded.get('probe_metrics')
            if payload is None:self.case_note.setText('Load checked probe metrics first.');return
            rows,report=union_error_cases(payload,checked(self.target_checks),checked(self.dimension_checks),checked(self.account_checks))
            self.set_selection(rows);self.case_note.setText(f"Kept {len(rows):,} items from {report['available_groups']} checked variants; {report['unavailable_groups']} unavailable / unloaded. Loss ranks are computed within each variant; no cross-target score.");return
        elif r is None:self.case_note.setText('Load a valid active result first.');return
        elif name=='Highest absolute measurement 10%':
            if r.rendering=='categorical':self.case_note.setText('Category codes have no magnitude. Choose a loss or score measurement first.');return
            ids=np.flatnonzero(r.available);ids=ids[np.lexsort((r.rows[ids],-np.abs(r.values[ids])))];rows=r.rows[ids[:max(1,math.ceil(len(ids)*.1))]]
        else:rows=r.rows[r.available]
        self.set_selection(np.asarray(rows,np.int64));self.case_note.setText(f'Kept {len(rows):,} canonical items using {name.lower()}. Population/map membership is unchanged.')

    def refresh_group_views(self,*_):
        if not hasattr(self,'prediction_subtabs') or self._reloading:return
        self.update_audit_feedback();self.update_group_pages();tab=self.prediction_subtabs.currentWidget()
        if tab in (self.audit_tab,self.targets_tab,self.population_tab):
            key=(self.prediction_subtabs.currentIndex(),tuple(checked(self.target_checks)),tuple(checked(self.dimension_checks)),tuple(checked(self.account_checks)),self.group_page.currentIndex(),self.audit_view.currentIndex(),tuple((name,m.get('result_signature')) for name,(a,m) in sorted(self.loaded.items())),tuple((name,m.get('result_signature')) for name,m in sorted(self.navigation_index.items())))
            if key==self._group_draw_key:return
            self._group_draw_key=key
        if tab==self.subset_tab:self.draw_subset_visuals()
        elif tab==self.classification_tab:self.draw_classification_visuals()
        elif tab==self.audit_tab:self.draw_audit_visuals()
        elif tab==self.targets_tab:self.draw_target_groups()
        elif tab==self.population_tab:self.draw_population_groups()

    def draw_subset_visuals(self):
        r=self.resolved_measurement;f=self.subset_figure;f.clear();ax=f.add_subplot(121);other=f.add_subplot(122);style(ax,'All supported items in displayed subset');style(other,'Measurement distribution')
        if r is None or r.reason or not r.available.any():
            ax.text(.05,.5,r.reason if r and r.reason else 'No supported observations',color='white',transform=ax.transAxes)
        else:
            rows,ia,ib=np.intersect1d(self.landscape.rows,r.rows,return_indices=True);xy=self.landscape.arrays['xy'][ia];v=r.values[ib];good=np.isfinite(xy).all(1)&np.isfinite(v)
            if r.rendering=='categorical':
                for code in np.unique(v[good]):
                    mask=good&(v==code);label=r.labels.get(str(int(code)),{}).get('name',str(int(code)));ax.scatter(xy[mask,0],xy[mask,1],s=13,label=label,color=self.landscape.category_colors[int(code)] if int(code)<len(self.landscape.category_colors) else None)
                if good.any():ax.legend(fontsize=7)
                codes,counts=np.unique(r.values[r.available],return_counts=True);other.bar([r.labels.get(str(int(c)),{}).get('name',str(int(c))) for c in codes],counts,color='#80b5cf')
            else:
                if good.any():
                    limit=1. if r.rendering=='probability' else max(1e-12,float(np.max(np.abs(v[good]))));signed=r.rendering=='signed' or bool(np.any(v[good]<0));mesh=ax.hexbin(xy[good,0],xy[good,1],C=v[good],gridsize=30,reduce_C_function=np.mean,mincnt=1,cmap='coolwarm' if signed else 'viridis',vmin=-limit if signed else 0,vmax=limit);f.colorbar(mesh,ax=ax,fraction=.045)
                values=np.sort(r.values[r.available]);other.plot(values,np.arange(1,len(values)+1)/len(values),color='#89c8de');other.set_ylabel('Cumulative fraction',color='#bfcddd')
            self.subset_note.setText(f'{int(r.available.sum()):,} supported saved observations; {int(good.sum()):,} have display coordinates. Hexagons summarize supported observations only; no prediction is inferred for unmeasured members. Units: {r.units}.')
        f.subplots_adjust(left=.08,right=.96,bottom=.2,top=.83,wspace=.48);self.subset_canvas.draw_idle()

    def draw_classification_visuals(self):
        f=self.classification_figure;f.clear();ax=f.add_subplot(111);style(ax,'Observed × predicted classes · active subset');r=self.resolved_measurement;metrics=r.summary.get('metrics',{}) if r else {};matrix=metrics.get('confusion')
        if matrix is None:ax.text(.05,.5,'Choose a Boolean/category result with saved observations.\nConfusion counts are unavailable for unverified observation-free predictions or a paired loss field.',color='white',transform=ax.transAxes)
        else:
            matrix=np.asarray(matrix);labels=[r.labels.get(str(i),{}).get('name',('True' if i else 'False') if r.kind=='boolean' else str(i)) for i in range(len(matrix))];image=ax.imshow(matrix,cmap='Blues');f.colorbar(image,ax=ax,fraction=.04);ax.set_xticks(range(len(matrix)),labels,rotation=30,ha='right');ax.set_yticks(range(len(matrix)),labels)
            if len(matrix)<=12:
                for (i,j),value in np.ndenumerate(matrix):ax.text(j,i,str(value),ha='center',va='center',color='white' if value>matrix.max()/2 else '#233449',fontsize=8)
            ax.set_xlabel('Predicted class',color='#bfcddd');ax.set_ylabel('Observed class',color='#bfcddd')
        f.subplots_adjust(left=.2,right=.92,bottom=.23,top=.84);self.classification_canvas.draw_idle()

    def draw_target_groups(self):
        names=checked(self.target_checks);page=max(0,self.group_page.currentIndex());names=names[page*2:page*2+2];f=self.group_figure;f.clear();meta=self.navigation_index.get('probe_metrics',{});records=meta.get('metrics',[]);dimensions={int(q) for q in checked(self.dimension_checks)};accounts=checked(self.account_checks)
        if not names:
            ax=f.add_subplot(111);style(ax,'No targets checked');ax.text(.1,.5,'Choose a target preset in Checklists & presets.',transform=ax.transAxes,color='white')
        for index,name in enumerate(names):
            ax=f.add_subplot(1,2 if len(names)>1 else 1,index+1);spec=meta.get('targets',{}).get(name,self.store.catalog.raw['features'].get(name,{}));kind=spec.get('kind');metric='mae' if kind=='numeric' else 'brier';style(ax,f'{name} · {metric.upper()} (raw target-specific units)')
            any_points=False
            for account,color in [('broad','#86b8ef'),('local','#e9bd7b'),('baseline','#a3b09a')]:
                if account not in accounts:continue
                selected=[r for r in records if r.get('feature')==name and r.get('account')==('broad' if account=='baseline' else account) and r.get('scope')=='Matched broad/local held-out support' and r.get('dimension') in dimensions]
                selected.sort(key=lambda r:r['dimension']);key='baseline_'+metric if account=='baseline' else metric;points=[(r['dimension'],r.get(key),r['n']) for r in selected if r.get(key) is not None]
                if points:
                    line,=ax.plot([p[0] for p in points],[p[1] for p in points],'-o',label=account,color=color,picker=6);line.navigation_target=name;line.navigation_account=account;any_points=True
                    for q,value,n in points:ax.annotate(f'n={n}',(q,value),xytext=(0,5),textcoords='offset points',fontsize=6,color='#c4cfdc')
            if any_points:ax.legend(fontsize=7)
            else:ax.text(.05,.5,'Not generated / undefined on saved support.\nPrepare prediction family explicitly.',transform=ax.transAxes,color='#bdcddd',fontsize=8)
            ax.set_xlabel('Retained dimensions · each point’s own support',color='#bfcddd',fontsize=8)
        f.subplots_adjust(left=.09,right=.97,bottom=.2,top=.85,wspace=.35,hspace=.9);self.group_canvas.draw_idle()

    def pick_group_variant(self,event):
        artist=event.artist
        if not hasattr(artist,'navigation_target') or not len(event.ind):return
        q=int(artist.get_xdata()[event.ind[0]]);self._nav_updating=True
        for widget,value,bydata in [(self.feature,artist.navigation_target,False),(self.dimension,str(q),False),(self.account,artist.navigation_account,True),(self.result_module,'probe_metrics',True)]:
            widget.blockSignals(True);widget.setCurrentIndex(widget.findData(value) if bydata else widget.findText(value));widget.blockSignals(False)
        self._nav_updating=False;self.navigation_module_changed()

    def draw_population_groups(self):
        payload=self.loaded.get('feature_distribution');f=self.population_figure;f.clear();names=checked(self.target_checks);page=max(0,self.group_page.currentIndex());names=names[page*2:page*2+2]
        if not payload:
            ax=f.add_subplot(111);style(ax,'Full membership distributions · not loaded');ax.text(.05,.5,'Choose Prediction + population or All applicable, then Load checked / Compute checked.\nThese summaries cover frozen map membership, including unmeasured anchors.',color='white',transform=ax.transAxes);self.population_note.setText('No source scan runs on tab changes. A saved full-membership summary is required.')
        else:
            a,m=payload;total=m['support']['question_members'];self.population_note.setText(f'Full frozen map membership: {total:,} items, not just prediction anchors. Missing values are counted separately; this does not replace the independent population view.')
            for i,name in enumerate(names):
                ax=f.add_subplot(1,2 if len(names)>1 else 1,i+1);record=m['summaries'].get(name)
                if not record:style(ax,name+' · unavailable');continue
                style(ax,f"{name} · known {record['known']:,}/{total:,}; missing {record['missing']:,}")
                if record['kind']=='numeric' and record.get('histogram'):
                    h=record['histogram'];edges=np.asarray(h['edges']);ax.bar(edges[:-1],h['counts'],width=np.diff(edges),align='edge',color='#80b5cf')
                else:
                    labels=self.navigation_index.get('probe_metrics',{}).get('targets',{}).get(name,{}).get('labels') or self.store.catalog.labels(name);codes=list(record['counts']);ax.bar([labels.get(c,{}).get('name',c) for c in codes],[record['counts'][c] for c in codes],color='#80b5cf')
                ax.set_ylabel('Items',color='#bfcddd',fontsize=8)
        f.subplots_adjust(left=.09,right=.97,bottom=.2,top=.85,wspace=.35,hspace=.9);self.population_canvas.draw_idle()

    def draw_audit_visuals(self):
        f=self.audit_figure;f.clear();payload=self.loaded.get('source_support')
        if not payload:
            ax=f.add_subplot(111);style(ax,'Audit measurements not loaded');ax.text(.05,.5,self.audit_state.text(),transform=ax.transAxes,color='white',wrap=True);self.audit_canvas.draw_idle();return
        a,m=payload;panels=[f.add_subplot(121),f.add_subplot(122)]
        if self.audit_view.currentIndex()==0:
            self.draw_vector_audit(panels,a,m)
        else:self.draw_neighbor_audit(panels,a,m)
        f.subplots_adjust(left=.1,right=.97,bottom=.25,top=.82,wspace=.4);self.audit_canvas.draw_idle()

    def draw_vector_audit(self,panels,a,m):
        f=self.audit_figure
        ax=panels[0];style(ax,'Source L2 norms · valid resolved context');edges=a['norm_edges'];ax.bar(edges[:-1],a['norm_counts'],width=np.diff(edges),align='edge',color='#80b5cf');ax.set_ylabel('Rows',color='#bfcddd')
        ax=panels[1];rank=m['measurements']['rank'];style(ax,f"Centered unit-vector covariance · PR {rank['value']:.3g}" if rank['value'] is not None else 'Covariance participation ratio undefined');energy=a['rank_variance'];total=energy.sum();ax.plot(np.arange(1,len(energy)+1),energy/total if total>0 else np.zeros_like(energy),color='#9dbde5');ax.set_xlabel('Singular component',color='#bfcddd',fontsize=8);ax.set_ylabel('Variance fraction',color='#bfcddd')

    def draw_neighbor_audit(self,panels,a,m):
        ax=panels[0];style(ax,'Neighbor occurrences · all saved candidates');counts=a['occurrences'];ax.hist(counts,bins=min(24,max(1,int(np.sqrt(len(counts))))),color='#c1abde');ax.set_xlabel('Occurrences (zero candidates included)',color='#bfcddd',fontsize=8)
        ax=panels[1];style(ax,'Exact duplicate groups · coordinate equality');nonempty=False
        for name,color,label in [('source_duplicate_sizes','#82bfd0','source'),('unit_duplicate_sizes','#e9bd7b','unit normalized')]:
            sizes=a[name]
            if len(sizes):codes,n=np.unique(sizes,return_counts=True);ax.plot(codes,n,'o-',color=color,label=label);nonempty=True
        if nonempty:ax.legend(fontsize=7)
        else:ax.text(.05,.5,'Measured: no repeated coordinate groups\non this sampled valid context.',transform=ax.transAxes,color='#bdcddd',fontsize=8)
        ax.set_xlabel('Group size (not similarity)',color='#bfcddd',fontsize=8)
