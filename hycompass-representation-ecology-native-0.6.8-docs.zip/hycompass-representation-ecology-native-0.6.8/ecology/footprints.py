"""Projection-aligned saved membership rasters, prepared by a single worker."""
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from threading import Lock

import numpy as np
from scipy.ndimage import binary_erosion, distance_transform_edt

from .catalog import array_digest, digest, stamp
from .store import Store

SIZE = 256
CHUNK = 65536
FORMAT = 2


class FootprintUnavailable(ValueError):
    pass


@dataclass(frozen=True)
class Footprint:
    counts: np.ndarray
    bounds: tuple
    members: int
    present: int
    projected: int
    projection: dict
    revision: str
    distance: np.ndarray


def aggregate(membership, reverse, positions, bounds, size=SIZE):
    """Bin canonical membership using the registered canonical-to-view mapping."""
    xmin, xmax, ymin, ymax = bounds
    low = np.array([xmin, ymin], dtype=np.float64)
    high = np.array([xmax, ymax], dtype=np.float64)
    if not np.isfinite([low, high]).all() or np.any(high <= low):
        raise ValueError("Invalid projection bounds")
    counts = np.zeros(size * size, dtype=np.uint64)
    present = projected = 0
    for start in range(0, len(membership), CHUNK):
        canonical = membership[start:start + CHUNK]
        if np.any(canonical < 0) or np.any(canonical >= len(reverse)):
            raise ValueError("Stale membership: canonical row out of range")
        rows = reverse[canonical]
        rows = rows[rows >= 0]
        present += len(rows)
        xy = positions[rows]
        xy = xy[np.isfinite(xy).all(axis=1)]
        projected += len(xy)
        # The maximum belongs to the final bin. Match population field clamping.
        cells = (np.clip((xy - low) / (high - low), 0, 1) * size).astype(np.intp)
        np.minimum(cells, size - 1, out=cells)
        counts += np.bincount(cells[:, 1] * size + cells[:, 0],
                              minlength=len(counts)).astype(np.uint64)
    counts = counts.reshape(size, size)
    counts.flags.writeable = False
    return counts, present, projected


def file_revision(path):
    stat = path.stat()
    return (str(path.resolve()), stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns,
            stat.st_ino)


def validate_reverse(forward, reverse, domain_size, collection_size):
    if (forward.shape != (domain_size,) or reverse.shape != (collection_size,)
            or forward.dtype.kind not in 'iu' or reverse.dtype.kind != 'i'):
        raise ValueError("Invalid stored correspondence")
    for start in range(0, len(forward), CHUNK):
        part = forward[start:start + CHUNK]
        if (np.any(part < 0) or np.any(part >= len(reverse))
                or not np.array_equal(reverse[part], np.arange(start, start + len(part)))):
            raise ValueError("Invalid stored forward correspondence")
    for start in range(0, len(reverse), CHUNK):
        part = reverse[start:start + CHUNK]
        if np.any(part < -1) or np.any(part >= len(forward)):
            raise ValueError("Invalid stored reverse correspondence")
        valid = np.flatnonzero(part >= 0)
        if not np.array_equal(forward[part[valid]], start + valid):
            raise ValueError("Invalid stored reverse correspondence")


def matches_view(definition, dataset):
    return (definition["domain"], definition["settings"].get("projection")) == (
        dataset.domain_id, dataset.projection_id)


def footprint_rgba(footprint, *, radius=6, threshold=0.38, opacity=0.45,
                   fill=True, boundary=True, points=True, color=(89, 198, 221)):
    """Compose one bounded texture from cached map-only support."""
    rgba = np.zeros((*footprint.counts.shape, 4), dtype=np.uint8)
    if not footprint.projected:
        return rgba
    field = np.exp(-0.5 * (footprint.distance / radius) ** 2)
    inside = field >= threshold
    if fill:
        rgba[inside, :3] = color
        rgba[inside, 3] = np.rint(255 * opacity * field[inside]).astype(np.uint8)
    if boundary:
        rgba[inside & ~binary_erosion(inside, border_value=1)] = (*color, round(255 * opacity))
    if points:
        rgba[footprint.counts > 0] = (*(int(0.7 * channel + 0.3 * 255) for channel in color), 230)
    return np.ascontiguousarray(rgba[::-1])


class Footprints:
    """Bounded process cache. Only complete, revision-checked data is published."""
    def __init__(self):
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="map-footprints")
        self.pending = {}
        self.lock = Lock()
        self.rasters = OrderedDict()
        self.mappings = OrderedDict()
        self.memberships = OrderedDict()
        self.coordinates = OrderedDict()

    def request(self, ds, key):
        request = (ds.session.root, ds.domain_id, ds.projection_id, ds.positions_key,
                   tuple(ds.bounds), key)
        with self.lock:
            future = self.pending.get(request)
            if future is not None and not future.done():
                return future
            future = self.executor.submit(self.build, ds, key)
            self.pending[request] = future
        future.add_done_callback(lambda finished: self._forget(request, finished))
        return future

    def _forget(self, request, future):
        with self.lock:
            if self.pending.get(request) is future:
                del self.pending[request]

    @staticmethod
    def _remember(cache, key, value, limit):
        cache[key] = value
        cache.move_to_end(key)
        while len(cache) > limit:
            cache.popitem(last=False)
        return value

    def build(self, ds, key):
        store = Store(ds.session.root)
        catalog = store.catalog
        definition = store.read(key)
        collection = definition["collection"]
        registration = catalog.raw["domains"].get(ds.domain_id)
        if registration is None or registration["collection"] != collection:
            raise FootprintUnavailable("Incompatible collection or unregistered population domain")
        collection_spec = catalog.collection(collection)
        if collection_spec["revision"] != definition["collection_revision"]:
            raise FootprintUnavailable("Stale collection revision")
        domain = catalog.manifest.domains[ds.domain_id]
        projection = catalog.manifest.projections[ds.projection_id]
        projection_path = catalog.resolve(projection.positions)
        if projection.domain != ds.domain_id or ds.session.file_cache_key(projection.positions) != ds.positions_key:
            raise FootprintUnavailable("Stale projection coordinates. Reload the population view.")
        paths = [store.folder(key) / "membership.npy", projection_path,
                 catalog.resolve(registration["forward"]), catalog.resolve(registration["reverse"])]
        identity_paths = tuple(dict.fromkeys((domain.item_ids, collection_spec["item_ids"])))
        paths.extend(catalog.resolve(p) for p in identity_paths)
        revisions = tuple(file_revision(path) for path in paths)
        for name in identity_paths:
            if stamp(catalog.resolve(name)) != registration["source_stamps"].get(name):
                raise FootprintUnavailable("Stale item identity source: " + name)
        membership_key = (key, definition["membership_digest"], revisions[0])
        mapping_key = (registration["revision"], collection_spec["revision"], revisions[2:4 + len(identity_paths)],
                       ds.n)
        cache_key = (FORMAT, SIZE, definition["revision"], membership_key, mapping_key, ds.projection_id,
                     revisions[1], tuple(ds.bounds))
        if cache_key in self.rasters:
            self.rasters.move_to_end(cache_key)
            return self.rasters[cache_key]

        mapping = self.mappings.get(mapping_key)
        if mapping is None:
            forward = catalog.load(registration["forward"])
            reverse = catalog.load(registration["reverse"])
            validate_reverse(forward, reverse, len(catalog.load(domain.item_ids)),
                             catalog.n(collection))
            if len(forward) != ds.n:
                raise FootprintUnavailable("Stale population domain. Reload the view.")
            reverse_digest = array_digest(reverse)
            self._remember(self.mappings, mapping_key, (reverse, reverse_digest), 4)
        else:
            reverse, reverse_digest = mapping
            self.mappings.move_to_end(mapping_key)
        membership = store.membership(key)
        if (membership.shape != (definition["n_members"],) or membership.dtype.kind not in 'iu'
                or (membership_key not in self.memberships
                    and array_digest(membership) != definition["membership_digest"])):
            raise FootprintUnavailable("Stale frozen membership")
        self._remember(self.memberships, membership_key, True, 32)
        counts, present, projected = aggregate(membership, reverse, ds.positions, ds.bounds)
        coordinate_digest = self.coordinates.get(revisions[1])
        if coordinate_digest is None:
            coordinate_digest = array_digest(ds.positions)
            self._remember(self.coordinates, revisions[1], coordinate_digest, 16)
        provenance = dict(id=projection.id, domain=ds.domain_id, bounds=list(ds.bounds),
                          fingerprint=digest([coordinate_digest, reverse_digest, registration["revision"],
                                              collection_spec["revision"], list(ds.bounds)]))
        distance = (distance_transform_edt(counts == 0).astype(np.float32)
                    if projected else np.zeros(counts.shape, np.float32))
        distance.flags.writeable = False
        result = Footprint(counts, tuple(ds.bounds), len(membership), present, projected,
                           provenance, definition["revision"], distance)
        if (revisions != tuple(file_revision(path) for path in paths)
                or Store(ds.session.root).catalog.raw["domains"].get(ds.domain_id) != registration
                or store.read(key)["revision"] != definition["revision"]):
            raise FootprintUnavailable("Stale source changed during preparation. Select the map again.")
        return self._remember(self.rasters, cache_key, result, 8)


footprints = Footprints()
