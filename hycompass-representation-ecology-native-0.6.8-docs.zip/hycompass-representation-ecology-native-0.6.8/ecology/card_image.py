"""Standalone share image for a saved map."""
import base64
import io
from pathlib import Path

from matplotlib import get_data_path
from PIL import Image, ImageDraw, ImageFont

from .card_report import GUIDE, family, select_highlights, value_text

WIDTH = 1200
BACKGROUND = "#0b141b"
PANEL = "#12232c"
MUTED = "#a7bebd"
INK = "#edf5f3"
MINT = "#73dfce"
GOLD = "#ffd38a"


def export_card_image(card, path):
    image = Image.new("RGB", (WIDTH, 1360), BACKGROUND)
    draw = ImageDraw.Draw(image)
    fonts = Path(get_data_path()) / "fonts" / "ttf"

    def font(size, bold=False):
        return ImageFont.truetype(str(fonts / ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")), size)

    def block(text, x, y, width, size, color=INK, *, lines=2, bold=False):
        face = font(size, bold)
        # Wrap long IDs as well as prose, then elide to keep the image bounded.
        remaining = " ".join(text.split())
        for index in range(lines):
            if not remaining:
                break
            end = len(remaining)
            if draw.textlength(remaining, font=face) > width:
                low, high = 1, len(remaining)
                while low < high:
                    mid = (low + high + 1) // 2
                    if draw.textlength(remaining[:mid], font=face) <= width:
                        low = mid
                    else:
                        high = mid - 1
                end = low
                space = remaining.rfind(" ", 0, end + 1)
                if space > 0:
                    end = space
            line = remaining[:end].rstrip()
            if end < len(remaining) and index + 1 == lines:
                while line and draw.textlength(line + "…", font=face) > width:
                    line = line[:-1]
                line = line.rstrip() + "…"
            draw.text((x, y), line, fill=color, font=face, anchor="lt")
            y += int(size * 1.25)
            remaining = remaining[end:].lstrip()
        return y

    draw.rounded_rectangle((52, 46, 1148, 98), radius=14, fill=PANEL)
    block("HYCOMPASS   /   SAVED MAP", 76, 62, 1000, 21, MINT, bold=True)
    title_size = 61
    words = card["title"].split()
    while title_size > 30 and any(draw.textlength(word, font=font(title_size, True)) > 570 for word in words):
        title_size -= 3
    y = block(card["title"], 55, 132, 570, title_size, lines=3, bold=True)
    y = block("Embedding  " + card["embedding"], 58, y + 14, 556, 24, MUTED)
    projection = card["projection"]
    if projection:
        y = block("Projection  " + projection["id"], 58, y + 7, 556, 24, MUTED)
    if card["note"] and y + 50 <= 590:
        block(card["note"], 58, y + 20, 555, 24, lines=min(5, (590-y-20)//30))

    draw.rounded_rectangle((660, 126, 1148, 590), radius=22, fill=PANEL, outline="#2b454d", width=2)
    if card["png"]:
        with Image.open(io.BytesIO(base64.b64decode(card["png"]))) as source:
            width, height = source.size
            scale = min(430 / width, 384 / height)
            thumbnail = source.convert("RGB").resize(
                (max(1, round(width * scale)), max(1, round(height * scale))), Image.Resampling.BILINEAR)
        image.paste(thumbnail, (904 - thumbnail.width // 2, 332 - thumbnail.height // 2))
        block("● Member cells", 689, 551, 220, 20, GOLD, lines=1)
        block("◒ Coverage field", 914, 551, 215, 20, MINT, lines=1)
    else:
        block(card["location"], 697, 319, 410, 25, MUTED, lines=3)

    stats = [(card["members"], "Frozen members")]
    if projection:
        stats += [(card["present"], "In this domain"), (card["projected"], "With coordinates")]
    if card["anchors"] is not None:
        stats.append((card["anchors"], "Max. measured anchors"))
    width = 1096 // len(stats)
    for i, (value, name) in enumerate(stats):
        left = 52 + i * width
        draw.rounded_rectangle((left, 625, left + width - 9, 731), radius=15, fill=PANEL)
        block(f"{value:,}", left + 16, 642, width - 35, 34, MINT, lines=1, bold=True)
        block(name, left + 16, 692, width - 35, 19, MUTED, lines=1)

    highlights = select_highlights(card["findings"])
    families = {family(row["result"]) for row in highlights}
    summaries = [row for row in card.get("overview", {}).get("modules", [])
                 if family(row["name"]) not in families]
    entries = [(row["target"], f'{row["metric"]}  ·  {value_text(row["value"])}',
                row["scope"], family(row["result"])) for row in highlights]
    entries += [(row["name"].replace("_", " "), "", row["scope"], family(row["name"]))
                for row in summaries[:3-len(entries)]]
    bottom = 760
    if entries:
        block("WHY LOOK CLOSER", 56, 773, 1080, 20, MINT, bold=True)
        for i, (title, metric, scope, module) in enumerate(entries):
            left = 52 + i * 367
            draw.rounded_rectangle((left, 815, left + 354, 1134), radius=16, fill=PANEL)
            y = block(title, left + 18, 837, 318, 26, lines=2, bold=True)
            y = block(metric, left + 18, y + 10, 318, 22, GOLD, lines=2)
            y = block(scope, left + 18, y + 10, 318, 17, MUTED, lines=3)
            if module in GUIDE:
                block(GUIDE[module][0], left + 18, y + 14, 318, 20, MINT, lines=3)
        bottom = 1164
    block("Frozen snapshot  ·  " + card["map_id"] + "  ·  " + card["revision"],
          54, bottom, 1080, 18, MUTED, lines=1)
    image.crop((0, 0, WIDTH, bottom + 48)).save(path, format="PNG", optimize=True)
