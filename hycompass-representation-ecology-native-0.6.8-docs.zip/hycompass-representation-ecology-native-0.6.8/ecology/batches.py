"""Atomic target batches: completed work survives cancellation and is verified on resume."""
from pathlib import Path
import json
import os
import shutil
import uuid
import numpy as np
from .catalog import atomic_json,checksum,digest
from .store import encode_metadata,decode_metadata


def target_batches(store,key,channel_cap=8):
    current=[];channels=0;out=[]
    for name in store.read(key)['settings']['features']:
        count=store.catalog.raw['features'][name].get('cardinality') or 1
        if current and channels+count>channel_cap:out.append(current);current=[];channels=0
        current.append(name);channels+=count
    if current:out.append(current)
    return out


def read_batch(store,key,family,targets):
    signature=digest(dict(parent=store.signature(key,family),targets=targets));folder=store.folder(key)/'batches'/family/signature
    if not folder.exists():return None
    meta=json.loads((folder/'metadata.json').read_text())
    if meta['signature']!=signature:raise ValueError('Stale target batch')
    arrays={}
    for name,spec in meta['arrays'].items():
        path=folder/(name+'.npy')
        if checksum(path)!=spec['sha256']:raise ValueError('Corrupt target batch')
        a=np.load(path,mmap_mode='r',allow_pickle=False)
        if list(a.shape)!=spec['shape'] or str(a.dtype)!=spec['dtype']:raise ValueError('Batch array schema mismatch')
        arrays[name]=a
    return arrays,decode_metadata(meta['result'],arrays)


def publish_batch(store,key,family,targets,arrays,metadata,token):
    metadata,arrays=encode_metadata(metadata,arrays)
    signature=digest(dict(parent=store.signature(key,family),targets=targets));parent=store.folder(key)/'batches'/family;parent.mkdir(parents=True,exist_ok=True);temp=parent/('.pending-'+uuid.uuid4().hex);temp.mkdir()
    try:
        if store.disk_bytes(key)+sum(a.nbytes for a in arrays.values())>store.read(key)['settings']['max_output_bytes']:raise ValueError('Batch output budget exceeded')
        schemas={}
        for name,a in arrays.items():
            token.check();path=temp/(name+'.npy');np.save(path,a,allow_pickle=False);schemas[name]=dict(shape=list(a.shape),dtype=str(a.dtype),sha256=checksum(path))
        atomic_json(temp/'metadata.json',dict(signature=signature,targets=targets,family=family,arrays=schemas,result=metadata))
        if store.disk_bytes(key)>store.read(key)['settings']['max_output_bytes']:raise ValueError('Batch output byte budget exceeded')
        token.check();os.replace(temp,parent/signature)
    finally:
        if temp.exists():shutil.rmtree(temp)


def reconstruct_batches(ctx,store,key,token,progress,compute):
    batches=target_batches(store,key);arrays={};combined=None;completed=[]
    if not batches:raise ValueError('No requested reconstruction targets')
    for i,targets in enumerate(batches):
        token.check();cached=read_batch(store,key,'reconstruction',targets)
        if cached is None:
            local={**ctx,'cfg':{**ctx['cfg'],'features':targets}}
            aa,meta=compute(local,store,key,token,progress)
            publish_batch(store,key,'reconstruction',targets,aa,meta,token)
        else:aa,meta=cached
        arrays.update({k:v for k,v in aa.items() if not k.startswith('transform_')});completed.append(targets)
        if combined is None:combined=__import__('copy').deepcopy(meta)
        else:
            combined['classification'].extend(meta['classification']);combined['classification_accounts'].extend(meta['classification_accounts'])
            for field in ('summaries','transfer','selections','status','accounts'):combined['numeric'][field].extend(meta['numeric'][field])
            combined['numeric']['coverage']['numeric_targets'].extend(meta['numeric']['coverage']['numeric_targets'])
        store.set_status(key,'reconstruction',status='running',completed_target_batches=completed,total_target_batches=len(batches),batch_bytes=sum(p.stat().st_size for p in (store.folder(key)/'batches'/'reconstruction').rglob('*') if p.is_file()))
        progress('target batches',(i+1)/len(batches))
    combined['target_batches']=completed;combined['batch_policy']='At most 8 expanded class channels per batch; a single larger category is its own batch. Shared support/router and identical fold protocol. Numeric PCA may be repeated across batches.'
    return arrays,combined
