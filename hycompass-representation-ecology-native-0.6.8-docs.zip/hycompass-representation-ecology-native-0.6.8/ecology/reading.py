"""Deterministic plain-language readings of existing measurements, not new scores."""
import numpy as np

FAMILIES=(
 ('variation','How many ways can neighbors differ?',('geometry/effective_dimension','geometry/hidden_two','geometry/radius_dimension'),
  'More directions leave room for distinctions; they are not a count of causal explanations.'),
 ('support','How much support or redundancy is nearby?',('geometry/radius',),
  'Smaller source-space radii mean closer support at the same k/context. Close-substitute and hubness profiles are not measured here.'),
 ('access','How many ways can this region be reached?',('routes/deletion_damage',),
  'Available: fixed-graph fragility. A full route-count profile is not available; no corpus-wide route claim follows.'),
 ('stress','Does this organization survive stress?',('stability/perturbation_jaccard','stability/resampling_jaccard'),
  'Higher neighbor agreement means better survival of that particular test; it is not prediction confidence.'),
)

MEANINGS={
 'effective_dimension':('Independent neighbor variation','Larger values mean the measured neighbors differ along more independent local directions. Smaller values mean a few directions account for most variation.','This is a variance-based effective count, not a count of reasons for a prediction.'),
 'hidden_two':('What the flat view leaves out','Larger fractions mean two local PCA axes omit more neighborhood variation. Smaller fractions mean those two axes retain more of it.','These local axes are different from the global atlas coordinates. A flat-looking map can still hide variation.'),
 'radius_dimension':('How quickly neighborhoods grow','Larger values suggest faster population growth as source-space distance widens. Compare the same neighbor count and context.','This radius-growth proxy can be noisy or undefined with ties. It is different from covariance dimensions.'),
 'radius':('How close the available support is','Smaller radii mean the kth neighbor is closer in the original normalized embedding. Larger radii mean the same neighbor count reaches farther.','Support is relative to the declared context, not necessarily the corpus. Closeness alone does not establish prediction accuracy or interchangeable items.'),
 'deletion_damage':('Where the fixed graph is fragile','Larger fractions mean removing this anchor disconnects more pairs on the fixed candidate graph. Smaller fractions mean less damage in this particular ablation.','Neighbors are not refilled. This is neither model retraining nor proof that no routes exist outside the measured graph.'),
 'perturbation_jaccard':('Does the neighborhood survive perturbation?','Higher overlap means more neighbors survive the tested coordinate perturbations; lower overlap means more memberships change.','This measures the declared perturbation, not semantic certainty or held-out prediction error.'),
 'resampling_jaccard':('Does support survive reference removal?','Higher overlap means neighborhoods survive the tested reference subsamples better. Lower overlap means the result depends more on which references remain.','This is a reference-set sensitivity experiment, not independent source-data resampling.'),
 'projection_neighbor_jaccard':('Does the display keep the same neighbors?','Higher overlap means the display agrees more closely with source-space neighbors among the same eligible display anchors.','Agreement is descriptive, not a guarantee that projected regions are true source-space neighborhoods.'),
 'discrepancy':('Where the feature account does not fit geometry','Positive residuals mean observed pairs lie farther apart than the feature account predicts. Negative residuals mean they lie closer.','This is a signed held-out relational residual. It is not the same as target reconstruction loss, and it does not establish a cause.'),
}


def compact_families(fields,dimension):
    out=[]
    for key,title,preferred,note in FAMILIES:
        selected=[name for name in preferred if name in fields]
        if key=='stress':
            exact=f'compression/pca_q{dimension}_jaccard';candidates=[name for name in fields if name.startswith('compression/pca_q') and name.endswith('_jaccard')]
            if exact in fields:selected.append(exact)
            elif candidates:selected.append(candidates[0])
        out.append(dict(id=key,title=title,keys=selected,note=note))
    return out


def _numeric(values,indices,mean=False):
    v=np.asarray(values)[indices];v=v[np.isfinite(v)]
    return (float(v.mean() if mean else np.median(v)) if len(v) else None,len(v))


def _format(value):return 'unavailable' if value is None else f'{value:.4g}'


def reading_for(key,values,here,ahead,*,feature_kind=None,feature_name=None,labels=None,kept=0,view_name='',scope=''):
    if values is None or key is None:
        return dict(title='Evidence is not available in this view',body='Load saved analyses, or compute the missing measurement in Compute / storage. Unavailable evidence is not a zero measurement.',reading='',limit='',context=f'{kept:,} kept items. '+scope)
    tail=key.split('/',1)[-1];mean='__q' in key or tail=='discrepancy';a,an=_numeric(values,here,mean);b,bn=_numeric(values,ahead,mean)
    statistic='Mean' if mean else 'Median';read=f'{statistic} here: {_format(a)} (n={an}) → ahead: {_format(b)} (n={bn}).'
    if a is not None and b is not None:read+=f' Change ahead − here: {b-a:+.4g}.'
    else:read+=' There is not enough finite support to compare both regions.'
    title,body,limit=MEANINGS.get(tail,('Reading the measured field','Read the saved measurement in its declared units, together with support and context.','A change on the map is descriptive evidence, not by itself an explanation.'))
    if key.startswith('compression/pca_q'):
        q=tail.split('_')[1][1:]
        if tail.endswith('jaccard'):title='What remains after dropping directions';body=f'Higher overlap means retaining {q} PCA directions keeps more of the original neighbor memberships. Lower overlap means the discarded directions change who counts as nearby.';limit='This is the recorded context-fitted compression test. A lost distinction may be useful signal or noise; check target-specific held-out errors.'
        else:title='How much vector variation was discarded';body=f'Larger residual fractions mean retaining {q} PCA directions leaves more centered vector energy out. Smaller fractions retain more of it.';limit='Discarded energy is representation loss, not feature reconstruction error or semantic importance.'
    elif key.startswith('feature/'):
        title='Following '+str(feature_name or tail);body='This is an observed source feature. Compare its local distribution and missingness before treating a color change as a meaningful transition.';limit='Here and ahead are projected regions. Their feature difference is an association, not evidence that the feature causes a geometric or predictive change.'
        if feature_kind=='boolean':
            a,an=_numeric(values,here,True);b,bn=_numeric(values,ahead,True);read=f'Positive share here: {_format(a)} (n={an}) → ahead: {_format(b)} (n={bn}). Missing is different from false.'
        elif feature_kind=='category':
            def summary(indices):
                v=np.asarray(values)[indices];v=v[np.isfinite(v)].astype(int)
                return '; '.join(f"{(labels or {}).get(str(code),{}).get('name',str(code))}: {(v==code).sum()}" for code in np.unique(v)) if len(v) else 'unavailable'
            read='Here: '+summary(here)+'. Ahead: '+summary(ahead)+'.';body='Compare which named categories occur and their known-row shares. Codes identify categories; their numerical distance has no meaning.'
    elif '__q' in tail:
        target,rest=tail.split('__q',1);q,measure=rest.split('__',1);unit='MAE in target units' if feature_kind=='numeric' else 'binary Brier' if feature_kind=='boolean' else 'multiclass Brier'
        if measure=='gain':title='Does the regional probe improve the same held-out items?';body=f'This is broad loss minus regional loss at {q} retained directions. Positive values mean the regional probe has lower {unit}; negative values mean it performs worse.'
        elif measure=='baseline':title='The training-only reference error';body=f'The baseline uses a training-fold mean or class prior. It shows how much {unit} remains without the embedding-based decoder.'
        else:title=f'{target}: {measure} held-out prediction loss';body=f'At {q} retained directions, lower {unit} means better reconstruction of this target on the measured held-out observations.'
        limit='Use the same finite support for broad/regional comparisons. Group folds and training transforms stay frozen; observer motion does not refit them.'
    hints={'Shapes & spectra':'Left: full spectra. Middle: actual PCA-3 neighborhoods. Right: one ribbon per neighbor. Local bases are independently oriented.',
           'Geometry in context':'Compact groups summarize the same saved profiles; the detailed charts and table remain available.',
           'Feature audit':'Distributions use their stated cohort/support. Probe tables report named held-out ML metrics, not a single quality score.',
           'What survives scale?':'The evaluation-region selector changes which saved observations are summarized; it does not retrain the probes.',
           'Kept selection':'The kept item set is separate from the moving here/ahead observation regions.'}
    hint=hints.get(view_name,'')
    context=(f'{kept:,} canonical items kept. ' if kept else 'No items kept. ')+scope
    if hint:context+=' '+hint
    return dict(title=title,body=body,reading=read,limit=limit,context=context)
