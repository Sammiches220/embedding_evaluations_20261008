# 0.6.0 — coordinated saved metric exploration

The baseline had reconstruction-loss map controls, a separate table browser with permissive first-array fallbacks and automatic kept-set changes, no semantic category-score adapter, no shared subset/comparison state, incomplete classification visualization and combined sampled validity exclusions. Those gaps are replaced by `navigation.py` and the integrated `navigation_ui.py`; the disconnected browser is removed.

The shared immutable selection pins analytical identities separately from viewer choices. One resolver supplies canonical support, knownness, units, rendering, labels, metrics and provenance. Map/evidence/overview/ladder controls select it without computation. Numeric, Boolean and category views, optional paired loss comparisons, explicit case keeping and subset recomputation use saved data. Empty or statistically undefined metrics remain unavailable. Protocols remain distinct from viewer subsets. Classification details expose labelled confusion/per-class records.

Explicit loads verify only selected target/dimension payloads (including a requested comparison dimension); target metadata search opens no arrays. Existing viewer residency remains bounded at 64 MB, with an additional scalar resolver cache capped at four entries / 4 MB and cleared on unload. Observer summaries are throttled at 160 ms. Family generation still retains its existing budgeted target batches. The scoped audit uses the ordinary registry/worker/planner, cooperative cancellation, signatures, atomic publication, capabilities, deletion and portable package paths. CLI and REST share backend semantics.

Affected signatures advance for saved probes, reference evaluation, resolved support, source support and external results. External descriptors are format 2. Fresh producers, consumers, tests and the bundled demo use these contracts directly; no migrations, aliases or dataset conversions were added. Ridge/fold numerical behavior, independent population membership, geometry/spectra layouts and compact resource toolbar remain in place.

## Validation result

The complete regression suite passed: **100 tests**. After the final typed-scale and unavailable-choice adjustments, all **18 focused navigation/resource tests** passed; an additional **19 scoring/camera tests** passed. All bundled demo artifact signatures and payloads were validated. The final release ZIP is integrity-tested and extracted for a second bundled-file resolution check.

## Scope and tested limits

- Small deterministic fixtures and the 360-item fresh demo cover numeric/Boolean/category browsing, knownness, absent observations, shuffled canonical joins, incompatible target revisions/codebooks/protocols, zero baseline/constant targets, empty/one-class subsets, bounded case keeping and saved viewing packages without sources.
- Actual widgets are shown and rendered at 1500×1000, including typed map colors, coordinated distributions/cases, a paired comparison and the compact toolbar. Screenshots below are ordinary Qt offscreen renders, not design mockups.
- Sample audit tests distinguish exact source versus normalized equality, non-finite versus finite near-zero rows, participation-ratio support, saved-neighbor candidate denominators, cancellation and scope refusal. Measurements are sample-only. Full-population duplicate/rank scans are intentionally unsupported.
- External losses can be locally scored with registered observations, but external protocol claims are not verified by this import contract; external loss comparisons are therefore restricted. Prediction browsing remains available.
- Cold saved-result loading verifies selected payload checksums on the explicit Load action. Large-scale I/O, native desktop OpenGL/VRAM and million-item performance have not been benchmarked. The existing worker's cancellation remains cooperative between native operations.

![Numeric prediction evidence at 1500×1000](navigation-broad-0.6.0.png)
![Categorical Brier evidence](navigation-category-0.6.0.png)
![Paired broad/regional loss improvement](navigation-comparison-0.6.0.png)

See [Metric navigation](METRIC_NAVIGATION.md) for usage and the supported audit limits.
