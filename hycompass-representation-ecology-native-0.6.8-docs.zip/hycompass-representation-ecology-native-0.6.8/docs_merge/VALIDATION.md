# 0.4.2 validation

12 targeted native camera/evidence/integration tests passed. Inspected the tighter layout offscreen at 1750 × 1200; [screenshot](native-anatomy-0.4.2.png). Numerical evidence and saved analyses are unchanged.

---

# 0.4.1 validation

12 targeted native camera, probe/evidence and integration tests passed. Shapes & spectra was rendered and visually inspected offscreen at 1750 × 1200. Ribbons occupy a wider right column; the PCA-3 hulls use a narrow center column, no axis cube/grid and a shared orthographic scale. See [native anatomy](native-anatomy-0.4.1.png). This update changes display layout/style only. Desktop population OpenGL remains unverified here.

---

# 0.4.0 validation

63 tests passed in the native/numerical suite. Added checks cover compact family availability, active compression scale, click-to-map, all seven anatomy axes and their grid positions, complete spectra and actual ribbon contents, typed Boolean/category interpretations, negative reconstruction gains, selection-aware guidance and unavailable evidence.

Offscreen Qt screenshots were inspected at 1750 × 1200 with resized map/evidence panes: [compact groups](native-compact-groups-0.4.png) and [paired anatomy](native-compact-anatomy-0.4.png). The sidebar scrolls when its readings and controls exceed the available height.

The five bundled saved maps and 17 artifacts were reopened. Requesting their existing instruments returned no work and left all 666 NPY file timestamps unchanged. No probe refits or new numerical artifacts are required by these view changes. Desktop population OpenGL rendering remains unverified in this offscreen environment.

---

# 0.3.0 verification

**60 tests pass.** New numerical/model/native checks cover camera pan/zoom invariants, 2D/3D lasso, independent color legends, real PC direction ribbons, paired anatomy, standard ML scores, agreement with saved held-out losses, grouped tables and offline reference. Final 2D/3D, geometry-profile, ribbon, probe and reference views were rendered offscreen and inspected. See `VALIDATION_0.3.json` and `RELEASE_NOTES_0.3.md`. Desktop population GL and production-scale performance remain unverified.

## Earlier release evidence

# 0.2.0 verification

**52 automated tests pass**, including nine new field-guide integration/model tests. All evidence tabs, audit subtabs, exact item tables, selections, expanded panels and 2D/3D canvases were rendered offscreen and inspected. See `VALIDATION_0.2.json` and `RELEASE_NOTES_0.2.md`. The fresh 360-item demo includes the full-question feature audit alongside saved geometry and models.

The movement path reuses its scene and performs no analytical regeneration. A 16 ms timer is a target, not a measured universal frame rate. Population OpenGL/compositor behavior remains unverified in this environment. Detached highlighting is verified at the actual native model/runtime layer.

## Baseline release evidence

# Executed validation and resource evidence

The original HyCompass suite passed **20 tests before changes**. Nine selected tests from the supplied Representation Ecology 1.3.0 suite passed. The merged suite passes **43 tests**, including real offscreen Qt canvas/keyboard tests. `VALIDATION.json` records versions, achieved demo support, per-instrument pilot times, array/disk sizes and comparison summaries. `openapi.json` is generated from the merged API.

Verification used Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, scikit-learn 1.8.0 and PySide6 6.12.0. The FastAPI test client emits one dependency deprecation warning about httpx/httpx2; requests still pass. No failing tests are suppressed.

## What was actually run

| Check | Actual bounded size / evidence |
|---|---|
| Original native regression | 20 API/runtime/query/contract tests |
| Original 1.3.0 tests | Nine tests; 480-row/8D grouped experiments, 160-row offline output, 90-row/12D spectrum checks, hull/degeneracy fixtures |
| Stored numeric regression fixture | Original unmodified accessibility kernel, 144 × 8 vectors; grouped outer/inner split, dimensions 1/2/4/8; native results within 1e-6 |
| Stored spectral regression fixture | Original Gram spectrum on 48 × 8 vectors, eight neighbors; native SVD spectrum within 1e-6 |
| Model/API integration tests | 120-item synthetic collections, shuffled/partial domains, explicit validity and source predicates, canonical API retrieval, frozen membership |
| Native integration tests | 120-item collections; actual Qt widgets and canvases, keyboard move/turn, all available feature/reconstruction fields, profiles, spectra, 3D mesh, zero relief, comparison maps and open/close |
| Full shipped small demo | 360 canonical items; 360 × 12 and 288 × 12 embeddings; up to 144 evaluation anchors; contexts of 288 or 231 rows |
| Native visual QA | Actual offscreen screenshots of 2D, 3D with local hull and paired comparison canvases; inspected locally |
| Artifact lifecycle | Incremental geometry→routes, restart/reopen, relevant-dependency reuse across definitions, cancellation before/during generation, stale completion rejection, source revision detection, label reload, disk deletion, RAM unload |
| Held-out evidence | Numeric 1.3.0 parity, negative gains, group consistency, Boolean/categorical Brier baselines, saved frozen-account reevaluation matching original per-item losses |
| Geometry evidence | Same-item comparisons, context-sensitive boundary changes, monotone sparse-graph filtration, degenerate layouts without jitter, bounded near-shortest diamond-route entropy |
| Large population / GPU benchmark | **Not run** |

The population widget could be constructed for model/state assertions, but Qt's offscreen plugin reports **QOpenGLWidget is not supported on this platform**. Population buffers, shader rendering, pan/zoom/lasso against the actual GPU and prolonged GPU resource behavior were not observed. The code remains the supplied population implementation; this is not a substitute for a user-run desktop rendering check. No browser substitute was used.

## Small pilot measurements

On the packaged demo's shared-base question, with 144 anchors, 288 context rows, 12 dimensions, k=12, five typed features and dimensions 1/2/4/8:

| Instrument | Observed seconds (one small pilot) | Saved array payload |
|---|---:|---:|
| Geometry / spectra / graph | 0.1463 | 120,920 bytes |
| Reconstruction | 0.1838 | 105,984 bytes |
| Discrepancy | 0.0308 | 83,196 bytes |
| Three perturbation/resampling repetitions | 0.0224 | 12,672 bytes |
| Routes / deletion / bounded route sets | 0.0143 | 4,608 bytes |
| PCA compression / display-neighbor loss | 0.0238 | 14,256 bytes |

These are single machine-local observations, without controlled cold-cache conditions, and include bounded context resolution and per-instrument kernels rather than desktop frame throughput. They are not calibrated predictions for larger inputs. Saved metadata is additional output; all five map folders together occupy approximately **2.70 MB** in this run. Source arrays and UI screenshots are additional files.

A 288 × 12 float32 gather has only **13,824 nominal source bytes**; actual page-cache/storage traffic may exceed that due to NumPy headers, scattered page access and repeated independent jobs. The preflight accounts separately for mapping/selection workspaces, gather/normalization copies, neighbor batches, tangent/PCA workspaces, expanded category targets and saved output. Its numerical-library workspace allowances are estimates, not measured RSS maxima or hard allocator limits. Source registration/map checks still have O(N) costs, and per-tab cache limits do not include an arbitrary number of other open tabs or the population GL cache.

## Remaining checks and limits

See `BASELINE_CAPABILITIES.md` for unfinished viewer instruments and precise port coverage. Larger input preparation and user-run desktop tests are described in `USER_GUIDE.md`. No million-row pipeline or large offline demonstration was run. Cancellation is cooperative at bounded units; publication resumes at instrument boundaries. The disk budget applies to generated artifact output within each map, while persistent folders require explicit cleanup. Concurrent CLI and GUI writers on the same workspace are unsupported.
