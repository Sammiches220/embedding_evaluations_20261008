# 0.6.1 — group visual browsing and actionable audit feedback

## Changed

- Prediction evidence now has nine separate subtabs. Full-membership distributions, multi-target/dimension curves, whole-subset visual summaries, confusion matrices and diagnostic plots make larger groups browsable. Facets show two targets per page; source audits show two plots per view.
- Checklists and broad presets default to all configured targets/dimensions/accounts and all applicable built-in resource families. One load admits the checked groups within a configurable viewer budget. Active/comparison payloads take priority, and budget omissions are explicit. Bulk case checkboxes and full-support presets include a union of worst-loss fractions per checked variant, without combining incompatible target scales.
- Exhaustive computation attempts independent families after a failure, retaining every completed artifact. GUI feedback, persisted job records, CLI and REST expose partial completion and the actual failure reasons. No display action fits or scans source vectors.
- Cached estimates now retain the embedding dimensions and measured context count, identify zero *new* work, and report saved-payload/verification I/O. Missing audit work still has nonzero structural estimates. Action feedback distinguishes queued/running, loaded/measured, saved/unloaded and failed/cancelled states; estimates are not overwritten by polling. The compact resource actions follow the current visual subtab.
- Source audits now persist norms, singular-energy spectrum, exact duplicate-group sizes and saved neighbor occurrences for reproducible graphical browsing. The affected `source_support` signature advances to revision 4. The fresh bundled demo uses the current contract; there are no readers, migrations or conversions for old audit payloads.

## Validation and limits

The complete regression suite passed **109 tests**. Final focused checks cover cached versus missing audit estimates, bounded batch residency, preset selection, support totals, larger item presets, scale-independent unions of per-variant cases, subtab-specific resource actions, source diagnostics, job partial completion and cancellation. Widgets are shown/rendered at 1500×1000. A 1,200-item fixture verifies full-map summaries over 960 frozen members versus 144 prediction anchors. This verifies support semantics and usability on small fixtures, not million-item throughput.

Full-member source distributions are streamed explicit jobs. Reconstruction plots still describe saved measured anchors; no extrapolation fills unmeasured members. Source audits retain the 8192 × 512 cap and sample-only scope. Native SVD/sort blocks remain cooperatively cancellable between checkpoints. Analysis budgets remain declared per family, while viewer RAM can be set separately. External producer aggregates are not folded into the verified built-in curves.

See [Metric browsing](METRIC_NAVIGATION.md) for the current workflow.

![Checked target curves](group-targets-0.6.1.png)
![Full map membership distributions](group-population-0.6.1.png)
![Visual source audit and measured support](group-audits-0.6.1.png)
![Checklists and broad presets](group-batch-0.6.1.png)
