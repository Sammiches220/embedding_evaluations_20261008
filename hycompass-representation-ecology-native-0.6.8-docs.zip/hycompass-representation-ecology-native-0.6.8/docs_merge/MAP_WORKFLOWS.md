# Map workflows

Map definitions freeze canonical membership, embedding identity, sampling and analysis settings. A map never replaces the population view. Population coverage rasters use the separate `coverage_field` vocabulary.

## Start

```bash
python -m pip install -r requirements.txt
python main.py --workspace demo_workspace --map shared-base
```

Open **Open map…** in the toolbar to manage saved maps. The manager supports searching, opening, renaming, duplicating definitions, unloading viewers, deleting results/maps, exporting packages and attaching exact layers. Renaming edits metadata and preserves analytical results. Duplicate creates a new identity without copying results; compatible results can be reused during generation (payloads still consume disk space).

Each screen shows its required resources with a **Compute missing + load this screen** button and a saved-only load action. The Compute / storage table has checkboxes with Check all / Clear checks / Use preset and bulk compute/load/unload controls. Loading adds to existing viewer resources. Tabs do not silently compute or load resources. Compact geometry cards have their own group action.

The cost preview includes Big-O time and peak space for checked resources. Detailed estimates define every symbol and include output-space bounds, prerequisite kernels and saved-loading costs alongside numeric estimates. See [0.5.1 workflows](RELEASE_NOTES_0.5.1.md).

**Browse saved results** opens target/module/scope/metric navigation. Result selection never initiates fitting.

A missing source disables only dependent computations. Saved results remain viewable against their recorded identities. A changed available source marks dependent results stale. Missing groups never trigger an automatic replacement evaluation protocol.

## Offline commands

```bash
python -m ecology.cli --workspace demo_workspace list-maps
python -m ecology.cli --workspace demo_workspace capabilities shared-base
python -m ecology.cli --workspace demo_workspace plan shared-base --instruments geometry neighborhood_agreement
python -m ecology.cli --workspace demo_workspace generate shared-base --instruments neighborhood_agreement
python -m ecology.cli --workspace demo_workspace rename shared-base "Reference population"
python -m ecology.cli --workspace demo_workspace duplicate shared-base "Another question"
```

`resolved_support` saves ordered valid anchor/context rows and exclusions. `neighbors` saves separate anchor-to-context and anchor-only searches. Exact search excludes self and resolves equal distances by ordered context index. `neighborhood_agreement` measures known-neighbor support and typed local agreement; it is descriptive, not a leakage-free prediction experiment. `feature_distribution` summarizes full frozen membership without requiring embeddings.

Reconstruction batches targets by expanded class-channel count. Completed batches are atomic and checksum-verified; rerunning a cancelled computation resumes them. The result browser exposes saved checkpoints as reconstruction--<signature> variants, including completed work from an interrupted run. The final result retains the established group-held-out Ridge/router protocol. The active-feature cap remains 16; this release does not assume unlimited target cardinality is safe. Numeric PCA may repeat across target batches, while its saved transform payloads are deduplicated within a result.

## Locate saved maps in the population

1. Open a population view and turn on **Saved maps → Show Saved maps layer**. The sidebar lists maps saved for that exact domain and projection. Check up to eight maps to overlay their points and fields together. The swatches identify their colors. Click any row for its profile. Filtering the list leaves checked maps visible on the chart. A map saved with map-local PCA or with another projection remains accessible in the map manager. **Define map** starts with the active population projection selected. Use **Refresh** to rescan after changes outside the UI.
2. The overlay draws occupied cells from frozen membership and a coverage field on the same 256 × 256 grid. Field strength falls with distance from the nearest occupied cell. Use **Spread**, **Threshold** and **Field opacity** to adjust it, and toggle **Field**, **Boundary** and **Points** independently. A large spread can connect nearby regions. The thumbnail always uses the map's own points and field on a plain background.
3. **Open map** or double-click the entry to open or focus its interactive tab. The field can be available for a definition-only map without saved interactive geometry. The preview reports missing or stale sources and zero projected members. If the view's coordinate asset changed on disk, reload the workspace assets before refreshing the layer.

The footprint uses the view's registered collection correspondence. It describes frozen membership independently of working selection, highlights, timeline and visibility filters. Pan and zoom only move the raster on screen. The field and point style are per-view and persist in a Saved View.

## Exchange a portable map card

Choose **Map card…** in the population sidebar or map manager. The manager's **Edit card note** action saves a question, motivation or context as map metadata. The in-app preview shows a compact profile with a points-and-field thumbnail, member count, projection and short note. For a population thumbnail from the manager, open the map's exact population projection first.

Below the profile, **Broad overview** selects result summaries and a spread of saved findings across result families and targets. Result summaries are independently checkable, even when a result has few scalar measurements. Use the family filter or hide individual measurements to work at the summary level. The target distribution, model evaluation and geometry/support presets narrow the selection. Search and check individual findings to adjust any preset. Changing the checklist filter keeps checked rows selected, including hidden rows. Exports include the compact profile, a definition summary, a saved-result inventory and up to 96 chosen findings with scope and provenance. These summaries read saved headers without embedding analysis arrays or running new analyses.

- **Export card (PNG)…** saves a single shareable image with the map thumbnail, profile, coverage counts and up to three selected highlights.
- **Export report (HTML)…** creates a self-contained, responsive map page. It opens with the map thumbnail and membership coverage, then groups charts by questions about neighborhood shape, robustness, item distributions and model evidence. Checked result summaries include their available chart previews. Individual findings can still be included separately. Depending on the saved results, previews include local spectra, neighborhood-radius and dimensionality distributions, graph connectivity, perturbation and compression tests, frozen target distributions, and held-out reconstruction curves. Previews summarize bounded saved arrays and metadata. They carry their scope and do not rerun analyses. Read the inline interpretation notes for what to look for and what the measurement can support. Expand chart values, findings and provenance for details. The charts use saved summary values and can be read offline.
  The **Feature representation and reconstruction** section appears when saved per-feature evidence exists. By default it includes all available features, independent of the highlight checklist. Uncheck the feature explorer option to omit it. Search, filter by type or evidence, and sort by observed coverage. Select one feature and one metric, account and evaluation scope to see the saved curve, exact values, support and provenance. The explorer is the primary home for feature distributions and reconstruction curves. Charts duplicated by the explorer move out of the static chapters. Reports with the explorer turned off retain the static charts. Geometry associations and held-out measurements stay separate. Results from completed batches can appear before a finalized reconstruction is available. The explorer runs locally inside the exported page.

- **Export JSON…** creates a versioned snapshot capped at 512 KiB. In the destination project, use **Open map… → Imported cards… → Import card JSON…**. Reimporting the same card keeps one snapshot. Use **Show exported overview and findings** to expand the profile. Version 1 cards remain readable.
- **Open map** in the card browser requires an exact local map ID and definition revision. **Show in population** requires the map's exact domain and projection to be open and checks any projection provenance recorded on the card. A card without a local match remains readable in the browser.

For sharing the interactive viewer and its saved artifacts, use the `viewing` profile of the existing package workflow.

### Footprint verification and scale

Regression tests cover disjoint and overlapping occupancy, max-extent bins, full and partial correspondence, nonfinite coordinates, definition-only maps, map tab reuse, population state isolation, projection switches, cache invalidation, card validation and exact local matching. The existing population and package checks run in the same test suite.

For the original saved-map point raster, a synthetic 20,000,000-row fixture used file-backed membership, coordinates and forward/reverse correspondence. On the verification host, chunked validation, source fingerprints and raster aggregation took **1.96 s** together. Aggregation with validated input took **1.25 s**. Peak traced working allocations were **4.57 MiB**. Process RSS reached **687 MiB** from a **71 MiB** baseline, including up to **610 MiB** of mapped input pages. The fixture used contiguous identity correspondence. Highly scattered gathers can have different I/O costs.

One count raster is **512 KiB**. The process retains up to eight completed rasters, each with a **256 KiB** cached distance grid, and four validated memory-mapped correspondences. Each enabled view with a visible footprint holds one **256 KiB** draw image. Checked maps are composited into a single image whenever a checkbox, footprint or style changes. There is one image draw per frame with no additional population-sized render buffers. For the original overlay at 1280 × 800, the isolated Qt raster draw took **0.55 ms** at 1× and **1.00–1.02 ms** at 8× and 5000×, using five batches of 1,500 draws per zoom. This measures the incremental draw on an offscreen CPU surface. GPU timing and full-frame interactive throughput depend on the display and driver.

## Portable packages

```bash
python -m ecology.cli --workspace demo_workspace export shared-base reference.hcmap --profile viewing
python -m ecology.cli import-package reference.hcmap relocated_workspace
python main.py --workspace relocated_workspace --map shared-base
python -m ecology.cli --workspace demo_workspace export shared-base full.hcmap --profile full
python -m ecology.cli --workspace relocated_workspace attach-package full.hcmap
```

Profiles:

| Profile | Content |
|---|---|
| `definition` | Definition, canonical identities/correspondences, membership and source declarations |
| `viewing` | Definition plus complete saved results and self-contained view support |
| `embeddings` | Definition plus embeddings, available display coordinates and groups |
| `targets` | Definition plus typed values/knownness/codebooks and groups |
| `full` | Selected map and frozen-reference closure, available source layers and saved results |

A definition-only map can be inspected; it has no renderable landscape until geometry exists. Viewing packages need no original vectors or targets. Imports create a **new workspace directory** and refuse existing destinations. Full source identity and row ordering are preserved; no row compaction or implicit remapping occurs.

Package payloads are streamed with full SHA-256 checksums, deduplicated within the package and stored without expensive recompression. Import checks paths, expanded bytes, numeric-array safety, payload checksums, analytical definitions, dependency signatures and saved support before atomically publishing the workspace. Optional omitted layers produce capability reasons. Attach requires the same immutable map/source definitions, accepts only declared missing exact layers and can be retried after interruption. Changed/new data belongs in a separately registered revision and new map.

These packages intentionally contain only the chosen map/reference and analysis-display closure. Unrelated population densities, segmentations, themes and saved views are outside that closure. Whole-workspace backup is a separate operation.

## REST and headless operation

```bash
python -m ecology.cli --workspace demo_workspace serve --host 127.0.0.1 --port 8765
```

API version 0.7.0. Open `/docs` for the generated contract. GUI and API share one bounded heavy worker per workspace/process. Cooperating processes use a workspace writer lock. Direct writes against a workspace with an active writer are refused promptly; analytical work is queued through the job service. Queued/running records become interrupted after worker restart; completed components/batches remain reusable.

Important routes:

- `GET/POST /ecology/maps`, `GET/PATCH/DELETE /ecology/maps/{key}`
- `GET /ecology/maps/{key}/capabilities`, `/plan`, `/deletion-preview`, `/results`
- `POST /ecology/maps/{key}/jobs` with `map_revision` and `instruments`
- `GET /ecology/jobs/{job_id}`, `POST /ecology/jobs/{job_id}/cancel`
- `POST /ecology/maps/{key}/results/external`
- `GET /ecology/maps/{key}/results/{component}/arrays/{array}?signature=…`
- `POST /ecology/maps/{key}/export`, `/ecology/packages/import`, `/ecology/packages/attach`

Job changes publish small `map.job.changed` events through the existing replay/resync stream. Job snapshots are authoritative. Progress is coalesced in memory and terminal records persist; cancellation remains cooperative at bounded checkpoints, not a hard kill of a native numerical call. At most eight map jobs are queued/running through the job service.

External registration accepts bounded typed canonical IDs, predictions, optional knownness, target kind, producer provenance, explicit evaluation scope and a pinned map revision. Each external variant is independently addressed (`external_<result_id>`). Duplicate/unknown IDs, membership violations, invalid probabilities and target schema mismatches fail. Missing observed targets do not block prediction viewing. Producer metrics are labelled unverified and never silently treated as equivalent held-out results. Category columns follow the registered target code order when a target exists; otherwise they are positional codes 0…C−1.

Binary arrays stream as `.npy` files. Registration accepts up to 100,000 inline rows; large remote uploads and remote object storage remain outside this local-service implementation. Package routes use server-local paths.

## Formats

Workspace format 4, ecology catalog 2, map definition 1, result component 1, package 1. Only these contracts are accepted. There are no old exploration endpoints/flags, schema aliases, migration commands or dataset conversion readers. Generate a fresh workspace with `python -m ecology.cli --workspace NEW_DIRECTORY demo`.
