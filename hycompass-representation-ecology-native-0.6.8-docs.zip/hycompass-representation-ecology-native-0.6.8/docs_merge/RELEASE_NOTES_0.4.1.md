# 0.4.1 — clearer neighborhood shapes and wider ribbons

Shapes & spectra allocates a narrow center column to PCA-3 neighborhoods and gives the recovered width to the direction ribbons. Spectra remain left, here above ahead, with covariance dimensions below.

PCA-3 hulls use a compact orthographic camera without the axis cube, ticks, pane backgrounds or 3D grid. Brighter outlined points and more visible hull faces/edges emphasize the measured neighborhood. Both endpoints share identical world limits, camera settings and magnification; a shared chord-scale caption preserves size context. The source offsets, hulls, spectra and direction scores are unchanged.
