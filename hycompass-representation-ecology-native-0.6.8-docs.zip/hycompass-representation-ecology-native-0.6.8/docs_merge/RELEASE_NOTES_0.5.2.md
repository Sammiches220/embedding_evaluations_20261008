# 0.5.2 — compact resource toolbar

The three screen-resource actions now sit immediately to the right of **Reference / help** in the existing map toolbar. Their short labels are **Prepare** (or Load/Retry as appropriate), **Load saved**, and **Select**. They use fixed-height compact buttons.

A single-line resource status follows the three buttons: Ready, Working, or counts to compute/load. Detailed requirements and errors are available in tooltips. The separate resource heading and explanatory paragraph have been removed, returning their vertical space to the map and evidence panes. Bulk controls and complexity estimates are unchanged.

![Compact resource toolbar](compact-toolbar-0.5.2.png)
