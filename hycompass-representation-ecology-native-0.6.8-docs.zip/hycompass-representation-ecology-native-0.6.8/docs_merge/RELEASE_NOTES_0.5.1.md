# 0.5.1 — screen preparation and bulk resources

Each map screen now has a visible resource bar showing what it needs, how many results must be computed, and how many saved results need loading. **Compute missing + load this screen** resolves prerequisites, computes only missing results, then loads the requested resources. **Load saved for this screen** never starts computation. **Select this screen’s resources** checks the matching items in Compute / storage.

Nested screens have different requirements: the regression/classification probe tables request `probe_metrics`, distributions request `feature_audit`, shapes request `geometry` and `directions`, and scale curves request reconstruction or the map's frozen-reference evaluation. The current prediction/discrepancy coloring is included when it needs additional results. Compact geometry cards also have their own compute/load buttons, so an access or stress card can be prepared without generating every other geometry measurement.

The Compute / storage table is checkable. **Check all**, **Clear checks**, and **Use preset** control the selection; **Compute checked + load**, **Load checked**, **Unload checked**, and **Unload all** operate on the selection. Check all excludes model families that cannot apply to the map's declared targets/reference. Prerequisites are resolved by the backend. The dropdown remains available for inspecting one component's method or deleting one saved result.

Loading is additive. A job remembers its requested resource set even if the selected tab or inspection dropdown changes before completion. Unloading does not delete saved files. Geometry is retained when other resident map results still require it as a display scaffold; Unload all releases the complete viewer. Switching tabs no longer silently loads modules or starts computation. A missing or stale dependency remains an explicit error rather than silently regenerating an immutable result.

## Complexity estimates

Big-O time and peak working-space bounds now appear beside the numeric resource estimates for checked resources. **Inspect detailed cost estimate** includes persistent output-space bounds, the full prerequisite closure, per-family notes, a complete symbol key, and the existing numeric estimate. The same structured information is returned by CLI `plan` and REST map-plan requests.

Examples:

| Operation | Time | Peak additional working space |
|---|---|---|
| Exact context + anchor neighbors | O(A R D + A R + A k log k + A² D) | O(B R + A k) |
| Tangent geometry from saved neighbors | O(A k D min(k,D) + E log A + L(A + E)) | O(k D + k² + A k + L A) |
| Source-only distributions | O(M T) | O(B + T) |
| Saved-result verification/loading | O(V + M) | O(V) viewer copies |

A = measured anchors, R = sampled context rows, D = embedding dimensions, k = neighbors, B = processing block rows, M = map membership, T = targets, E = graph edges, L = filtration levels, and V = selected saved payload bytes. All other symbols used by reconstruction, routing and stability are defined in the detailed estimate.

The bounds describe the current exact kernels and declared support. Kernel time adds missing prerequisite computations and one shared input-resolution pass. Peak RAM counts simultaneously live inputs/outputs plus scratch, rather than adding every kernel's scratch requirement. Saved results are labelled as saved/reuse instead of suggesting their kernel must run again. Big-O bounds do not predict seconds; actual byte/work estimates and budget guards remain separate.

![Bulk resource controls](resource-checklist-0.5.1.png)

![Screen resource actions](screen-resources-0.5.1.png)
