# Metric browsing: groups first

Open `python main.py --workspace demo_workspace --map shared-base`. Choose **Will it predict here? → Prediction evidence**.

## Compute and load a broad set once

In **Checklists & presets**, targets, retained dimensions and accounts start checked. Use **All applicable** for every applicable built-in resource family, or **Prediction + population** / **Geometry + audits**. The resource checklist shares its state with Compute / storage. Target presets include all targets, numeric, Boolean/category, the current target, and none.

**Compute checked · continue errors** explicitly attempts the checked families and their prerequisites on the normal worker. Each family retains its declared time/work/RAM/disk budgets. Completed results remain saved; a failed or unsupported family is reported and does not suppress attempts at independent families. The final feedback lists completed and failed families; partial batches also appear in the compact toolbar. Cancel stops the batch cooperatively at a checkpoint. No checkbox, preset, tab or plot click starts computation.

**Load checked** loads the checked targets and dimensions in one action. The active target/dimension and comparison take priority. Complete target/dimension groups are loaded within the viewer limit; omitted groups are explicitly reported as saved but not resident. Increase **Viewer RAM** (64 MiB–1 GiB) and Load checked again to admit more saved groups. This changes the viewer budget, not analytical budgets. Computation still generates the configured target/dimension family, rather than promising per-cell fitting. Checked accounts filter group curves; loaded groups retain complete saved accounts and class columns.

## Visual tabs

| Subtab | What it shows |
|---|---|
| Distribution | The active measurement across every supported observation in the displayed subset, rather than only the case list. |
| Subset visuals | Numeric measurement hexagons plus its cumulative distribution, or named categorical groups. It uses all supported observations with available coordinates and declares unprojected/missing support. |
| Across targets | Broad, regional and baseline curves for checked targets and dimensions. Two targets per page keep the plots legible. Every point reports support; raw numeric and Brier values stay in separate target panels. Click a point to select that saved variant. |
| Full membership | Saved numeric histograms and named class counts for all items in frozen map membership, including items outside the sampled prediction anchors. Known/missing counts remain explicit. This is not a claim about an entire collection outside the saved map. |
| Cases & keep | A checkable bounded case list plus bulk item presets. Check all/clear checks and Keep checked cases avoid item-by-item selection. |
| Classification | Observed × predicted confusion counts for the active subset, with class labels and detailed per-class statistics. |
| Source audits | Norm histograms, covariance spectrum/participation ratio, neighbor occurrences including zero-occurrence candidates, and exact duplicate-group sizes. Two plots at a time retain useful space. |
| Availability | The target × variant table with saved/loaded/unavailable and support states. |
| Checklists & presets | Broad target/dimension/account and resource selection, bulk computation/loading, and viewer RAM. |

**Full membership** needs the `feature_distribution` resource. Its plots come from a streaming source-only job, or a saved summary. It never scans source columns on a tab change. **Across targets** uses saved held-out aggregates on each variant's own support; changing the observer subset does not silently turn those global saved curves into regional metrics. Region-specific measurements remain in the active Distribution, Subset visuals and Classification tabs. No view infers predictions for unmeasured items.

Use the existing **Expand evidence** control when a plot deserves the full right pane. Each subtab has its own space; cases, classification, availability and resource lists no longer share one small vertical stack.

## Keep larger item subsets

The case list remains capped at 50. Bulk presets operate on their declared complete support:

- All supported observations in the displayed subset.
- All measured anchors.
- Highest absolute active measurement 10% (not available for category codes).
- Union of the worst 10% of losses independently in each checked target/account/dimension. Raw target units are never pooled into a score; unavailable groups are counted.
- Here and ahead.
- All frozen map members, including unmeasured items.

Only a Keep action changes the kept set. Map membership and the independent population view remain unchanged. Linking uses the existing link preference.

## Read individual measurements and comparisons

The searchable **Follow feature** picker still selects the active target. Choose a saved account, dimension and display: observed value, prediction, error or training-baseline improvement. Numeric residuals use a signed scale; Boolean scores retain [0,1]; named categories remain flat categorical colors. Classification decoders are clipped/normalized linear Ridge outputs, not calibrated logistic models. Log loss clips class scores to [1e-12,1], then row-normalizes them. Numeric Error is absolute error; Squared error summarizes RMSE from predictions. R² is an aggregate only.

Choose all measured anchors, here, ahead or kept. Subsets filter saved observations; they never change the evaluation protocol or train an account. Empty regions and undefined statistics remain unavailable. Classification details expose labelled confusion/per-class records.

In Error view, choose comparison B to see **loss A − loss B**, positive where B has lower loss. Means use the exact paired canonical intersection. Revision, units, codebook, collection and evaluation assignments must match; changed contexts are disclosed. The original dimensional ladder remains available and declares its support policy.

## Audit feedback

An estimate for a cached audit now reads **Already saved: rows × dimensions; zero NEW compute**, followed by nonzero saved-payload/checksum I/O bytes. Zero new compute means reuse, not a measurement of zero cost or an empty audit. Missing audits instead report estimated operations, RAM and additional output, or a concrete budget/scope refusal. Actual generation time is shown as an observation, not a forecast.

**Prepare / load audit** opens the visual audit tab and reports queued/running, loaded/measured, failed, cancelled, or saved/unloaded states. The compact toolbar follows the current visual subtab: audit actions request `source_support`; population actions request `feature_distribution`. The sidebar also has **Open visual audits**. Estimates remain visible separately from live action feedback.

The audit remains bounded to 8192 resolved context rows × 512 embedding dimensions. It reports sampled non-finite and finite near-zero exclusions separately (source L2 ≤ 1e-8). Duplicate equality is exact source-coordinate or individually unit-normalized equality, with signed zeros equal; it is not near-duplicate similarity. Covariance participation ratio uses centered unit-normalized valid context. Neighbor occurrence denominators describe the actual saved anchor-to-context search. None is a corpus-wide diagnosis. Unsupported audits are reported; an exhaustive batch continues other families.

## Portable results and backend

Viewing packages preserve saved observations/knownness, predictions, losses, labelled target revisions and protocol metadata, plus saved population summaries and diagnostic plot arrays when included. Missing source vectors/target columns do not prevent browsing their saved results. Observation-dependent views stay unavailable if their observed arrays are absent. External predictions use their producer result, External producer account and dimension 0. Producer aggregates/protocol claims remain unverified; local losses can be scored with matching registered truth, but external loss comparisons remain restricted.

```bash
python -m ecology.cli --workspace demo_workspace plan shared-base --instruments source_support
python -m ecology.cli --workspace demo_workspace generate shared-base --instruments source_support feature_distribution --continue-on-error
```

REST jobs accept `continue_on_error: true` and return `partial` with a failure map when independent families fail. Ordinary jobs retain fail-fast behavior. CLI continuation returns an explicit completed/failed report. `Selection`, `resolve_saved`, `compare_resolved`, `POST /ecology/navigation/resolve` and `resolve-navigation` share the saved metric contracts. Navigation choices do not alter analytical revisions.
