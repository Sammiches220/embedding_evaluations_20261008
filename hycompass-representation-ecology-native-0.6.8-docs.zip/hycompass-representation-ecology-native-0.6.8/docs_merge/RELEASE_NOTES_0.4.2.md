# 0.4.2 — tighter Shapes & spectra

The center PCA-3 allocation is reduced from 0.5 to 0.3 relative width units, while direction ribbons increase from 1.7 to 2.2. Horizontal and vertical gaps are reduced. The hull camera magnification increases to keep the measured shapes legible within the narrower column. Endpoint scale remains shared. Ribbon unit labels move to the outside right edge to avoid the compact hull views.

12 targeted native tests passed; the updated layout was visually inspected offscreen. The ZIP was fully extracted and all contents compared with source.
