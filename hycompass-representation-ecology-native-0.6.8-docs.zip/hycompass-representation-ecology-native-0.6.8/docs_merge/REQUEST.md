# Implement a native HyCompass–Representation Ecology merge

## Inputs and instruction

You are receiving this prompt with two source archives:

1. **HyCompass**, supplied as `hycompass_20261101_archive(1).zip` or an equivalently named HyCompass archive.
2. **Representation Ecology 1.3.0**, supplied as `representation-ecology-1.3.0.zip`.

Use **Representation Ecology 1.3.0** as the analytical and detailed-interaction baseline. Do not substitute later population-extension versions. Inspect the actual archives, including applicable project instructions, rather than assuming directory names or treating this prompt's architectural observations as a substitute for reading the code.

**Implement the merge.** First establish the baselines and explain your concrete approach briefly, then implement, validate, package, and deliver the resulting native application. Do not stop at a proposal, interfaces with no working instruments, or a thin demonstration that leaves the core workflow unimplemented.

Make reasonable implementation decisions within these requirements. The goal is a coherent working application, not a speculative framework. Report genuine constraints and unfinished requirements explicitly; do not quietly redefine completion around whichever subset was easiest.

## 1. Product objective

HyCompass becomes the complete native desktop platform. Its large-population browsing is the persistent foundation. Representation Ecology contributes detailed, scoped analyses and their navigable landscapes.

The intended experience is:

> I can browse the whole population using HyCompass, choose items or a question, generate and save a more detailed map, navigate that map using the richer Representation Ecology instruments, compare it with other embeddings or selections, and return to the unchanged population baseline. I can see the cost and evidential consequences of each compromise.

This is a merge into HyCompass's native PySide6/OpenGL form. The final application must not depend on the browser explorer, an embedded web page, or launching another application to perform its core detailed interactions. The old browser implementation can inform behavior and numerical regression fixtures; it is not the target runtime.

The population and detailed map interfaces may be different workspaces within the same native application. Do not force the detailed observer and every technical control onto the millions-of-points population view. Equally, do not create disconnected tools with unrelated selections, identities, or result management.

### Conceptual foundation

The top-down/bottom-up distinction concerns broad accounts versus accounts that depend on particular contexts. Computational accessibility is part of investigating that distinction: how far can an account extend, what detail does it retain, what local specialization does it need, and what does it cost?

Preserve these qualifications:

- Cheap computation does not establish global meaningfulness.
- Expensive computation does not establish local meaningfulness.
- Model failure does not prove intrinsic complexity or noise.
- High geometric variation can contain important distinctions.
- A projected region need not be an original-space neighborhood.
- Reconstruction adequacy, feature-to-geometry discrepancy, and projection/compression loss are different measurements.

The application investigates these questions through explicit geometric measurements, held-out experiments, feature relationships, and stability evidence. Do not replace them with one understanding, meaningfulness, or knownness score.

## 2. Preservation means useful behavior, not legacy formats

This is a new combined starting point. No production data migration is required.

Do not implement:

- Saved-analysis migration or legacy workspace converters.
- Compatibility readers for old generated browser payloads.
- Refresh commands that rewrite previous outputs into the new format.
- Parallel old/new implementations retained solely because historical files might exist.
- New general-purpose data ingestion, ETL, plugin-discovery, or distributed execution frameworks.

Preserve useful analytical definitions, interaction capabilities, and proven performance characteristics through tests. Refactor or replace structure when that makes the merged application coherent. Remove genuinely superseded code where appropriate, while retaining code that still implements supported functionality.

Preserve the useful semantics of HyCompass's native asset/query/selection/API workflows in the merged model. Their internals and request contracts may change coherently where item identity requires it. Update callers, tests, documentation, and OpenAPI together; do not add legacy endpoint shims solely for historical clients.

Generate fresh demo workspaces and outputs using the new model.

## 3. Establish the actual baselines before editing

Run only small, inexpensive fixtures. Do not run a million-row benchmark or the large offline demonstration during implementation.

### HyCompass baseline

Inspect and record the actual status of:

- Native population rendering, pan/zoom, picking, lasso and selection.
- Multiple domains/embeddings, projections, views, and asset registration.
- Cluster coloring, density fields, contours, segmentations, map overlays, and timeline behavior where supported.
- Working selections, predicates, visibility, focus, highlights, candidate results, and result sets.
- Query/features API, revision/delta events, and GUI/API state consistency.
- Memory-mapped data access and large-data preparation.
- Resource sharing across views and GPU resource lifetimes.

Useful source locations identified in the supplied reference include:

- `model/workspace/{manifest,session,assets,registration,preparation}.py`
- `model/source/numpy_source.py`
- `model/source/indexed_numpy_source.py`
- `model/query/{engine,features,language}.py`
- `model/spatial_index.py`
- `model/analysis/{base,representative_candidates}.py`
- `api/runtime.py`, `api/routes/`, and `api/schemas/`
- `render/{renderer,resources,shared_resources}.py` and `render/layers/`
- `ui/main_window.py`, `ui/map_widget.py`, and `ui/panels/`

Verify these observations in the actual code:

- The indexed NumPy source can read selected domain rows in chunks.
- The spatial index is projected-space picking/selection infrastructure, not an original-vector neighborhood index.
- Existing map/familiarity values are not equivalent to analytical measurement coverage.
- Shared static OpenGL resources are cached for the process lifetime; temporary analysis resources need bounded ownership.
- Background point caps do not necessarily reduce the number of vertices submitted by the point renderer.
- FeatureProvider exposes native assets; it is not already a complete source-feature system.

Do not claim to have validated tens-of-millions performance by running a tiny fixture. Treat the working HyCompass renderer as the baseline to protect, and document unmeasured scaling claims.

### Representation Ecology 1.3.0 baseline

Inspect and verify, where actually implemented:

- Observer navigation, here/ahead attention, and linked profiles.
- Continuous fields, contours, points, 2D/3D terrain and relief.
- Geometry interpretations, local shapes/clouds, and spectra.
- Feature selection, distributions, queries, selections, and exports.
- Feature-to-geometry discrepancy and prediction evidence.
- Broad/local reconstruction, retained-dimension ladders, matched gains, validation-selected accounts, and transfer comparisons.
- Candidate-graph filtration controls.
- Detailed geometry, perturbation/resampling, route/fragility evidence, feature audit, and optional bounded topology.

Relevant source families include `src/representation_ecology/`, `src/geometric_ecology/`, `src/parquet_audit/`, and `src/embedding_feature_audit/`. Inspect the numerical implementations as well as the viewer.

Record missing or partial capabilities honestly. Optional topology is not the same as an already complete interactive global persistence system. Build a small numerical/interaction reference before changing the analytical pipeline.

Deliver a baseline capability matrix and use it to track the native port. A formerly working instrument must become a real native instrument or be explicitly reported as unfinished, not silently removed or represented by a decorative control.

## 4. Introduce item identity above embeddings

Create a minimal item-collection abstraction that lets selections and source attributes retain meaning across embeddings.

### Required objects

| Object | Meaning |
|---|---|
| Item collection | Canonical item identities and their membership universe. |
| Embedding | A vector representation of some or all collection items, with explicit row correspondence. |
| Projection | Display coordinates associated with an embedding or a recorded analytical map. |
| Selection | Membership expressed in canonical item identity, with an efficient internal row representation. |
| Map | A saved analytical definition and its generated artifacts, contexts, accounts, and navigation state. |
| Analytical artifact | A graph, spectrum set, field, segmentation, model, projection, or other scoped result. |
| Presentation metadata | Human-readable labels, descriptions, colors, and annotation provenance. |

Adapt HyCompass's existing domain concept rather than building a second unrelated identity system. Dense integer row spaces should continue serving numerical and rendering performance. Stable item IDs provide correspondence across those row spaces.

Support embeddings with different row order and partial item coverage. Distinguish:

1. Selection membership in the item collection.
2. Availability in each chosen embedding.
3. Vector validity for a requested analysis.
4. Availability of finite display coordinates.
5. Visibility in the current view.

Visibility, finite projected coordinates, or a render cap must not silently become analytical membership. Items lacking display coordinates can still be eligible for source-space analysis if valid vectors exist.

### Mapping rules

- Store explicit collection-to-embedding/embedding-to-collection mappings when row order differs; permit an efficient identity-map case.
- Never assume equal-length matrices have matching identities.
- Validate uniqueness, duplicates, missing coverage, and map bounds.
- Reject ambiguous correspondence rather than guessing from vector values or labels.
- Preserve canonical IDs on exports and linked selections.
- Avoid repeated whole-population string scans or Python dictionaries for each interaction.
- Use bounded/vectorized mapping operations and memory-mapped arrays where appropriate.
- A saved map freezes resolved item membership by default. A reusable live query may be saved too, but reevaluating it creates an explicit new map definition/revision.

## 5. Keep the population workspace independently available

Creating or opening an map must not overwrite the population projection, views, layers, source assets, or saved population camera state.

The population baseline must remain directly accessible without recomputation. Its purpose includes explaining where an map came from, its coverage, and why its results might matter beyond the selected subset.

Provide bidirectional links:

- Population selection → create/open an map.
- Map items/region → highlight corresponding items in a population view.
- Selection or result in one embedding → linked correspondence in another embedding, with missing coverage reported.

Cross-view actions should be explicit and reversible. Selecting or focusing items is not permission to replace a different view's coordinates, filters, or working selection silently.

Use the existing HyCompass projection for the population baseline. Do not replace it with a small reference atlas, inverse-distance attachment to reference anchors, arbitrary jitter, stretched coordinates, or an unexplained new embedding. Local analytical layouts are additional scoped projections.

## 6. Saved maps: define, generate, navigate

The primary model is similar to generating and loading navigable chunks, not observer movement deciding the experiment on every frame.

Keep these operations separate:

1. **Define:** choose item membership, embeddings, source features, context, instruments, and budgets.
2. **Generate:** compute missing analytical artifacts, interactively or offline.
3. **Navigate:** load and render generated detail at appropriate fidelity and memory residency.

An observer position is navigation state. Analysis membership is an explicit experimental choice. An optional bounded preparation-near-observer policy may be offered, but it must not be required or silently change scope, fitting, or saved membership.

### Persistent map state

Persist enough to reopen and navigate without rerunning completed work:

- Parent item collection and relevant embedding/feature revisions.
- Frozen selection and resolved per-embedding membership.
- Display projections and their coordinate provenance.
- Instruments, presets, parameters, budgets, seeds, and actual achieved support.
- Evaluation anchors, context pools, training groups, validation/test definitions.
- Generated graphs, fields, spectra, shapes, models, validation evidence, and summaries.
- Generation/dependency status and incomplete or unsupported results.
- Presentation choices, observer/camera state, selected comparisons, and notes.

Use references to immutable source arrays when practical; do not copy the whole corpus per map. Make source dependencies and portability explicit. A self-contained demo should reopen after being moved to a different directory.

### Chunking and LoD

Use stable storage/rendering blocks, cached geometry, raster levels or bounded representative content where useful. Do not create a full 3D voxel-world abstraction or a game engine.

Crucially, distinguish:

- **Rendering LoD:** different presentation detail for the same measurement.
- **Analytical approximation:** changing anchors, dimensions, candidates, sampling, or method.

Changing presentation LoD must not silently change analytical values or membership. Changing the approximation creates a distinct result definition.

Storage chunks are not automatically valid statistical or graph boundaries. Neighbor-sensitive instruments need surrounding context; route/connectivity/topology instruments may depend on a larger frozen graph. Record those dependencies explicitly. Do not stitch arbitrary independently generated local graphs together and call them a measured corpus graph.

Support partial generation: opening an map with only some completed instruments should retain those results and clearly show what has not been generated. The user can generate additional instruments later without recomputing independent completed results.

### Memory versus disk lifetime

Unloading resident vectors/textures must not delete generated artifacts. Navigation can release expensive working state while retaining saved results on disk. Provide bounded warm caches and explicit pin/delete/regenerate controls.

Use separate lifetimes for static population GPU resources and temporary map resources. Release temporary GL allocations through valid context ownership. Persistent disk artifacts also require visible size accounting and an explicit cleanup mechanism; saving maps must not imply unlimited accumulation.

## 7. Multiple native interfaces with shared foundations

Implement native workspaces or equivalent modes for:

### Population workspace

Retain HyCompass's efficient corpus overview, projections, density/contour/segmentation/clustering layers, item inspection, selections, queries, and views.

### Map workspace

Port the useful detailed interaction of Representation Ecology 1.3.0:

- Observer movement and here/ahead attention over a bounded generated landscape.
- Linked geometry, feature, discrepancy, and reconstruction readings/profiles.
- Local shapes and variance spectra.
- Continuous fields, actual points, contours, 2D/3D terrain, and relief.
- Feature/query/selection tools and detailed measurements.
- Filtration, retained dimension, account selection, and support explanations.

The observer must work natively; moving and turning should not depend on global mouse capture. Preserve the effective keyboard/placement behavior where suitable. Keep camera zoom, attention radius, display contrast, height exaggeration, retained dimensions, and filtration thresholds distinct.

Native 3D/relief rendering is real implementation work. Do not claim parity merely because the Python metrics are available or because a 2D field can be colored. Verify actual height displacement, independent relief changes including zero, and coordinate consistency between 2D and 3D.

### Comparison workspace or mode

Provide linked comparison of embeddings, selections, or analytical variants using the same item identity and artifact model. This can reuse tabs/panels and need not be a separate framework.

Interfaces should share vocabulary, legend conventions, selection correspondence, job status, and result provenance while allowing different technical detail. Avoid disconnected browser reports or modal copies as the core map workflow.

## 8. Make analytical instruments modular

Separate the Representation Ecology workflow into usable numerical instruments rather than rerunning the complete report pipeline for every request.

Each instrument should have:

- Typed supported inputs and explicit eligibility checks.
- Question scope, evaluation rows/anchors, context rows, and training rows where applicable.
- Required artifacts and shared intermediate dependencies.
- Parameter/budget validation and a preflight estimate.
- A bounded execution path with progress and cancellation checkpoints.
- Structured outputs, units, validity/support, and approximation metadata.
- A native presentation adapter where needed.

Prefer simple functions/data objects and an explicit instrument registry over a general plugin system. New computations should be addable without rewriting selection, job management, or artifact persistence.

Reuse normalized vectors, bounded neighbor results, transforms, distances where genuinely affordable, and fitted accounts. Reuse is valid only when the dependencies and experiment definitions match.

Presets should bundle instrument choices, budgets, and display defaults. Allow inspection/editing of individual settings, save the resolved preset with an map, and show estimated versus achieved support. A preset is a convenience, not a hidden universal quality ladder.

## 9. Support independent compromise controls

At minimum, distinguish:

| Control | What it governs |
|---|---|
| Question population | Members the investigation concerns. |
| Evaluation coverage | Which members or anchors receive measurements. |
| Context/reference extent | Observations eligible as neighbors or comparison points. |
| Representation fidelity | Original vectors versus an explicitly reduced/compressed representation. |
| Instrument/method | Which analytical question is evaluated. |
| Validation effort | Folds, resamples, perturbations and sensitivity checks. |
| Presentation detail | Rendering density, field/mesh LoD and resident resources. |

Selections may contain millions of members while an instrument evaluates a bounded representative set. Show both numbers. Rendering or anchor caps must not truncate the selection itself.

Do not silently use cluster centers as individual observations, substitute averaged vectors for source members, or treat selected anchors as a census. Record sampling strategy and weights where used. Offer deterministic sampling for comparable experiments; density-weighted or candidate-ranked samples must not masquerade as unbiased population samples.

## 10. Dramatically constrain source-feature support

Do not port the broad original source-ingestion machinery into a general-purpose native import platform. Support a narrow, predictable column contract registered against the item collection.

### Core analytical types

| Kind | Compact data | Meaning |
|---|---|---|
| Numeric scalar | `float32 [N]` plus explicit validity | Scalar measurements and reconstruction targets. |
| Boolean | Compact 0/1 values plus explicit validity | Binary features and target membership. |
| Disjoint category | Bounded integer code array plus explicit validity and label dictionary | One category per known item. |

Use non-pickled NumPy assets or an equivalently narrow binary format justified by the existing code. Keep metadata small, readable, and editable.

Constraints:

- No arbitrary objects, nested records, free text, dynamic per-row lists, media ingestion, SQL query engine, or automatic external adapters.
- External preparation produces correctly aligned arrays. The native app validates/registers them; it does not infer a schema from arbitrary datasets.
- A fixed tag vocabulary may be represented as declared binary columns. Do not add an unrestricted multilabel-list type to recover scope by another name.
- Ordinal data can be externally encoded as a numeric scalar with a declared interpretation; do not infer ordinal meaning from category codes.
- Group identifiers and split assignments are bounded experimental metadata, not reasons to add arbitrary feature types.
- Unknown is different from false, zero, absent tag, or a valid category. A valid category code of zero must not be confused with raster segmentation background.
- Constrain active features and vocabulary/cardinality per expensive experiment, with estimates and clear rejection when over budget.
- Read only requested columns. Do not deserialize all registered features for every selection.

Separate provenance roles: independently supplied source attributes, embedding-derived clusters, projection/raster-derived values, and human annotations. Predicting a cluster label derived from the same vectors can test the clustering operator, but does not establish independent semantic validity. Raster-sampled targets have analogous limitations.

### Human-readable mappings

Support simple editable JSON sidecars for label names, descriptions, and optional colors. For example:

```json
{
  "asset_id": "clustering-a",
  "labels": {
    "0": {"name": "Unassigned"},
    "12": {"name": "Architecture", "color": "#648fba"},
    "27": {"name": "Mixed outdoor scenes", "color": "#7b9c62"}
  }
}
```

The example does not mandate reserving category zero globally. Dictionaries are asset-specific: cluster 12 in one clustering is not cluster 12 in another.

Allow sidecars to be reloaded at runtime. Renaming or recoloring a label changes presentation without recomputing geometry or invalidating fitted models. Changing category membership, analytical order, feature values, or coding semantics is an analytical change and must invalidate affected results.

Do not put millions of per-item labels into a mandatory monolithic JSON document. Category dictionaries are small metadata; item identity remains in compact row-aligned assets. Show missing dictionary entries with a stable code fallback rather than failing the map.

## 11. Comparison semantics across embeddings and selections

Implement these explicit comparison modes:

1. Same selected items, different embeddings.
2. Same embedding, different selections.
3. Same items/embedding, different projections or analytical settings.
4. Different selections and embeddings, with the changed factors clearly identified.

For controlled cross-embedding comparisons, default to shared eligible evaluation items, report exclusions and missing coverage, and keep training/test group definitions aligned where the experiment permits.

Use comparable settings and baselines. Match anchors, candidate identities, and feature targets where appropriate; if contexts differ, identify that as a changed variable. Do not imply that two different random cohorts isolate embedding quality.

Display quantitative fields on comparable units/scales when justified; label separately scaled fields. An equal retained dimension is not an equal explained-variance fraction. Different raw metrics or normalizations are not automatically commensurate.

Independent projections can rotate, reflect, distort, or change scale. Link by item correspondence and measured quantities; do not silently pretend their coordinates are registered. Any optional alignment is a separate declared display operation, not a replacement for original coordinates.

## 12. Local geometry, context, and boundaries

Make the following questions separately selectable:

- Structure among selected members only.
- Structure of selected members relative to a broader reference/context population.

An exact kNN search inside a subset is exact only within that subset. A display-space halo does not guarantee original-space neighborhood coverage.

Implement a bounded context policy suitable for the first release: selected rows, an explicitly sampled broader reference, and/or source-space candidate retrieval where available. Avoid a mandatory global kNN graph. If no adequate external context is available, keep within-subset analysis usable with an honest boundary limitation.

If approximate retrieval is used, separate candidate generation from exact distance reranking. Record candidate universe, retrieval settings, and any measured recall checks. Exact reranking of approximate candidates does not establish complete corpus neighborhoods.

Instrument-specific requirements include:

- Local spectra/shapes: actual source vectors, stated normalization, neighborhood/context support, and retained variance.
- Density/dimension proxies: tie/duplicate behavior and boundary/context sensitivity.
- Routes/fragility: graph scope and truncation; a local route cannot establish the absence of routes outside the analyzed graph.
- Perturbation/resampling: actual repeated measurements under explicit budgets, not a decorative confidence indicator.
- Feature neighborhoods: supported primitive distances, knownness masks, tie handling, and comparable candidate pools.

Do not impose the first version's tiny reference/snapshot cap on all instruments. Choose safe instrument-specific defaults using estimates and pilots. Avoid replacing it with one large universal row cap that ignores dimensions or operation count.

## 13. Preserve broad/local reconstruction as a real experiment

A broad account is a frozen reusable reference for a declared embedding, feature encoding, training population, and protocol. Local accounts specialize for a recorded context. Observer movement must not silently refit either.

Required behavior:

- Train transformations, normalizations that learn statistics, PCA, feature encodings, and decoders using the appropriate training partition.
- Hold out items/groups consistently; preserve the existing group-aware safeguards.
- Use inner validation for account/dimension choices before observing outer-test outcomes.
- Compare broad and local accounts on the same eligible held-out observations; show matched support and baseline error.
- Preserve negative gains: local specialization can hurt.
- Treat insufficient training/test support as unavailable evidence, not zero error.
- Preserve retained-dimension curves, account choices and transfer readings where supported.
- Fit separate broad accounts for different embeddings and compare under aligned protocols. Do not apply coefficients from one vector space directly to another.
- A subset-trained account is not corpus-wide merely because it uses all rows of that subset.
- A population-sampled broad fit and a full-population evaluation are independent scopes. Do not label a sampled evaluation as a census.
- Reuse persisted transforms/accounts for evaluation in newly selected regions when valid.
- Avoid automatically materializing predictions for every row × feature × account × retained dimension. Permit aggregate evaluation and selectively persisted per-item outputs.

Numeric targets should retain the 1.3.0 reconstruction experiment. Boolean and categorical features need explicit suitable baselines, losses and bounded decoders using existing primitives where possible; do not turn category codes into regression magnitudes. Report unsupported or insufficient protocols clearly.

Record exploratory versus reserved evaluation roles. Repeatedly choosing models after inspecting test results is adaptive map, not an untouched final evaluation. Do not make the ordinary map workflow unusable to enforce a research protocol, but preserve the distinction.

## 14. Keep clashes, filtration, and display scale distinct

Retain separate evidence channels for:

- Feature-to-geometry discrepancy: observed relations versus a chosen feature account.
- Broad/local reconstruction: held-out feature reconstruction under broad and specialized accounts.
- Projection/compression loss: variation or relations omitted by a declared representation change.

Show active method, baseline, support and interpretation. Do not infer one channel from another.

Preserve the actual meaning of the existing filtration: threshold components of a stated candidate graph. Omitted edges do not enter, and unresolved components are not permanent metric-space separations.

Provide local exact-distance H0 or bounded higher-order topology only where the implementation and explicit budgets support it. Higher-order work needs simplex/output/time caps, not just a point count. An interrupted computation is not a completed persistence result.

Camera zoom, chunk loading, spatial raster resolution, attention radius, retained PCA dimension and source-distance filtration must remain distinct controls. Do not add global persistence to claim filtration support, or treat the union of unrelated map filtrations as corpus topology.

## 15. Integrate fields, contours, and segmentations coherently

Use HyCompass's native layer system for population and map results where appropriate. Representation Ecology metrics should become useful native scalar/point/graph/mesh artifacts, not only tables or exported HTML.

Every analytical layer needs:

- Units and method.
- Item/anchor membership and context scope.
- Finite/missing support and evaluation coverage.
- Aggregation or interpolation rule.
- Actual artifact revision and stale/partial status.
- Interpretation limits and baseline where applicable.

Do not force signed errors, unbounded measurements, or category values into a density-specific `[0,1]` semantic contract. Display normalization is separate from raw values. Signed gain/discrepancy fields need an explicit zero and appropriate symmetric display scale when used.

Continuous fields, contours, points, and relief must remain usable together. Preserve unknown holes and supported-component boundaries rather than smoothing unavailable evidence into plausible terrain. An interpolated anchor field is not a full-population measurement. A cluster or segmentation is not automatically an original-space connected component.

A population overlay must not overwrite the original baseline assets. An map may have its own local layout and height surface with explicit scope.

## 16. Analytical coverage is instrument-specific

Retain HyCompass's visitation/familiarity concept as its own layer. Add measured coverage/status separately.

Distinguish at least:

- Not requested/not generated.
- Queued/running.
- Generated and valid.
- Partially generated or sampled.
- Stale/incompatible with current sources/settings.
- Failed, cancelled, unsupported, or over budget.

A region can have spectra but no reconstruction test, or valid reconstruction evidence but no route graph. Coverage should be selectable by instrument. Low error, high density, being visited, being resident in RAM, and having been analyzed are not interchangeable states.

Store precise evidence membership in artifacts; coverage rasters are navigational summaries rather than the sole record of support. Do not mark a whole spatial cell measured merely because one anchor inside it was evaluated without showing the approximation.

## 17. Compute estimates, execution, and offline generation

Make cost estimation and job management native desktop functions, with equivalent offline generation using the same kernels and result contracts.

### Before execution

Show the resolved plan:

- Selected population size and eligible embedding coverage.
- Evaluation anchors/rows, context/candidate counts, and active feature/cardinality counts.
- Dimensions, representation, metric and normalization.
- Existing reusable dependencies and missing work.
- Estimated source reads/full scans, temporary RAM, GPU residency where relevant, pair/edge/simplex work, fitting effort, output/disk requirements.
- Timing range or uncertainty from small machine-local pilots where available; distinguish cached versus cold reads.

Do not present unsupported precision in wall-time estimates. Memory-safe batching does not remove full scans or fitting arithmetic.

Offer user-resolved plans/presets within budgets. Do not silently switch exact geometry to reduced-space geometry, shrink membership, or replace a median with a mean to make a job finish.

### Execution

- Keep heavy operations out of the Qt GUI/render thread.
- Use a small bounded local execution system, not distributed infrastructure.
- Limit concurrency and contention for CPU, disk and GPU; population navigation must stay usable during jobs.
- Report stage/progress, achieved counts, measured timings, and cancellation state.
- Cancel queued obsolete work; running work needs actual cooperative checkpoints between bounded units.
- Result publication must check the originating map/settings revisions. Completion of an old job must not replace a newer view's state.
- Write temporary outputs, validate them, then publish atomically. Keep failed/incomplete outputs distinguishable.
- Resume long generation at meaningful completed artifact/stage boundaries where feasible. Do not claim arbitrary interruption inside a numerical kernel is checkpointable.

Offline commands should plan, generate missing artifacts for a defined map, inspect job/artifact status, and open results in the native app. Generating new artifacts for a current map is supported; converting historical output formats is not.

### Cache and dependency validity

Key results by immutable collection/embedding revisions, resolved membership, context, metric, normalization, feature/encoding revisions, training/test protocol, method/settings, seeds and approximation parameters.

Avoid hashing tens of gigabytes on every observer tick. Establish source revisions/checksums at registration or explicit validation, and identify frozen selection/artifact revisions efficiently. Presentation-only dictionary changes must not invalidate numerical results.

Maintain bounded RAM/GPU caches separately from persisted results. Account for memory-mapped file cache, gather copies, Python objects, indexes, fits, and numerical-library workspaces rather than treating mapped arrays as free.

## 18. Scaling facts that the design must acknowledge

Use these as arithmetic examples, not measured performance claims. Units below are decimal:

| Example | Raw size/work |
|---|---:|
| 10 million float32 2D positions | 80 MB |
| 10 million float32 1,024D vectors | 40.96 GB |
| One float32 feature over 10 million items | 40 MB |
| Thirty-two such features | 1.28 GB before masks |
| 64 neighbors per item over 10 million items, uint32 IDs + float32 distances | 5.12 GB before other graph/index overhead |
| Dense float32 distance matrix for 2,048 rows | 16.8 MB |
| Dense float32 distance matrix for 8,192 rows | 268.4 MB |

Full distance evaluation for the last two cohorts at 1,024 dimensions involves approximately 4.3 billion and 68.7 billion coordinate products respectively, before downstream analyses. Using symmetry can reduce work; avoiding storage of the dense matrix alone does not make the computation cheap.

Budget by bytes and operation structure, not a universal row count. Consider:

- Sorted/coalesced source reads with analytical order restored after gathering.
- Byte-sized batch limits and reusable compact intermediate representations.
- Explicit fidelity and loss when reduced vectors are used.
- Representative anchors rather than measuring every selected row.
- Mergeable counts/sums/histograms where sufficient; exact medians/quantiles require different work and cannot be silently approximated.
- Bounded graphs/pairs and instrument-specific candidate pools.
- Limited active features and categorical vocabularies.
- Shared intermediates, incremental artifact generation, and optional offline population evaluation.
- Bounded output; serialization, per-item records, plots and prediction arrays can dominate.

Do not require a full corpus kNN graph, global exact distance matrix, or global topology to enable the product. Do not require an ANN dependency unless an implemented path demonstrably needs it; source-context limitations can be explicit. If ANN is introduced, validate its bounded role and recall/precision tradeoff rather than calling it exact.

## 19. Implementation sequence and completion criteria

Use stages to manage implementation, but deliver the integrated workflow rather than stopping after architectural scaffolding.

### A. Baselines and identity

Establish both small baselines; implement canonical item correspondence, embedding coverage, collection selections, constrained features and label sidecars. Keep HyCompass's population functions working.

### B. Persistent map and jobs

Implement native creation/open/save of an map, resolved membership/context, instrument dependencies, estimation, bounded jobs, atomic artifacts and reopening. Demonstrate a real instrument, not a placeholder job.

### C. Detailed analytical landscape

Port the 1.3.0 bounded geometry and detailed interaction into a native map workspace: observer, profiles, spectra/shapes, fields/contours, 2D/3D relief, discrepancy, reconstruction, filtration and relevant detailed tools. Separate numerical work from rendering and avoid full-report recomputation for independent instruments.

### D. Comparisons and coverage

Implement same-item cross-embedding and same-embedding cross-selection comparisons, persistent broad references, local account evaluation, bidirectional population links, instrument-specific coverage, and incremental generation of additional detail.

### E. Resource behavior and release

Verify navigation during jobs, cancellation, cache residency/eviction, saved reopening, label reload, portability of the demo, current CLI/API documentation, packaging and native UI tests. Provide a larger user-run recipe without executing it.

If an environment cannot run native OpenGL, do not substitute a browser implementation. Exercise numerical and model tests, use available headless/offscreen native facilities where meaningful, and state the exact unverified native interaction/rendering claims. Do not describe unobserved UI behavior as tested.

## 20. Required validation

Use small deterministic fixtures with meaningful ground truth. Avoid expensive broad benchmark suites unrelated to changes.

### Identity, selection, and comparison

- Two embeddings with shuffled rows and partial overlap resolve to correct canonical items.
- Duplicate/ambiguous IDs and invalid maps are rejected.
- Same-item comparisons use aligned eligible rows and matched experimental settings.
- Different-selection comparisons report the changed population and support.
- Render caps, anchor budgets, visibility and missing projection coordinates do not silently change saved selection membership.
- Population → map → population linking returns the correct IDs without changing baseline coordinates or camera state.

### Persistence and generation

- Save, close, restart, and reopen a generated map without rerunning completed instruments.
- Generate one instrument, add another later, and demonstrate valid dependency reuse.
- Changing membership/context/settings invalidates affected artifacts, not unrelated ones.
- Failed/cancelled work never appears complete; stale jobs do not overwrite current state.
- Source revision changes are detected through the chosen explicit revision policy.
- Label JSON reload updates presentation without numerical recomputation; analytical category changes invalidate the correct dependencies.
- Unloading memory preserves disk artifacts, and explicit cleanup removes only intended results.

### Analytical correctness

- Compare native numerical results against actual 1.3.0 outputs on the same small input/protocol, allowing documented numerical tolerances.
- Source-space and display-space selections have distinct recorded scopes.
- Within-subset neighbors are not labeled corpus neighbors.
- Boundary/context changes produce appropriately distinct results.
- Missing, zero, false and category-background values remain distinct.
- Numeric, Boolean and categorical baselines/reconstruction losses have correct meaning.
- Group-separated training/validation/test and matched broad/local evaluation remain correct.
- Negative local gains and insufficient support are represented honestly.
- Candidate-graph filtration is monotone over its declared fixed graph; changing camera/LoD does not change its analytical components.
- Topology limits and interrupted states are checked if higher-order work is enabled.

### Native interaction and performance behavior

- HyCompass's original population features remain usable.
- Observer movement, attention, feature changes, profiles, local shapes/spectra, contours, actual 3D relief and independent controls work natively.
- Population view remains unchanged and accessible while maps exist.
- Instrument-specific coverage differs from visitation and RAM residency.
- Navigation does not trigger full analytical regeneration.
- A job obeys bytes/anchor/pair/edge/time/output budgets as applicable and leaves the GUI responsive.
- Repeated open/close/navigation does not accumulate temporary GPU resources without bound.
- LoD changes presentation without changing the underlying measurement or selection.
- Small layout tests investigate degeneracy/aspect/clipping rather than hiding collapse with jitter or stretching.

### Required small demonstration

Create a fresh synthetic item collection with:

- At least two embeddings with known transformations or controlled distortions, shuffled row ordering, and partial coverage.
- More than one selection, including overlapping selections.
- A numeric broad signal, a context-dependent signal, independent noise, a Boolean feature, and a small disjoint category feature.
- Declared group identities for evaluation where appropriate.
- Editable category/cluster names in JSON.
- A complete population view and at least one saved detailed map.
- Working same-item embedding comparison and same-embedding selection comparison.
- A real frozen broad/local held-out experiment and at least one boundary/context-sensitive geometry example.

Use small sizes appropriate to the implementation environment. A separate cheap rendering fixture may exercise display-cap behavior without executing expensive analyses on all its rows. Report every actually executed size and operation.

## 21. Deliverables

Provide:

1. A complete downloadable merged native project with clear installation/start instructions and dependencies.
2. A fresh, reopenable small demo workspace and saved map(s), including relative dependencies where feasible.
3. Native GUI instructions for population browsing, map generation/navigation, comparisons, label editing, costs, and offline work.
4. Offline plan/generate/open commands and a larger user-run recipe. **Do not execute the large recipe yourself.**
5. A source-grounded baseline/capability matrix showing what was preserved, changed, implemented, or remains incomplete.
6. A concise architecture explanation covering item correspondence, map persistence, instrument dependencies, native workspaces, and resource lifetimes.
7. Resource estimates with assumptions and measured small pilots, including source-read/output costs and explicit unbenchmarked limits.
8. Meaningful automated numerical/model tests and native interaction/rendering validation, with exact limitations if the environment prevents a check.
9. A concise final summary of changes, how they were tested, remaining bounds, and how to run the demonstration.

The acceptance target is a single coherent HyCompass-based desktop application: its population remains a stable baseline; item identity makes representations and selections comparable; saved maps provide generated, navigable detailed landscapes; and computational compromises remain inspectable through real measurements, bounded jobs, and explicit support.
