# Representation Ecology: scales, generalization, and implementation direction

Consolidated design note · 1 November 2026  
Baseline: Representation Ecology 1.2.0  
Status: proposed next direction; this document does not implement changes.

## 1. Purpose and scope

The next stage should connect corpus-wide explanations with local evidence, using computational accessibility as a practical clue to the scope over which an interpretation remains useful.

The central question is:

> Which distinctions can a compact account preserve across the population, where does that account fail locally, and what additional context, dimensions, or computation make those distinctions accessible again?

This retains the original top-down/bottom-up comparison. It does not replace it with a dashboard of computation costs. Geometry, source features, reconstruction, prediction, and topology supply different tests of the relationship between broad accounts and local organization.

The philosophical motivation is analogous to level of detail for meaning: broad descriptions preserve some distinctions and discard others. For implementation, use explicit targets, evaluation populations, errors, scales, and resource budgets. “Meaning,” “understanding,” and “bumpy terrain” are motivations for those tests, not new quantities claimed to have been measured directly.

Preserve the existing explorer, its four questions, continuous fields, contours, point identities, local shape views, relief control, observer navigation, and held-out prediction evidence. Extend their shared evidence model rather than starting another disconnected interface.

## 2. Definitions that should govern implementation

| Term | Operational meaning |
|---|---|
| Broad or top-down account | A reusable description evaluated over a declared population, with sufficiently low application and navigation costs for that scope |
| Local or bottom-up account | Evidence or a description obtained from a selected region, especially when it requires expensive inspection or specialized computation |
| Computational accessibility | The measured resources needed to obtain a stated answer at a stated accuracy, including construction, evaluation, storage, and interaction |
| Scope of validity | Populations, regions, and scales on which an account meets a declared evaluation criterion |
| Clash | A measured disagreement between accounts, or between an account and observations, evaluated on comparable items or relations |
| Refinement | Additional dimensions, context, model capacity, observations, or computation used to investigate a failure |
| Unknown | An answer that has not been adequately evaluated; distinct from success, failure, zero, or intrinsic difficulty |

These distinctions are relational. A local fit can become part of a compact broad account if it generalizes and is cheap to route to and evaluate. Its expensive discovery remains bottom-up work. An expensive global calculation is also bottom-up work under the computational interpretation; running it offline does not make it cheap. Its cached result may subsequently support top-down navigation.

Keep three population scopes explicit: the full source population, the evaluation cohort, and the current visible or selected region. A model evaluated on a sample is not automatically validated on the full source population.

## 3. What the current implementation establishes

The 1.2.0 project is a useful bounded reference implementation, not a million-point backend.

- The combined configuration defaults to an evaluation ceiling of 5,000 items.
- Embedding neighborhoods use exact brute-force search. Several perturbation and compression analyses repeat neighborhood searches.
- Multiple mutual-kNN graphs provide rank-scale evidence. Sparse H0 records distance-threshold mergers on the maximum-k mutual graph.
- The retained audit can compute complete-distance filtrations on bounded samples, feature organization across radii, and bounded H1 persistence. This optional analysis is disabled in the supplied examples. Defaults are 512 sampled points and a 64-point H1 subset; the built-in H1 implementation is limited to 128 points and guarded by a simplex budget.
- Feature-expected neighborhoods currently compare each evaluation item against the whole cohort. Replacing embedding search alone will therefore not remove all quadratic work.
- Held-out pair models compare feature-predicted and observed embedding distances. Feature probes provide separate target reconstruction evidence.
- Continuous surfaces summarize supported item measurements over the atlas projection. They are not measurements of manifold topology or model comprehension.
- The browser uses a self-contained payload and substantial per-item data. That delivery pattern must evolve for corpus-scale navigation.

The implementation direction below extends these mechanisms. It does not imply that the existing sparse filtration is full metric persistence or that optional topology currently drives the observer.

## 4. Three scales, kept distinct

| Scale | Controlled change | Useful question |
|---|---|---|
| Geometric extent | Increase a distance radius or move through a specified connectivity hierarchy | Over what extent do populations connect and interpretations remain valid? |
| Representation detail | Retain different numbers of directions or different compact descriptions | Which distinctions survive compression? |
| Computational budget | Permit additional fitting, search, model capacity, or local investigation | What extra work improves the answer, and by how much? |

A radius filtration is nested: connections present at a smaller radius remain at a larger radius. A density hierarchy is a different construction and needs its own units and parameters. A sequence of model families is not automatically a mathematical filtration. Nested PCA subspaces can provide nested detail levels, but held-out prediction errors need not improve monotonically with retained dimension.

Do not collapse these controls into one ambiguous scale slider. The primary scale control can follow geometric extent, while compact secondary controls select representation detail and the account being evaluated. State which quantities are held fixed.

Low dimension and cheap computation are related possibilities, not equivalents. A high-dimensional linear decision can be inexpensive to apply. A low-dimensional curved structure can resist one global linear account. Normalization to a hypersphere removes magnitude; its usefulness must be assessed against the distinctions lost. The existing normalized chordal geometry should remain explicitly identified, with raw norm information retained separately where relevant.

## 5. Filtrations as the structural context for interpretation

### 5.1 Start with connectivity across distance

For a fixed item set and metric, inspect the nested graphs obtained as the allowed edge length increases. H0 records component mergers. Attach feature summaries, reconstruction errors, support counts, and account-transfer results to selected nodes or intervals of this hierarchy.

The practical questions are not merely “how many components exist?” They include:

- When two populations merge, can one compact account describe both?
- Does feature reconstruction worsen at that merger?
- Does a distinction survive across a useful range of radii?
- Is an apparent boundary stable enough to motivate a local investigation?

A sparse candidate graph supports exact H0 for that graph, not automatically for the complete metric space. Missing candidate edges can delay mergers or leave false disconnections. Record candidate construction, distance cutoff, neighbor caps, approximation settings, and validation results. In a truncated filtration, unresolved components should not be presented as proven permanent separations.

A minimum spanning forest preserves the H0 merger information of its weighted graph. It does not preserve loops, alternative routes, or deletion fragility of the original graph. Maintain the separate sparse graph needed for those analyses.

### 5.2 Add density-sensitive comparison where useful

Variable sampling density can make raw-distance connectivity hard to interpret. A mutual-reachability hierarchy, as used by HDBSCAN, is an established complementary construction [2]. Treat it as a density-sensitive account, not a replacement for every geometric measurement or a source of unquestionable semantic clusters.

Show its density parameters and construction scope. Avoid forcing all observations into a few shape categories. Excluded or low-density populations remain part of the evidence and navigation problem.

### 5.3 Keep H1 selective

H1 investigates loops that remain after triangle filling. It is distinct from graph cycle counts and competitive route counts. Use bounded, identified regions or matched samples initially. Record sample IDs, radius limits, censoring, approximation method, simplex counts, and skipped status.

Controlled sparse Rips approximations and persistence-preserving reductions are established options [1]. An arbitrary kNN or ANN graph does not inherit those guarantees. Do not promise full-corpus H1 at millions of points.

Filtrations describe structural change; they do not directly measure meaning or intrinsic dimension. Local spectra, distance-growth estimates, and target reconstruction supply complementary evidence.

## 6. Core measurable comparisons

### 6.1 Feature reconstruction: the first implementation target

For embedding z and observed target y, fit a broad account f and evaluate held-out loss:

`loss(i) = loss_function(y(i), f(z(i)))`.

Use appropriate target losses, matched baselines, known-value masks, and group-aware splits. A linear decoder is an initial account, not a definition of all information present in the embedding. Probe controls and capacity comparisons help distinguish useful accessibility from memorization or shortcut learning [3].

Compare a limited set of predeclared retained dimensions and account families. Fit transformations on training data and freeze them for evaluation. Report reconstruction separately from geometric reconstruction: recovering a source property is not equivalent to reconstructing embedding coordinates.

### 6.2 Broad versus local accounts

On the same held-out regional items, compare broad-account loss with local-account loss. Report the paired loss difference, sample support, training scope, model complexity, and evaluation cost.

Local fitting is useful evidence only when assessed beyond its training examples. Freeze region selection using training/reference data before confirmatory evaluation. Exploratory region selection using observed failures remains allowed, but subsequent gains need fresh evaluation or explicit exploratory status.

An improvement suggests the broad account misses a locally recoverable regularity. It does not establish inherent hardness, causality, or the need for that particular model family.

### 6.3 Transfer between contexts

Train an account in region A, evaluate on held-out A and on region B, and compare with a broad account and, where available, a B-trained account on the same B evaluation records. This asks whether a local interpretation survives relocation or expansion.

Record target distribution and annotation coverage changes. Lack of support outside A is an unknown, not proof that the interpretation fails there. If local PCA frames differ, compare predictions in shared target units rather than directly comparing unaligned coefficients.

### 6.4 Compression and geometry

Measure geometric reconstruction loss and distortion on a declared, bounded set of relations. Include near, boundary, and reference pairs with explicit sampling weights or sampling-conditional interpretations. Do not treat enriched pair samples as an unbiased estimate over all corpus pairs.

A low geometric reconstruction error can still discard a rare target-critical direction. A high reconstruction error can coexist with excellent accessibility of one specific feature. Keep those readings separate.

### 6.5 Minimum tested adequate account

For a predeclared target criterion, report the least expensive account among those tested that meets it on validation data. Assess the chosen account on held-out data. Report “no tested account met the criterion” when appropriate.

This is not a proof of minimum possible complexity. Cost is a vector: construction time, application time, storage, and interaction latency. If a single ordering is needed, use a declared budget policy rather than an unexplained composite score.

### 6.6 Preserve the existing relation clash

The original signed residual remains:

`observed embedding distance − feature-predicted distance`.

Positive values indicate extra separation relative to the configured feature account; negative values indicate extra proximity. Magnitude identifies disagreement regardless of sign. Signed averages can cancel, so preserve both channels, support qualification, held-out endpoints, and actual-versus-feature-expected neighbor inspection.

This remains a core top-down/source-account versus bottom-up/embedding comparison. Add reconstruction, transfer, and scale comparisons beside it rather than replacing it with computation-cost estimates.

## 7. Reading the clashes together

| Observation | Grounded reading | Next useful check |
|---|---|---|
| Broad decoder succeeds, local decoder adds little | The target is accessible through the tested compact broad account | Check subgroup exceptions and transfer |
| Broad decoder fails, local decoder improves on matched held-out items | A locally recoverable regularity is missing from the broad account | Test neighboring-region transfer and routing cost |
| Adding dimensions helps | The tested compressed account omitted target-relevant information | Check whether the gain persists across contexts |
| Added computation produces little gain | Tested refinements did not resolve the failure | Check target quality, support, and alternative accounts |
| Low average error, high subgroup error | Population aggregation conceals an exception | Retain subgroup-specific evidence and evaluate coverage |
| Feature account disagrees with geometry across scales | The mismatch persists under the tested structural progression | Inspect omitted features, model fit, and geometric stability |
| Local account works throughout a path but changes between neighborhoods | A contextual description may be economical despite a poor single global fit | Test overlap consistency, routing, and held-out transfer |
| No local analysis exists | The region is unevaluated at this level | Offer a bounded investigation |

Do not infer a universal difficulty surface. Every displayed failure or refinement requirement is relative to a task, account, scale, and evaluation design.

## 8. Architecture for millions of points

### 8.1 Corpus-wide layer

Favor bounded passes over partitioned inputs, compact model application, selected per-item scalar outputs, and sparse graph processing. Candidate outputs include feature summaries, missingness, broad decoder predictions and errors, compact projection coordinates, reconstruction residuals, and regional aggregates.

Use established indexed search when exhaustive search becomes unaffordable. Faiss provides batch search and accuracy/resource tradeoffs [4]. Measure recall on exact queries and validate downstream component, boundary, density, and discrepancy changes. Exact reranking cannot recover candidates that were never retrieved.

Feature-side retrieval needs independent candidate generation or bounded exact audits. Comparing only embedding neighbors would hide missing feature-expected neighbors. Missing-value-aware mixed-feature distances may not have a convenient metric index; use declared approximations and recall checks rather than assuming a vector index solves every feature comparison.

### 8.2 Selective regional layer

Run detailed local spectra, tangent fits, nonlinear decoder comparisons, exact relation checks, H1, route investigations, and stress tests on bounded regions. Use overlapping regions or a context halo, report analyzed extent, and distinguish a cropped boundary from a measured boundary.

Selection should combine measured failures, disagreement, uncertainty, user priorities, underrepresented populations, and a random audit allocation. Selecting only large residuals would miss failures the current account cannot detect.

### 8.3 Reusable accounts produced by local work

A local investigation may produce a small reusable model or a better regional summary. Include routing cost, number of local models, storage, and transfer evidence when deciding whether this is an economical broader account. Do not expand to one independently fitted model per item by default.

### 8.4 Interactive delivery

Keep a bounded working set in the browser. Serve multiresolution fields and aggregates, visible point subsets, requested item records, and cached regional evidence. Retain an offline bounded demo mode, but do not require an inline copy of all corpus records for large deployments.

Computational coverage is an explicit layer: measured, sampled, approximated, predicted, and not evaluated must remain distinguishable. A coarse regional result is not an individual measurement for every member.

## 9. Resource preflight before expensive work

Every operation should declare item count, dimensions, features or targets, graph edges, folds, repeats, output volume, and bounded-work settings. Use a pilot to estimate throughput, memory, and output size before expanding scope.

| Operation | Main scaling concern | Default direction |
|---|---|---|
| Exact full-cohort neighbors | Approximately quadratic pair search times embedding dimension | Replace or bound; verify indexed alternatives |
| Exact feature-expected neighbors | All-cohort feature comparisons, embedding distances, and rankings | Independent retrieval plus sampled exact checks |
| Broad decoder application | Items × input dimensions × outputs; repeated folds/passes | Batch and cap targets/model families |
| Low-rank projection | Items × input dimensions × retained dimensions, plus fitting | Pilot, batch, cache, and test retained distinctions |
| Local spectra and fits everywhere | Repeated neighborhood matrix construction and decomposition | Selected anchors/regions; batched work where justified |
| Sparse H0 | Edge construction plus sorting and union-find | Broad only with an affordable validated graph |
| H1 | Combinatorial simplex growth and reduction | Bounded local/sample analysis |
| Routes and graph distances | Number of sources, graph size, alternatives enumerated | Regional summaries and on-demand detail |
| Browser operations | Payload size and per-frame work | Bounded visible data and multiresolution aggregation |

For orientation, one million 1,024-dimensional float32 vectors occupy about 4.1 GB; eight million occupy about 32.8 GB before copies or indexes. A compact directed 64-neighbor table with int32 IDs and float32 distances uses about 512 MB per million items. A dense million-by-million float32 distance matrix alone needs about 4 TB. These are storage arithmetic, not runtime forecasts.

Batching limits memory but does not remove arithmetic. Raising the current row ceiling is not a scalability implementation. Define hard memory, pair, edge, simplex, output, and time budgets. When an operation is unavailable or exceeds budget, report that state explicitly rather than rendering a zero-valued result. Preserve usable completed evidence without marking the missing analysis complete.

## 10. Extend the current interface coherently

Keep the four existing questions as the main entry points. Add a shared comparison context containing the account, geometric extent, retained detail, and evaluation population. Advanced resource settings belong in optional controls.

The observer should coordinate:

1. The broad-account prediction or interpretation.
2. The local observations and any validated refinement.
3. What changes between here and ahead, or as extent expands.

Continuous fields can show reconstruction error, paired broad/local improvement, relation discrepancy, or measured refinement requirements. Unknown and approximated areas need explicit visual distinction. Point shapes should retain actual category identities, not arbitrary bins of numeric difficulty.

Keep color, contours, and height independently meaningful. Geometry remains a useful default elevation; the user may explicitly choose another measured numeric field. Relief changes display exaggeration only. Do not conflate steep rendered terrain with measured computation time or prediction failure. Any cost field must state the operation and whether cost was measured or estimated.

Integrate a compact filtration strip or merger view with the existing profiles: changing scale updates selected structural context and linked evidence, not an unrelated report tab. Use stable atlas positions initially, so scale changes do not create apparent movement unrelated to the measurements. Geometric extent must remain distinct from projected attention radius and display-grid resolution.

An interpretation should state a concrete result such as:

> The broad linear decoder has higher held-out error in the region ahead. A local decoder improves on the same evaluation items. That gain has not yet been tested outside this region. Increasing retained dimension did not materially improve the tested broad account.

Actual displays must provide values, counts, model identities, and evaluation scope. Avoid claims that a region “contains more meaning” or that a model inherently “understands less.”

## 11. Evidence records and validation

Each result should identify dataset/encoder versions, item IDs or cohort identity, feature schema, metric/normalization, scale definition, account and transformation versions, training/validation/test splits, groups, source region, evaluation region, loss and baseline, support, approximation status, and resource measurements.

Record selection and stopping policies for adaptive local investigations. Account for routing when evaluating mixtures of local models. Lock routing and model selection before final testing. Held-out thresholds and account choices need independent evaluation; browsing test results is exploratory.

Validation should include controlled fixtures for global linear structure, locally linear curved structure, rare target-critical directions, subgroup exceptions, unequal density, disconnected populations, noisy labels, missing annotations, and approximate-search omissions. Test the claimed mechanisms rather than relying on attractive screenshots.

Required invariants include nested filtration membership, correct sample/cutoff status, no conversion of missingness into zeros, consistent scale units, matched evaluation comparisons, separate unknown/refinement states, and stable fixed display references during navigation. Benchmark costs and quality at increasing sizes. Claim million-point support only for operations actually exercised at that scale, with hardware and resource figures.

## 12. Suggested implementation sequence

### First increment: establish one rigorous end-to-end comparison

Preserve current analyses and navigation. Add a preflight cost report, broad target reconstruction under a small set of retained dimensions, held-out regional error summaries, an inspectable H0 hierarchy with explicit graph scope, and one bounded local-refinement workflow. Connect these in the existing observer and here/ahead profiles.

The initial demonstration should show a broad account failing in a known subset, a local account recovering a real held-out gain, and the limits of that account's transfer. Include a fixture where added complexity does not help.

### Second increment: make corpus-scale navigation real

Separate source-population summaries from detailed evaluation cohorts. Add indexed candidate retrieval, bounded exact audits, batch evaluation, partitioned artifacts, and streamed/multiresolution browser data. Preserve support for independent feature-side mismatch detection. Publish measured scaling rather than extrapolating from the bounded demo.

### Third increment: deepen scale and context comparisons

Add selective H1, density-sensitive comparison, richer transfer experiments, and validated collections of local accounts. Extend scope only when the cost and evidence design justify it.

Do not add a universal comprehension score, mandatory natural categories, literal movement penalties inferred from error, a novel persistence algorithm, a causal explanation system, or full-corpus higher-order topology as prerequisites.

Continue generating fresh analyses from source inputs. Do not reintroduce legacy conversion, existing-analysis refreshing, or historical viewer migration. Preserve comparisons, investigations, source audits, and the full workspace.

## 13. Completion criteria for the next direction

The next implementation should let a user identify a target, inspect a broad account, locate a supported local failure, vary geometric extent and retained detail without confusing them, evaluate a bounded refinement, and see whether its interpretation transfers. The same scene must expose where evidence is absent and what computational work supports the displayed answer.

Success is not a terrain that merely looks complicated. It is a reproducible explanation of which distinctions survive broadening or compression, where the broad account and local evidence clash, and what measured additional work improves the answer.

## References and source grounding

The project-status statements above refer to Representation Ecology 1.2.0: `representation_ecology/common.py`, `workflow.py`, `features.py`, and `analysis.py`; `geometric_ecology/core.py`; and `embedding_feature_audit/topology.py`. Proposed architecture and comparisons are design recommendations, not existing features or established universal measures of understanding.

1. [GUDHI — Rips complex user manual](https://gudhi.inria.fr/python/latest/rips_complex_user.html). Filtration construction, size limits, controlled sparse approximations, and reductions.
2. [HDBSCAN — How HDBSCAN works](https://hdbscan.readthedocs.io/en/latest/how_hdbscan_works.html). Density-sensitive mutual reachability, spanning trees, and component hierarchies.
3. [Hewitt and Liang — Designing and Interpreting Probes with Control Tasks](https://aclanthology.org/D19-1275/). Why probe success needs interpretation controls.
4. [Faiss documentation](https://faiss.ai/). Indexed similarity search, batching, and accuracy/resource tradeoffs.

These references support component methods. They do not validate the proposed combined explorer or establish that computational cost measures meaning.
