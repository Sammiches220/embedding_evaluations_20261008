# Mapping the Clash Between Learned Representation and Corpus-Level Explanation

## Purpose

This methodology studies the moving boundary between what an embedding corpus contains and what a current analytical framework can explain.

It does not treat high dimensionality, novelty, stability, or topological complexity as meaning by themselves. It also does not assume that a feature audit exhausts what an embedding represents. Instead, it examines the **clash between two directions of representation**:

- **Bottom-up representation:** structure learned by an encoder from data and training objectives.
- **Top-down representation:** structure imposed by corpus analysis, source-derived features, reconstruction tests, probes, interventions, and human-readable visualizations.

The primary object of analysis is neither direction in isolation. It is the residual between them: where they agree, where one suppresses what the other recognizes, and where stable organization remains unexplained.

---

## 1. Two incomplete accounts of the same corpus

Let a fixed encoder map source items into normalized embeddings:

\[
x_i \xrightarrow{f} z_i, \qquad \|z_i\|_2=1.
\]

The embeddings form a learned relational geometry. Neighborhoods, directions, boundaries, and separations arise from the encoder's architecture, data, objective, augmentations, and bottlenecks. This is the **bottom-up account**.

A corpus-level analysis then introduces concepts such as:

- Multiscale neighborhoods and reciprocal graphs
- Components, boundaries, bottlenecks, and routes
- Density, redundancy, hubness, and local dimension
- Resampling, perturbation, and compression behavior
- Source-derived features
- Reconstruction and probe performance
- Controlled interventions
- Human-readable feature and terrain visualizations

This is the **top-down account**. It makes the learned space inspectable, but it is itself conditional on selected metrics, estimators, features, scales, partitions, and explanatory models.

Neither account is neutral or complete:

> The encoder imposes a learned geometry. The evaluator imposes a language for describing that geometry.

The methodology therefore treats disagreement between these accounts as evidence to investigate rather than an error to immediately eliminate.

---

## 2. The central analytical question

The central question is:

> Where does stable bottom-up representational organization exceed, contradict, or evade the current top-down explanatory model?

This separates the project from three simpler goals:

1. It is not an attempt to infer meaning from dimensionality.
2. It is not an attempt to reward globally uniform or visually attractive embedding spaces.
3. It is not an attempt to reduce every item or region to a single feature explanation.

The objective is to map the boundary between the **currently comprehensible** and the **credibly unresolved**.

---

## 3. Comprehensibility is relative to an explanatory system

“Incomprehensible” should not mean high-dimensional, sparse, distant, visually unusual, or difficult to project. It should mean that a stable representational behavior is not adequately explained by the current analytical vocabulary.

Let:

- \(z_i\) be an embedding.
- \(\phi_C(z_i)\) be its corpus-relative geometric profile.
- \(y_i\) be the currently measured source features.
- \(T_j\) be controlled source transformations.
- \(E\) be the current collection of explanatory models.

Define a family of explanatory residuals rather than one scalar incomprehensibility score:

\[
\mathcal{R}_i =
[
R_{\text{neighbor}},
R_{\text{distance}},
R_{\text{topology}},
R_{\text{intervention}},
R_{\text{probe}},
R_{\text{cross-view}}
].
\]

These residuals ask whether the current explanation accounts for:

- Local neighbor membership
- Pairwise embedding distances
- Boundaries, branches, components, and routes
- Responses to controlled changes
- Recoverability of measured features
- Agreement among alternative representations of the same items

A region is not incomprehensible merely because one residual is large. Credible unresolved structure requires repeated, stable, and localized explanatory failure.

---

## 4. Principal clash types

## 4.1 Bottom-up distinction without top-down explanation

The embedding consistently separates items or regions, but known features do not explain the separation.

Evidence may include:

- A persistent boundary or branch
- Stable reciprocal neighborhoods
- Low sensitivity to resampling and small perturbations
- Reproducibility across corpus subsets
- Weak explanation by current feature distances or probes

This is an **excess of learned distinction** relative to the current vocabulary.

Possible causes include:

- An unmeasured source feature
- A nonlinear interaction among known features
- A distributed relation not reducible to one feature
- Data lineage or acquisition effects
- Preprocessing artifacts
- Encoder shortcuts

It should therefore be called unresolved structure, not hidden meaning.

## 4.2 Top-down distinction without bottom-up support

The explanatory system recognizes a substantial difference, but the embedding suppresses it.

Examples include source changes that alter topology, composition, structure, or measured features while producing little embedding displacement or neighborhood change.

This is an **excess of top-down distinction** relative to the learned representation. It identifies what the encoder treats as interchangeable or irrelevant.

## 4.3 Bottom-up continuity versus top-down categories

The learned space forms a smooth continuum where the explanatory system introduces discrete classes or boundaries.

This may reveal that:

- The category boundary is operational rather than intrinsic to the embedding.
- Several named categories share one continuous morphology.
- The current taxonomy is too coarse or too discrete.

The correct response is not necessarily to force separation. The continuum itself may be the more faithful representation.

## 4.4 Bottom-up discontinuity versus top-down continuity

A known feature changes smoothly, but the embedding geometry changes abruptly.

This can appear as:

- A cliff in neighbor distances
- A sudden neighborhood reorganization
- A component or branch transition
- A sharp change in local dimension or compression response

Possible explanations include a learned threshold, the edge of training support, interaction with another factor, inadequate corpus coverage, or a normalization artifact.

## 4.5 Stable structure that remains unexplained

This is the strongest unknown category. It combines:

- Multiscale persistence
- Resampling and perturbation stability
- Adequate local support
- Repeatability across corpus subsets or encoder checkpoints
- Failure of current features, probes, and interventions to explain the organization

The evidential claim is limited but important: the current explanatory system is incomplete in a structured way.

## 4.6 Apparent explanation that fails intervention

A feature may be highly reconstructable from embeddings without being the cause of the observed organization.

For example, a probe may predict feature \(y\) because \(y\) correlates with another encoded factor. If deliberately changing \(y\) does not produce the predicted embedding response, the reconstruction was correlational rather than explanatory.

This clash distinguishes:

- **Information accessibility:** a feature can be reconstructed.
- **Representational dependence:** changing the feature changes the representation as expected.

Both are necessary for a strong explanation.

---

## 5. Four primary epistemic profiles

The corpus should be navigable through profiles rather than a single score.

## 5.1 Agreement

The learned geometry and current explanation support one another.

Typical evidence:

- Stable neighborhoods
- High agreement between embedding and feature neighborhoods
- Predictable intervention responses
- Probe generalization both globally and locally
- Topological organization aligned with measured features

Agreement can be low-dimensional or high-dimensional. Complexity is not the defining property.

## 5.2 Suppression

The top-down account identifies a source distinction that the learned representation removes or strongly attenuates.

This profile answers:

> What does the encoder make interchangeable?

## 5.3 Excess

The learned representation contains stable distinctions not explained by the current top-down account.

This profile answers:

> Where does the representation distinguish more than the current vocabulary can articulate?

## 5.4 Instability

Neither account yields a reliable relationship because the observed geometry changes under resampling, perturbation, compression, parameter changes, or corpus subsets.

Instability must remain separate from excess. An unexplained but stable structure is a credible unknown; an unexplained unstable structure is primarily unresolved measurement.

## 5.5 Plural explanation

Several top-down accounts explain the same bottom-up relation approximately equally well.

This can occur when a neighborhood relation is consistent with multiple combinations of features or when several near-equivalent graph routes connect the same regions.

Plural explanation is not necessarily a defect. It may indicate that the representation supports multiple relational translations rather than one unique semantic axis.

---

## 6. Core measurements of the clash

## 6.1 Feature-distance residuals

Let \(y_i\) contain measured features for item \(i\). Fit an explanatory model for local embedding distances:

\[
\widehat d_{ij}=g(y_i,y_j,\text{context}_{ij}).
\]

Then calculate:

\[
R^{distance}_{ij}=d(z_i,z_j)-\widehat d_{ij}.
\]

Interpretation:

- Large positive residual: learned separation exceeds the known-feature explanation.
- Large negative residual: learned proximity exceeds what known features predict.
- Structured residual fields: likely missing features, interactions, or context-dependent encoding.
- Unstructured residuals: likely noise, sparse support, or inadequate explanatory modeling.

The analysis should focus first on retained graph edges and nearby nonedges rather than every corpus pair. This localizes explanation to the relations actually defining the corpus topology.

## 6.2 Neighborhood explainability

Construct an embedding neighborhood and a neighborhood induced by the current explanatory features:

\[
N_k^{embedding}(i), \qquad N_k^{known}(i).
\]

Measure overlap, rank correlation, and asymmetric membership differences.

The most informative interpretation combines explainability with stability:

| Embedding geometry | Known-feature agreement | Interpretation |
|---|---|---|
| Stable | High | Comprehensible agreement |
| Stable | Low | Credible unresolved learned structure |
| Unstable | High | Weak or noisy representation of known structure |
| Unstable | Low | Unresolved measurement or unsupported unknown |

This prevents low agreement alone from being mistaken for discovery.

## 6.3 Intervention response residuals

For a controlled transformation \(T\), observe:

\[
\Delta z_T(x)=z(Tx)-z(x).
\]

Evaluate:

- Embedding displacement magnitude
- Directional consistency
- Neighbor retention
- Boundary or component crossing
- Local-dimension change
- Changes in route attachment

Where repeated interventions exist, predict the expected response and calculate residual error. Context-dependent response directions indicate that a feature is encoded differently across regions.

## 6.4 Probe disagreement

Use several probe families:

- Linear probes
- Shallow nonlinear probes
- Region-specific probes
- Local-feature probes
- Global-embedding probes

Interpret their disagreements:

- High nonlinear and low linear accuracy suggests entanglement.
- Strong global and weak local accuracy suggests family-level correlation.
- Strong local accuracy with varying coefficients suggests multiple encodings or translations.
- Strong probe accuracy with weak intervention response suggests correlation rather than dependence.

Probe residuals should be mapped across the corpus, not summarized only by one global result.

## 6.5 Cross-representation disagreement

When multiple embedding views exist for the same corpus, compare relational judgments rather than forcing identical vectors.

For spaces \(a\) and \(b\):

\[
D_{ab}(i,j)=|d_a(i,j)-d_b(i,j)|.
\]

Also compare:

- Neighbor overlap
- Component assignment
- Boundary placement
- Local dimension
- Route attachment
- Feature probe behavior

Cross-view disagreement may reveal genuinely different forms of similarity rather than an error requiring fusion.

## 6.6 Explanatory coverage

For each region, estimate what fraction of stable local geometry is accounted for by the current explanatory system.

Coverage may combine:

- Explained local distances
- Explained neighbor memberships
- Explained boundaries
- Successful intervention predictions
- Probe generalization

It should remain a profile with uncertainty, not a universal measure of understanding.

---

## 7. Visualizing the interface

The visualization should show learned geometry, explanatory structure, and their disagreement without conflating them.

## 7.1 Preserve the corpus map as the shared spatial substrate

Use the established graph atlas or another corpus-relative map as the stable navigation surface. Roads, components, boundaries, density, local dimension, and stability remain descriptions of the learned space.

Do not move points when switching explanatory overlays. Otherwise, changes in layout can be mistaken for changes in the measured relationship.

## 7.2 Feature fields

For each source-derived feature, render independently selectable fields such as:

- Observed feature value
- Probe-predicted value
- Probe residual
- Local probe performance
- Feature uncertainty or missingness
- Intervention response magnitude

A feature is not represented by one global arrow. It may vary smoothly in one region, fragment in another, and disappear elsewhere.

## 7.3 Clash fields

Add dedicated overlays for:

- Neighborhood disagreement
- Distance-model residual
- Intervention prediction error
- Cross-representation disagreement
- Explanatory coverage
- Excess, suppression, instability, and plural-explanation profiles

These fields should remain distinct from local dimension, density, and terrain complexity.

## 7.4 Local explanatory lens

At a selected point or representative region, show:

- Actual nearest neighbors
- Neighbors expected from known features
- Shared and conflicting neighbor sets
- Local covariance spectrum
- Feature values and probe residuals
- Controlled intervention trajectories, when available
- Alternative explanatory models and their residuals

This lens turns an unexplained field into an inspectable local disagreement.

## 7.5 Feature vectors in local tangent space

Where repeated observations support it, estimate how a feature changes in the local embedding tangent space.

Display:

- Direction of increasing feature value
- Strength and consistency of the local relation
- Residual variance orthogonal to that feature
- Changes in the feature direction across neighboring regions

Do not imply that a globally consistent semantic direction exists when the evidence is only local.

## 7.6 Intervention paths

Controlled transformations should appear as paths through the existing corpus geometry:

- Source and transformed embedding
- Actual displacement
- Neighbor changes
- Crossed boundaries
- Expected versus observed path
- Stability across repeated interventions

An intervention path can reveal whether the learned space responds continuously, saturates, changes direction, or crosses a discontinuity.

## 7.7 Competing explanation routes

When multiple feature combinations explain a relation, show alternative explanatory routes with explicit conditions and residuals.

The route metaphor should distinguish:

- Graph navigation routes through the embedding corpus
- Explanatory routes through feature combinations or model assumptions

Their interaction is valuable, but they are not the same object.

---

## 8. Translating ecology and feature audit into one analytical cycle

The corpus ecology and feature audit should not be collapsed into one model. They provide independent accounts that become more valuable through comparison.

### Ecology contribution

The ecology identifies:

- Stable neighborhoods and components
- Boundaries, bottlenecks, and routes
- Local dimension and metric variation
- Redundancy and near substitutes
- Compression and resampling sensitivity
- Structurally influential or weakly connected regions

It identifies **where organized behavior exists**.

### Feature-audit contribution

The audit identifies:

- Which measured features are reconstructable
- Whether reconstruction is linear or nonlinear
- Where probe performance succeeds or fails
- Which features are redundant or conditionally informative
- Whether source interventions produce expected embedding changes

It identifies **which available explanations account for that behavior**.

### Combined contribution

Their translation produces:

- Regions with stable geometry and strong explanation
- Regions with stable geometry but poor explanation
- Regions where features predict globally but fail locally
- Regions where probes succeed but interventions fail
- Boundaries explained by different features on different sides
- Multiple explanatory routes for the same corpus relationship

The combined system should therefore be organized around disagreement and explanatory coverage rather than a merged master score.

---

## 9. Iterative expansion of the comprehensible boundary

The methodology is inherently iterative.

### Step 1: Map existing structure

Freeze the embedding corpus and map its multiscale geometry, stability, and terrain.

### Step 2: Apply the current explanatory vocabulary

Measure source features, train probes, calculate residuals, and attach feature visualizations to the map.

### Step 3: Identify credible unexplained regions

Prioritize regions that are:

- Stable across resampling and perturbation
- Persistent across scales
- Adequately sampled
- Poorly explained by current features
- Reproducible across corpus subsets or compatible encoder views

### Step 4: Propose candidate explanations

Candidate explanations may include:

- A new measurable feature
- An interaction among existing features
- A local rather than global relationship
- A source or preprocessing artifact
- A missing relational or temporal variable

### Step 5: Test through intervention and reconstruction

Add source-grounded measurements or controlled changes. Evaluate whether the candidate explanation reduces the local residual without damaging explanation elsewhere.

### Step 6: Update, but do not erase history

Record how the comprehensible boundary changes:

- Which residual regions shrink
- Which split into distinct explanations
- Which persist
- Which disappear as measurement artifacts
- Which become unstable under stronger controls

The history of failed explanations is itself useful evidence about the representation.

---

## 10. Scientific controls

## 10.1 Stability before interpretation

A region must demonstrate adequate stability before unexplained structure is treated as credible.

Use independent controls for:

- Corpus subsampling
- Input resampling
- Embedding perturbation
- Dimensional compression
- Neighborhood scale
- Compatible encoder checkpoints or views

## 10.2 Null corpora

Use null and matched-control corpora to determine which terrain and residual patterns can arise from high-dimensional sampling alone.

Controls should preserve selected properties such as:

- Global covariance
- Density distribution
- Neighbor-distance distribution
- Group-size imbalance

No single null can establish significance for every measurement.

## 10.3 Local support limits

Local dimension, tangent directions, local probes, and feature vectors are bounded by neighborhood size and sampling coverage. Unsupported regions should be marked rather than interpolated into false certainty.

## 10.4 Corpus relativity

All roles are relative to a frozen corpus, encoder, metric, and analysis version. Adding or removing substantial data can change neighborhoods, boundaries, and explanatory residuals.

## 10.5 Separation of correlation and intervention

Feature reconstruction must not be treated as a causal explanation without intervention evidence or another defensible identification strategy.

## 10.6 Avoiding evaluator capture

The clash profile should not become a single public optimization target. A sufficiently capable system can exploit any fixed scalar evaluator.

Retain multiple independent measurements, hidden perturbation conditions, held-out features, and versioned controls.

---

## 11. Recommended outputs

The system should produce coordinated profiles rather than one verdict.

### Corpus geometry profile

- Density and redundancy
- Local dimension and anisotropy
- Stability and compression behavior
- Components, boundaries, routes, and influence

### Feature explanation profile

- Observed and predicted feature fields
- Global and local probe performance
- Feature-distance explanation
- Intervention response
- Missingness and uncertainty

### Clash profile

- Agreement
- Suppression
- Excess
- Instability
- Plural explanation
- Cross-view disagreement

### Local investigation report

- Actual and expected neighbors
- Dominant residual relations
- Candidate feature explanations
- Intervention evidence
- Stability qualification
- Remaining unresolved structure

### Progress-over-time report

- Explanatory vocabulary version
- Regions newly explained
- Regions remaining unresolved
- Explanations rejected by intervention
- Changes caused by encoder or corpus revisions

---

## 12. Interpretation boundaries

The methodology can support claims such as:

- A stable region is not explained by the current measured features.
- A feature is recoverable globally but not locally in this region.
- A controlled source change is suppressed by the embedding.
- Two representation views organize the same items differently.
- A boundary persists across scales and corpus subsets.
- Several explanations fit the same local geometry.

It cannot establish by itself that:

- Unexplained structure is meaningful.
- High-dimensional structure is valuable.
- A feature has a unique semantic interpretation.
- A stable boundary corresponds to a natural human category.
- An embedding captures authorship, intent, experience, or cultural worth.

The methodology maps the limits of the current explanation. It does not convert those limits into metaphysical conclusions.

---

## Conclusion

The proposed direction treats learned embeddings and corpus-level explanation as two incomplete translations of the same underlying material.

The learned representation supplies a bottom-up organization. Corpus geometry, features, probes, interventions, and visualization supply top-down accounts. The most informative object is the tension between them:

- What the encoder distinguishes but the current vocabulary cannot explain
- What the explanatory system distinguishes but the encoder suppresses
- Where continuous and categorical accounts conflict
- Where stable unknowns can be separated from unstable measurement
- Where several explanations remain simultaneously plausible

The goal is not to eliminate this clash. It is to make it navigable, testable, and historically traceable as the explanatory vocabulary evolves.
