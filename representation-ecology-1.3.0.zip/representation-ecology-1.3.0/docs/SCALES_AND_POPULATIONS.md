# Scale-aware accounts and population workflows — 1.3.0

## Start with the included small demonstration

Install the project with `python -m pip install -e .`, then run:

```bash
representation-ecology serve --run examples/offline-small/run --open
```

This example evaluates 384 synthetic rows and displays detailed geometry for a fixed 160-row sample. Select **context_signal** in Explore & compare, then **Broad − local error** in the visible Prediction account control. The interface switches to Will it predict here. Teal/amber curves compare held-out broad/local errors as retained dimension changes. Positive signed gain means the local account has lower error on the same items; negative means it hurt.

Compare global_signal (a global linear relation), context_signal (a sign-dependent interaction that local linear accounts can recover), and noise_signal (independent noise). These are numerical mechanisms, not media encodings or proof of behavior on real data.

## Three independent controls

**Distance filtration** advances through exact threshold components on the maximum-k mutual candidate graph of the displayed cohort. Rings highlight the component touching the first item in the observer's here region; Keep connected extent captures its IDs. The local curve uses that extent, while the caption also reports population-wide means. Radius is measured in normalized chord distance. Missing candidate edges never enter, so remaining components are unresolved outside that graph. This is H0, not full-space persistence or H1. Its maximum-k candidate graph differs from the retained navigation graph: filtration components can span atlas islands without creating a route in the retained graph.

**Retained directions** selects a training-fitted PCA dimension for the new decoder experiment. It changes broad/local evidence, not the atlas positions, attention radius or graph. The local-cloud PCA and original geometry dimension measurements remain separate.

**Prediction account** selects the original probe, broad linear error, routed local linear error, paired gain, or validation-selected error. The last can use different dimensions in different folds; its caption states that fact. The dimension selector still controls the diagnostic broad/local curves. Geometry is the default elevation; Field as height is explicit. Relief still changes only visual exaggeration.

The transfer heatmap evaluates each local training-region account against each test region, at the maximum tested dimension. Darker is worse; hover gives MAE and count. It tests context dependence rather than asserting semantic clusters or causal explanations. Different targets have different loss units and color ranges.

## Evaluation protocol

The new experiment currently supports numeric targets (including count targets). Original categorical/tag analyses and probes remain available unchanged.

1. Freeze at most four KMeans routing regions from a bounded unlabeled reference sample. This is transductive routing, independent of labels; it is not an independently validated clustering result.
2. Hash groups into three outer folds by default. For each experiment fold, one fold tests, the next validates, and remaining folds train. Without groups, each item is its own group. String and integer group hashes are deterministic within their respective encoding; preserve group encoding when reproducing an experiment.
3. Cap training and validation rows at 2,048 each. Fit PCA only on that fold's training vectors. Fit broad ridge decoders and local ridge decoders on the same target with the same PCA basis. Local models require at least 16 known training targets per region. Unsupported local predictions stay missing.
4. Test dimensions 1, 2, 4, 8 where input/training dimensions permit. Validate a candidate against 80% of the matched training-mean baseline MAE, requiring complete known-target validation coverage. Test broad dimensions in ascending order, then local dimensions in ascending order. This is a declared policy, not measured minimum complexity or a significance test. A degenerate zero baseline does not qualify.
5. Freeze that choice before evaluating the outer test fold. Each group supplies test predictions once. Test labels cannot influence that fold's PCA, decoders or selection. Full target columns may contain NaN, which remains missing.

Broad/local gain is paired per item. Displayed separate means may have different coverage; the gain count identifies the comparable set. Transfer MAE uses the same target and test-region population for available source accounts. Small regions can have inadequate support. Routing regions are shared across folds, while PCA and fitted coefficients are fold-specific.

Exports include PCA means/components, reference/routing centers, bounded training and validation indices, coefficients, intercepts, training support, validation choices, fold counts, transfer summaries, statuses and timings. Fit timings include PCA/decoders/selection. Evaluation timings include transfer computations and any prediction-output I/O; they are not separate benchmarks of broad versus local inference. Account success is accessibility under this experiment, not proof of a causal model or complete information recovery.

## Create a larger demo yourself, entirely offline

No large population run was performed while preparing this release. The largest new population smoke fixture has 384 rows. The following commands are provided for your machine.

Plan first; this prints estimates and creates no output directory:

```bash
representation-ecology offline-demo --out large-population --n 100000 --dimension 32 --display-rows 240 --plan-only
```

Then generate and analyze it:

```bash
representation-ecology offline-demo --out large-population --n 100000 --dimension 32 --display-rows 240
representation-ecology serve --run large-population/run --open
```

For a million-row experiment, use a fresh destination and change `--n` to `1000000`. Start with `--plan-only`. That is a runnable configuration, not a million-row benchmark claim. It produces substantially more prediction output and performs more batched inference. No network, downloaded models or external services are used; ordinary package dependencies must already be installed.

`--batch-rows` controls generation and inference batching. It does not set the bounded training cap or the display sample size. Detailed atlas geometry, feature-neighbor comparisons, original probe families and sparse H0 operate only on the 80–512 display rows. Whole-population operations are the synthetic source generation, numeric reconstruction experiment and aggregate/transfer summaries. The population never receives an all-pairs graph, full topology, or full feature-expected-neighbor search.

Outputs:

- `population_vectors.npy` / `population_targets.npy`: memory-mappable aligned matrices.
- `population_source.parquet`: batched source records and IDs.
- `population_summary.json`: streamed numeric source summaries.
- `held_out_predictions.parquet`: row/fold/region/target/dimension, actual target, broad/local predictions and losses, baseline loss; one record per evaluated target/dimension/item.
- `accessibility_summary.json`: population experiment, accounts and construction/evaluation records.
- `ground_truth.json`: mechanisms and sample indices.
- `inputs/`: portable bounded atlas inputs.
- `run/`: existing explorer and analysis outputs plus linked accessibility evidence.
- `resource_plan.json` and `status.json`: preflight and explicit completion/failure.

The root status covers the complete population operation. The nested run status covers the sampled atlas. Existing destinations are never silently overwritten.

## Analyze real row-aligned numeric arrays

```bash
representation-ecology population-run \
  --vectors embeddings.npy \
  --targets numeric-targets.npy \
  --features exposure detail quality \
  --groups group-codes.npy \
  --ids item-ids.npy \
  --out population-analysis \
  --display-rows 240 \
  --plan-only
```

Repeat without `--plan-only` to execute, then serve `population-analysis/run`.

Vectors must be real numeric N×D with D≥2; targets must be numeric N×F with 1–32 uniquely named columns. Provide one name per target column, in order. NaN targets are unknown; infinite targets and nonfinite/zero vectors are rejected. Every vector batch is checked before fitting. Groups, when supplied, must be aligned integer codes; IDs must be aligned unique fixed-width string arrays. NPY object/pickled arrays are not accepted. IDs are checked for uniqueness; absent IDs become row identifiers. Absent groups mean no protection against unknown family relationships. Files remain read-only.

Alignment is the caller's contract: shape checks cannot establish that the rows mean the same things. This command does not replace the full schema-driven source audit; it adds a numeric population pass to the bounded detailed explorer. The ordinary `run` workflow still audits typed mixed source features and supports the original analyses. Categorical targets must use that workflow until a population categorical experiment is explicitly added.

The memory-mapped API is also available as `representation_ecology.accessibility.analyze(matrix, targets, groups, cfg, sample_indices=..., sink=...)`. Pass a bounded `sample_indices` array for large inputs. Omitting it retains per-item browser fields for the whole population, which is intended only for bounded experiments. A sink receives typed batches of outer-held-out prediction records.

## Resource checks and limits

`representation-ecology plan --schema ... --config ... --combined-config ...` estimates the ordinary bounded workflow before execution. The ordinary run writes that plan and enforces it before gathering the evaluated source cohort. New population commands also support planning before construction.

Guards cover estimated exact-distance work, estimated numeric prediction output (default 4 GB uncompressed), and conservative working-array estimates (2 GB). `--max-output-bytes` can explicitly change the prediction-output budget. Reduce dimensions/cohort size when the working-array guard rejects an operation. These are arithmetic gates, not a process memory limiter, precise SVD runtime predictor, total disk quota, or hard wall-clock deadline. Libraries, file cache and other source-analysis allocations can use additional resources. The output estimate refers to prediction records, not all artifacts combined. A pilot on your hardware is still necessary.

Fitting is bounded in row count but can be expensive at very high embedding dimensions; PCA uses a full SVD on the bounded training matrix. The batched population pass has no N² relation step, but inference, hashing/group arrays and output volume still grow with N. It is not a distributed engine. There is no ANN or density hierarchy backend in this release, and no million-point interactive graph/topology claim. Whole-population spatial tiling, arbitrary region refinement on demand and higher-order topology remain later work. This release uses a fixed atlas sample and bounded regional models.

Do not use approximate interpolation or a sampled geometry boundary as evidence that every omitted population item shares that structure. The scope paragraph and population/sample counts remain visible in the interface. Unknown local predictions remain holes. No universal comprehension or intrinsic-difficulty score is computed.

## Validation supplied

Small controlled tests check group separation, outer-test label isolation, local-context recovery, noise non-improvement, missingness, subset alignment, nested filtration components, resource rejection, plan-only behavior, and the real-data entry point. Browser checks cover filtration extent capture, dimension/account independence, signed fields, linked profiles, scope labels, original predictor fallback and relief. Original analysis and explorer checks remain included. See `VALIDATION.json` for the exact release results.
