# Reading the representation ecology explorer

The explorer starts with a shape question and keeps geometry, measured features and held-out error in the same observer scene. Walk with WASD, turn with left/right arrows, and change look distance with up/down arrows. Escape releases movement. Here and ahead are projected sampling regions, not guarantees of a traversable graph path. Empty support remains a gap.

## Four questions, one landscape

**What shape is this?** shows four families together. Each measurement has a small profile, a here-to-ahead reading, a possible practical use and a limit. Select any reading to put its continuous field and contours on the landscape. The twelve measurements remain individually available; no universal quality score replaces them.

| Family | Measurements | What the question can establish |
|---|---|---|
| Variation | Effective covariance directions; variation hidden in two axes; population growth with distance | How many independent directions carry local differences, and how incomplete a flat picture may be |
| Support | Inverse-radius density rank; close substitutes; neighbor-list hubness | Where measured geometric coverage, redundancy or repeated retrieval exposure concentrates |
| Access | Competitive regional routes; uneven neighbor spacing; fixed-graph deletion pair loss | Alternative graph access and vulnerable connections |
| Stability | Reference removal loss; PCA compression loss; their maximum | How much neighborhoods change under the two recorded stress tests |

**What changes here?** maps an observed source feature. Numeric features form continuous color fields. Categories have distinct point symbols over the geometric terrain; category IDs are never averaged. For tags, select a tag to see its prevalence, with known absence distinct from missing annotation. Here/ahead distributions and nearby feature contrasts provide leads for cohort analysis.

**What doesn't fit?** maps held-out disagreement between embedding distances and the configured feature account. Signed mode distinguishes greater separation from greater proximity than that account predicts; magnitude mode shows error regardless of direction. Neither is an automatic claim of semantic excess, suppression or missing causal factors. Qualification excludes inadequate pair support and unstable observations. Inspect actual and feature-expected neighbors to examine a concrete mismatch.

**Will it predict here?** maps actual held-out feature loss from the selected predictor. Compare with the matched baseline and evidence count. A geometric pocket becomes useful for prediction decisions only when target-specific evidence supports that connection. Predictor selection does not automatically choose the best result on the test set.

The three survey profiles stay aligned: geometry, observed feature, and held-out error. Middle-half bands describe the sampled values; they are not confidence intervals. Component boundaries and absent evidence break continuity. The interpretation panel connects a measured pattern to a next investigation, rather than declaring deployment readiness from geometry alone.

## Seeing the shape rather than assigning it a category

Color and contours describe continuous variation. Numeric observations use continuous-color point markers, without forced low/medium/high shape bins. Point shapes carry actual discrete identities or missingness. All layers can remain visible together; use their toggles to inspect overlaps.

The terrain is a smoothed field over the atlas projection. Interpolation is restricted to supported grids inside each retained component; it does not join disconnected components. Feature and error fields require at least 60% known interpolation weight as well as sufficient finite evidence and underlying geometric support. A known zero contributes a real observation. An unknown value contributes no numeric value. A smooth field is a display summary, not a new measurement at every location or evidence of a causal boundary.

Contours mark raw measurement levels. The displayed slope depends on smoothing, projection, range and relief; it is not an embedding distance, graph travel cost or predictive difficulty. Geometry sets the default elevation. The explicit **Field as height** option lets a feature or error field supply elevation instead. Unsupported height cells remain holes in the rendered surface.

**Relief** is always available beside the 2D/3D controls. Zero flattens the terrain; higher values exaggerate it for navigation. Changing relief does not change vectors, neighbors, measurements or predictor outputs.

Display reference controls color and height together:

| Reference | Reading |
|---|---|
| Observed corpus span (guide default) | Uses the finite minimum and maximum actually measured in this corpus; useful contrast can exaggerate a numerically small span |
| Semantic corpus range | Uses the field's configured interpretation range, including theoretical limits where available |
| Corpus 5–95% | Boosts central contrast and clips tails |
| Kept region | Uses the captured IDs as the reference; moving the observer does not silently change that population |

The numeric legend states the displayed range. Signed residual ranges remain centered on zero under every reference. Changing the display reference changes contrast, not the underlying evidence.

## Local anatomy: what the map leaves out

The local anatomy panel shows the actual centered embedding neighbors projected onto their first three local PCA axes, alongside the full recorded variance spectrum. Drag the point cloud to rotate it. Compare the variance retained in two or three axes with the discarded tail before judging a flat patch to be intrinsically simple. The cloud is a local source-space view, not the global terrain rendered a second time. Different neighborhoods have independently fitted axes; their orientations are not aligned and must not be compared as a shared coordinate frame.

Effective covariance directions summarize how variance is distributed. They do **not** count explanations of a prediction. A high value means several independent ways neighbors differ; whether those differences matter depends on the target and predictor. Population growth with radius estimates a different property and can disagree with the covariance count, especially in sparse or tied-distance neighborhoods.

Competitive routes answer a graph-access question. The exported count summarizes entropy-equivalent alternatives among bounded simple regional paths to sampled reference destinations, within the configured detour limit of the cheapest path. The interface displays the actual enumeration cap and detour setting. The optional bundle fixes a particular source and destination for inspection; it is one example, not every path entering the regional summary. Several competitive routes can share the same critical bridge, so read fragility and actual path overlap alongside the count. A single dominant route can be direct rather than fragile.

To ask about competing predictive explanations, compare predictor families with comparable held-out performance and inspect their disagreements. Even those comparisons do not identify causal reasons without stronger source interventions and assumptions.

## Detail without making it the starting point

Optional controls retain feature search, neighborhood size, attention radius, camera behavior, geometry focus, display reference, model choices, ID import/export, feature queries and kept-region comparison. The full workspace preserves arbitrary cohorts, Boolean queries, raw evidence tables, routes, investigation records and standalone geometry/reference views. The atlas reference remains available for detailed definitions; the integrated cards make its central readings navigable without tabbing through its tables.

## Fresh analyses only

This release builds current outputs from input data into a new empty destination. It has no saved-analysis conversion, viewer-update command or migration path. To obtain a current analysis, run the current pipeline on the source inputs. Comparing separately generated runs, recording investigations and evaluating supplied intervention embeddings remain supported.

The visual demo's measurements are synthetic mechanisms, not features extracted from real images. The backend retains its exact sampled computation limits; this release adds neither ANN scaling nor a real media encoder.

## Scale-aware reconstruction in 1.3

The visible scale/account bar and broad/local evidence panel extend this guide. See [Scales and populations](SCALES_AND_POPULATIONS.md) for the held-out protocol, filtration extent, transfer matrix, larger offline generator and real numeric population command. All geometry and feature readings above remain available.
