# Implementation and interpretation notes

## Current interface in 1.2

The guide integrates geometric variation, support, graph access and sensitivity with feature and held-out-model analysis. Color fields and contours are continuous; optional point glyphs do not partition numeric data into classes. All twelve geometry readings, actual PCA-3 neighborhood clouds and variance spectra are available in context. Visible relief controls support flat and exaggerated 3D readings. See [FIELD_GUIDE.md](FIELD_GUIDE.md).

The build produces its interface from current analysis results. Saved-run updating and conversion paths are not supported.

## Responsibilities

`workflow.py` freezes one source cohort using the original audit validation and ingestion logic, computes canonical unit vectors and one ordered exact neighbor graph per view, passes that graph into Ecology through a validated precomputed-neighbor hook, and passes the same graph/vectors to the preserved audit engine. Normalization, invalid-vector handling and graph reconstruction are explicit in the combined manifest.

The new `features.py` and `analysis.py` modules operate independently of point layout. The viewer bridges the exported Ecology interface through a same-origin iframe. Feature fields do not modify Ecology's raw geometric fields, point positions, retained edges or route costs. A parent overlay draws discrete per-item measurements in flat/relief/mesh views. Interpolated geometry surfaces retain their original geometric meaning.

The standalone observer exports no source attributes. Its additional host API returns projected selection indices only. The parent combined page owns feature data and here/ahead aggregation.

## Metric and identity

Canonical geometry is Euclidean chord distance on float32 unit vectors. Cosine distance equals half the squared chord distance on unit vectors; ordering can agree while lengths, radius thresholds and shortest paths differ. The combined run intentionally uses chord distance consistently rather than treating these distance values as interchangeable.

Canonical IDs are supplied by the original audit's typed semantic contract. The manifest retains the original identity schema and the ordered-ID hash. Joins use canonical IDs; graph indices are always final-cohort positions. Related-item groups remain independent units for held-out models. Evaluation manifests include the actual partition assignment hash.

The full source file is fingerprinted in bounded chunks. Embedding and graph hashes refer to the evaluated arrays. Code hashing includes shipped Python/JavaScript/HTML/CSS/JSON sources. Resolved source schemas record original absolute paths for provenance; to regenerate the included example use `examples/omitted/inputs/schema.json`, which has portable relative paths.

## Feature distances

Numeric differences use training-set IQR, with standard-deviation fallback. Constant numeric features have no useful distance scale and are omitted from that feature-space instance. Ordinal differences use the declared category order and a training scale. Categorical differences are mismatches. Multilabel distance is one minus Jaccard over all known observed tags, preserving known-empty versus unknown.

Feature families receive equal total weight by default. Columns within one family share its allocation; `feature_families` can override family weights. Missing dimensions are excluded and the remaining weights renormalized. Every pair retains a jointly observed feature count. Pair-model records also retain the exact available-feature mask.

The descriptive whole-corpus feature-neighbor comparison fits numeric scales on the evaluated corpus. This is explicitly descriptive, distinct from explanatory model scaling. Both actual embedding ranking and expected feature ranking are computed within the same feature-comparable pool. Cutoff ties produce overlap lower/upper bounds. The displayed expected list uses stable index order only as a representative ordering; the tie set is not a unique prediction. Large tied sets are truncated to 256 IDs in browser details, with their full count retained.

## Pair design and models

Pairs are unique and unordered. The sample allocates approximately half its budget to retained or near relations and fills the rest with reference pairs; reference sampling can also select additional near pairs. Pair-class labels indicate the sampling path. This is an enriched exploratory design, not a uniform estimate over all corpus pairs.

Items or related-item groups are split before selecting training/evaluation pairs. A model trains only on training–training pairs and is scored only on test–test pairs for that fold. Cross-fold endpoint pairs do not receive a fabricated out-of-fold prediction. With an explicit source train/test split, only designated test–test pairs are scored. Fit counts and skip reasons are recorded.

The current symmetric explanatory inputs are pairwise numeric/ordinal differences, category mismatch, and tag-set differences. Ridge uses regularization and standardization; random forest supplies a bounded nonlinear alternative. Missing values are imputed to zero with explicit missing indicators. This may itself expose annotation patterns; strong residual changes should be checked against missingness. No embedding distances, endpoint IDs or embedding-derived cell labels are explanatory inputs.

The constant-distance baseline is fitted on training pairs. Signed residual is observed chord distance minus predicted distance. Models are not constrained to produce nonnegative predictions; unusual predictions remain visible rather than silently clipped. Read absolute error and baseline gain as well as signed error.

## Probe and local fit scope

The preserved audit report uses its original fixed held-out probes. New bridge probe maps use cross-fitting over items/groups or an explicit source split. Numeric loss is absolute error; categorical/tag loss is 0/1 disagreement. Multilabel values are separate binary tasks. Missing or unsupported labels remain unscored. Probe status and fit metrics are exported.

A local tangent fit uses known original-space neighbors, excluding the center and its entire related group. Local PCA retains up to three axes, then ridge predicts the center's numeric feature. The exported ambient gradient and raw-PCA projection describe that local fit. It is not a global semantic vector, a causal response or an arrow in the graph-geodesic atlas. Coefficient/subspace uncertainty is not estimated in this release.

## Evidence profiles

Candidate flags are deliberately limited operational rules:

- Insufficient pair support or insufficient feature-comparable pool → `insufficient_evidence`.
- Perturbation overlap below the configured margin → `instability`.
- Supported positive mean residual plus feature-neighborhood overlap upper bound below 0.5 → `excess_candidate`.
- Supported negative mean residual beyond the configured margin → `suppression_candidate`.
- Positive local relative error gain plus overlap lower bound at least 0.5 → `agreement_evidence`.
- Other supported discrepancies → `unresolved_model_discrepancy`.

Resampling overlap, nested-scale rank support and perturbation overlap remain separate values. Candidate flags are not a declaration that structure is stable under every control. Suppression candidates do not establish that a source distinction should have been encoded. A weak explanatory model can create either residual sign. No automatic metaphysical meaning, causal explanation, semantic worth or universal comprehension score is inferred.

Node residuals aggregate the held-out sampled pairs incident to that node, which can span several distance bands. They are not exclusively retained-edge statistics. Inspect pair class and endpoints before calling a pattern local. Pair records are conditional on the features jointly available in that fold. Model comparisons offer competing correlational accounts, not unique or automatically plural causal explanations.

## Topology and routes

Ecology H0 uses a sparse mutual-neighbor filtration. Audit H0/H1 use complete distances on bounded matched samples; the optional H1 implementation includes triangles and enforces simplex/memory budgets. The combined viewer links the audit report for topology rather than merging incompatible persistence objects. Original route alternatives remain navigation evidence, not an H1 calculation.

Route field profiles use cumulative original chord length along actual retained edges. Observer summaries use projected attention selections; they do not assert those selected points form one original-space neighborhood. Point overlays are observations. The guide also renders smoothed numeric fields and raw-level contours, confined to supported grids within each component. Missing-source areas do not receive a numeric zero; the field mask requires sufficient finite support. These displays do not estimate source geometry in unobserved space.

## Interventions and progress

The intervention adapter consumes externally transformed/re-encoded vectors and explicit metadata. It reports frozen attachments, source-relative displacement, neighbor retention and aggregate response direction consistency. It cannot verify the encoder by inspecting an arbitrary matrix, isolate collateral changes, or infer a new transformed component. It does not generate or encode real source files.

Run comparison matches endpoint/fold/model records and checks geometry and evaluation identity. Only matched relations have a delta; annotation expansion can change which relations are measurable. Inspect matched counts and coverage before claiming overall improvement. Differences when the corpus, encoder, graph or split changes are descriptive comparisons rather than vocabulary-only progress.

## Resource boundaries

The source pass streams Parquet data. Vector neighborhoods, repeat searches, PCA, explanatory feature distances and browser snapshots are bounded in-memory analyses. Feature-neighbor comparison performs O(N²F) work with row-wise bounded temporary memory. Exact embedding search remains approximately O(N²D). There is no ANN, GPU search, tiling, background job server or production multiwriter history service.

The combined snapshot checks a payload budget and fails with a clear status if exceeded. Analyses may have already completed and retained their Parquet outputs when browser export fails. Reduce the cohort/feature vocabulary or explicitly raise the budget. A failed folder is never treated as a complete run.

## Verification

The release is verified with the retained 32 Ecology unit tests; 22 combined/new tests covering joins, typed semantics, ties, group splits, endpoint-held-out pairs, cross-fitting, rotation invariance, shared-graph validation, omitted-factor recovery, run artifacts, history, comparison and interventions; and five JavaScript state checks (three retained Ecology checks plus guide and continuous-landscape checks).

Real-browser integration exercises linked item selection, feature query, overlay scaling, ID selections, retained route capture, 3D mesh rendering and observer here-region capture. The test asserts no JavaScript page errors and checks that overlays do not change atlas coordinates. The viewer has been inspected visually at a desktop viewport. Browser execution requires a usable Chromium/WebGL environment; the optional test reports when mesh testing is unavailable.

The prebuilt example is synthetic and is not a large-scale performance benchmark. This implementation preserves the original source projects' interpretation limits rather than converting their demonstration outputs into claims about a real corpus.

## Version 1.3 scope

Scale-aware numeric accounts, sparse candidate-graph H0 navigation, resource preflight, and population batching are documented in [Scales and populations](SCALES_AND_POPULATIONS.md). Population reconstruction and bounded atlas geometry have separate coverage. The inherited mixed-feature analyses remain bounded exact computations. No million-point benchmark was run.
