# Combining Geometric Ecology and Parquet Representation Audit

*A source-grounded assessment and proposed implementation direction — 1 November 2026*

## 1. Recommendation

Combine the projects as **a shared corpus with independent geometric and explanatory analyses, connected by an explicit comparison layer**. Geometric Ecology should provide the navigable spatial substrate and geometry controls. Parquet Representation Audit should supply the typed source-feature contract, population summaries, annotation-aware measurements, and held-out probes. A new layer should measure where those accounts agree and disagree.

The first implementation should make feature analyses available throughout Ecology. The next should investigate relationships that the features do not adequately explain. Those are related goals, but they require different machinery: a feature overlay displays an association; an explanatory residual tests a specified account of a relationship.

This is feasible as an incremental extension of the attached projects. It does not require a new embedding representation or a new topological framework. It does require careful alignment, additional row- and edge-level exports, defensible explanatory baselines, and a way to distinguish unsupported measurements from credible unexplained organization.

The most valuable combined question is:

> Given this frozen corpus, encoder, metric, graph policy, and explanatory vocabulary, which relational judgments are supported, suppressed, or left unresolved—and what evidence would distinguish the possible reasons?

Do not build a single score for incomprehensibility or overall embedding quality. Build a navigable collection of specific, testable disagreements.

## 2. Scope and evidence

This assessment examines the supplied source trees, configuration contracts, documentation, tests, and representative generated artifacts. It also reads the complete supplied methodology, `mapping_the_clash_between_learned_representation_and_corpus_level_explanation.md`.

The conclusions below distinguish implemented capabilities from proposals. Relative file paths refer to the roots of the extracted projects; they identify evidence in the supplied archives rather than external references.

Verification performed during this review:

- All **32 Ecology Python unit tests passed**.
- Ecology's `scale_state.cjs`, `reference_state.cjs`, and `observer_state.cjs` checks passed.
- On the audit's supplied `disjoint_clusters/embedding_a.npy` fixture, containing **360 × 16** vectors, Ecology and the audit produced identical ordered Euclidean neighbor indices after the same normalization at `k=20`. Cosine neighbor sets had complete overlap on this fixture; converting chord distances to cosine distances differed by at most approximately **2.56 × 10⁻⁸**.
- The audit's baseline and linear numeric probes ran on that fixture using 270 training and 90 test items. Their prediction table covered the held-out items for each model, not every corpus item.

These are compatibility checks, not evidence that real corpus features will explain real geometric organization. The full Parquet CLI pipeline was not executed: this environment lacked `pyarrow` and `jsonschema`. No browser visual QA or large-corpus performance benchmark was performed. No project source was modified.

One versioning caveat matters: Ecology's README calls itself 0.6.2, its package metadata declares 0.10.0, and its persisted map schema is version 2. Integration should pin source hashes and artifact schemas rather than treating the README version as authoritative.

## 3. What Geometric Ecology actually contributes

### 3.1 A measured geometry, not merely a projection

`src/geometric_ecology/core.py` builds an analysis from aligned embedding vectors and unique IDs. It rejects nonfinite or effectively zero vectors, normalizes each vector, and searches exact Euclidean neighbors in the normalized space. Its distances are **unit-sphere chord lengths**.

Its main structures are:

| Structure | Current meaning | Integration consequence |
|---|---|---|
| Directed ordered kNN arrays | Nearest items at configured neighborhood sizes | Best initial common substrate for feature statistics |
| Mutual kNN edges across scales | Reciprocal relations retained at different k values | Useful relations for edge explanations |
| Edge frequency across nested scales | Fraction of configured scales supporting an edge | Rank support, not an independent estimate of repeatability |
| Retained graph | Edges meeting the support policy, with support-weighted route costs | Navigation and connectivity must remain distinct from raw distances |
| Connected components | Components of the retained graph | Graph-policy-dependent separation |
| Navigation cells | Graph Voronoi partitions built from seeds | Browsing units, not discovered semantic categories |
| Sparse H0 filtration | Component mergers on maximum-k mutual edges | Not complete-distance Vietoris–Rips persistence |

The graph route cost is approximately chord length divided by edge support plus 0.01. That is an explicit navigation policy. It should never silently become the target for a model claiming to explain embedding distance.

### 3.2 A collection of geometry profiles

Ecology already measures neighborhood radius, distance-growth dimension, hubness, scale support, perturbation overlap, subsampling overlap, PCA compression response, coordinate-mask response, fixed-graph deletion damage, sampled betweenness, and effective next-hop choices.

The terrain, mesh, and local lenses add covariance spectra, effective covariance dimensions, hidden variance, substitution tolerances, metric variation, bounded route alternatives, and boundary diagnostics. These are complementary measurements. For example, local covariance dimension and neighbor-radius dimension are different estimators; neither is a semantic complexity score.

The validation layer includes training-only frozen-map attachment experiments, route checks, synthetic mechanism diagnostics, and descriptive null corpora. These provide a useful starting vocabulary for deciding whether a discrepancy is worth investigating.

However, current stability controls are not a complete credibility certificate. The subsampling experiment compares original vectors against reduced reference sets; it is a conditional neighborhood-recovery test, not independent data collection. Gaussian perturbations of vectors are not controlled changes to source content. Fixed-graph deletion does not refill neighbors. The geometric nulls have one realization each and do not supply inferential significance.

### 3.3 A mature starting point for navigation

`atlas.py` lays out components separately, using landmark graph distances within components. Their placement relative to one another is schematic. Terrain fields interpolate measurements computed in the original embedding space; they do not infer original-space density from the drawing.

The explorer supports measured fields, raw-versus-display scaling, arbitrary subsets, graph routes, local spectra, and independent color and elevation choices. The observer adds movement, here/ahead comparisons, and directional profiles across the displayed map.

These are strong integration assets. A feature audit should become something users can inspect while moving through this map, selecting a route, or comparing two regions.

There is an important boundary: observer attention regions are selected in projected coordinates. They can contain items that are distant in the embedding geometry. A feature average over an attention cone is a valid summary of the displayed selection; it is not automatically a local embedding estimate.

### 3.4 What it does not yet provide

Although the CLI accepts metadata, `io.py` does not turn general metadata into feature fields or an explanatory system. The dedicated observer deliberately excludes item attributes, and a test enforces that behavior. Synthetic demo labels are used in validation, but general source-feature analysis is absent.

Adding features therefore needs a deliberate optional extension to the data contract and interface. Passing a metadata JSON file is not sufficient.

## 4. What Parquet Representation Audit actually contributes

### 4.1 An explicit source contract

The `parquet_audit/` layer validates a declared Parquet schema, identifies rows, streams source statistics, selects a bounded evaluation cohort, aligns external assets, and invokes `embedding_feature_audit/` computations and reports.

Its roles distinguish IDs, features, embeddings, groups, strata, splits, predictions, probabilities, and ignored columns. Its semantic kinds include numeric, count, categorical, cluster labels, Boolean, ordinal, multilabel, datetime, and text.

These declarations are more useful than automatic guesses. They preserve distinctions such as one disjoint cluster assignment versus a set of tags, and unknown annotation versus an observed empty set. They also prevent source feature names from determining how the geometry is built.

Not every declared kind has the same analysis. Numeric/count features enter continuous computations; categorical, cluster, Boolean, and ordinal features enter categorical computations. Text and datetime do not directly receive those geometric computations. An ordinal field currently loses its ordering in the categorical analysis, even though its source values can remain intact. Ordered-distance analysis would need an explicit additional treatment.

### 4.2 Feature organization, recoverability, and missingness

The audit already provides:

- Population prevalence, numeric summaries, annotation coverage, and tag cooccurrence.
- Categorical and multilabel neighborhood purity and prevalence-aware lift.
- Numeric local differences, local variance, and graph autocorrelation.
- Local categorical or tag entropy over a fixed vocabulary.
- Numeric feature/embedding distance association.
- Held-out baseline, linear, neighbor, forest, and optional XGBoost probes.
- Group-aware or explicit training/test splits and training-only regularization tuning.
- Artificial annotation removal followed by reconstruction and distortion measurements.
- Evaluation of externally supplied predictions and probabilities.
- Paired comparisons between two aligned embeddings, including conditional bootstrap summaries.
- Direction/magnitude comparisons under alternative normalization choices.

This already covers much of Ecology's immediate feature-analysis need. It is substantially more than a label coloring tool.

Several limits are important for the combined design. Probe predictions come from one fixed held-out split. They are not out-of-fold predictions for the whole map. Local entropy can be exported per anchor, but many feature organization outputs remain aggregated over anchors. New per-anchor and per-edge outputs will be needed for comprehensive clash fields.

Artificial missingness reconstructs hidden annotations on a fixed graph. It does not transform the source item, invoke an encoder, or test encoder dependence on a source property. Its default embedding-based kNN reconstruction is not independent confirmation of what the embedding represents.

### 4.3 Topology and an existing exploration interface

`embedding_feature_audit/topology.py` computes complete-distance threshold filtrations on matched bounded samples, measures annotation entropy or variance within components across radii, compares with shuffled annotations, and implements tightly bounded exact H1 reduction with triangles over GF(2).

This differs materially from Ecology's sparse-graph H0 and navigation terrain. Both are useful, but their bars, components, and loops answer different questions.

The audit also has an offline row explorer, feature queries with unknown-aware logic, cohort comparisons, PCA coordinates, and paired embedding views. Reuse those query and cohort semantics. Maintaining two full selection systems and two competing map interfaces would add unnecessary complexity; the more useful arrangement is Ecology for spatial navigation and the audit report for detailed statistical reading, linked by shared item selections.

### 4.4 Population and scale boundaries

Source statistics can cover all Parquet rows while expensive geometry and models operate on a uniform bounded evaluation sample. Those scopes are intentionally distinct. The runner records common valid-cohort exclusions across embeddings and writes row-alignment artifacts.

Neither project currently provides a general scalable approximate-neighbor engine. The audit's streaming source summaries do not make its vector analysis population-scale. Ecology's exact search, repeated searches, PCA work, and map export likewise target prototypes.

## 5. How to refine the supplied conceptual direction

The attached methodology is a strong foundation because it treats disagreement as investigable evidence, preserves independent accounts, and avoids equating unexplained structure with meaning. Several refinements make it more implementable.

### 5.1 There are at least three accounts

The encoder's learned relations, the geometric evaluator, and the feature-based explanatory evaluator should be recorded separately:

1. **Learned representation:** embeddings produced by a specific encoder and preprocessing pipeline.
2. **Geometric account:** metric, neighborhood scales, graph construction, estimators, layout, and stability tests.
3. **Feature account:** observed variables, annotation rules, explanatory models, controls, and intervention assumptions.

A frozen embedding is already shaped by training choices; “bottom-up” is a useful relative label, not a claim that it is unmediated reality. Likewise, Ecology is itself a top-down measurement framework. The clash is between the learned relationships **as measured by a declared geometry** and a competing explanatory account.

This matters operationally: if a boundary vanishes when changing graph support, the first discrepancy to investigate may be evaluator sensitivity rather than an unmeasured source property.

### 5.2 Separate information access from relational explanation

A probe estimates a mapping such as:

\[
\widehat y_i=h(z_i).
\]

An explanatory distance model estimates:

\[
\widehat d^Z_{ij}=g(y_i,y_j).
\]

These answer different questions. A feature may be decodable from a small embedding direction while most neighborhood organization depends on other factors. Conversely, features may predict coarse distances while individual labels remain hard to decode.

The combined system should put **recoverability, local organization, and relational explanation** side by side. Do not infer one from another.

### 5.3 Treat profiles as overlapping evidence, with an abstention state

The supplied document names agreement, suppression, excess, instability, and plural explanation. Keep all five; they need not be mutually exclusive.

Add **insufficient evidence** explicitly. Low known-neighbor coverage, too few independent groups, near-constant outcomes, poor intervention validity, and out-of-distribution inputs can all prevent a conclusion. Missing evidence should not be rendered as high excess or low agreement.

“Excess” means separation beyond the tested feature-based account. “Suppression” initially means a discrepancy candidate. Calling it encoder suppression requires evidence that the source distinction is real and relevant under the stated task or intervention, not merely a large arbitrary difference in a chosen feature metric.

### 5.4 Do not make interventions a universal causal gate

Interventions strengthen claims about representational dependence when they have a defensible interpretation. They are not required for every useful observational description, and some relational or historical properties cannot be cleanly manipulated.

For example, a controlled recoloring can test sensitivity to color, but it may also change contrast, segmentation, or realism. A failed test does not automatically refute every correlational explanation involving color. Record manipulated variables, collateral changes, encoder access, and the scope of the claim.

### 5.5 Keep stability and unresolvedness separate

The strongest current conclusion should be phrased as:

> On the specified corpus and controls, this relation is reproducible and remains poorly explained by the tested feature families and model classes.

It is stronger than “this point looks unusual,” but weaker than “the encoder has discovered a hidden meaningful factor.” It can still reflect a stable acquisition artifact, an inadequate explanatory model, or an omitted nuisance variable.

## 6. Proposed architecture

Use a coordinator and shared artifacts first. Extract a shared computation package only after the contracts have settled.

```mermaid
flowchart TD
  C["Frozen corpus and aligned IDs"] --> G["Ecology geometry"]
  C --> F["Typed feature audit"]
  G --> X["Relational comparison"]
  F --> X
  G --> V["Shared map and local lens"]
  F --> V
  X --> V
  V --> H["Versioned investigation record"]
```

Feature analysis must not silently alter geometry. If a later experiment learns a feature-weighted metric or new embedding, register it as another representation view and compare it with the original.

### 6.1 Shared corpus and identity contract

Create one explicit evaluation cohort before either engine builds neighborhoods. Record:

| Contract field | Required content |
|---|---|
| Source identity | Dataset snapshot/fingerprint and source row positions |
| Item identity | Canonical ID plus declared original type or composite schema |
| Encoder identity | Model/checkpoint, preprocessing, vector artifact hash |
| Cohort identity | Ordered IDs, selection policy, common exclusions, cohort hash |
| Vector view | Raw or normalized, dtype, normalization policy and vector hash |
| Geometry | Metric, scales, tie policy, directed and retained graph definitions |
| Feature vocabulary | Kind, units, missingness, annotation scope, source lineage |
| Evaluation policy | Splits, groups, null strata, fitting scope, model configuration |
| Artifact lineage | Code revision, library versions, seeds, producing run |

Ecology currently stringifies IDs. The audit validates typed IDs and serializes composite identities, but its single-column canonical key is also a string representation. Carry type/schema information in the shared manifest to prevent cross-dataset collisions such as integer `1` versus string `"1"`. Do not join by display labels or row positions alone.

If Ecology is built on 10,000 items and the audit uses 5,000, the attached field must identify its measured subset and candidate pool. Do not pretend the sampled neighborhoods are the same as full-atlas neighborhoods.

### 6.2 Share the directed graph; keep retained navigation edges separate

The safest first common metric is Euclidean distance on the exact unit-normalized vectors used by Ecology. The audit supports Euclidean geometry and can accept validated ordered neighbor arrays. Preserve raw vectors separately for optional norm analysis.

For unit vectors:

\[
d_{\mathrm{chord}}=\sqrt{2d_{\mathrm{cos}}},\qquad
 d_{\mathrm{cos}}=1-z_i^Tz_j.
\]

These preserve neighbor ordering apart from numerical and tie effects. They do **not** preserve distance values, regression residuals, filtration radii, or shortest paths under summation. Convert explicitly, or label the views separately.

Export the shared **ordered directed kNN graph**, with enough columns for every requested k, rather than passing Ecology's sparse retained adjacency to the audit's fixed-k functions. The supplied-graph audit contract requires final cohort order and validates declared distances. It checks structural validity and distance consistency; it does not prove a supplied graph contains the true nearest neighbors.

Ecology retains an extra neighbor for frozen-query thresholds. Export the requested columns deliberately. Keep rank support, raw edge length, and route cost as separate fields.

### 6.3 Initial artifact boundary

A practical first bundle would contain:

```text
combined_run/
  manifest.json
  cohort.parquet
  geometry/                 # Existing frozen Ecology artifacts
  audit/                    # Existing report and feature tables
  bridge/
    feature_registry.json
    node_feature_fields.parquet
    edge_explanations.parquet
    neighborhood_comparisons.parquet
    probe_predictions.parquet
    evidence_status.parquet
  investigations/
    selections.json
    explanation_history.json
```

These are proposed files, not existing outputs. Use stable keys linking run, item, feature, scale, and model. Export a bounded JSON payload for the browser; keep Parquet as the richer analysis interchange. No new storage server is necessary for the initial sampled implementation.

## 7. First milestone: feature analysis inside Ecology

This should be a complete useful release before attempting the full clash framework.

### 7.1 Feature fields

Start with:

- Numeric observed values, units, and missingness.
- Categorical identity and category-specific membership.
- Multilabel membership for selected tags, with vocabulary and annotation rules visible.
- Known-neighbor share and effective known counts at each k.
- Numeric local absolute differences and local/global variance.
- Categorical or tag local entropy and anchor-specific same-label agreement.
- Held-out probe predictions, probability/loss or numeric residual, and split status.

Reuse the audit's existing aggregate measures, then add per-anchor outputs where absent. Do not broadcast a corpus-wide lift or accuracy into every point as if it were a local observation.

Categorical values should use categorical encodings. Never average category IDs into a terrain height. A selected category's membership probability or neighborhood prevalence can be a numeric overlay with a clear definition.

### 7.2 Selection and comparison

An Ecology selection should be exportable as canonical IDs to the audit's cohort tools. Feature predicates should likewise return IDs that can be highlighted in Ecology. Support point, original-space neighborhood, cell, component, route, hand-selected subset, and feature query as distinct selection origins.

Every local statistic should state whether it uses:

- Original full-cohort neighbors around selected anchors.
- Only neighbors also inside the selection.
- A newly rebuilt subset graph.

The first is the recommended default. Rebuilding is an explicit separate run. Changing display contrast must remain independent of changing statistical baselines or candidate pools.

### 7.3 Preserve a geometry-only mode

Keep the current geometry-only observer available. Add a feature-enabled exploration mode that loads a separate payload and exposes feature selectors. The existing observer attribute-exclusion test should continue to protect the geometry-only path; add checks for the optional feature path.

This is a product distinction with analytical value: users can inspect geometric evidence before introducing labels, then see how their interpretation changes when features are revealed.

## 8. Second milestone: measure the clash directly

### 8.1 Start with specific relations and explicit baselines

Use retained graph edges, directed neighbor pairs, nearby nonneighbors, and a smaller distance-stratified reference sample. Record why each pair was sampled. Near edges alone cannot characterize suppression across distant regions, and uniform random pairs alone can miss the local organization defining the map.

Avoid duplicating undirected pairs unintentionally. If pair sampling is deliberately enriched, report results conditional on that sampling design; use inclusion weights only for a declared population estimand.

### 8.2 Define a transparent feature distance before learning one

Numeric features can use differences normalized by training-set robust scale; categorical features can use mismatch; multilabel features can use a declared set distance. Ordinal distance requires a documented order. Feature-family weights must be explicit so hundreds of tags do not automatically outweigh a few physical measurements.

For missing features, require sufficient comparable information and report the effective feature set. A pair compared on one known feature is not equivalent to a pair compared on twenty. Prefer family-specific comparisons before one mixed distance.

This produces a deliberately simple baseline. A learned distance predictor can improve it later, but it should not erase the baseline or silently infer feature importance from test data.

### 8.3 Neighborhood disagreement

Compare embedding neighborhoods with feature-induced neighborhoods using overlap, rank displacement, and directional differences. On complete common-support cases, define:

\[
U_i=N_k^Z(i)\setminus N_k^Y(i),\qquad
V_i=N_k^Y(i)\setminus N_k^Z(i).
\]

`U` contains unexpected embedding neighbors; `V` contains expected feature neighbors absent from the embedding neighborhood. Show actual examples from both.

With incomplete annotations, compare against a feature-comparable candidate pool and also recompute the embedding ranking within that same pool. Otherwise missingness alone can create disagreement. Retain full-corpus embedding neighborhoods as a separately labeled view.

Nominal categories can create enormous tied feature-neighbor sets. Use tie-aware overlap bounds, repeated admissible tie breaks, or comparison with the entire tied set; do not manufacture a unique expected ranking from arbitrary IDs.

### 8.4 Distance explanation residuals

Fit an explicitly symmetric model:

\[
\widehat d^Z_{ij}=g(\psi(y_i,y_j)),\qquad
r_{ij}=d^Z_{ij}-\widehat d^Z_{ij}.
\]

Here `ψ` contains symmetric pair features such as absolute numeric differences, category matches, tag overlap, and selected interactions. Start with regularized simple models and compare with a bounded nonlinear alternative.

Positive residual means more separation than this model predicts; negative residual means more proximity. These are **model-relative discrepancies**, not a semantic diagnosis.

Evaluate improvement over an appropriate constant or nuisance-only baseline. Report error by distance band, region, annotation coverage, and known confounds. Include both signed and absolute residuals: positive and negative edges can cancel in a node average.

Do not give the explanatory model embedding distances, embedding-derived cells, or unrestricted endpoint identities as inputs and then claim the features explain geometry. Such inputs can be useful in a separate conditional diagnostic, but must be labeled as geometry-assisted.

### 8.5 Prevent pair leakage

Randomly splitting edges is inadequate: the same endpoint or near-duplicate family can appear in both training and testing, allowing memorization.

Split items or related-item groups first. Train on training–training pairs, evaluate generalization on held-out–held-out pairs, and report training–held-out attachment separately when useful. Fit feature scaling and tune models on training data only. If cases are selected after seeing residuals, reserve new confirmation data or clearly retain exploratory status.

Distinguish a descriptive all-corpus atlas from deployment-style evaluation. A fixed full-corpus atlas may be used for transductive description, but an inductive claim requires fitting relevant preprocessing and geometry on training data or explicitly declaring access to unlabeled test vectors.

### 8.6 Probe maps and local models

Initially show the existing held-out probe residuals on their measured items and mark training items as unscored. For a whole-map loss field, add group-aware cross-fitting so every scored item is evaluated by a model that did not train on its group.

Summarizing held-out errors within a region is different from training a region-specific probe. Implement the former first. Local fitting needs enough independent training/test support, explicit neighborhoods, and its own validation.

Global success with local failure may reflect restricted label variation, class imbalance, selection, or family-level confounding. Compare appropriate local baselines before interpreting it as a different encoding.

### 8.7 A candidate evidence profile

For a selected region, expose:

| Evidence channel | Example measurement |
|---|---|
| Geometric support | Number of items and independent groups, neighbor gaps, duplicate share |
| Repeatability | Perturbation response, resampling response, scale sensitivity |
| Feature availability | Known item/pair fractions and annotation completeness |
| Feature organization | Local variation, prevalence-aware agreement, null contrast |
| Information accessibility | Held-out probe gain and local loss |
| Relational fit | Out-of-sample pair-distance and neighborhood agreement |
| Sensitivity | Feature metric, model family, normalization, candidate-pool changes |
| Status | Agreement evidence, excess candidate, suppression candidate, unstable, insufficient evidence |

Statuses should link to their component evidence and remain nonexclusive. Thresholds are versioned operational rules, not discoveries of natural categories.

## 9. Topography and topology: retain two complementary analyses

“Topography” is the terrain rendering and local field variation. “Topology” concerns connectivity and holes under a specified construction. A high mountain or sharply colored seam is not itself a topological feature.

| Analysis | Ecology | Audit | Combined use |
|---|---|---|---|
| Connectivity | Retained mutual multiscale graph | Full-distance radius graphs on samples | Compare with construction and sample scope visible |
| H0 | Sparse maximum-k mutual-edge filtration | Complete-distance filtration within sample and radius range | Keep separate provenance; compare only matched constructions when making direct claims |
| H1 | Route alternatives are not Rips H1 | Exact bounded GF(2) Rips H1 including triangles | Inspect sampled cycles with original IDs and support evidence |
| Boundaries | Cuts between navigation cells with contrast/conductance diagnostics | Feature variation/entropy across distance components | Test correspondence; do not equate a cell with a class |
| Terrain | Rendered scalar fields over schematic layout | PCA/report plots and feature measures | Use Ecology as shared display, retaining raw tables |

A good combined experiment asks: **at what geometric scales do components become more homogeneous with respect to feature F, compared with annotation shuffles?** Much of this already exists in the audit. A second asks whether a proposed Ecology bottleneck remains supported when examining the same sampled items under complete distances.

Do not compare component integers across runs; they are arbitrary labels. Compare memberships on shared IDs, co-membership relations, and matched merges. Never draw a graph edge or continuous surface across disconnected components just to make a topology visualization easier to read.

Use H1 selectively. A cycle representative is not unique, a budget can force skipping, and right-censored intervals are not proven infinite holes. Sampled H1 should remain an investigation panel rather than the central whole-corpus score.

## 10. Visual experience: make disagreement inspectable

### 10.1 One fixed map, multiple independent channels

Keep point positions and the retained navigation graph frozen when changing explanatory overlays. Preserve current global, robust-global, and subset display scaling, with visible units and clipped ranges.

A useful default is geometric elevation, feature or residual color, and sparse edge marks for disagreements. Keep geometry instability and annotation missingness distinguishable; reusing one fog channel for both would hide the reason evidence is weak.

Residual maps require diverging scales centered at zero. Loss maps require sequential scales. Category maps require discrete colors. Unsupported values need a separate visual state rather than a zero.

### 10.2 A local comparison lens

For a selected anchor, show four coordinated lists or panels:

1. Actual embedding neighbors and distances.
2. Expected feature neighbors, including ties and missingness.
3. Shared and conflicting relations, with measured pair differences.
4. Held-out predictions, residuals, and applicable stability/support evidence.

For an edge, show actual versus predicted distance, model version, feature differences, endpoint split membership, and uncertainty or status. Offer comparison with an alternative model rather than a single authoritative explanation.

### 10.3 Observer and route profiles

Let here/ahead panels compare feature distributions, known fractions, held-out loss, and residual summaries alongside geometric quantities. Separate projected attention selections from original-space neighborhoods, and expose which is active.

Along a retained route, show feature values and edge residuals against cumulative chord length or route cost, with the horizontal axis labeled. A sharp feature change along a smooth route is an investigation candidate; it is not automatically a discontinuity in the encoder.

Do not interpolate across unsupported areas, disconnected components, or incompatible scoring scopes. For mixed-feature residuals, make the comparable-feature mask available when inspecting a suspicious region.

### 10.4 Small multiples for competing explanations

A fixed region shown under feature families A, B, A+B, nuisance controls, and a nonlinear model often explains more than a complicated blended overlay. Mark which results are observational and which are supported by interventions. This makes plural explanation a visible result rather than a forced choice of one winning feature.

## 11. Later stages that require genuinely new machinery

### 11.1 Source interventions

Neither project currently supplies a general source transformation and re-encoding pipeline. Add an external adapter that records original/transformed IDs, transformation parameters, source artifact hashes, feature changes, encoder version, and resulting embeddings.

Attach transformed vectors to the frozen atlas using Ecology's query attachment as one diagnostic. Also calculate displacement, neighbor changes, and expected-versus-observed behavior directly. Frozen attachment does not discover a new component or create a true route for the transformed point. Do not snap it to an anchor and present that anchor's route as the intervention trajectory.

Track collateral feature changes and compare with matched controls. Repeated transformations across multiple source items are needed before estimating a consistent feature response.

### 11.2 Local tangent explanations

Ecology's local PCA lenses are a useful basis for local feature gradients, but the feature fits are new work. Within a supported neighborhood, fit a regularized relationship between retained local coordinates and a numeric feature, evaluate held-out error, and report conditioning and uncertainty.

PCA axis signs can flip; nearly equal eigenvalues permit rotations within an eigenspace. Compare directions only after expressing them in a common ambient frame or using an appropriate subspace comparison. A 2D display arrow can hide a mostly invisible direction. Start with local coefficients and spectra before presenting globally continuous semantic vector fields.

### 11.3 Explanatory coverage and history

Keep at least three denominators separate:

- **Annotation coverage:** fraction of relevant items or pairs with usable measurements.
- **Evaluation coverage:** fraction with valid held-out/model evidence.
- **Explanatory performance:** how well a specified model predicts specified relationships on those cases.

If a coverage fraction is introduced, define exactly what counts as a successfully predicted relation, over which supported relation set, and under what tolerance. Missing cases should reduce measurable scope, not silently count as either explained or unexplained.

When adding a feature, freeze the original geometry and evaluation splits, compare old/new explanatory models on identical test relations, and record failures as well as improvements. If the corpus or encoder changes, distinguish that from progress made by expanding the explanatory vocabulary.

## 12. Feasibility and implementation order

| Stage | Deliverable | Reuse level | Main new work | Completion evidence |
|---|---|---|---|---|
| 0 | Matched corpus and graph adapter | High | Typed identity bridge, cohort/hash manifest, metric agreement | Permuting feature rows preserves joins; mismatched assets are rejected |
| 1 | Feature-enabled Ecology explorer | High | Feature registry, node fields, selection bridge, optional observer payload | Audit values reproduce on the same IDs/k; overlays leave geometry unchanged |
| 2 | Neighborhood and distance disagreement | Moderate | Feature metrics, pair sampling, held-out explanatory models, edge tables | Known synthetic discrepancies recovered; leakage controls pass |
| 3 | Supported local probe/residual maps | Moderate | Cross-fitting, local support/baselines, missingness-aware comparisons | No training-item losses presented as held-out evidence |
| 4 | Topology-linked investigations | Moderate | Shared sample IDs, comparable constructions, linked selections | Sparse and complete filtration results remain clearly distinguished |
| 5 | Intervention and tangent tools | Low | Source adapters, re-encoding, response models, local fit validation | Repeated controlled changes and collateral effects are traceable |
| 6 | Large-corpus operation | Low for expensive geometry | ANN adapters, recall evaluation, caching, tiled/lazy payloads | Runtime/memory bounds and local fidelity benchmarks on target corpus |

Do not fold stages 5 and 6 into the first feature integration. They are separate engineering and validation problems. Reliable feature fields plus neighborhood disagreement already make a substantial combined tool.

For large corpora, distinguish anchor samples from candidate pools. Searching every sampled anchor against a full-corpus ANN index is different from rebuilding neighborhoods inside a small sampled corpus. Compare ANN with exact neighbors on held-out anchors, including ties, rare regions, and suspected boundaries. Batch computation reduces memory pressure, but does not remove the quadratic work of exact all-pairs neighbor search.

A fixed 10,000-item evaluation cohort has nearly 50 million unordered pairs. Sampling declared pair classes is a practical starting point. Full PCA decompositions and repeated searches also need review; replacing the initial neighbor call alone will not make Ecology a multimillion-item engine. Browser payload size is another independent limit.

## 13. Validation experiments that would make the combined method credible

Use the existing synthetic generators as a starting point, then add deliberately controlled cases:

| Fixture | Planted relationship | Expected evidence |
|---|---|---|
| Feature-aligned groups | Known features account for geometry | Strong held-out agreement under an adequate model |
| Missing factor | Geometry depends on an omitted synthetic variable | Stable residual; reduced on new test data when factor is added |
| Suppressed source variable | Source property varies independently of embedding | Feature distinction without corresponding embedding response |
| XOR or other interaction | Linear explanation misses a known nonlinear relationship | Failure attributed to model class, reduced by suitable interaction model |
| Global family shortcut | Feature correlates with family but not within-family variation | Global success weakens under group-held-out or within-family controls |
| Annotation gaps | Missingness concentrated in one region | Reduced coverage/abstention rather than automatic excess |
| Ties and duplicates | Equal vectors or large tied feature classes | Self exclusion, tie-aware comparison, no invented structure |
| Normalization confound | Feature encoded mainly in vector magnitude | Raw/norm analysis differs from direction-only atlas |
| Narrow graph bridge | Connectivity depends on graph policy or a few points | Appropriate graph sensitivity; no causal boundary claim |
| Coordinate rotation | Orthogonal transform preserves unit-space relations | Distance/neighborhood results invariant within numerical tolerance |

The rotation case also clarifies that coordinate masking is basis-dependent, even though distances are not. It should remain a declared stress test rather than universal representation robustness.

Additional integration checks should cover exact ID alignment, unknown-aware predicates, missing feature distances, multiple scales, immutable geometry under overlays, null-case abstention, held-out pair endpoints, and source-only runs without fabricated vector evidence.

For exploratory selection, do not automatically display conventional confirmatory p-values after choosing the most striking region. The current audit's correction family does not automatically cover new region searches, model searches, or pair-level hypothesis tests. Predeclare confirmatory cases or validate discoveries on reserved groups.

## 14. Suggested module responsibilities

These are proposed responsibilities, not a demand to reorganize all code immediately.

| Existing module area | Keep responsibility | Extension |
|---|---|---|
| `parquet_audit/semantics.py`, `ingest.py`, `config.py` | Source interpretation and asset validation | Shared cohort/identity export |
| `embedding_feature_audit/geometry.py`, `feature_overview.py` | Feature organization on ordered neighborhoods | Per-anchor fields with denominators |
| `embedding_feature_audit/modeling.py` | Held-out feature probes | Group-aware cross-fit exports and local summaries |
| `embedding_feature_audit/topology.py` | Bounded complete-distance topology | Linked selections and construction provenance |
| `geometric_ecology/core.py`, `validation.py` | Geometry and independent geometric checks | Eventually accept a validated neighbor backend |
| `geometric_ecology/io.py`, `display.py`, viewer scripts | Geometry export and navigation | Optional feature registry and evidence overlays |
| New bridge/comparison modules | Alignment and independent-account comparisons | Feature distance, pair design, residuals, evidence statuses |

Both projects use a fairly direct arrays/tables/functions style. Keep that style initially. A narrow coordinator and versioned artifact contract will be easier to validate than a large abstraction layer that absorbs both projects at once.

## 15. What the combined direction would achieve

The immediate result would let a user move through a geometric atlas and inspect how observed properties, annotation support, local organization, and held-out probe errors vary across it.

The next result would let that user select a boundary, point, route, or region and ask a more precise question: **which actual relations does the current explanatory system predict incorrectly, and does that failure persist under appropriate controls?**

The long-term research direction is a versioned history of explanatory change. A newly measured source property might resolve a stable discrepancy; a better model might reveal an interaction; group controls might expose a shortcut; an intervention might weaken an apparent explanation. Some disagreements will remain unresolved. Preserving these outcomes is more informative than forcing every region into a comprehensible/incomprehensible binary.

The two projects are complementary because Ecology supplies relational structure and navigable context, while the audit supplies explicit external measurements and tests of their accessibility and organization. Their combination becomes distinctive when it preserves the independence of those accounts and makes their disagreements inspectable, testable, and revisable.

## Appendix: source map

### Geometric Ecology

- `README.md`, `pyproject.toml`: usage, scale limitations, declared package version.
- `src/geometric_ecology/core.py`: normalization, exact neighbors, graph support, profiles, H0, partitions, frozen query scoring.
- `src/geometric_ecology/validation.py`: geometric recovery, route tests, synthetic checks, descriptive nulls.
- `src/geometric_ecology/atlas.py`, `terrain.py`, `mesh.py`, `flat.py`: layouts, terrain, boundary evidence, local lenses, spectra, contours.
- `src/geometric_ecology/io.py`, `display.py`: persistence, exports, display field registry.
- `src/geometric_ecology/observer.py`, `observer.js`, `observer_core.js`: geometry-only export and projected directional selection.
- `docs/OBSERVER.md`, `docs/criteria.md`, `docs/reading_atlas.md`, `docs/methodology.md`: interpretation and design context.
- `tests/`: Python geometry/export checks and JavaScript state checks.

### Parquet Representation Audit

- `README.md`, `docs/data-model.md`, `docs/analysis.md`, `docs/probes.md`, `docs/information-preservation.md`: declared semantics and analytical scope.
- `parquet_audit/config.py`, `semantics.py`, `ingest.py`, `runner.py`: validation, source statistics, cohort selection, asset alignment, execution.
- `parquet_audit/predictions.py`, `reporting.py`: supplied predictions and source/report adaptation.
- `embedding_feature_audit/dataframe_report.py`: analysis orchestration and output manifests.
- `embedding_feature_audit/geometry.py`, `statistics.py`, `feature_overview.py`: neighborhoods, local entropy, feature association and summaries.
- `embedding_feature_audit/modeling.py`, `normalization.py`, `experiments.py`: probes, direction/magnitude comparisons, artificial missingness.
- `embedding_feature_audit/topology.py`, `comparison.py`: sampled filtrations, bounded H1, paired views.
- `embedding_feature_audit/exploration.py`, `explorer_html.py`: feature queries, cohorts, bounded row exploration.
- `examples/`: synthetic generators, aligned example vectors, schemas, and saved reports.
