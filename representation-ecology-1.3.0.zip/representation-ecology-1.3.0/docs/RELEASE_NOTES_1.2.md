# Representation Ecology 1.2.0

The guide now begins with **What shape is this?** and integrates all twelve geometry readings in four families. Each reading explains the observed change, its possible use and the limit of that inference. Feature, discrepancy and held-out prediction questions remain connected to the same observer and profiles.

Continuous numeric fields, raw-level contours and continuous point colors replace numeric shape bins. Actual categories keep distinct symbols. Signed discrepancy and magnitude are separate modes. Fields honor missing observations, finite support and component boundaries; missing values never become observed zeros.

Local anatomy uses the actual centered embedding-neighbor PCA-3 coordinates and the full variance spectrum. This makes hidden local variation inspectable without pretending the global projection preserves every direction. Local frames are independently fitted.

The visible relief slider supports flattening and exaggeration. Geometry remains the default height; an explicit option makes the selected numeric field the height. Observed corpus contrast is the guide default, with semantic, robust and fixed kept-region references also available. Ranges remain stable during walking; changing contrast never recomputes analysis.

Competitive route counts, covariance directions and prediction explanations are distinguished throughout. Route bundles are optional, bounded examples with fixed endpoints, and route overlap is a reason to inspect fragility rather than infer robustness from count alone. Reference-table interpretations have been made consistent with these limits.

Existing-run conversion and viewer-update commands have been removed. Current analyses are generated from inputs into fresh outputs. Analysis, comparison, investigation records, interventions, source audits, geometry/reference views and the full workspace remain available.

The package includes fresh 360-item visual and 240-item omitted-factor examples, source code, setup instructions and reproducible checks. Validation: 48 Python tests, five JavaScript checks, both browser suites with WebGL, and a wheel build passed. See `VALIDATION.json` for scope.
