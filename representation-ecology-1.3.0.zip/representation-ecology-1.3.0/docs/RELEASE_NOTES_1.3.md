# Representation Ecology 1.3.0

This release links geometric extent, retained dimensions and broad/local target reconstruction in the existing observer. The four questions, continuous fields, contours, local shape/spectrum views, relief, original source/geometry analyses, probes, investigation tools and full workspace remain available.

The visible distance-filtration control exposes exact H0 components of the displayed maximum-k mutual candidate graph. It highlights and captures the connected extent touching here without changing atlas positions. Missing candidate edges remain a declared limitation.

Numeric reconstruction compares training-only PCA/ridge broad and routed local accounts under group-separated outer test folds. Inner validation selects an adequate tested account before test labels are observed. The interface includes signed paired gain, dimension curves, full-evaluation-population versus displayed-region readings, transfer heatmaps, and explicit missing support. Persisted transforms, coefficients, choices, support and timings make the experiment inspectable.

Resource planning adds exact-work, working-array and output gates. The offline synthetic generator and real-data numeric population command use memory-mapped arrays and batched reconstruction without full-population pair comparisons. They retain only a declared sample for the detailed atlas. Plans create no population data. The larger recipe defaults to 100,000 rows and can be changed by the user; it was not run at large scale for this release.

Scope is deliberately explicit: no million-point benchmark, whole-population interactive geometry, ANN backend, density hierarchy or new H1 engine is claimed. Existing bounded optional topology remains available. Detailed current protocol and commands are in `SCALES_AND_POPULATIONS.md`.

Validation: 22 combined/new Python tests plus 32 retained Ecology tests, five JavaScript checks, three browser suites, and a wheel build. The largest new population smoke fixture is 384 rows; its atlas has 160 rows. Large demonstration data is not bundled or generated during validation.
