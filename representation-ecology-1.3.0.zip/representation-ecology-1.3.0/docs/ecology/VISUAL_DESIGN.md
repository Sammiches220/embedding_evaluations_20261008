# Visual design

Both the flat atlas and orbitable mesh expose measured geometry. Choose the
flat view for exact planar comparisons and independent raw-value contours;
choose the mesh when elevation makes a field easier to inspect.

Every mesh peak is interpreted through its selected measurement. Surface color
is a second independent channel: covariance variance omitted by two axes.
Relief exaggeration, reference scaling and field choice are separate controls.
No apparent mountain certifies a predictive regime or travel difficulty.

Global is the default; local contrast is explicit and persistent. Subsets can
cross cells and components but do not create paths between them. Blue outlines
identify fixed reference members. Orange point markers expose clipping. The
shared readout retains raw selected values and reference limits. The global
measurement arrays and graph remain untouched by visual transformations.

See [Reading the atlas](reading_atlas.md), [flat view](FLAT_VIEW.md),
[mesh view](MESH_VIEW.md) and [calibration](criteria.md) for current behavior.
