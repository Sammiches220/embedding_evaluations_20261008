# Mesh view

The orbitable mesh and flat atlas are complementary first-class views.
See [Reading the atlas](reading_atlas.md) for active height meanings, raw-value
scales, subset selection, independent hidden-variance color, and relief controls.

The rendered terrain is an interpolated measurement field over schematic atlas
coordinates. It is not an embedding-manifold mesh. Local neighbor hull glyphs
are actual PCA-3 offsets normalized to a common display size; spectral bars
expose omitted directions. Facets are rendering geometry, not a dimension count.

Global, robust-global and subset contrast share the flat view's frozen reference.
The camera never changes that reference. Point and road heights follow the same
interpolated field as the surface; inspectors retain original unsmoothed values.
Disconnected components have separate masked surfaces and no fabricated roads.
