# 0.6.2 follow-up checks

- All 30 numerical tests passed after the UI/reference changes.
- Selection-state tests cover additive/toggle removal, last-member corpus fallback,
  undo, explicit subset activation and direct click-to-deselect inspection.
- Actual relief sampling/projection tests continue to pass.
- Translation tests cover all four height fields, flat-field changes and shared,
  fixture-specific reference rows in the lab. The curated payload contains nine
  tables and excludes the source documents' invented route/feature examples.
- All inline scripts in generated explorer, reference and controlled-lab pages
  pass JavaScript syntax checks with no unresolved reference placeholders.

Rendered browser/WebGL verification remains unavailable in this environment;
these are numerical, controller and export checks, not a visual sign-off.

# 0.6.1 follow-up checks

The 30 Python tests still pass. The controller harness additionally executes
actual relief sampling, surface construction and screen projection functions:
subset contrast expands vertical span, a shared gain changes projected height,
and zero gain removes elevation. Generated explorer/reference scripts parse,
and the reference data contains 24 tables and four complete height translations.
Real-browser visual/WebGL verification remains unavailable in this environment.

# Verification record · 0.6

Executed on the revised project:

- 30 Python unittest checks passed. They cover geometry, connectivity, real
  graph roads, persistence round trips, frozen query attachment, masked contours,
  covariance, calibrated thresholds, empty/constant references, configuration
  errors, deterministic bootstrap results, threshold scale equivariance and
  actual omitted-route cap detection.
- `node tests/scale_state.cjs` passed. This dependency-free controller harness
  checks global/robust/subset modes, fixed membership while changing selected
  items, constant ranges, invalid and arbitrary-ID imports, and unchanged data.
  It is not a rendered browser test.
- A 400-item, 16-dimensional synthetic map was generated end to end with 16
  requested cells, 16 landmarks and two resamples. Independent geometric
  evaluation and held-out attachment ran; null controls were skipped for this
  integration run (`--skip-nulls`). The two large examples were not regenerated.
- All exported JavaScript blocks and source JavaScript parsed successfully.

A real-browser visual/WebGL check was **not completed**: no browser executable
was installed and the Chromium download returned an invalid archive. No claim
of visual QA is made. `tests/browser_scaling.cjs` supplies a real-browser check
for the new controls and unchanged geometry when Chromium is available.
`tests/browser_smoke.cjs` retains the broader 20,000-item demo checks.

Version 0.6 changes map schema and generated terrain/display results. Earlier
verification counts and example screenshots do not validate this release.
