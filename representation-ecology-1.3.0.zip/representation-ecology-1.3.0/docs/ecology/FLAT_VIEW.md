# Flat view

See [Reading the atlas](reading_atlas.md) for interpretation and selection.
Color fields use the shared display scale. Contours retain corpus-selected raw
quantile levels independently of contrast; their labels are measured values.
Spectrum rings and local PCA ellipses describe neighborhood variation in a local
frame. Positions never change with field, contrast or preset changes.

Blue outlines identify the frozen reference subset. Orange squares flag raw
values clipped by the current range. The inspector and scale readout retain
raw values, corpus range, displayed range and finite reference sample size.
Constant ranges map to the middle color without inventing variation.
