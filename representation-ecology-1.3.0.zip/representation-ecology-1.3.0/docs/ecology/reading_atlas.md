# Reading the atlas: geometry first

An item is a vector produced by an embedding model. The atlas measures how those
vectors are organized. A downstream predictor is a separate learned system;
neither a mountain nor a plain establishes its accuracy. Interpret source
features only after examining the actual items and validating feature probes.

## Two complementary interfaces

The flat atlas keeps positions planar, using independent colors and raw-value
contours. Spectrum rings show which local directions a two-axis picture omits.
The orbitable mesh turns the selected measurement into elevation. Its surface
is an interpolated field over schematic atlas coordinates, **not a reconstruction
of the embedding manifold**. Triangle count, steepness and screen distance are
not dimension, geodesic length, or prediction error. Local neighbor hulls instead
show actual offsets in a local PCA frame; their size is normalized for legibility.
They do not share a meaningful global orientation.

| Height field | High values | Low values |
|---|---|---|
| Effective directions | Many covariance directions contribute | Few directions contribute |
| Distance-growth dimension | Neighborhood population expands rapidly with radius | Slower expansion |
| Route-set ambiguity | Several competitive regional paths to reference destinations | One route dominates |
| Metric variation | Uneven neighbor spacing, as a corpus rank | More uniform spacing |

Mesh color independently shows variance hidden by two axes. Its legend and the
height readout must be read separately. Relief multiplies display height only.
Low relief is a useful visual check, but a peak surviving it is not a statistical
test or evidence of a predictive regime. Inspect raw effect size, support and
sensitivity; then validate held-out outcomes.

## Fixed geometry and descriptive metaphors

Roads follow real retained edges. A regional cut disconnects the regional
quotient graph; the tests also check the corresponding original graph.
A marked narrow pass additionally has unusually low conductance under the
recorded corpus calibration. Ridges require low conductance at every analyzed
scale, unusually long boundary crossings, and a density dip. Cliffs require
unusually large relative gaps and crossing contrast. These are candidates,
conditional on graph scales and navigation cells, not semantic boundaries.

Islands are disconnected retained-graph components. Water means no route in
that graph; component spacing on screen is arbitrary. Fog shows sensitivity
under reference removal or compression. Compression disagreement may reflect
useful subtle structure, noise, or both. No single field supplies a confidence
score for prediction.

A possible operating region combines dense support, geometric near substitutes,
low disagreement, useful local diversity and supported access. These are
questions to investigate, not an automatically certified “safe settlement.”

## Global, robust-global and subset contrast

Global is the default. Fractions and percentile ranks use 0–1; route count uses
1–the configured enumeration budget. Dimension fields use finite corpus-observed
ranges. Robust global uses the 5th–95th display quantiles; orange point markers
and clipping counts expose clipped extremes. These quantiles are an explicit
visual convention, not an inference threshold.

Capture any item, its original-space neighbors, a navigation cell, a connected
component or a computed graph route. “Add to subset” unions captures. Import a
JSON array of string item IDs for arbitrary subsets; export the selected IDs for
reuse. Unknown IDs reject the whole import. Blue outlines identify the frozen
members. Zooming, selecting another item, switching views and changing relief
never silently change the reference subset.

Subset contrast uses finite raw minima and maxima within that fixed set. It
applies the resulting mapping to the whole displayed corpus, making outside
values clip visibly. Thus outside points share the same local reference; they
are not silently given independent scales. The persistent LOCAL CONTRAST badge,
corpus range, display range, valid reference count and raw selected value make
this exaggeration explicit. Single-valued ranges map to the midpoint with a
constant-range message. Invalid values are excluded from range estimation.

Flat colors and mesh heights use the same reference mode. Flat contour positions
and labels retain corpus-selected raw quantile levels, explicitly independent of
contrast. This avoids making moving contours look like changing geometry.
Contours may therefore be sparse within a narrow-range subset. All measurement
arrays, ranks, thresholds, neighbors, graph routes, cells and coordinates remain
unchanged by display controls. The 2.5D relief view uses the same mapping.

## Routes, feature reconstruction and prediction

Route-set ambiguity is destination-conditioned: several similarly inexpensive
chains of neighboring item regions connect a particular source and destination.
The overview is a median across up to three geometry-selected destinations.
The bundle inspector states its endpoints, effective count and cap flag.
Enumeration is bounded; route count is not density, all-path entropy or semantic
confusion. Useful redundancy and difficult-to-summarize geometry can both have
high counts. A low count can mean a clear corridor or a fragile bottleneck.

Compare original features or held-out feature reconstruction along the actual
routes to name candidate feature pathways. Reconstruction shows recoverable
information, not causation. Test whether route-specific differences improve
held-out predictive performance and persist under folds and geometry settings.
The atlas does not automatically fit a predictor or feature reconstruction model.

An item known to the atlas may be outside the predictor's training population.
For strict deployment evaluation, build a training-only frozen atlas, train the
predictor, then attach held-out vectors using `score`. A full-corpus atlas is a
transductive descriptive analysis because evaluation items helped shape it.

Frozen attachment reports candidate regions, distances, compression response
and entry paths without changing the corpus. Proxy support is not prediction
accuracy. It cannot establish a new island, bridge, articulation role or
persistence of a new population. Rebuild for structural changes, and build a
separate atlas for a changed encoder unless compatibility has been validated.

The four supplied interpretation documents are retained in
`interpretation_sources/`. This guide qualifies their intuitive predictive
claims and generalizes island contrast to arbitrary subsets.


## Current selection and reference controls (0.6.2)

Inspection and membership are separate: Inspect mode reads one item; Edit subset
mode toggles clicked points in the blue-outlined set. Use group subtraction,
remove inspected point, the searchable member list, clear or undo to deselect.
The saved subset does not set the range until you choose Use subset for color &
elevation. The active-population banner reports M / N items or Entire corpus.
Removing the last member returns to the corpus. Escape exits edit mode and clears
inspection; clicking empty space clears inspection without deleting the subset.
Point diameter resizes markers and corresponding picking tolerances/outlines.

Use the bottom Reference tab for topic-specific tables and the controlled lab's
Follow demonstration reference for relevant rows. Both use the same curated data
as atlas_reference.html. Domain-specific reconstruction examples from the source
guides are not presented as application features or measured results.
