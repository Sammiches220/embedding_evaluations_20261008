# Automatic criteria and audit trail

Version 0.6 replaces several fixed terrain claims with reproducible descriptive
calibration. `criteria.json` and `atlas.json → terrain.calibration` record the
actual values. The manifest retains configuration so re-export uses the same
policy. No labels or source metadata select the geometry or thresholds.

| Quantity | Automatic policy | Qualification |
|---|---|---|
| Near-substitute chord tolerance | Lower Tukey fence of first-neighbor distances, floored at zero | Geometric closeness, not semantic interchangeability; zero admits exact duplicates only |
| Narrow pass | Exact regional cut plus conductance below the corpus lower fence | May select none; depends on the navigation partition |
| Ridge candidate | Conductance below lower fence at every tested graph scale, plus crossing contrast and density dip above upper fences | Strong descriptive filter, not a discovered semantic boundary |
| Cliff candidate | Crossing contrast and local relative gap above upper fences | All qualifying candidates retained; no silent top-24 inference cap |
| Route cost band and temperature | Median within-neighborhood distance coefficient of variation | Measured policy proxy, not calibrated route uncertainty |
| Flat contour levels | Unique corpus deciles, 10% through 90% | Presentation choice in raw units, not inferred thresholds |
| Dimension display range | Finite corpus-observed minimum and maximum | No hidden 95th-percentile clipping in Global mode |

For a reference sample, upper fence = Q3 + m × IQR and lower fence = Q1 − m × IQR.
The default m=1.5 is a named robust descriptive convention, **not a magic
statistical significance level**. Strict inequalities avoid manufacturing
outliers in a constant population. Empty samples report unavailable criteria.
Each fence includes sample size, a reproducible 2.5–97.5% bootstrap interval,
and thresholds/selected counts at 0.75m, m and 1.25m. Bootstrap draws use at most
2048 observations each for bounded cost; the point threshold uses all values.
Graph-derived observations are dependent: these intervals describe threshold
sensitivity, not inferential coverage or false-discovery control. Multi-condition
ridge classifications may be conservative and return no candidates.

Route enumeration requests one extra route to determine whether a qualifying
route was actually omitted. Reaching the budget exactly does not by itself mark
capping. Each source/destination detail includes candidate counts at half, equal
and double the cost-band excess, with truncation flags. These counts use bounded
enumeration, so they are lower bounds when marked truncated. Entropy is computed
only within the chosen band and budget. Automatic band excess and temperature
are the median local distance CV; this remains an exploratory operational rule.

## Overrides

Pass `--criteria criteria_config.json` to `build` or `demo`, or pass a dictionary
as `build_map(..., criteria=...)`. Omitted values use defaults. Unknown keys and
invalid values fail instead of being silently ignored.

```json
{
  "fence_multiplier": 1.5,
  "bootstrap_repeats": 128,
  "route_limit": 24,
  "route_detour": null,
  "route_temperature": null,
  "substitute_tolerance": null
}
```

`null` requests automatic selection for the last three values. Explicit detour
must be at least 1, temperature positive, and tolerance nonnegative. Route budget
is 2–512; bootstrap repeats are 16–512. The default 24-route budget is a compute
budget, not an upper bound on actual connectivity. Change the budget to check
saturation rather than interpreting clipped counts as complete.

## Remaining explicit policies

Neighborhood scales, retained-edge support, partition cell count, reference
subsample fraction, compression ranks and the 0.01-chord perturbation remain
recorded experimental choices. They are not claimed to be universally optimal.
The role tags now state their percentile/cutoff rules directly rather than
calling them intrinsically dense, complex or unstable. `--scales`, `--support`,
`--regions`, `--resamples` and `--landmarks` retain direct configuration.

Raster grid size, smoothing, coastline occupancy, label budgets and glyph
spacing are drawing choices, not scientific detection criteria. They cannot
create navigable edges. The contour inventory and masks can change visual
appearance without proving new topology. Surface holes and triangle slopes
must not be used in place of the retained graph.

Automatic descriptive calibration reduces manual cutoff work. It does not
replace external validation, null controls, parameter sweeps or outcome-specific
held-out tests. In particular, bootstrap threshold intervals do not account for
rebuilding the entire atlas under new samples.
