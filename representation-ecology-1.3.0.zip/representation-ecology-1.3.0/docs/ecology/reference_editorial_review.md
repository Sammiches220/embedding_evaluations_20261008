# Reference editorial review

The application reference is curated from the supplied guides. It describes implemented controls and distinguishes external modeling tasks. The source documents remain in interpretation_sources for provenance.

| Source table | Treatment in the application |
|---|---|
| 3D mesh: what a mountain means (table-0) | Adapted to measured fields and actual navigation controls |
| Relief scale: visual emphasis, not model ability (table-1) | Merged into display-reference and control tables; removed universal low-relief significance claims |
| Relief as a sensitivity control (table-2) | Merged into display-reference and control tables; removed universal low-relief significance claims |
| Flat atlas: how to read each measurement layer (table-3) | Adapted to measured fields and actual navigation controls |
| Flat-map presets (table-4) | Adapted to measured fields and actual navigation controls |
| Fixed geography: meanings that do not change with the selected layer (table-5) | Adapted to measured fields and actual navigation controls |
| Backward translation through the learned representation (table-6) | Reframed as investigation workflow, not certified settlement or learned semantics |
| Establishing a hypothetical settlement (table-7) | Reframed as investigation workflow, not certified settlement or learned semantics |
| The issue (table-8) | Merged into display-reference and control tables; removed universal low-relief significance claims |
| Recommended interface: three scale modes (table-9) | Merged into display-reference and control tables; removed universal low-relief significance claims |
| How this applies to the flat atlas (table-10) | Merged into display-reference and control tables; removed universal low-relief significance claims |
| How this applies to the 3D mesh (table-11) | Merged into display-reference and control tables; removed universal low-relief significance claims |
| Predictive interpretation (table-12) | Merged into display-reference and control tables; removed universal low-relief significance claims |
| What route-set ambiguity is and is not (table-13) | Merged into route evidence and limits |
| Translation across interpretation levels (table-14) | Merged into route evidence and limits |
| Backward translation to source features (table-15) | Removed domain-specific examples and invented scores; replaced with available route evidence and explicit external work |
| Role of feature-specific reconstruction models (table-16) | Removed domain-specific examples and invented scores; replaced with available route evidence and explicit external work |
| Role of feature-specific reconstruction models (table-17) | Removed domain-specific examples and invented scores; replaced with available route evidence and explicit external work |
| Predictive interpretation (table-18) | Merged into route evidence and limits |
| 1. A known corpus item outside the predictor's training region (table-19) | Adapted to actual frozen-score outputs; removed unsupported prediction/applicability-report capabilities |
| 3. A new item outside the entire mapped corpus (table-20) | Adapted to actual frozen-score outputs; removed unsupported prediction/applicability-report capabilities |
| 4. One new item versus a new population (table-21) | Adapted to actual frozen-score outputs; removed unsupported prediction/applicability-report capabilities |
| 5. Backward interpretation through the embedding methodology (table-22) | Adapted to actual frozen-score outputs; removed unsupported prediction/applicability-report capabilities |
| 7. Recommended prediction output (table-23) | Adapted to actual frozen-score outputs; removed unsupported prediction/applicability-report capabilities |
