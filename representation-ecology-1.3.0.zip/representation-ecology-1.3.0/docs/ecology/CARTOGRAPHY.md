# Cartography

1. Normalize finite nonzero vectors and construct nested mutual-neighbor graphs.
2. Retain edges by declared scale support; disconnected components are separate.
3. Partition graph-distance navigation cells and identify representative items.
4. Lay out connected components using graph distances and population magnification.
5. Draw roads from real graph paths, including their actual crossing-edge evidence.
6. Interpolate raw measurement fields within each component's occupancy mask.
7. Apply explicit display-only scales to colors and heights at rendering time.

Horizontal layout, magnification and raster smoothing are schematic. They do not
supply navigation edges or prove manifold topology. Local glyphs show measured
neighbor offsets in independent PCA frames. Never infer connectivity from a
surface triangle, contour seam, screen-space proximity or apparent slope.

The raw channels are `covariance_dimensions`, `dimension`, `route_count`,
`variation`, `hidden_two`, `density`, `substitutes`, `resampling_loss`,
`compression_loss` and `fog`. Metric variation and density are corpus ranks;
route counts summarize recorded reference destinations. Backend pre-normalized
height channels have been removed. The browser applies one selected reference
mode, independently of relief exaggeration.

Contour levels are unique corpus deciles in raw units. Raster interpolation and
point/road elevation use the same fields; the selected-point inspector retains
unsmoothed raw values. Invalid covariance estimates are excluded from reference
ranges and rendered as unavailable in flat coloring.

For calibrated pass, cliff and ridge criteria, see [criteria](criteria.md).
For the distinction between field encodings and predictive hypotheses, see
[Reading the atlas](reading_atlas.md). Color and contour reference conventions
are explicitly distinguished in the interface.
