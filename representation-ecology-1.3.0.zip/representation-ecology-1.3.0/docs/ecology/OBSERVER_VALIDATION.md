# Geometry-only observer validation · 0.10

Validated on 2026-10-22.

- **32 Python tests passed**, including exact multiscale source-lens comparisons and a data-boundary test that injects item text, image paths and semantic labels and verifies they are absent from the observer renderer payload.
- `observer_state.cjs`: passed. Covers heading-relative WASD, normalized diagonals, arrow-turning without translation, target geometry, fan construction, radius selection, finite geometric aggregation, directional profile values and unsupported gaps.
- Existing `scale_state.cjs` and `reference_state.cjs`: passed, preserving global/subset display behavior and reference interpretations.
- `browser_observer.cjs`: passed in Chromium 153 with software WebGL through Playwright. The mesh rendered actual triangles with no reported WebGL errors. Tests exercise explicit selection/release, keyboard translation and turning, independent HERE/AHEAD populations, 2D-to-3D population preservation, camera immutability while selected, 3D target-range changes, surface projection and frontmost picking, actual double-click surface placement, camera following, all ten height/color/contour selectors, WebGL contour batches, profile checklist and panel controls, field changes, source k, display scopes, empty geometry, PCA and return to the original atlas.
- Browser tests confirm there is no media/feature UI, no media-manifest request, no per-point metadata or features, and no external evaluation payload in the observer's renderer.
- Desktop 2D and 3D screenshots were inspected. Unsupported ribbons are hidden rather than leaving stale graphics visible. Distinct HERE and LOOKING AT annotations and the raw profile make the attention target explicit.

The shipped example is synthetic geometry only. Software correctness tests do not establish semantic meaning, physical terrain difficulty, or improved human navigation. Source-geometry estimation remains the existing implementation; the directional profile aggregates its existing signature-scale measurements.

Resolution validation checks that each grid is rebuilt from measured point values, includes all contour channels, updates 2D/3D rendering without WebGL errors, changes mesh facet counts, and preserves observer populations and coordinates. Small-chart labels are visually checked at narrow card widths.
