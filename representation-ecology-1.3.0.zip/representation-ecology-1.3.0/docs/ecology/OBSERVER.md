# Geometry-only observer · 0.10

The observer has access to embedding-derived geometry and item IDs only. Item metadata, semantic features, images, media manifests, galleries and the image-demo pipeline have been removed. There is no compatibility mode for the previous media/feature observer.

## Run

From the extracted project directory:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
geometric-ecology serve --map examples/observer_demo --port 8765
```

Open **http://127.0.0.1:8765/observer.html**. The bundled 360-vector example contains synthetic geometric structures, with no per-item semantic labels in its exported browser data. Build a map using `build --embeddings ... --ids ... --encoder ...`, then serve the resulting directory.

The project has one corpus per export directory, with graph-atlas and PCA coordinates. The observer exposes its existing 2D atlas, 3D mesh, and raw PCA views. Changing between 2D atlas and 3D mesh preserves observer coordinates and the observed population. Switching to/from raw PCA resets position because it uses a different coordinate system.

## Select, move, look

The observer starts **released**. Click **Select observer** or its dot to select it; Escape or Release observer releases it. There is no pointer lock and mouse motion never changes the observer's attention.

| Control | Behavior while selected |
|---|---|
| W / S | Forward / backward relative to the observer's heading |
| A / D | Strafe left / right relative to heading |
| Left / right arrows | Turn observer heading; camera stays fixed |
| Up / down arrows | Increase / decrease look distance in both 2D and 3D |
| Escape | Release observer and clear held keys |
| Double-click map / supported 3D surface | Place and select observer |
| Mouse drag / wheel | Existing pan/orbit and zoom controls, always available |
| Follow observer | Center the camera on the observer as it moves |

Typing in an input or select does not move the observer. Blur, visibility changes and release clear held keys. Arrow keys are intercepted before the embedded mesh's ordinary keyboard controls only while the observer is selected. When released, the original website keyboard behavior remains available. Movement clamps to projection bounds; unsupported areas inside those bounds remain possible and are reported honestly.

The 3D view remains a terrain observer, not a first-person game engine: arrow keys control heading and target range, not a simulated optical ray through high-dimensional space. The look distance control independently sets the target's distance along the ground-coordinate heading. Mouse orbit can change the external camera without altering that heading.

## Here and looking at

The teal dot and circle identify **HERE**. The amber target and circle identify **LOOKING AT**, located a configurable projected distance along the heading. Each circle selects all projected points within the same explicitly chosen radius.

Turning updates the target, its source-geometry ribbon, the numerical comparison, and the directional profile. It does not move the observer or change the HERE population. Moving updates both. There is no hover-driven attention system, so moving the mouse between website controls does not interrupt the comparison.

The optional direction fan is hidden by default. It is only a direction cue: **the amber circle, not the fan, defines the compared population**. Fan angle does not change the measurements.

## Seeing rises, mountains and cliffs

All ten embedding-derived measurements are available as height, color, contours, and observer profiles: distance-growth dimension, effective directions, hidden variance, density rank, near-substitute fraction, regional route alternatives, reference-subset disagreement, compression disagreement, metric-variation rank, and combined geometry disagreement.

The terrain selector drives height and the largest profile. Independent color and contour selectors work across atlas, relief and mesh. Raw PCA colors individual points with the selected metric; it has no interpolated contour surface. A grid below the active profile shows every other metric by default. The “Choose additional profiles” checklist hides individual non-active charts; the active chart always remains visible. Each chart has its own labelled raw metric scale, shared across its HERE→AHEAD samples, not across unlike units. Sampling populations are reused across all charts.

The observer details and profile panels have draggable edges and hide/show buttons. Focus an edge and use arrow keys to resize with the keyboard. Full-atlas side panels also have resize edges and hide/show buttons on desktop; its existing bottom-strip collapse control is preserved and a resize edge is added. At narrow widths panels stack vertically.

The **Here → ahead** profile samples 19 equally spaced projected positions along the heading. At each position, it summarizes the existing per-item geometric measurements within the same observation radius. Dots are medians; vertical bands show the finite minimum–maximum. A common corpus raw scale supports direct comparisons. Missing samples and samples without a shared retained-graph component are not joined. The text readout reports the highest sampled median and the largest supported adjacent change, without inventing significance thresholds.

A high crest or sharp step is visible evidence of a change in the selected measurement across the projection. It is **not** evidence of a physical obstacle, semantic boundary, source-space travel distance, or a difficult graph route. The directional line is a survey, not a path through the neighbor graph. Roads and connectivity remain the atlas's existing measured graph. HERE and AHEAD sharing no retained-graph component is reported explicitly. The raw profile can differ from the mesh's smoothed display surface.

## 3D integration

The existing `mesh_view.js` and `MeshGL` renderer still draw the terrain. The observer overlays a surface-draped dot, circles, direction cue and survey line using the same camera projection and selected display height. These are always-visible annotations, not an occlusion model. The observer's intrinsic position remains in the atlas coordinate plane; display height is not an extra embedding coordinate.

Double-click placement in 3D finds the frontmost rendered surface triangle under the pointer and uses its barycentric projected coordinates. Empty water does not silently place the observer on an invented flat plane. Follow mode centers the camera on the observer's surface position. Source population selection remains identical between 2D atlas and mesh.

If WebGL is unavailable, the page reports it and returns to 2D; it does not claim to have rendered a mesh.

## Surface resolution

The **Surface resolution** selector is available in the observer toolbar and full atlas layer controls. Choose Coarse (27 × 27), Standard (54 × 54), or Fine (108 × 108) samples per component chart. Switching updates mesh facets, relief, 2D colors, supported surface masks, contour paths and surface picking together. The default is Standard.

Each level is prepared from the original per-item geometry measurements with the existing weighted spatial-bin estimator. This is not triangle subdivision of an already smoothed mesh. Gaussian smoothing spans one grid bin, so finer grids reduce the projected smoothing footprint; sparse areas can split into smaller patches. Higher resolution does not add observations or guarantee more reliable detail. Contour levels and color/height reference ranges stay comparable across resolutions. Component boundaries remain separate.

Observer position, HERE/AHEAD populations, raw profiles, source k and the graph do not change with surface resolution. To change the population used by the observer's profiles, adjust **Region radius** separately. Raw PCA has no interpolated surface, so this selector only affects atlas and relief/mesh views.

The small profile charts reserve separate rows for HERE/AHEAD and projected look distance, including at narrow card widths.

## Independent analytical and display scales

| Setting | Changes | Does not change |
|---|---|---|
| Region radius | HERE/AHEAD populations and profile sampling windows | Source-space neighbor graph or k |
| Look distance | Where the target lies | HERE population or source metric |
| Ribbon k | Exact cached representative source-space neighborhood | Map fields, profile measurements, population |
| Global / robust / HERE-relative display | Existing color and mesh-height normalization | Raw comparison values, graph, coordinates |
| Relief gain | Rendered mesh elevation | Raw geometry measurements |
| Camera zoom / orbit | Viewpoint | Observed populations and normalization |

The profile and metric table use the atlas's existing signature-scale measurements. The ribbon k selector is explicitly independent. Subset scaling uses the current HERE population; an empty HERE population falls back to corpus reference. The profile stays on a corpus raw scale even when display contrast is local, so a local contrast expansion cannot create an apparent raw metric difference.

## Ribbons and exactness

Both contexts use the existing `GeometryViews.inlineLens`; the expanded HERE view uses `GeometryViews.lens`. `observer.py` calls the existing `terrain.local_lens` estimator at the recorded source-neighborhood scales. No new dimensionality estimator is introduced.

A ribbon belongs to an explicitly identified cached representative, not the arbitrary projected-radius population. The nearest cached representative inside the population is preferred; if none exists, the nearest outside representative is visibly labelled **OUTSIDE**. Empty populations have no ribbon. Representative spectrum differences are reported at the same k. Local PCA axis orientations are separate frames and must not be interpreted as globally aligned directions.

## Data boundary and reused components

`io.export_explorer` no longer serializes item metadata into browser points. `observer_map.html` is generated from the **same renderer template** as the original atlas with a geometry-only payload and no external evaluation payload. The observer loads this dedicated page rather than the ordinary explorer's potentially attached validation report. The browser receives no source images, text, class labels or feature values. IDs, embedding-derived positions, neighbor identities, graph roles, metrics, fields and cached lenses are sufficient.

The original CLI's separate offline evaluation workflow remains available; its optional labelled validation inputs are not passed to the observer. `metadata.json` is not part of the bundled observer demonstration.

Shared code changes:

- `io.py`: omit per-point metadata; export the geometry-only renderer page.
- `explorer.html`: remove item-text presentation/search; retain ID inspection; preserve mesh view in observer links.
- `mesh_view.js`: expose camera-consistent projection, frontmost surface picking, centering and view turning; recognize hidden embedded docks as zero-height.
- `terrain_overlay.js`: describe the additional geometry-only height channels.
- Existing flat fields, contours, display scaling, mesh rendering, local PCA/ribbons, source geometry and calibration remain authoritative.
- `observer_core.js`: heading-relative controls, spatial indexing, finite geometric aggregation and directional profile sampling.
- `observer.js`: attention state, input focus, comparisons and annotations.

## Performance and limitations

Observer graphics animate independently; population/profile summaries update at most five times per second. A projected uniform-grid index and 64-entry region cache avoid repeated full point scans. Source-space geometry is precomputed at export, never recalculated on each frame. Mesh placement scans existing surface triangles only on deliberate double-click; it is not run for every mouse move.

The entire existing frozen atlas and cached representative lenses load once. This is still the original small-to-medium exact-backend prototype, not a streaming million-point viewer. Very large radius populations, fine meshes, software WebGL and follow-camera redraws can be slower. This version has no physical collision engine, optical visibility, semantic inference, content/media UI, or compatibility path for the removed observer features.

## Tests

```bash
python -m unittest discover -s tests -p 'test_*.py'
node tests/observer_state.cjs
node tests/scale_state.cjs
node tests/reference_state.cjs
# Serve examples/observer_demo separately, then:
npm install playwright
npx playwright install chromium
node tests/browser_observer.cjs
```

Set `CHROMIUM_EXECUTABLE` to test with an installed Chromium. Browser tests cover data exclusion, explicit selection, independent movement/looking, directional populations, 2D/3D state preservation, real WebGL rendering, surface picking, camera follow, scaling and unavailable geometry. Python tests compare exact cached lens outputs and verify injected item attributes never appear in the observer payload.
