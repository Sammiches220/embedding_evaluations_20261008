# Predictive Models, Known Terrain, and New Data

## Two learned systems

It helps to distinguish two separate systems:

1. The **embedding model** converts an item into a location in the learned landscape.
2. A **predictive model** may be trained using only items from one part of that landscape.

The terrain directly describes embedding geometry. It can indicate where the predictive model is interpolating versus extrapolating, but it does not itself guarantee how the predictive model will respond.

```text
Predictor training region = settled territory
Entire atlas              = known but not necessarily settled world
Outside the atlas         = newly encountered territory
```

---

## 1. A known corpus item outside the predictor's training region

Suppose the corpus map contains islands A, B, and C, but the predictive model was trained only on part of island A.

| Item location | Predictive interpretation |
|---|---|
| **Inside a populated training plain** | Strongest interpolation case; many similar training items support the prediction |
| **Near the edge of the training plain** | Mild extrapolation; reliability may begin to decline |
| **Along a road beyond the training region** | The representation supplies a gradual transition, but the predictor has not necessarily learned it |
| **Across a pass** | The item enters another regime through limited support |
| **Across a ridge or cliff** | Learned characteristics change abruptly; transfer risk is higher |
| **In a nearby mountain** | The item varies along learned directions that may be poorly represented in predictor training |
| **In a maze** | Several learned paths connect the item to training territory; multiple predictive explanations may be plausible |
| **On another island** | No supported graph route connects it to training territory; it is out-of-domain for the predictor even though it is known to the atlas |
| **In fog** | The item's placement is unstable, weakening any terrain-based confidence |

An item can therefore be **known to the atlas but unseen by the predictive model**.

### Applicability measurements

The atlas can support predictor-applicability features such as:

- distance to the nearest training item;
- fraction of local neighbors included in predictor training;
- graph distance to the predictor's training region;
- whether a pass, ridge, cliff, or water separates the item from training;
- local density and near-substitute support;
- effective dimensions around the item;
- resampling and compression disagreement.

These measurements describe support for applying the predictor. They do not establish that its prediction is accurate.

### Recommended validation

Evaluate held-out predictive performance separately by terrain:

```text
Performance inside training plains
Performance near training boundaries
Performance across passes
Performance in mountains
Performance on separate islands
Performance under heavy fog
```

This tests whether atlas distance and terrain actually correspond to predictive degradation for the target being modeled.

---

## 2. Avoiding evaluation leakage

If the atlas is built from the complete corpus, including evaluation items, it can still describe where those items lie. However, it is not a strict simulation of deployment because evaluation items helped determine:

- nearest neighbors;
- components;
- density ranks;
- navigation cells;
- interpolated fields;
- route structure.

For a clean predictive evaluation:

```text
Predictor-training embeddings
        ↓
Build a frozen training atlas
        ↓
Train the predictive model
        ↓
Attach held-out items as new queries
        ↓
Measure predictive quality by attachment terrain
```

This evaluates what the combined system would have known before encountering each held-out item.

---

## 3. A new item outside the entire mapped corpus

The existing embedding model first converts the new item into an embedding. The frozen atlas then attaches that vector to the old corpus without rebuilding the landscape.

| Frozen-atlas attachment | Interpretation |
|---|---|
| **Several close neighbors in one low-fog plain** | Familiar case; likely interpolation relative to the old corpus |
| **Neighbors concentrated near a stable mountain** | Familiar region, but the model recognizes several preserved directions of variation |
| **Support split across navigation cells** | Ambiguous placement or a transition item |
| **Attachment near a ridge or pass** | Candidate boundary or bridge item |
| **Distant neighbors within one island** | Weakly supported extension of a known regime |
| **Nearest items occupy separate islands** | The new item challenges the frozen component structure; no cross-water route should be invented |
| **No close or stable attachment** | Out-of-corpus relative to the existing map |
| **Attachment changes under compression or subsampling** | The apparent placement is fragile |

### What the frozen atlas can estimate

A frozen-map attachment can estimate:

- local distances;
- candidate navigation regions;
- candidate-region ambiguity;
- compression response;
- insertion reverse-neighbor count;
- entry routes to compatible landmarks;
- inherited or proxy stability measurements.

### What requires rebuilding the atlas

The frozen atlas cannot establish the new item's full:

- persistence across rebuilt graph scales;
- structural influence;
- articulation role;
- contribution to a new component or island;
- effect on existing roads, passes, ridges, or cliffs.

Those properties depend on recomputing the corpus graph with the new data included.

---

## 4. One new item versus a new population

| Incoming data pattern | Appropriate treatment |
|---|---|
| **One or a few items attach cleanly** | Score against the frozen atlas |
| **Many items attach to familiar regions** | Score initially, monitor distribution drift, and rebuild periodically |
| **Many items form a coherent group away from existing items** | Rebuild; they may create a new island, bridge, or settlement |
| **New items repeatedly change nearest-region assignments** | Investigate corpus or encoder drift and rebuild |
| **Items use a changed embedding model** | Build a separate map unless representation compatibility has been validated |

A single item cannot demonstrate stable new terrain. A coherent population can create new roads, alter passes, bridge islands, or establish an entirely new region.

---

## 5. Backward interpretation through the embedding methodology

For a new item, the central question is:

> Does the previously trained embedding methodology know how to place this item relative to the distinctions it already learned?

| Placement | Backward interpretation |
|---|---|
| **Strong attachment to a stable plain** | The encoder treats the item as a familiar variation |
| **Attachment to a stable mountain** | The encoder recognizes it through several preserved distinctions |
| **Attachment through a pass** | The encoder places it between learned regimes |
| **Placement across a ridge** | The encoder strongly distinguishes it from the predictor's training region |
| **Weak, island-like attachment** | The encoder treats it as a separate regime |
| **Foggy attachment** | The encoder's placement is fragile |
| **No defensible attachment** | The old representation and corpus provide little support for interpretation |

---

## 6. Practical applicability rules

```text
Inside a dense, low-fog predictor-training region
→ interpolation is relatively well supported

Connected but outside the predictor-training region
→ structured extrapolation; validate performance along the route

Across a pass, ridge, or cliff
→ likely transfer between learned regimes

On another island
→ unsupported transfer from the predictor's training region

Outside the corpus but attaching cleanly
→ a familiar new item relative to the frozen atlas

Outside the corpus with weak or unstable attachment
→ an out-of-distribution candidate

Many coherent external items
→ potential new terrain; rebuild the atlas
```

---

## 7. Recommended prediction output

A prediction should be paired with an applicability report rather than returned alone.

```text
Prediction: 0.73
Nearest-training support: low
Graph distance to training region: high
Barrier: stable ridge
Local density: low
Geometry disagreement: moderate

Interpretation:
Prediction is available, but the item lies outside the model's
well-supported training territory.
```

Useful report fields include:

| Field | Purpose |
|---|---|
| **Prediction and model confidence** | States the predictor's output |
| **Nearest-training distance** | Measures proximity to actual predictor-training items |
| **Training-neighbor fraction** | Shows how much local support comes from training data |
| **Graph distance to training region** | Measures supported travel through the learned landscape |
| **Barrier type** | Identifies passes, ridges, cliffs, islands, or water |
| **Local density** | Distinguishes supported regions from sparse extensions |
| **Geometry disagreement** | Warns when placement is unstable |
| **Applicability category** | Summarizes interpolation, structured extrapolation, regime transfer, or out-of-distribution status |

---

## Bottom line

The terrain is best used as an **applicability map** for a predictive model:

- It shows where the predictor has dense, stable training support.
- It identifies connected but untrained territory.
- It exposes barriers and separate representational regimes.
- It provides a disciplined way to interpret a new item's attachment to the old corpus.
- It does not replace held-out validation or guarantee prediction accuracy.

The embedding atlas describes **where an item sits relative to learned structure**. The predictive model's evaluation determines **whether predictions remain accurate in that terrain**.
