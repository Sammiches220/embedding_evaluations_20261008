# Global vs. Island-Relative Scaling in the Terrain Atlas

## The issue

The atlas uses a **shared corpus-wide measurement scale** across all connected components. This preserves honest comparison between islands, but it can hide meaningful variation inside a small island.

For example:

```text
Corpus-wide effective-direction range: 1.0 to 9.4
Selected island range:                2.1 to 3.0
```

On the global scale, the island may look almost flat and uniform even though its internal change from 2.1 to 3.0 is meaningful for navigating that island.

This creates a real trade-off:

| Display scale | Strength | Failure mode |
|---|---|---|
| **Corpus-wide** | Supports honest comparison across islands | Small or low-range islands can appear featureless |
| **Island-relative** | Reveals internal variation within one island | Small differences can look as dramatic as major corpus-wide differences |
| **Both, clearly labeled** | Supports global comparison and local navigation | Requires explicit legends and persistent mode indicators |

---

## What should remain corpus-wide

The underlying measurements should not be recomputed merely because the user zooms into an island.

These should remain fixed:

- embedding vectors and normalization;
- nearest neighbors and retained graph edges;
- connected-component membership;
- roads, passes, ridges, and cliffs;
- per-item raw measurement values;
- corpus-relative ranks and thresholds;
- route computations within each connected component;
- atlas coordinates.

Local contrast should be a **display transformation**, not a new geometric analysis.

---

## Recommended interface: three scale modes

| Mode | Display behavior | Best question |
|---|---|---|
| **Global** | Uses one shared corpus-wide range for every island | “How unusual is this island relative to the corpus?” |
| **Selected island** | Expands the selected island’s observed range while leaving measurements unchanged | “How is this island internally organized?” |
| **Robust global** | Uses shared corpus-wide robust limits, such as the 5th–95th percentiles, while flagging clipped extremes | “What broad structure exists without one outlier dominating the display?” |

The default should remain **Global** because it prevents visual exaggeration and preserves comparability.

---

## Required labeling

When local contrast is active, the interface should make the transformation impossible to miss.

Example:

```text
Field: Effective local directions
Display mode: Selected-island contrast
Global range: 1.0–9.4
Island range: 2.1–3.0
Displayed range: 2.1–3.0
Raw selected value: 2.6
```

Recommended visual safeguards:

- persistent badge: **LOCAL CONTRAST**;
- separate global and local legends;
- raw value retained in hover and selection inspectors;
- clipped-value markers in robust-global mode;
- reset-to-global control;
- no silent automatic rescaling when zooming.

---

## How this applies to the flat atlas

The flat atlas should allow the color field and contour field to share the same selected scale mode, or clearly show when they do not.

| Flat layer | Global interpretation | Island-relative interpretation |
|---|---|---|
| **Effective local directions** | Is this island more multidirectional than the corpus? | Where does learned variation increase within this island? |
| **Density rank** | How dense is the region relative to all items? | Generally keep corpus-relative; local reranking would change the meaning of the measurement |
| **Near-substitute fraction** | Are close substitutes common by the fixed corpus tolerance? | Local contrast may expose small differences, but the tolerance must remain corpus-defined |
| **Route alternatives** | How many viable routes exist on the shared 1–12 scale? | Local contrast can reveal differences within an island, but must not redefine the route count |
| **Metric variation rank** | How irregular is spacing relative to the corpus? | Generally keep the corpus percentile; display contrast may expand a narrow island range |
| **Stability disagreement** | How unstable is the region on the shared 0–1 scale? | Retain the fixed 0–1 meaning; local contrast should be used cautiously |

### Fields that should usually retain fixed semantic ranges

Some fields already have meaningful absolute bounds:

```text
Fractions and disagreements: 0 to 1
Route alternatives:          1 to 12
Percentile ranks:             0 to 1
```

For these fields, local contrast should be optional and visibly marked. A disagreement of 0.10 should never visually imply the same instability as 0.80 merely because 0.10 is the maximum on a quiet island.

---

## How this applies to the 3D mesh

The selected height encoding determines what elevation means. Scale mode determines the reference range, while relief scale determines vertical exaggeration.

```text
Raw measurement
      ↓
Global, robust-global, or island-relative display range
      ↓
Relief-scale exaggeration
      ↓
Rendered height
```

| Control | What it changes | What it must not change |
|---|---|---|
| **Height encoding** | Which measurement controls elevation | Graph structure and item positions |
| **Scale mode** | Which value range is mapped into the available height range | Raw values and measurement definitions |
| **Relief scale** | How strongly mapped height differences are exaggerated | Scaling reference, neighbors, or predictive interpretation |

### Example

Suppose the selected island has effective dimensions from 2.1 to 3.0, while the corpus ranges from 1.0 to 9.4.

- **Global + moderate relief:** the island looks nearly flat; cross-island comparison is honest.
- **Global + high relief:** all corpus differences are exaggerated, but the island may still show little internal detail.
- **Island-relative + moderate relief:** the island’s internal structure becomes visible.
- **Island-relative + high relief:** small internal differences may look dramatic and should not be interpreted as corpus-scale mountains.

Relief scale therefore does **not** solve the reference-scale problem. It exaggerates the currently mapped values; it does not isolate the selected island’s range.

---

## Predictive interpretation

Use the modes for different modeling questions:

| Question | Recommended mode |
|---|---|
| Is this island globally unusual or complex? | **Global** |
| Does this island contain internal subregions? | **Selected island** |
| Is an extreme item hiding broad corpus structure? | **Robust global** |
| Are local differences strong enough to define separate predictive regimes? | Compare **Global** and **Selected island**, then validate on held-out outcomes |

A useful decision rule:

```text
Visible in global mode and stable under low relief
→ strong candidate for a corpus-level predictive regime

Visible only in island-relative mode
→ possible within-island subgroup; do not describe it as globally extreme

Visible only under local contrast plus high relief
→ exploratory distinction requiring validation

Visible under local contrast but covered by fog
→ likely too unstable to support confident modeling
```

---

## Recommended interpretation workflow

1. **Start in Global mode** to understand the island relative to the entire corpus.
2. **Check fog and sample size** before interpreting internal structure.
3. **Switch to Selected-island mode** to inspect subtle internal gradients.
4. **Keep raw values visible** in the inspector and legend.
5. **Compare the same region in both modes** before calling it a mountain, plain, boundary, or predictive regime.
6. **Use Robust-global mode** when one or a few extreme items dominate the display.
7. **Validate with held-out prediction or source-feature comparisons** before treating visual subregions as useful model structure.

---

## Bottom line

The current corpus-wide scale is methodologically honest but can make small islands difficult to interpret internally. The best remedy is not per-island recomputation and not relief adjustment alone. It is an explicit dual-scale interface:

```text
Global scale
→ honest comparison across the corpus

Selected-island contrast
→ internal navigation without changing measurements

Robust-global scale
→ broad comparison with reduced visual domination by extremes
```

All three views should preserve raw values, use clear legends, and distinguish display contrast from actual geometric or predictive significance.
