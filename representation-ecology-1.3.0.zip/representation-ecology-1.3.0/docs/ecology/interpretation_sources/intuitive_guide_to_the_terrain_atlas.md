# Intuitive Guide to the Terrain Atlas

## Core idea

Each point is an **item embedding**. The atlas shows how the model's training methodology organized those items.

- The **flat atlas** shows measurements through color, contours, rings, roads, and hatching.
- The **3D mesh** turns one selected measurement into height.
- The **relief scale** changes only the visual exaggeration of that height.

The map does not directly display the original item features. Instead, it identifies **which items or regions to compare** when investigating what the model learned to preserve, ignore, connect, or separate.

```text
Original item features
        ↓
Training methodology and embedding model
        ↓
Item embeddings
        ↓
Atlas reveals learned organization
        ↓
Compare the source features of relevant items
```

---

## 3D mesh: what a mountain means

A “mountain” has a different meaning for each selected height encoding.

| Selected height | A mountain means | A plain means | Predictive or navigation intuition |
|---|---|---|---|
| **Effective dimensions** | Nearby items differ along many learned directions | Nearby items vary along only a few learned directions | Plains favor simple, stable interpolation. Mountains offer richer variation but may require more data or a more flexible predictor. |
| **Distance-growth dimensions** | New item distinctions appear rapidly as the neighborhood expands | The item population remains a narrow branch or slowly widening corridor | Plains are easier to cover. Mountains may represent broader populations that require more examples. |
| **Route-set ambiguity** | Several comparably good item-to-item routes lead toward reference destinations | One route generally dominates | Mountains provide alternative pathways. Plains are more direct, while very low narrow areas may depend on one route or pass. |
| **Metric variation** | Nearby items are unevenly spaced, mixing small steps with large jumps | Item-to-item steps are relatively even | Plains favor smooth interpolation. Mountains may indicate boundaries, sparse coverage, or mixed populations. |

### Quick translation

```text
Effective-dimension mountain = many learned directions
Distance-growth mountain     = rapidly expanding item population
Route-ambiguity mountain     = many viable routes
Metric-variation mountain    = uneven item spacing
```

A mountain is therefore **not automatically good or bad**. Its meaning depends on the active height encoding.

---

## Relief scale: visual emphasis, not model ability

The relief scale controls how strongly the current height measurement is exaggerated. It does **not** change embeddings, neighbors, roads, components, measurements, or actual predictive ability.

| Relief setting | Intuitive reading | Predictive-model use |
|---|---|---|
| **Low** | “What is the broad shape of this population?” | Best for identifying large, robust modeling regimes without overreacting to small differences. |
| **Moderate** | “Where do meaningful local differences appear?” | Best default for selecting subgroups, boundaries, or regions for separate validation. |
| **High** | “Where are even subtle differences located?” | Useful for discovery, but it can visually exaggerate weak or noisy contrasts. |

### Relief as a sensitivity control

```text
Low relief  = emphasize strong, broad effects
High relief = expose smaller, local effects
```

| Selected height | A peak that remains distinct at low relief suggests |
|---|---|
| **Effective dimensions** | A substantially more multidirectional learned region, possibly requiring a more flexible predictor |
| **Distance-growth dimensions** | A population that expands much faster, possibly requiring more training coverage |
| **Route-set ambiguity** | Substantially more alternative paths, possibly reflecting multiple predictive mechanisms |
| **Metric variation** | A genuinely irregular neighborhood, possibly marking a boundary or weak interpolation zone |

### Practical rule

```text
Stable and visible at low relief
→ strong candidate for a distinct predictive regime

Visible mainly at high relief
→ exploratory difference; validate before using

Visible only at high relief and covered by fog
→ likely too fragile to drive modeling decisions
```

Use **moderate relief** by default, **low relief** to judge broad regimes, and **high relief** only to inspect subtle contrasts. Always check the legend, item inspector, stability layers, and held-out performance rather than judging apparent height alone.

---

## Flat atlas: how to read each measurement layer

The flat atlas keeps item positions fixed. A high-value area appears through stronger color or higher-value contours rather than greater elevation.

| Flat-map field | High-value area means | Low-value area means | Intuitive use |
|---|---|---|---|
| **Variation hidden by two axes** | Much learned variation is missing from a simple 2D view | Two local directions explain most variation | Inspect high areas with spectral rings before drawing conclusions from the flat layout alone. |
| **Effective local directions** | The model preserved several independent distinctions among nearby items | Nearby items vary simply or redundantly | High areas are diversity resources; low areas can form predictable settlement cores. |
| **Original-space density** | Many items support the surrounding learned region | Few items support the region | High areas are well-supported; low areas are sparse or frontier territory. |
| **Near-substitute fraction** | Many items have extremely close alternatives | Items are comparatively difficult to replace | High areas indicate redundancy and dependable substitutes; low areas suggest possible distinctiveness. |
| **Regional route alternatives** | Several learned routes connect the region to reference destinations | One route dominates | High areas offer resilient access or maze-like ambiguity; low areas form direct corridors or fragile passes. |
| **Reference-subset disagreement** | Neighborhoods change when reference items are removed | Neighborhoods survive resampling | High areas are resampling fog; low areas have stable placement. |
| **Compression disagreement** | Neighborhoods depend on embedding directions removed by compression | Coarse dimensions preserve the neighborhood | High areas may contain subtle learned information or fragile noise. |
| **Metric-variation rank** | Nearby items are unevenly spaced | Nearby item-to-item steps are smooth | High areas suggest boundaries, frontiers, gaps, or mixed populations. |
| **Combined disagreement** | At least one stability test substantially changes the neighborhood | Both tested relationships are stable | High areas are fog and make weak foundations for confident prediction. |

### Flat-map presets

| Preset | What it helps locate |
|---|---|
| **Dimensionality** | Rich learned variation versus simple or repetitive item populations |
| **Density & redundancy** | Well-supported plains, interchangeable inventory, and sparse distinctive regions |
| **Routes & passes** | Accessible regions, alternative pathways, bottlenecks, and bridge items |
| **Stability** | Reliable territory versus foggy, corpus-sensitive organization |

---

## Fixed geography: meanings that do not change with the selected layer

| Map feature | Meaning for embedded items | Predictive or settlement implication |
|---|---|---|
| **Road** | An actual retained item-to-item connection | Supported navigation through the learned representation |
| **Pass** | A restricted set of connections joins two item populations | Valuable access and informative bridge items, but potentially fragile |
| **Ridge** | Persistent separation between item populations | A possible interpretable modeling boundary |
| **Cliff** | An unusually large transition between neighboring populations | Possible missing coverage, abrupt learned distinction, or shortcut |
| **Maze** | Several viable routes connect regions | Multiple learned pathways, but less unique interpretation |
| **Island** | A disconnected item population | May support a separate model; transfer to the mainland is uncertain |
| **Water** | No retained route between populations | Crossing represents unsupported extrapolation, not interpolation |
| **Fog** | Item relationships change under resampling or compression | Low confidence regardless of the apparent terrain |

---

## Backward translation through the learned representation

| Terrain | What the item population looks like | What the model may have learned |
|---|---|---|
| **Plain** | Many similar items with substitutes | Differences among those items are largely ignored or compressed |
| **Mountain** | Several local directions of variation | Multiple distinctions were preserved, according to the active height encoding |
| **Pass** | A few items connect larger populations | A restricted bridge between learned regimes |
| **Ridge or cliff** | The population changes abruptly | A strong separation, which may be meaningful or may reflect a training shortcut |
| **Maze** | Multiple item-to-item paths reach a destination | Several learned pathways or combinations support the relationship |
| **Island** | A separately connected population | A distinct representational regime |
| **Fog** | Neighborhoods are unstable | Fragile learned organization |
| **Water** | No supported connection | No defensible learned transition between the populations |

---

## Establishing a hypothetical settlement

A “settlement” is a region where you want to retrieve, predict, curate, or operate reliably.

| Settlement need | What to seek on the atlas | Why |
|---|---|---|
| **Predictable core** | High density, many substitutes, low fog, and relatively smooth local travel | Provides supported examples and stable interpolation |
| **Useful nearby diversity** | Stable high effective dimensions without heavy disagreement | Supplies distinctions preserved by the model without making the core unreliable |
| **Reliable access** | Several roads and at least one interpretable pass | Connects the core to other learned regimes without relying on unsupported jumps |
| **Resilience** | Some route alternatives | Avoids dependence on a single fragile connection |
| **Clear borders** | Stable ridges with understandable item differences | Supports subgroup definitions or separate validation |
| **Safe separation** | Clear boundaries without total isolation | Distinguishes the region while preserving supported access |
| **Conditions to avoid** | Heavy fog, unexplained cliffs, tiny unsupported islands, or one fragile pass | These weaken confidence, transfer, or robustness |

### Compact settlement profile

```text
Core:
  broad, populated, low-fog plain

Resources:
  nearby low-fog effective-dimension mountains

Access:
  multiple stable roads and an interpretable pass

Borders:
  stable ridges rather than unexplained cliffs

Route structure:
  enough alternatives for resilience, but not uncontrolled ambiguity

Avoid:
  heavy fog, unsupported water crossings, and dependence on one fragile route
```

The ideal settlement is therefore a region where the training methodology learned **a dependable common structure, meaningful nearby variation, stable connections to other regimes, and understandable boundaries**.
