import tempfile,unittest
from pathlib import Path
import numpy as np
from representation_ecology.accessibility import analyze,filtration,fold_ids,unit
from representation_ecology.resources import estimate,enforce
class AccessibilityTests(unittest.TestCase):
    def fixture(self):
        rng=np.random.default_rng(12);n=480;z=rng.normal(0,.05,(n,8));z[:,0:2]=rng.normal(size=(n,2));z[:,2]=rng.choice([-2.,2.],n);z[:,3]=4;z=unit(z)
        return z,{'global':3*z[:,0],'context':np.sign(z[:,2])*4*z[:,1],'noise':rng.normal(size=n)},np.arange(n)//3
    def test_filtration_nested_mergers_and_censoring(self):
        f=filtration(5,[[0,1],[1,2],[2,3]],[.1,.3,.5]);counts=[l['components'] for l in f['levels']];self.assertEqual(counts,sorted(counts,reverse=True));self.assertEqual(counts[-1],2);self.assertIn('unresolved',f['truncation'])
        for a,b in zip(f['levels'],f['levels'][1:]):
            for i in range(5):
                for j in range(5):
                    if a['labels'][i]==a['labels'][j]:self.assertEqual(b['labels'][i],b['labels'][j])
    def test_context_gain_and_global_reconstruction(self):
        z,y,g=self.fixture();r=analyze(z,y,g,dict(regions=2,min_train=16,batch_rows=128),seed=3)
        self.assertLess(np.nanmean(r['views']['global']['8']['broad']),.02);self.assertGreater(np.nanmean(r['views']['context']['8']['gain']),.1);self.assertLess(np.nanmean(r['views']['noise']['8']['gain']),.15)
        self.assertEqual(len(r['transforms']),3);self.assertEqual(len(r['transfer']),12)
    def test_outer_test_targets_cannot_change_predictions_or_selection(self):
        z,y,g=self.fixture();fold=fold_ids(g,3);records=[];a=analyze(z,{'target':y['context']},g,dict(regions=2,dimensions=[2,8]),seed=3,sink=records.append)
        altered=y['context'].copy();altered[fold==0]+=1000;other=[];b=analyze(z,{'target':altered},g,dict(regions=2,dimensions=[2,8]),seed=3,sink=other.append)
        self.assertEqual([s for s in a['selections'] if s['fold']==0],[s for s in b['selections'] if s['fold']==0])
        for left,right in zip([r for r in records if r['fold'][0]==0],[r for r in other if r['fold'][0]==0]):
            np.testing.assert_allclose(left['broad_prediction'],right['broad_prediction']);np.testing.assert_allclose(left['local_prediction'],right['local_prediction'],equal_nan=True)
    def test_group_split_missingness_and_sample_alignment(self):
        z,y,g=self.fixture();fold=fold_ids(g,3);self.assertTrue(all(len(set(fold[g==group]))==1 for group in np.unique(g)))
        full=analyze(z,{'missing':np.full(len(z),np.nan)},g);self.assertTrue(np.isnan(full['views']['missing']['1']['broad']).all());self.assertTrue(full['status'])
        sample=np.array([35,4,225]);full=analyze(z,{'global':y['global']},g,seed=4);part=analyze(z,{'global':y['global']},g,seed=4,sample_indices=sample);np.testing.assert_allclose(part['views']['global']['8']['broad'],full['views']['global']['8']['broad'][sample])
    def test_resource_guard_and_streamed_plan(self):
        with self.assertRaises(ValueError):enforce(estimate(1_000_000,1024))
        p=estimate(1_000_000,32,mode='streamed');self.assertEqual(p['exact_distance_coordinate_work'],0)
        with self.assertRaises(ValueError):enforce(p,max_output_bytes=10)
        from representation_ecology.offline import offline_demo
        with tempfile.TemporaryDirectory() as root:
            destination=Path(root)/'not-generated';plan=offline_demo(destination,plan_only=True);self.assertFalse(destination.exists());self.assertEqual(plan['rows'],100000)
    def test_real_population_entrypoint_and_prediction_records(self):
        from representation_ecology.offline import population_run
        import pandas as pd,json
        z,y,g=self.fixture();n=160
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);np.save(root/'x.npy',z[:n]);np.save(root/'y.npy',np.column_stack([y['global'][:n],y['context'][:n]]));np.save(root/'g.npy',g[:n])
            result=population_run(root/'x.npy',root/'y.npy',root/'out',['global','context'],root/'g.npy',display_rows=80,batch_rows=128)
            self.assertEqual(result['population_rows'],160)
            records=pd.read_parquet(root/'out/held_out_predictions.parquet');self.assertEqual(len(records),160*2*4)
            self.assertFalse(records.duplicated(['row','feature','dimension']).any())
            self.assertTrue((root/'out/run/bridge/accessibility.json').is_file());self.assertEqual(json.loads((root/'out/status.json').read_text())['status'],'complete')
