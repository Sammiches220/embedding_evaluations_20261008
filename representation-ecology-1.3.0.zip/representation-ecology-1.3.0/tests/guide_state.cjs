const assert=require('node:assert/strict');
const G=require('../src/representation_ecology/assets/guide_core.js');
assert.equal(G.median([1,null,3]),2);assert.equal(G.mean([null,NaN]),null);
const f={kind:'categorical',values:['a',null,'b','a']};
assert.deepEqual({...G.featureSummary(f,[0,1,2]).counts},{a:1,b:1});
assert.equal(G.featureSummary(f,[0,1]).coverage,.5);
assert.equal(G.featureContrast(f,[0],[2]),1);
assert.equal(G.featureContrast(f,[1],[2]),null);
assert.equal(G.featureSummary({kind:'categorical',values:['__proto__']},[0]).counts.__proto__,1);
assert.equal(G.gapKind(null),'unqualified');
assert.equal(G.gapKind({pair_support:20,mean_absolute:.8,mean_signed:.4,perturbation_overlap:.2}),'unqualified');
assert.equal(G.gapKind({pair_support:20,mean_absolute:.8,mean_signed:.4,perturbation_overlap:.9}),'farther');
assert.equal(G.gapKind({pair_support:20,mean_absolute:.8,mean_signed:-.4,perturbation_overlap:.9}),'closer');
const data={ids:['a','b','c','d'],manifest:{config:{min_local:5}},geometry:{component:[0,0,1,1],region:[0,0,1,1]},
 evidence:[{model:'ridge',row:0,pair_support:20,mean_absolute:.8,mean_signed:.4,perturbation_overlap:.9}],
 edges:[{model:'ridge',i:0,j:1,residual:.2,absolute_residual:.2,baseline_error:.5}],
 neighborhoods:[{row:0,k:4,status:'ok',overlap_low:.25,overlap_high:.75}],
 probes:[{feature:'y',row:0,model:'linear',label:null,loss:2},{feature:'y',row:1,model:'linear',label:null,loss:100},{feature:'y',row:0,model:'baseline',label:null,loss:4}]};
const index=G.indexData(data);
assert.equal(G.pairSummary(index,[0,1],'ridge').n,1,'An edge touching both selected endpoints is counted once');
const probe=G.probeSummary(index,[0,1],'y','linear');
assert.equal(probe.loss,51);assert.equal(probe.matchedLoss,2);assert.equal(probe.baseline,4);assert.equal(probe.baselineN,1);
assert.equal(G.sharedComponent(data,[0],[2]),false);assert.equal(G.sharedComponent(data,[0],[1]),true);
assert.deepEqual(G.probeValues(index,4,'y','linear'),[2,100,null,null]);
assert.deepEqual(G.supportedRows(index,[0,1],'ridge',{}),[0]);
assert.equal(G.overlapSummary(index,[0,1],4).high,.75);
assert.equal(G.guideStops(data,index,'ridge')[0].row,0);
console.log('Guide interpretation checks passed: missingness, independent support, signed discrepancy shapes, matched baselines, tie bounds and disconnected regions.');
