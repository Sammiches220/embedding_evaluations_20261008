import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from representation_ecology.common import configuration
from representation_ecology.features import FeatureSpace,item_folds,local_fields
from representation_ecology.analysis import relational_models,sample_pairs,crossfit_probes
from geometric_ecology.core import build_map,knn,normalize
from representation_ecology.demo import create_demo
from representation_ecology.workflow import prepare,run
from representation_ecology.investigation import compare_runs,save_investigation,interventions


class FeatureTests(unittest.TestCase):
    def test_neighborhood_cloud_matches_spectrum_energy(self):
        from geometric_ecology.mesh import neighborhood_spectra
        rng=np.random.default_rng(8);z=normalize(rng.normal(size=(40,7)));_,nn=knn(z,8,exclude_self=True)
        measured=neighborhood_spectra(z,nn)
        cloud=measured['local_offsets'];self.assertEqual(cloud.shape,(40,8,3))
        energy=np.sum(cloud**2,axis=1)
        ratio=energy/energy.sum(axis=1,keepdims=True)
        expected=measured['spectrum'][:,:3]/measured['spectrum'][:,:3].sum(axis=1,keepdims=True)
        np.testing.assert_allclose(ratio,expected,atol=1e-6)

    def test_cli_does_not_offer_saved_run_conversion(self):
        from representation_ecology.cli import main
        import contextlib,io
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as stopped: main(['refresh','--run','anything'])
        self.assertEqual(stopped.exception.code,2)

    def test_tie_bounds_do_not_invent_disagreement(self):
        n=16;frame=pd.DataFrame({'category':['a']*n})
        space=FeatureSpace(frame,{'category':{'kind':'categorical','id_type':'string'}},np.arange(n))
        z=normalize(np.random.default_rng(4).normal(size=(n,4)));_,nn=knn(z,4,exclude_self=True)
        rows,_=space.neighborhoods(z,nn,[4])
        self.assertTrue(all(r['overlap_high']==1 for r in rows))
        self.assertTrue(all(r['overlap_low']==0 for r in rows))

    def test_unknown_not_a_negative_and_empty_set_known(self):
        frame=pd.DataFrame({'tags':[['a'],[],None,['b']]})
        spec={'tags':{'kind':'multilabel','encoding':'list','empty_is_unknown':False}}
        space=FeatureSpace(frame,spec,np.arange(4))
        distance,count=space.distance([[0,1],[0,2],[1,1]])
        self.assertEqual(distance[0],1);self.assertTrue(np.isnan(distance[1]));self.assertEqual(count[1],0);self.assertEqual(distance[2],0)

    def test_feature_family_weight_and_training_only_scale(self):
        frame=pd.DataFrame({'x':[0.,1.,2.,10000.],'y':[0.,1.,2.,3.]})
        spec={n:{'kind':'numeric','family':'one'} for n in frame}
        space=FeatureSpace(frame,spec,np.array([0,1,2]))
        self.assertAlmostEqual(space.data['x']['scale'],1)
        self.assertAlmostEqual(sum(d['weight'] for d in space.data.values()),1)

    def test_ordinal_order_is_not_label_distance(self):
        frame=pd.DataFrame({'v':['low','mid','high','low']})
        space=FeatureSpace(frame,{'v':{'kind':'ordinal','id_type':'string','order':['low','mid','high']}},np.arange(4))
        d,_=space.distance([[0,1],[0,2]])
        self.assertAlmostEqual(d[1],2*d[0])

    def test_group_fold_has_no_group_leakage(self):
        groups=np.repeat(np.arange(8),3)
        for train,test in item_folds(24,groups,4,42):self.assertFalse(set(groups[train])&set(groups[test]))
        with self.assertRaisesRegex(ValueError,'leaks'):item_folds(24,groups,4,42,np.array(['train','test']*12))

    def test_endpoint_held_out_pair_models(self):
        n=80;rng=np.random.default_rng(1);x=rng.normal(size=(n,5));z=normalize(x);_,nn=knn(z,6,exclude_self=True)
        frame=pd.DataFrame({'x':x[:,0],'y':x[:,1]});spec={n:{'kind':'numeric'} for n in frame}
        cfg=configuration();cfg.update(max_pairs=1500,folds=4,pair_models=['ridge'])
        records,scores,folds,status=relational_models(frame,spec,z,nn,np.empty((0,2)),cfg)
        self.assertTrue(records);self.assertTrue(scores)
        partition={(r['fold'],r['row']):r['partition'] for r in folds}
        for r in records:
            self.assertEqual(partition[r['fold'],r['i']],'test');self.assertEqual(partition[r['fold'],r['j']],'test')

    def test_rotation_preserves_neighbors_and_pair_targets(self):
        rng=np.random.default_rng(5);z=normalize(rng.normal(size=(45,8)));q=np.linalg.qr(rng.normal(size=(8,8)))[0]
        da,na=knn(z,6,exclude_self=True);db,nb=knn(z@q,6,exclude_self=True)
        np.testing.assert_array_equal(na,nb);np.testing.assert_allclose(da,db,atol=1e-6)

    def test_measured_missing_factor_reduces_heldout_error(self):
        rng=np.random.default_rng(13);n=120;h=rng.choice([-1.,1.],n);noise=rng.normal(0,.03,(n,3))
        z=normalize(np.column_stack([np.ones(n),h*3,noise]));_,nn=knn(z,6,exclude_self=True)
        frame=pd.DataFrame({'unrelated':rng.normal(size=n),'hidden':h})
        cfg=configuration();cfg.update(max_pairs=5000,folds=4,pair_models=['ridge'])
        _,old,_,_=relational_models(frame,{'unrelated':{'kind':'numeric'}},z,nn,np.empty((0,2)),cfg)
        _,new,_,_=relational_models(frame,{'unrelated':{'kind':'numeric'},'hidden':{'kind':'numeric'}},z,nn,np.empty((0,2)),cfg)
        self.assertLess(np.mean([r['mae'] for r in new]),np.mean([r['mae'] for r in old])*.2)

    def test_shared_graph_validated(self):
        rng=np.random.default_rng(3);raw=rng.normal(size=(40,5));z=normalize(raw);d,n=knn(z,9,exclude_self=True)
        model=build_map(raw,scales=[4,8],repeats=2,neighbor_data=(d,n));np.testing.assert_array_equal(model['neighbors'],n)
        with self.assertRaisesRegex(ValueError,'disagree'):build_map(raw,scales=[4,8],repeats=2,neighbor_data=(d+.4,n))

    def test_misspelled_options_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            p=Path(root)/'bad.json';p.write_text('{"max_row":30}')
            with self.assertRaisesRegex(ValueError,'Unknown'):configuration(p)

    def test_crossfit_covers_each_group_once(self):
        rng=np.random.default_rng(6);n=64;z=normalize(rng.normal(size=(n,5)));frame=pd.DataFrame({'y':z[:,0]});cfg=configuration();cfg.update(folds=4)
        rec,scores,status=crossfit_probes(frame,{'y':{'kind':'numeric'}},z,cfg,np.repeat(np.arange(n//2),2))
        linear=[r['row'] for r in rec if r['model']=='linear'];self.assertEqual(sorted(linear),list(range(n)))


class EndToEndTests(unittest.TestCase):
    def test_pipeline_exports_joined_artifacts_and_frozen_geometry(self):
        with tempfile.TemporaryDirectory() as root:
            root=Path(root);source=create_demo(root/'input',96,42,'missingness')
            combined=json.loads((source/'combined_config.json').read_text());combined.update(scales=[4,8],validation=False,nulls=False,tangent=False,max_pairs=2000,pair_models=['ridge'])
            (source/'combined_config.json').write_text(json.dumps(combined))
            audit=json.loads((source/'audit_config.json').read_text());audit['nulls']['permutations']=0;audit['probes']['enabled']=False
            (source/'audit_config.json').write_text(json.dumps(audit))
            out=run(source/'schema.json',source/'audit_config.json',root/'run',source/'combined_config.json')
            self.assertEqual(json.loads((out/'run_status.json').read_text())['status'],'complete')
            a=np.load(out/'audit/neighbors.npy');g=np.load(out/'geometry/map.npz')['neighbors'];np.testing.assert_array_equal(a,g[:,:8])
            self.assertTrue((out/'expert.html').exists())
            self.assertTrue((out/'viewer_manifest.json').exists())
            self.assertTrue((out/'index.html').exists());self.assertTrue((out/'bridge/probe_predictions.parquet').exists())
            predictions=pd.read_parquet(out/'bridge/probe_predictions.parquet');self.assertIn('true_json',predictions)
            selection=root/'selection.json';selection.write_text('["item-00000"]');record=save_investigation(out,selection,'candidate')
            self.assertEqual(record['item_ids'],['item-00000'])
            result=compare_runs(out,out,root/'comparison');self.assertTrue(result['same_geometry']);self.assertAlmostEqual(result['mean_absolute_error_delta'],0)
            response=interventions(out,source/'interventions.parquet',source/'intervention_vectors.npy',root/'responses','synthetic-v1')
            self.assertTrue(response);self.assertGreater(response[0]['mean_displacement'],0)
            with self.assertRaisesRegex(ValueError,'empty'):run(source/'schema.json',source/'audit_config.json',out,source/'combined_config.json')

    def test_visual_demo_declares_its_measurements(self):
        with tempfile.TemporaryDirectory() as root:
            source=create_demo(Path(root)/'input',96,scenario='visual')
            cfg=configuration();cfg.update(validation=False,scales=[4,8])
            data=prepare(source/'schema.json',source/'audit_config.json',cfg)
            self.assertIn('exposure_score',data['specs'])
            self.assertEqual(data['specs']['catalog_age_days']['kind'],'count')
            self.assertNotIn('capture_pipeline',data['specs'])
            self.assertTrue(data['frame'].catalog_age_days.between(0,365).all())

    def test_alignment_follows_ids_not_external_row_order(self):
        with tempfile.TemporaryDirectory() as root:
            source=create_demo(Path(root)/'input',96)
            cfg=configuration();cfg['validation']=False;cfg['scales']=[4,8]
            first=prepare(source/'schema.json',source/'audit_config.json',cfg)
            ids=np.load(source/'ids.npy');a=np.load(source/'vectors.npy');b=np.load(source/'comparison.npy');order=np.arange(len(ids))[::-1]
            np.save(source/'ids.npy',ids[order]);np.save(source/'vectors.npy',a[order]);np.save(source/'comparison.npy',b[order])
            second=prepare(source/'schema.json',source/'audit_config.json',cfg)
            np.testing.assert_array_equal(first['ids'],second['ids']);np.testing.assert_array_equal(first['arrays'][0],second['arrays'][0])

if __name__=='__main__':unittest.main()
