const assert=require('node:assert/strict'),L=require('../src/representation_ecology/assets/landscape.js'),GG=require('../src/representation_ecology/assets/geometry_guide.js');
const base={size:5,bounds:[0,0,1,1],valid:Array.from({length:5},()=>Array(5).fill(1))};
let grid=L.grid([[.5,.5]],[0],[0],base);assert(grid.valid.flat().some(Boolean));assert(grid.values.flat().every(v=>v===0),'Observed zero must remain zero');
grid=L.grid([[.5,.5]],[null],[0],base);assert(grid.valid.flat().every(v=>v===0),'Missing values must never create a supported zero surface');
grid=L.grid([[.5,.5],[.5,.5]],[10,null],[0,1],base);assert(grid.valid.flat().every(v=>v===0),'Below 60% known kernel support must stay unfilled');
const f={size:2,bounds:[0,0,1,1],valid:[[1,1],[1,1]],values:[[0,1],[0,1]]};
const lines=L.isolines(f,[.5]);assert(lines[0].paths.length);assert(lines[0].paths.flat().every(p=>Math.abs(p[0]-.5)<1e-9));
f.valid[0][0]=0;assert.equal(L.isolines(f,[.5])[0].paths.length,0);
assert.deepEqual(L.levels([1,1]),[]);assert.deepEqual(L.color(0,[-1,1],'signed'),[246,243,226]);
const offsets=[1,2,3],spectral=GG.spectrumSummary([.5,.25,.25]);assert(Math.abs(spectral.effective-8/3)<1e-8);assert.equal(spectral.visibleThree,1);assert.equal(GG.spectrumSummary([0,0]),null);
for(const group of GG.families)for(const key of group.keys){const m=GG.metrics[key];assert(m.high&&m.low&&m.use&&m.limit)}
assert(/not.*causal/.test(GG.metrics.route_count.limit));assert(/not.*reasons/.test(GG.metrics.covariance_dimensions.limit));
console.log('Continuous landscape checks passed: finite masks, known zeros, annotation support, raw-value contours, signed midpoint and geometry interpretation boundaries.');

const clone=()=>({size:5,bounds:[0,0,1,1],valid:Array.from({length:5},()=>Array(5).fill(1)),values:{},isolines:{}});
const island={component:0,field:clone(),field_levels:{'5':clone()}};let registered;const engine={data:{points:[{component:0},{component:0}],atlas:{xy:[[.25,.25],[.75,.75]],display_fields:{},islands:[island]}},flatAtlas:{register:def=>registered=def}};
L.register(engine,'test','Test field',[-1,1],'signed',true);assert(island.field.values.test);assert(island.field_levels['5'].values.test);assert(registered.levels.includes(0));assert(engine.data.atlas.display_fields.test.symmetric);
console.log('Active-grid registration and zero signed contour checks passed.');
