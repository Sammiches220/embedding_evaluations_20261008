/* Dependency-free interaction checks for the display controller; not visual QA. */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const els=new Map(),listeners=new Map();
class Element {
 constructor(id){this.id=id;this.value='';this.children=[];this.style={};this.textContent='';}
 set innerHTML(html){for(const m of html.matchAll(/id="([^"]+)"/g))els.set(m[1],new Element(m[1]));}
 addEventListener(name,fn){this['on'+name]=fn;}
 prepend(){} append(el){this.children.push(el);} after(){} replaceChildren(){this.children=[];}
}
for(const id of ['height-channel','map-subtitle','mesh-height','relief-gain-label','height-range-readout'])els.set(id,new Element(id));els.get('height-channel').value='covariance_dimensions';els.get('mesh-height').value='3.4';
const document={getElementById:id=>els.get(id),createElement:()=>new Element(),querySelector:()=>new Element(),
 addEventListener:(name,fn)=>{if(!listeners.has(name))listeners.set(name,[]);listeners.get(name).push(fn)},dispatchEvent:e=>(listeners.get(e.type)||[]).forEach(f=>f(e))};
const vals=[2.1,2.5,3,9],channel={values:vals,observed:[2.1,9],global_range:[2.1,9],robust_range:[2.16,8.1]};
const fields={hidden_two:{...channel,values:[.1,.2,.3,.9],global_range:[0,1]},covariance_dimensions:channel};
const points=vals.map((_,i)=>({id:'item-'+i,neighbors:[(i+1)%4],region:i<3?0:1,component:0}));
const data={atlas:{display_fields:fields},points},before=JSON.stringify(data);let selected=null;
const window={ecology:{data,getSelected:()=>selected,getRoute:()=>[0,1,2],getMode:()=> 'atlas',requestDraw(){}}};
vm.runInNewContext(fs.readFileSync(require('node:path').join(__dirname,'../../src/geometric_ecology/display_scale.js'),'utf8'),{window,document,console,CustomEvent:class{constructor(type){this.type=type}},Blob,URL,setTimeout});
const S=window.atlasScale,$=id=>els.get(id),arr=v=>JSON.parse(JSON.stringify(v));
function mode(value){$('display-mode').value=value;$('display-mode').onchange();}
mode('subset');assert.equal(S.mode,'global');
selected=0;$('subset-source').value='cell';$('capture-subset').onclick();mode('subset');
assert.deepEqual(arr(S.range('covariance_dimensions')),[2.1,3]);assert.equal(S.normalize(3,'covariance_dimensions'),1);
assert.equal(S.clipped(9,'covariance_dimensions'),true);
selected=3;document.dispatchEvent({type:'ecology-select'});assert.deepEqual(arr(S.range('covariance_dimensions')),[2.1,3]);
$('subset-source').value='item';$('capture-subset').onclick();assert.equal(S.normalize(9,'covariance_dimensions'),.5);
mode('robust');assert.deepEqual(arr(S.range('covariance_dimensions')),[2.16,8.1]);
$('reset-scale').onclick();assert.deepEqual(arr(S.range('covariance_dimensions')),[2.1,9]);
assert.equal(JSON.stringify(data),before);
// Exercise the actual relief surface, sampling and projection code, not only colors.
const projectDir=require('node:path').join(__dirname,'../../src/geometric_ecology');
const template=fs.readFileSync(projectDir+'/explorer.html','utf8');
const measureCode=template.slice(template.indexOf('function measureHeight('),template.indexOf('// Points and roads'));
const screenCode=template.match(/function screen\(xy\)\{[^\n]+/)[0];
const field={size:2,bounds:[0,0,1,1],valid:[[1,1],[1,1]],values:{covariance_dimensions:[[2.1,3],[2.1,3]],density:[[.5,.5],[.5,.5]]}};
const context={window,A:{terrain:{},islands:[{field}]},heightChannel:'covariance_dimensions',mode:'relief',pan:[0,0],currentTransform:{w:200,h:200,dock:0,cx:0,cy:0,unit:10}};
vm.createContext(context);vm.runInContext(measureCode+screenCode,context);
vm.runInContext(fs.readFileSync(projectDir+'/geometry_views.js','utf8'),context);
const paint={beginPath(){},moveTo(){},lineTo(){},closePath(){},fill(){},stroke(){}};
function reliefVertices(){const vertices=[];window.GeometryViews.surface(paint,field,p=>{vertices.push([...p]);return context.screen(p)},'covariance_dimensions',{scale:S});return vertices;}
mode('global');const globalHeight=context.measureHeight([1,0]),globalVertices=reliefVertices();
selected=0;$('subset-source').value='cell';$('capture-subset').onclick();mode('subset');
const localHeight=context.measureHeight([1,0]),localVertices=reliefVertices();
assert(localHeight>globalHeight*5);assert.equal(localHeight,1);
assert(localVertices[1][2]>globalVertices[1][2]*5);
assert.equal(context.measureHeight([.5,0]),.5);
$('mesh-height').value='2';const at2=context.screen([1,0,localHeight]);
$('mesh-height').value='4';const at4=context.screen([1,0,localHeight]);
assert.equal(at2[0],at4[0]);assert.equal(at2[1]-at4[1],10);
$('mesh-height').value='0';assert.equal(context.screen([0,0,0])[1],context.screen([0,0,1])[1]);
assert.equal(S.reliefGain,0);assert.equal(JSON.stringify(data),before);
// Selection edits and reference population are separate state changes.
$('reset-scale').onclick();S.setSubset([0,1]);assert.equal(S.mode,'global');
assert($('reference-population').textContent.includes('not setting the range'));
$('use-subset').onclick();assert.equal(S.mode,'subset');assert($('reference-population').textContent.includes('only the 2'));
S.toggleMember(0);assert.deepEqual(arr(S.members),[1]);
S.toggleMember(1);assert.equal(S.mode,'global');assert.equal(S.members.length,0);
$('undo-subset').onclick();assert.deepEqual(arr(S.members),[1]);assert.equal(S.mode,'global');
S.setSubset([0,1,2]);selected=1;$('remove-inspected').onclick();assert.deepEqual(arr(S.members),[0,2]);
$('clear-subset').onclick();assert.deepEqual(arr(S.members),[]);
assert.equal(JSON.stringify(data),before);
const clicks={window,selected:0,select(i){this.selected=i;},clearSelection(){clicks.selected=null;}};
// Stubs use the same lexical context as the actual click dispatcher.
clicks.select=i=>{clicks.selected=i;};
vm.createContext(clicks);vm.runInContext(template.match(/^function handlePointClick.*$/m)[0],clicks);
$('edit-subset').checked=false;clicks.handlePointClick(0);assert.equal(clicks.selected,null);
clicks.handlePointClick(2);assert.equal(clicks.selected,2);clicks.handlePointClick(-1);assert.equal(clicks.selected,null);
$('edit-subset').checked=true;clicks.handlePointClick(3);assert.deepEqual(arr(S.members),[3]);clicks.handlePointClick(3);assert.deepEqual(arr(S.members),[]);$('edit-subset').checked=false;
console.log('Subset add/remove, last-member fallback, undo and reference-population messages passed.');
console.log('Relief coordinates verified: subset expands elevation, shared slider changes projected heights, zero relief is flat.');

(async()=>{const old=arr(S.members);await $('subset-file').onchange({target:{files:[{text:async()=> '["unknown"]'}]}});assert.deepEqual(arr(S.members),old);
 await $('subset-file').onchange({target:{files:[{text:async()=> '["item-0","item-2"]'}]}});assert.deepEqual(arr(S.members),[0,2]);console.log('Display interaction checks passed: fixed subsets, global/robust/local scales, constant ranges, import validation, geometry immutability.');})();
