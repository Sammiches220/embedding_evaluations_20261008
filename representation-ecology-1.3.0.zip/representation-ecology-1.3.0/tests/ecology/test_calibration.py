import unittest
import numpy as np
from geometric_ecology.criteria import fence, configuration, calibrate
from geometric_ecology.core import build_map, normalize, sparse_graph
from geometric_ecology.atlas import build_atlas
from geometric_ecology.terrain import enrich_terrain, route_set
from geometric_ecology.mesh import enrich_mesh
from geometric_ecology.display import display_fields

class CalibrationTests(unittest.TestCase):
    def test_constant_and_empty_reference_abstain(self):
        self.assertIsNone(fence([])['value'])
        for side in ['high','low']:
            f=fence(np.ones(50),side=side)
            self.assertEqual(f['value'],1)
            self.assertEqual([s['selected'] for s in f['sensitivity']],[0,0,0])
    def test_scale_equivariance_and_seed_reproducibility(self):
        a=np.r_[np.linspace(0,2,100),100]
        f=fence(a); g=fence(a*7)
        self.assertEqual(f,fence(a))
        self.assertAlmostEqual(g['value'],f['value']*7)
        np.testing.assert_allclose(g['interval'],np.asarray(f['interval'])*7)
    def test_config_rejects_silent_typos_and_invalid_budgets(self):
        for cfg in [dict(unknown=1),dict(route_limit=0),dict(route_temperature=0),dict(fence_multiplier=float('nan'))]:
            with self.assertRaises(ValueError):configuration(cfg)
    def test_route_cap_requires_an_omitted_qualifying_route(self):
        diamond=sparse_graph(4,np.array([[0,1],[1,3],[0,2],[2,3]]),np.ones(4))
        self.assertFalse(route_set(diamond,0,3,limit=2)['capped'])
        self.assertTrue(route_set(diamond,0,3,limit=1)['capped'])
    def test_display_and_calibration_preserve_frozen_geometry(self):
        x=normalize(np.random.default_rng(13).normal(size=(160,10)))
        model=build_map(x,scales=[6,12,24],regions=10,repeats=2,
                        criteria=dict(substitute_tolerance=.02,route_limit=8))
        edges=model['stable_edges'].copy(); atlas=build_atlas(model);xy=atlas['xy'].copy()
        atlas['terrain']=enrich_terrain(model,atlas);atlas['mesh']=enrich_mesh(model,atlas)
        channels=display_fields(model,atlas)
        np.testing.assert_array_equal(edges,model['stable_edges'])
        np.testing.assert_array_equal(xy,atlas['xy'])
        self.assertEqual(calibrate(model)['substitute']['selected_value'],.02)
        self.assertEqual(channels['route_count']['global_range'],[1,8])
        self.assertEqual(channels['fog']['global_range'],[0,1])
        finite=channels['covariance_dimensions']['values']
        self.assertEqual(channels['covariance_dimensions']['global_range'],[float(min(finite)),float(max(finite))])
        for channel in channels.values():self.assertEqual(len(channel['values']),160)
