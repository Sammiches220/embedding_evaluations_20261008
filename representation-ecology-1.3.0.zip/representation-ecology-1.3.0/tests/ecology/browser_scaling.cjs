/* Optional real-browser check: npm install playwright; npx playwright install chromium.
   node tests/browser_scaling.cjs /absolute/path/to/explorer.html */
const {chromium}=require('playwright'),assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url'),path=require('node:path');
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:1680,height:1080}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 try{
  await page.goto(pathToFileURL(path.resolve(process.argv[2])).href);
  await page.waitForFunction(()=>window.flatAtlas&&window.atlasScale);
  const frozen=await page.evaluate(()=>JSON.stringify([ecology.data.atlas.xy,ecology.data.edges,ecology.data.atlas.display_fields]));
  await page.evaluate(()=>ecology.select(0));
  await page.selectOption('#subset-source','neighbors');await page.click('#capture-subset');
  for(const value of ['subset','robust','global']){
   await page.selectOption('#display-mode',value);
   assert.equal(await page.evaluate(()=>atlasScale.mode),value);
   for(const mode of ['atlas','mesh','relief']){
    await page.evaluate(mode=>ecology.setMode(mode),mode);
    await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
    for(const key of ['covariance_dimensions','dimension','route_count','variation']){
     await page.evaluate(key=>{const e=document.getElementById('height-channel');e.value=key;e.dispatchEvent(new Event('change',{bubbles:true}));},key);
     await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(resolve)));
    }
   }
  }
  assert.equal(await page.evaluate(()=>JSON.stringify([ecology.data.atlas.xy,ecology.data.edges,ecology.data.atlas.display_fields])),frozen);
  assert.deepEqual(errors,[]);
  if(await page.evaluate(()=>mesh3D.supported))assert.equal(await page.evaluate(()=>mesh3D.getStats().webgl_error),0);
  console.log('Browser scaling/geometry checks passed.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
