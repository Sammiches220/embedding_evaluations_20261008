"""Verify exported multiscale lenses use the existing estimator without approximations."""
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
from geometric_ecology.core import build_map
from geometric_ecology.terrain import local_lens
from geometric_ecology.observer import export_observer

class ObserverExportTests(unittest.TestCase):
    def test_exact_multiscale_geometry_cache(self):
        rng=np.random.default_rng(33)
        model=build_map(rng.normal(size=(64,12)),scales=[6,12],repeats=2,regions=4,landmarks=8)
        k=model['manifest']['signature_k']
        existing=local_lens(model['x'],0,model['neighbors'][0,:k])
        with tempfile.TemporaryDirectory() as directory:
            export_observer(model,directory,{'terrain':{'lenses':{'0':existing}}})
            result=json.loads((Path(directory)/'observer_lenses.json').read_text())
            for scale in result['scales']:
                expected=local_lens(model['x'],0,model['neighbors'][0,:scale])
                actual=result['lenses'][str(scale)]['0']
                np.testing.assert_allclose(actual['spectrum'],expected['spectrum'])
                self.assertEqual(actual['neighbor_ids'],expected['neighbor_ids'])
            self.assertTrue((Path(directory)/'observer.html').exists())
            self.assertFalse((Path(directory)/'media_manifest.json').exists())

    def test_export_excludes_item_attributes(self):
        import re
        from geometric_ecology.io import export_explorer
        model=build_map(np.random.default_rng(45).normal(size=(64,12)),scales=[6,12],repeats=2,regions=4,landmarks=8)
        with tempfile.TemporaryDirectory() as directory:
            export_explorer(model,directory,metadata=[{'title':'FORBIDDEN_ITEM_CONTENT','image':'private.jpg','class':'semantic-label'} for _ in range(64)])
            html=(Path(directory)/'observer_map.html').read_text()
            self.assertNotIn('FORBIDDEN_ITEM_CONTENT',html)
            self.assertNotIn('private.jpg',html)
            payload=json.loads(re.search(r'<script id="ecology-data" type="application/json">(.*?)</script>',html,re.S).group(1))
            self.assertIsNone(payload['evaluation'])
            for point in payload['points']:
                self.assertNotIn('metadata',point)
                self.assertNotIn('features',point)
                self.assertNotIn('image',point)
