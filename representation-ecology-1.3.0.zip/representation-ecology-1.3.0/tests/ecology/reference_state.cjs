const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.join(__dirname,'../../src/geometric_ecology'),els=new Map(),listeners=new Map();
class Element{constructor(){this.value='';this.textContent='';}set innerHTML(v){this.html=v;for(const m of v.matchAll(/id="([^"]+)"/g))els.set(m[1],new Element());}prepend(){}}
els.set('height-channel',new Element());els.get('height-channel').value='covariance_dimensions';
const document={getElementById:id=>els.get(id),body:{dataset:{}},createElement:()=>new Element(),querySelector:()=>new Element(),addEventListener:(name,fn)=>{listeners.set(name,fn)}};
let mode='mesh',field='hidden_two';const window={ecology:{getMode:()=>mode},atlasScale:{mode:'subset'},flatAtlas:{getState:()=>({color:field})}};
const data=JSON.parse(fs.readFileSync(root+'/interpretation.json','utf8'));
vm.runInNewContext(fs.readFileSync(root+'/interpretation.js','utf8').replace('__INTERPRETATION_DATA__',JSON.stringify(data)),{window,document});
assert.equal(data.tables.length,9);
assert(!JSON.stringify(data).includes('Braking behavior'));
assert(!JSON.stringify(data).includes('Route A'));
assert(JSON.stringify(data).includes('not built-in')||JSON.stringify(data).includes('external'));

const heights=data.tables.find(t=>t.title==='3D mesh: what a mountain means');
for(let i=0;i<4;i++){els.get('height-channel').value=data.height_keys[i];listeners.get('atlas-field')();assert(els.get('translation-field').textContent.includes(heights.rows[i][0]));assert(els.get('translation-table').html.includes('Predictive / navigation intuition'));assert(els.get('open-atlas-reference').href.includes(data.height_keys[i]));}
mode='atlas';field='density';listeners.get('atlas-field')();assert(els.get('translation-field').textContent.includes('Original-space density'));assert(els.get('translation-table').html.includes('Intuitive use'));assert(els.get('translation-scale').textContent.includes('subset'));
console.log('Reference translations follow all four heights and the selected flat field.');

// The lab uses the same curated table payload and follows the active fixture.
document.body.dataset={lab:'true',demoCase:'mountain'};els.set('lab-reference',new Element());
vm.runInNewContext(fs.readFileSync(root+'/interpretation.js','utf8').replace('__INTERPRETATION_DATA__',JSON.stringify(data)),{window,document});
assert(els.get('lab-reference-content').html.includes('Effective local directions'));
document.body.dataset.demoCase='maze';listeners.get('terrain-demo')();
assert(els.get('lab-reference-content').html.includes('Maze'));assert(!els.get('lab-reference-content').html.includes('A candidate unusually large local step'));
console.log('Controlled demos reuse the same curated tables and follow the selected fixture.');
