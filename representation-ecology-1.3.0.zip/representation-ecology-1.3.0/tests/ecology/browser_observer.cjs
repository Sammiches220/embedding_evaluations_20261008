/* Serve examples/observer_demo, then run with Playwright and optional CHROMIUM_EXECUTABLE. */
const {chromium}=require('playwright'),assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'],...(process.env.CHROMIUM_EXECUTABLE?{executablePath:process.env.CHROMIUM_EXECUTABLE}:{})});
 const page=await browser.newPage({viewport:{width:1500,height:1150}}),errors=[],requests=[];page.on('pageerror',e=>{errors.push(e.message);console.error('Page error:',e.message)});page.on('request',r=>requests.push(r.url()));
 await page.goto(process.argv[2]||'http://127.0.0.1:8765/observer.html');await page.waitForFunction(()=>window.observer);const frame=page.frames().find(f=>f.url().includes('observer_map'));
 assert.equal(await page.locator('#gallery,#manifest,#features').count(),0);assert(!requests.some(u=>u.includes('media_manifest')));
 assert(await frame.evaluate(()=>ecology.data.points.every(p=>!('metadata' in p)&&!('features' in p))));assert.equal(await frame.evaluate(()=>ecology.data.evaluation),null);
 let s=await page.evaluate(()=>observer.getState());assert(!s.selected);assert(s.here.length>0);
 const pos=s.position,initialHeading=s.heading;await page.keyboard.press('w');assert.deepEqual(await page.evaluate(()=>observer.getState().position),pos);
 await page.click('#select-observer');await page.keyboard.down('ArrowLeft');await page.waitForFunction(h=>observer.getState().heading>h,initialHeading);await page.keyboard.up('ArrowLeft');s=await page.evaluate(()=>observer.getState());assert.deepEqual(s.position,pos);assert(s.heading>initialHeading);const target=s.target;assert.notDeepEqual(target,pos);
 await page.keyboard.down('w');await page.waitForTimeout(400);await page.keyboard.up('w');await page.waitForTimeout(220);assert.notDeepEqual(await page.evaluate(()=>observer.getState().position),pos);
 await page.keyboard.press('Escape');assert.equal(await page.evaluate(()=>observer.getState().selected),false);
 const here=await page.evaluate(()=>observer.getState().here);await page.evaluate(()=>observer.face(Math.PI));assert.deepEqual(await page.evaluate(()=>observer.getState().here),here);
 const p=await frame.evaluate(()=>{const p=ecology.coords(0);return[p,ecology.unproject(ecology.screen(p))]});p[0].forEach((v,i)=>assert(Math.abs(v-p[1][i])<1e-8));
 await page.selectOption('#projection','mesh');await page.waitForFunction(()=>document.getElementById('atlas').contentWindow.mesh3D.getStats().draws>0);assert(await frame.evaluate(()=>mesh3D.supported));assert((await frame.evaluate(()=>mesh3D.getStats().triangles))>0);assert.equal(await frame.evaluate(()=>ecology.getMode()),'mesh');
 assert.deepEqual(await page.evaluate(()=>observer.getState().here),here);const oldCamera=await frame.evaluate(()=>mesh3D.getCamera());
 await page.click('#select-observer');const meshPosition=await page.evaluate(()=>observer.getState().position);await page.keyboard.down('ArrowUp');await page.waitForTimeout(300);await page.keyboard.up('ArrowUp');assert.deepEqual(await page.evaluate(()=>observer.getState().position),meshPosition);assert.deepEqual(await frame.evaluate(()=>mesh3D.getCamera()),oldCamera);assert(Number(await page.locator('#range').inputValue())>5);
 const heading=await page.evaluate(()=>observer.getState().heading);await page.keyboard.down('ArrowRight');await page.waitForTimeout(300);await page.keyboard.up('ArrowRight');assert((await page.evaluate(()=>observer.getState().heading))<heading);assert.deepEqual(await frame.evaluate(()=>mesh3D.getCamera()),oldCamera);
 await page.selectOption('#camera','follow');await page.locator('h1').click();await page.keyboard.down('s');await page.waitForTimeout(350);await page.keyboard.up('s');await page.waitForTimeout(250);const q=await page.evaluate(()=>document.getElementById('atlas').contentWindow.mesh3D.projectSurface(observer.getState().position));const box=await page.locator('#atlas').boundingBox();assert(Math.abs(q[0]-box.width/2)<4);assert(Math.abs(q[1]-box.height/2)<4);
 // Surface picking must resolve a real rendered triangle rather than a flat inverse transform.
 const hit=await frame.evaluate(()=>{const p=ecology.data.atlas.islands[0].field,b=p.bounds;for(let r=1;r<p.size-2;r++)for(let c=1;c<p.size-2;c++){if(p.valid[r][c]&&p.valid[r+1][c]&&p.valid[r][c+1]&&p.valid[r+1][c+1]){const xy=[b[0]+(c+.25)/(p.size-1)*(b[2]-b[0]),b[1]+(r+.25)/(p.size-1)*(b[3]-b[1])],q=mesh3D.projectSurface(xy),hit=mesh3D.pickSurface(q);if(hit)return{xy,hit,q}}}return null});assert(hit);assert(hit.hit.every(Number.isFinite));
 await page.selectOption('#camera','overview');await frame.locator('#reset-view').click();await page.waitForTimeout(250);
 const clickable=await frame.evaluate(()=>{const m=ecology.data.atlas.islands[0].field;for(let r=1;r<m.size-2;r++)for(let c=1;c<m.size-2;c++){if(!m.valid[r][c]||!m.valid[r+1][c]||!m.valid[r][c+1]||!m.valid[r+1][c+1])continue;const p=[m.bounds[0]+(c+.5)/(m.size-1)*(m.bounds[2]-m.bounds[0]),m.bounds[1]+(r+.5)/(m.size-1)*(m.bounds[3]-m.bounds[1])],q=mesh3D.projectSurface(p),hit=mesh3D.pickSurface(q);if(hit&&q[0]>25&&q[0]<document.getElementById('mesh-map').clientWidth-25&&q[1]>50&&q[1]<document.getElementById('mesh-map').clientHeight-50)return{q,hit}}return null});assert(clickable);
 const meshBox=await page.locator('#atlas').boundingBox();await page.mouse.dblclick(meshBox.x+clickable.q[0],meshBox.y+clickable.q[1]);await page.waitForTimeout(250);const placed=await page.evaluate(()=>observer.getState().position);assert(Math.hypot(placed[0]-clickable.hit[0],placed[1]-clickable.hit[1])<.15);
 await page.click('#reset');await page.screenshot({path:'/tmp/observer-mesh-review.png'});
 await page.locator('summary').filter({hasText:'Observation controls'}).click();await page.selectOption('#scope','subset');assert.equal(await frame.evaluate(()=>atlasScale.mode),'subset');await page.selectOption('#scope','global');
 for(const field of await page.locator('#field option').evaluateAll(o=>o.map(x=>x.value))){await page.selectOption('#field',field);await page.waitForTimeout(230);assert((await page.locator('#profile-unit').innerText()).includes('raw scale'));assert.equal(await frame.evaluate(()=>mesh3D.getStats().webgl_error),0)}
 const scale=await page.locator('#scale option').first().getAttribute('value');await page.selectOption('#scale',scale);const anchors=await page.evaluate(()=>observer.getAnchors());if(anchors.here)assert.equal(anchors.here.data.neighbor_ids.length,+scale);
 await page.evaluate(()=>observer.place([1e6,1e6]));assert.equal((await page.evaluate(()=>observer.getState())).here.length,0);assert.match(await page.locator('#here-anchor').innerText(),/No supported/);await page.click('#reset');
 await page.selectOption('#projection','pca');assert.equal(await frame.evaluate(()=>ecology.getMode()),'pca');await page.selectOption('#projection','atlas');
 await page.screenshot({path:process.env.OBSERVER_SCREENSHOT||'/tmp/observer-geometry-review.png'});

 const metricKeys=await page.locator('#field option').evaluateAll(o=>o.map(x=>x.value));assert.equal(metricKeys.length,10);
 for(const selector of ['#color-field','#contour-field'])assert.deepEqual(await page.locator(selector+' option').evaluateAll(o=>o.map(x=>x.value)),metricKeys);
 assert.equal(await page.locator('.profile-card:visible').count(),9);
 assert((await page.locator('#profile').boundingBox()).height>(await page.locator('.profile-card:visible canvas').first().boundingBox()).height);
 await page.locator('summary').filter({hasText:'Choose additional profiles'}).click();const toggle=page.locator('#profile-checklist input:not(:disabled)').first();await toggle.uncheck();assert.equal(await page.locator('.profile-card:visible').count(),8);await toggle.check();
 await page.click('#toggle-side');assert.equal(await page.locator('.side:visible').count(),0);await page.click('#toggle-side');
 await page.click('#toggle-bottom');assert.equal(await page.locator('#profile-panel:visible').count(),0);await page.click('#toggle-bottom');
 const beforeWidth=(await page.locator('.side').boundingBox()).width;await page.locator('#resize-side').focus();await page.keyboard.press('ArrowLeft');assert((await page.locator('.side').boundingBox()).width>beforeWidth);
 await page.selectOption('#projection','mesh');await frame.locator('#mesh-map').focus();const fixedCamera=await frame.evaluate(()=>mesh3D.getCamera());await page.keyboard.down('ArrowLeft');await page.waitForTimeout(300);await page.keyboard.up('ArrowLeft');assert.deepEqual(await frame.evaluate(()=>mesh3D.getCamera()),fixedCamera);
 for(const key of metricKeys){await page.selectOption('#color-field',key);await page.selectOption('#contour-field',key);await page.waitForTimeout(100);assert.equal(await frame.evaluate(()=>flatAtlas.getState().color),key);assert.equal(await frame.evaluate(()=>flatAtlas.getState().contour),key);assert.equal(await frame.evaluate(()=>mesh3D.getStats().webgl_error),0)}
 assert((await frame.evaluate(()=>mesh3D.getStats().contourVertices))>0);
 const resolutionHere=await page.evaluate(()=>observer.getState().here),resolutionPosition=await page.evaluate(()=>observer.getState().position);
 const triangleCounts=[];
 for(const n of ['27','108','54']){await page.selectOption('#surface-resolution',n);await page.waitForTimeout(400);assert(await frame.evaluate(n=>ecology.data.atlas.islands.every(i=>i.field.size===+n),n));assert.equal(await frame.locator('#surface-resolution').inputValue(),n);triangleCounts.push(await frame.evaluate(()=>mesh3D.getStats().triangles));assert.equal(await frame.evaluate(()=>mesh3D.getStats().webgl_error),0);assert.deepEqual(await page.evaluate(()=>observer.getState().here),resolutionHere);assert.deepEqual(await page.evaluate(()=>observer.getState().position),resolutionPosition)}
 assert(new Set(triangleCounts).size>1);
 await page.selectOption('#projection','atlas');await page.selectOption('#surface-resolution','108');await page.waitForTimeout(200);assert(await frame.evaluate(()=>ecology.data.atlas.islands.every(i=>i.field.size===108)));
 await page.locator('#profile-panel').evaluate(el=>el.scrollTop=180);await page.screenshot({path:'/tmp/observer-resolution-profile.png'});

 await page.click('#return');await page.waitForFunction(()=>window.ecology);await page.click('#mesh-view');assert.equal(await page.evaluate(()=>ecology.getMode()),'mesh');assert.deepEqual(errors,[]);
 console.log('Geometry-only observer browser tests passed: data boundary, keyboard selection/motion/view, directional populations, mesh projection/picking/follow, scales, missing geometry and original atlas.');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
