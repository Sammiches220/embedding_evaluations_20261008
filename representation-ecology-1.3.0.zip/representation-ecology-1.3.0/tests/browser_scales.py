"""Small-fixture UI checks for filtration and broad/local reconstruction."""
import argparse,functools,http.server,threading,json
from pathlib import Path
from playwright.sync_api import sync_playwright
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args):pass

def main():
    a=argparse.ArgumentParser();a.add_argument('--run',required=True);a.add_argument('--chromium');a.add_argument('--screenshot');args=a.parse_args()
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(Path(args.run).resolve())));threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(headless=True,executable_path=args.chromium,args=['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader']);page=browser.new_page(viewport={'width':1600,'height':1120});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://127.0.0.1:{server.server_port}/index.html');page.wait_for_function('representationEcology?.getContext()?.here.length>0')
            page.evaluate("representationEcology.selectFeature('context_signal')")
            xy=page.evaluate('JSON.stringify(representationEcology.getEngine().data.atlas.xy)')
            assert page.locator('#access-dimension option').count()==4
            page.locator('#access-account').select_option('gain');page.wait_for_timeout(200)
            assert page.evaluate('representationEcology.getLens()')=='prediction'
            assert page.evaluate('representationEcology.getSurfaceKey()').startswith('access_')
            assert 'Group-held-out' in page.locator('#gap-subtitle').inner_text()
            assert 'Population (384 rows)' in page.locator('#access-reading').inner_text()
            assert '160 displayed' in page.locator('#access-coverage').text_content(),page.locator('#access-coverage').text_content()
            assert 'local' in page.locator('#access-selection').text_content()
            page.locator('#access-dimension').select_option('2');two=page.evaluate('representationEcology.getSurfaceKey()');page.locator('#access-dimension').select_option('8');assert two!=page.evaluate('representationEcology.getSurfaceKey()')
            key=page.evaluate('representationEcology.getSurfaceKey()');r=page.evaluate('k=>representationEcology.getEngine().data.atlas.display_fields[k].global_range',key);assert abs(sum(r))<1e-9
            last=page.locator('#filtration-level').get_attribute('max');page.locator('#filtration-level').fill('0');page.locator('#keep-filtration').click();small=len(page.evaluate('representationEcology.getSelection()'));page.locator('#filtration-level').fill(last);page.locator('#keep-filtration').click();large=len(page.evaluate('representationEcology.getSelection()'));assert large>=small
            assert 'omitted edges' in page.locator('#scale-scope').inner_text()
            assert page.evaluate('JSON.stringify(representationEcology.getEngine().data.atlas.xy)')==xy
            for account in ['broad','local','selected']:
                page.locator('#access-account').select_option(account);assert account in page.evaluate('representationEcology.getSurfaceKey()')
            page.locator('#view-3d').click();page.locator('#relief').fill('4');page.wait_for_timeout(200)
            if args.screenshot:page.screenshot(path=args.screenshot,full_page=True)
            page.locator('#access-account').select_option('probe');assert not page.evaluate('representationEcology.getSurfaceKey()').startswith('access_')
            response=page.request.get(f'http://127.0.0.1:{server.server_port}/bridge/accessibility.json');assert response.ok
            assert not errors,errors
            print(json.dumps({'status':'passed','checks':['filtration extent capture','independent dimension control','broad/local/gain/selected fields','matched profiles','population/sample scope','signed gain','original predictor retained','3D relief','immutable coordinates'],'page_errors':errors}));browser.close()
    finally:server.shutdown();server.server_close()
if __name__=='__main__':main()
