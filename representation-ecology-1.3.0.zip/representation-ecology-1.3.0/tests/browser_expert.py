"""Optional real-browser integration test; starts its own isolated local server."""
import argparse
import functools
import http.server
import json
import threading
from pathlib import Path
from playwright.sync_api import sync_playwright

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args): pass

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',required=True);parser.add_argument('--chromium');args=parser.parse_args()
    root=Path(args.run).resolve()
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(root)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with sync_playwright() as p:
            options=dict(headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader'])
            if args.chromium: options['executable_path']=str(Path(args.chromium).resolve())
            browser=p.chromium.launch(**options);page=browser.new_page(viewport={'width':1640,'height':1100});errors=[]
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.goto(f'http://127.0.0.1:{server.server_port}/expert.html')
            page.wait_for_function('window.representationEcology?.getEngine()!=null',timeout=30000)
            first_id=page.evaluate('representationEcology.data.ids[0]')
            page.evaluate('representationEcology.inspect(0)')
            assert page.locator('#item-title').inner_text()==first_id
            original_hash=page.evaluate('JSON.stringify(representationEcology.getEngine().data.atlas.xy)')
            page.locator('[data-panel=cohorts]').click();page.locator('#capture-kind').select_option('neighbors');page.locator('#capture').click()
            k=int(page.locator('#k').input_value());assert len(page.evaluate('representationEcology.getSelection()'))==k
            numeric=page.evaluate("Object.keys(representationEcology.data.features).find(k=>representationEcology.data.features[k].kind==='continuous')")
            assert numeric,'Browser fixture requires a numeric feature'
            page.locator('#query-feature').select_option(numeric);page.locator('#query-op').select_option('known');page.locator('#add-clause').click();page.locator('#query').click()
            assert len(page.evaluate('representationEcology.getSelection()'))>0
            page.locator('#field').select_option(numeric+' · observed');page.locator('#scale').select_option('subset')
            assert page.evaluate('JSON.stringify(representationEcology.getEngine().data.atlas.xy)')==original_hash
            page.evaluate('''()=>{const e=representationEcology.getEngine(),edge=e.data.edges[0];if(edge){e.select(edge[0]);e.select(edge[1],true)}}''')
            page.locator('#capture-kind').select_option('route');page.locator('#capture').click()
            assert len(page.evaluate('representationEcology.getSelection()'))>=2
            engine=page.frames[1];mesh_supported=engine.locator('#mesh-view').is_enabled()
            if mesh_supported:
                engine.locator('#mesh-view').click();page.wait_for_timeout(250)
                assert page.evaluate('representationEcology.getEngine().getMode()')=='mesh'
            page.locator('#observer-tab').click();page.wait_for_timeout(1500)
            page.wait_for_function('representationEcology.getEngine()!=null',timeout=30000)
            page.wait_for_function("document.getElementById('atlas').contentWindow.observerBridge?.getRegions().here.length>0",timeout=30000)
            page.locator('#capture-kind').select_option('here');page.locator('#capture').click()
            assert len(page.evaluate('representationEcology.getSelection()'))>0
            assert not errors,errors
            print(json.dumps({'status':'passed','webgl_mesh_tested':mesh_supported,'page_errors':errors}))
            browser.close()
    finally:server.shutdown();server.server_close()

if __name__=='__main__':main()
