"""Current-build browser integration: continuous fields, geometry readings and relief."""
import argparse
import functools
import http.server
import threading
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args):pass

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',required=True);parser.add_argument('--chromium');parser.add_argument('--screenshots');args=parser.parse_args()
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(Path(args.run).resolve())))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with sync_playwright() as p:
            options=dict(headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader'])
            if args.chromium:options['executable_path']=str(Path(args.chromium).resolve())
            browser=p.chromium.launch(**options);page=browser.new_page(viewport={'width':1600,'height':1120});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
            page.goto(f'http://127.0.0.1:{server.server_port}/index.html')
            page.wait_for_function('representationEcology?.getContext()?.here.length>0',timeout=30000)
            assert page.evaluate('representationEcology.getLens()')=='geometry'
            assert page.locator('#geometry-cards .geometry-family').count()==4
            assert page.locator('#geometry-cards .geom-row').count()==12
            assert page.locator('#neighborhood-anatomy').evaluate('c=>c.width>0&&c.height>0')
            assert 'not a count' in page.locator('#reading-visual').inner_text()
            assert page.evaluate('document.getElementById("atlas").contentWindow.document.getElementById("atlas").contentWindow.atlasScale.mode')=='observed'
            xy=page.evaluate('JSON.stringify(representationEcology.getEngine().data.atlas.xy)')
            page.locator('#walk').click();before=page.evaluate('representationEcology.getBridge().getState().position');page.keyboard.down('w');page.wait_for_timeout(300);page.keyboard.up('w');page.keyboard.press('Escape');assert before!=page.evaluate('representationEcology.getBridge().getState().position')
            assert page.evaluate('document.getElementById("atlas").contentWindow.document.getElementById("atlas").contentWindow.atlasScale.mode')=='observed'
            # Every geometry measurement must be usable as an actual field, not just a text selector.
            page.locator('#open-tools').click()
            page.locator('#display-reference').select_option('robust')
            page.locator('[data-close=tools]').click()
            page.locator('#walk').click();page.keyboard.down('w');page.wait_for_timeout(200);page.keyboard.up('w');page.keyboard.press('Escape')
            assert page.evaluate('document.getElementById("atlas").contentWindow.document.getElementById("atlas").contentWindow.atlasScale.mode')=='robust'
            page.locator('#open-tools').click();page.locator('#display-reference').select_option('observed')
            keys=page.locator('#geometry-field option').evaluate_all('(nodes)=>nodes.map(n=>n.value)')
            for key in keys:
                page.locator('#geometry-field').select_option(key)
                page.wait_for_timeout(80)
                assert page.evaluate('representationEcology.getSurfaceKey()')==key
            page.locator('#geometry-field').select_option('route_count');page.locator('[data-close=tools]').click()
            page.locator('#route-bundle').check()
            assert 'not causal' in page.locator('#reading-visual').inner_text()
            page.locator('#route-bundle').uncheck()
            page.locator('[data-lens=feature]').click();page.wait_for_timeout(200)
            info=page.evaluate('''()=>{const e=representationEcology.getEngine(),k=representationEcology.getSurfaceKey(),f=e.data.atlas.islands[0].field;return {key:k,values:!!f.values[k],mask:!!f.field_valid[k],valid:f.field_valid[k].flat().filter(Boolean).length,contours:f.isolines[k].length,colors:new Set(representationEcology.getPaint().map(p=>p.color)).size}}''')
            assert info['values'] and info['mask'] and info['valid']>0 and info['contours']>0,info
            assert info['colors']>12,info
            assert page.evaluate('new Set(representationEcology.getPaint().filter(p=>p.shape!=="cross").map(p=>p.shape)).size')==1,'Continuous numeric data should not be forced into shape classes'
            page.locator('[data-lens=gap]').click();page.locator('#gap-signed').click();page.wait_for_timeout(100)
            r=page.evaluate('''()=>{const e=representationEcology.getEngine(),k=representationEcology.getSurfaceKey();return e.data.atlas.display_fields[k].global_range}''');assert abs(r[0]+r[1])<1e-9
            page.locator('#gap-magnitude').click();assert 'magnitude' in page.evaluate('representationEcology.getSurfaceKey()')
            page.locator('[data-lens=prediction]').click();page.wait_for_timeout(100);assert page.locator('#gap-title').inner_text()=='Feature prediction error'
            page.locator('#follow-height').check()
            assert page.evaluate('document.getElementById("atlas").contentWindow.document.getElementById("atlas").contentWindow.document.getElementById("height-channel").value')==page.evaluate('representationEcology.getSurfaceKey()')
            supported=page.evaluate('document.getElementById("atlas").contentWindow.document.getElementById("atlas").contentWindow.mesh3D.supported')
            if supported:
                page.locator('#view-3d').click();page.wait_for_timeout(250)
                page.locator('#relief').fill('0');page.wait_for_timeout(100)
                point=page.evaluate('representationEcology.getEngine().data.points.findIndex((_,i)=>representationEcology.getEngine().pointHeight(i)>.01)');assert point>=0
                zero=page.evaluate('i=>document.getElementById("atlas").contentWindow.document.getElementById("atlas").contentWindow.mesh3D.projectIndex(i)',point)
                assert page.evaluate('document.getElementById("atlas").contentWindow.document.getElementById("atlas").contentWindow.atlasScale.reliefGain')==0
                page.locator('#relief').fill('5');page.wait_for_timeout(100)
                high=page.evaluate('i=>document.getElementById("atlas").contentWindow.document.getElementById("atlas").contentWindow.mesh3D.projectIndex(i)',point);assert zero!=high
                assert page.locator('#relief-value').inner_text()=='5×'
            page.locator('#follow-height').uncheck();page.locator('#capture-here').click();assert page.evaluate('representationEcology.getSelection().length')>0
            assert page.evaluate('JSON.stringify(representationEcology.getEngine().data.atlas.xy)')==xy
            if args.screenshots:
                folder=Path(args.screenshots);folder.mkdir(parents=True,exist_ok=True)
                for view in ['geometry','feature','gap','prediction']:
                    page.locator(f'[data-lens={view}]').click();page.wait_for_timeout(200);page.screenshot(path=str(folder/(view+'.png')))
            # All-unknown current source values must not form a supported zero-valued field.
            numeric=page.evaluate("Object.keys(representationEcology.data.features).find(n=>representationEcology.data.features[n].kind==='continuous')")
            page.evaluate("n=>{const d=representationEcology.data;d.features[n].values=d.ids.map(()=>null);representationEcology.selectFeature(n);representationEcology.setLens('feature')}",numeric)
            assert page.evaluate('''()=>{const e=representationEcology.getEngine(),k=representationEcology.getSurfaceKey();return e.data.atlas.islands.every(i=>i.field.field_valid[k].flat().every(v=>!v))}''')
            assert not errors,errors
            print(json.dumps({'status':'passed','webgl_mesh_tested':supported,'page_errors':errors,'checks':['12 integrated geometry fields','local shape and spectra','continuous source and error surfaces','raw-value isolines','signed symmetry','relief 0 and 5','3D displacement','walking','no numeric shape bins','unknown-field holes','immutable map coordinates']}))
            browser.close()
    finally:server.shutdown();server.server_close()
if __name__=='__main__':main()
