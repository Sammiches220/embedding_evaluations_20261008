/* Embeddings-derived geometry only. No item attributes, media, or semantic inputs. */
(function(root){'use strict';
const distance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
function move(position,heading,keys,dt,speed,bounds){
 const nextHeading=heading+((keys.has('ArrowLeft')?1:0)-(keys.has('ArrowRight')?1:0))*dt*1.5;
 const forward=(keys.has('w')?1:0)-(keys.has('s')?1:0),side=(keys.has('d')?1:0)-(keys.has('a')?1:0),length=Math.hypot(forward,side)||1;
 const dx=(forward*Math.cos(nextHeading)+side*Math.sin(nextHeading))/length,dy=(forward*Math.sin(nextHeading)-side*Math.cos(nextHeading))/length;
 return {position:[Math.max(bounds[0],Math.min(bounds[2],position[0]+dx*dt*speed)),Math.max(bounds[1],Math.min(bounds[3],position[1]+dy*dt*speed))],heading:nextHeading};
}
function cone(p,h,angle,range,steps=24){const out=[p];for(let i=0;i<=steps;i++){const a=h-angle/2+angle*i/steps;out.push([p[0]+range*Math.cos(a),p[1]+range*Math.sin(a)])}return out;}
function target(p,h,range){return[p[0]+Math.cos(h)*range,p[1]+Math.sin(h)*range]}
class SpatialIndex{
 constructor(xy,cellSize){this.xy=xy;this.size=Math.max(cellSize,1e-9);this.cells=new Map();xy.forEach((p,i)=>{const key=this.key(p);if(!this.cells.has(key))this.cells.set(key,[]);this.cells.get(key).push(i)})}
 key(p){return Math.floor(p[0]/this.size)+','+Math.floor(p[1]/this.size)}
 radius(p,r){const out=[];for(let x=Math.floor((p[0]-r)/this.size);x<=Math.floor((p[0]+r)/this.size);x++)for(let y=Math.floor((p[1]-r)/this.size);y<=Math.floor((p[1]+r)/this.size);y++)for(const i of this.cells.get(x+','+y)||[])if(distance(this.xy[i],p)<=r)out.push(i);return out.sort((a,b)=>a-b)}
}
function summarize(members,fields,key){const keys=Object.keys(fields),metrics={};for(const key of keys){const v=members.map(i=>fields[key]?.values[i]).filter(Number.isFinite).sort((a,b)=>a-b);metrics[key]=v.length?{median:v.length%2?v[v.length>>1]:(v[v.length/2-1]+v[v.length/2])/2,min:v[0],max:v.at(-1),n:v.length}:null}return{members,metrics};}
// Sample existing per-item measurements, not invented heights or new source geometry.
function profile(index,p,end,radius,fields,key,steps=18){return Array.from({length:steps+1},(_,i)=>{const t=i/steps,xy=p.map((v,k)=>v+(end[k]-v)*t),members=index.radius(xy,radius),s=summarize(members,fields,key);return{xy,distance:distance(p,xy),...s,component:null}});}
function transitions(rows,key,points){let steepest=null;for(let i=1;i<rows.length;i++){const a=rows[i-1],b=rows[i],av=a.metrics[key],bv=b.metrics[key];if(!av||!bv)continue;const ac=new Set(a.members.map(j=>points[j].component)),bc=new Set(b.members.map(j=>points[j].component));if(![...ac].some(c=>bc.has(c)))continue;const delta=bv.median-av.median,step=b.distance-a.distance;if(step>0&&(!steepest||Math.abs(delta/step)>Math.abs(steepest.slope)))steepest={index:i,delta,slope:delta/step};}return steepest;}
const api={distance,move,cone,target,SpatialIndex,summarize,profile,transitions};if(typeof module!=='undefined')module.exports=api;else root.ObserverCore=api;
})(globalThis);
