# Measured feasibility report

This is a geometric feasibility demonstration, not a semantic or human-value detector.
The atlas presents its computed analyses directly. All numbers below come from the shipped run.

## Corpus and construction

- Items: 160; dimensions: 8; encoder: synthetic-alternate-v1.
- Corpus SHA-256: `21f3e8b8155fada75ada66441a6365b983e9452458c48dbd2155919f2ab2e0f5`.
- Metric: unit-normalized Euclidean chord; exact batched neighbor backend.
- Scales: [6, 12, 24]; support threshold: 0.5.
- Build time: 0.068 s. Validation time: 0.240 s.
- Support graph components: 2; largest share: 0.994.
- Navigation cells: 9. These are graph Voronoi cells, not semantic classes.
- Sparse H0 infinite bars: 1. H1/loops are not measured.

## Does the representation survive changes?

- Median eligible-universe subsample Jaccard: 0.806.
- Median 0.01-chord perturbation Jaccard: 1.000.
- Median original-vs-display neighbor Jaccard: 0.714.
- PCA display variance explained: 0.714.

Low display Jaccard is a reason to inspect original neighbors and graph routes rather
than reading projected proximity as evidence. Nested k-edge support is a rank statistic;
it is never used as independent perturbation evidence. Resampling ranges are empirical
sensitivity ranges over 3 replicates, not confidence intervals.

## Held-out geometric recovery

The map and PCA are fit only to 128 training vectors; 32
vectors are held out. The target is the nearest training anchor under the original
query. Query vectors are then perturbed by 0.05 chord units.

| Measurement | Result |
|---|---:|
| Direct retrieval top-1 anchor recovery | 0.906 |
| Direct retrieval top-10 anchor recovery | 1.000 |
| Random anchor top-10 expectation | 0.078 |
| Compressed retrieval top-10 recovery | 1.000 |
| Centroid navigation-cell recovery | 0.844 |
| Majority navigation-cell baseline | 0.406 |
| Median correct-anchor rank | 1.000 |

The direct-neighbor baseline already has the embedding vectors. The map adds inspection,
terrain and routing; these measurements do not establish better retrieval accuracy.
The cell baseline can expose misleading accuracy from a dominant cell.

## Navigation and structural influence

- Reachable sampled pairs: 32/32.
- Median raw graph-length / direct-chord stretch: 1.406.
- Median support-weighted path-cost / direct-chord ratio: 1.510.
- Median Dijkstra expansions, including unreachable attempts: 82.000.
- Reachable fraction after one middle-edge ablation: 1.000.
- Mean route-edge retention after independent geometry noise: 0.997.
- Fixed-graph articulation vertices: 1.

Deletion influence is exact on the retained graph, with no neighbor refill. A redundant
path can make deletion influence zero even at an obvious connector. Sampled hop-path
betweenness complements it. Local effective next-hop count is not global route entropy.

## Null controls

One realization per null; these are descriptive comparisons, with no p-values.
The Gaussian control matches mean/covariance in expectation before renormalization,
not local density. Uniform-sphere structure is not a model of all irrelevant data.

| Cloud | Components | Median local dimension | Perturbation Jaccard | Display Jaccard |
|---|---:|---:|---:|---:|
| Observed | 2 | 2.528 | 1.000 | 0.714 |
| uniform_sphere | 1 | 5.298 | 1.000 | 0.117 |
| moment_matched_gaussian | 2 | 3.874 | 1.000 | 0.412 |

## Cartographic interface

The interface is the computed map, with no questionnaire or evidence-entry workflow.

- 160 points are embedded and represented; no display sampling.
- 1 substantial connected landmasses and 1 tiny components.
- 11 mapped road paths and 0 marked regional passes.
- Cartographic construction: 0.019 seconds.
- Median original-neighbor / atlas-neighbor Jaccard: 0.600.
- Separate component discs prevent visual overlap between disconnected major islands.
- Every road follows real retained edges. Passes require a critical cell-level crossing.

Measured dimension relief, flat-map density contours, narrow crossings and
resampling/compression disagreement are drawn automatically. The persistent inline strip
unfolds actual covariance directions without a neighborhood popup, and `terrain_lab.html` supplies eight
controlled comparisons. Route ambiguity uses a recorded bounded set of regional near-shortest
paths to stated destinations; it is distinct from the local next-hop statistic.
Dimension height, metric variation and bounded route ambiguity are separate
selectable channels. Landmark graph-distance MDS is followed by monotone population
magnification so populated basins remain legible beside long passages. Island spacing
and drawn areas are schematic, not metric distances. Terrain interpolation uses original
measurements within each component; synthetic labels do not enter cartography.


## 3D dimensionality view

The orbitable mesh shows local neighbor envelopes and ordered spectra
directly on the map. Hue is the variance omitted by the first two local covariance
axes. Default height is covariance participation ratio with explicit global, robust
or subset display ranges. Its estimator sample-rank bound is 7. It is distinct from radius-growth dimension.
All-point spectral analysis and representative hull construction: 0.007 s.

Surface facets are rendering geometry, not a dimension count or additional graph
edges. Representative meshes have normalized footprints in local PCA frames.
Color and spectra expose variation beyond their three displayed axes. Without
WebGL, relief and inline spectra remain available.


## Flat field atlas

The default view keeps every position strictly planar. Nine measured fields can
independently drive color and labelled isolines. Four presets combine
dimensionality, density/redundancy, route alternatives and stability. Spectrum
rings and first-two-axis ellipses show original local covariance at representatives.
Fields and contours are masked per component; unsupported gaps are not bridged.
Flat-field preparation and contour tracing: 0.053 s.


## Practical limits and omitted parts

This exact reference backend is appropriate for hundreds to low tens of thousands of
points, depending on dimension and hardware. Search remains quadratic over the corpus;
the retained graph is sparse but the full workflow is not linear. PCA and npz loading
are in memory. New-query scoring scans the reference corpus and reuses fitted PCA.
No million-point performance claim is made. An ANN backend needs a separate recall
benchmark before deployment. Sparse H0 omits edges absent from the max-k graph; no H1,
global route entropy, alternate encoder validation, block/branch recovery, corpus-drift
study, full leave-one-out topology, or generation experiment is implemented. Generation
output is only a constraint inventory, not a measured difficulty estimate.

The project presents corpus-relative geometry as a directly readable atlas. Whether
its regions correspond to meaningful content depends on the corpus, encoder and task.
