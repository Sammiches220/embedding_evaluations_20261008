# Larger offline demo — run locally

Install the project, then inspect the plan:

```bash
python examples/large-demo/make_demo.py --out large-population --n 100000 --plan-only
```

Run the same command without `--plan-only` to generate/evaluate the population. Open it with `representation-ecology serve --run large-population/run --open`. Set `--n 1000000` in a new destination for a larger experiment after reviewing its plan. No large population run was executed while preparing this release.

The population reconstruction experiment is batched; full atlas geometry/filtration is restricted to the declared sample (240 by default). See `docs/SCALES_AND_POPULATIONS.md` for scope, outputs, real-data input and limits.
