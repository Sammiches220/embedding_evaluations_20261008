"""User-run larger offline demo. Not executed during release validation."""
import argparse,json
from representation_ecology.offline import offline_demo
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',default='large-population');p.add_argument('--n',type=int,default=100000);p.add_argument('--dimension',type=int,default=32);p.add_argument('--display-rows',type=int,default=240);p.add_argument('--batch-rows',type=int,default=4096);p.add_argument('--seed',type=int,default=42);p.add_argument('--plan-only',action='store_true');a=p.parse_args()
    print(json.dumps(offline_demo(a.out,a.n,a.dimension,a.display_rows,a.batch_rows,a.seed,plan_only=a.plan_only),indent=2))
