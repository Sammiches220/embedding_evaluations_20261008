"""Auditable descriptive calibration; these are not significance tests."""
import numpy as np

DEFAULTS = dict(fence_multiplier=1.5, bootstrap_repeats=128, route_limit=24,
                route_detour=None, route_temperature=None, substitute_tolerance=None)


def configuration(overrides=None):
    result = {**DEFAULTS, **(overrides or {})}
    unknown = set(result) - set(DEFAULTS)
    if unknown:
        raise ValueError(f'Unknown criteria: {sorted(unknown)}')
    if not np.isfinite(result['fence_multiplier']) or result['fence_multiplier'] <= 0:
        raise ValueError('fence_multiplier must be positive and finite')
    for key, low in [('bootstrap_repeats', 16), ('route_limit', 2)]:
        if not isinstance(result[key], int) or not low <= result[key] <= 512:
            raise ValueError(f'{key} must be an integer in [{low},512]')
    for key, low in [('route_detour', 1), ('route_temperature', 0), ('substitute_tolerance', 0)]:
        value = result[key]
        if value is not None and (not np.isfinite(value) or value < low or (key == 'route_temperature' and value == 0)):
            raise ValueError(f'Invalid {key}')
    return result


def fence(values, *, side='high', multiplier=1.5, repeats=128, seed=42):
    """Tukey outlier fence with reproducible bootstrap threshold uncertainty.

    Strict inequalities avoid inventing extremes in constant populations.
    Resampling is capped at 2048 observations for bounded calibration cost.
    The interval is descriptive: graph observations are dependent.
    """
    a = np.asarray(values, float).ravel()
    a = a[np.isfinite(a)]
    if not len(a):
        return dict(value=None, interval=None, n=0, method='unavailable')
    def estimate(x, m=multiplier):
        q1, q3 = np.quantile(x, [.25, .75], axis=-1)
        return q3 + m*(q3-q1) if side == 'high' else q1-m*(q3-q1)
    value = float(estimate(a))
    rng = np.random.default_rng(seed)
    sample = rng.choice(a, (repeats, min(len(a), 2048)), replace=True)
    bounds = np.quantile(estimate(sample), [.025, .975]).tolist()
    compare = np.greater if side == 'high' else np.less
    return dict(value=value, interval=bounds, n=len(a), side=side,
                method='Tukey IQR fence; descriptive bootstrap interval',
                sensitivity=[dict(multiplier=float(m), threshold=float(estimate(a,m)),
                                  selected=int(compare(a, estimate(a,m)).sum()))
                             for m in [multiplier*.75, multiplier, multiplier*1.25]])


def calibrate(model):
    cfg = configuration(model['manifest'].get('criteria_config'))
    distances = model['distances'][:, :model['manifest']['signature_k']]
    nearest = distances[:, 0]
    f = fence(nearest, side='low', multiplier=cfg['fence_multiplier'],
              repeats=cfg['bootstrap_repeats'], seed=model['manifest']['seed'])
    tolerance = cfg['substitute_tolerance']
    if tolerance is None:
        tolerance = max(0., f['value'])
    # Relative within-neighborhood spacing dispersion sets the route cost band.
    # This is a measured policy proxy, not route uncertainty or a significance level.
    dispersion = np.median(np.std(distances,axis=1)/np.maximum(np.mean(distances,axis=1),1e-12))
    temperature = cfg['route_temperature']
    if temperature is None:
        temperature = max(float(dispersion), np.sqrt(np.finfo(float).eps))
    detour = cfg['route_detour'] if cfg['route_detour'] is not None else 1 + temperature
    return dict(config=cfg, substitute=dict(**f, selected_value=float(tolerance),
                    override=cfg['substitute_tolerance'] is not None,
                    interpretation='Unusually close first-neighbor distances, not semantic interchangeability; negative lower fences become zero (exact duplicates only).'),
                routes=dict(limit=cfg['route_limit'],detour=float(detour),temperature=float(temperature),
                    method='Median within-neighborhood distance CV; optional explicit cost policy overrides',
                    limitation='A descriptive cost-band policy, not evidence that all routes are meaningful. Enumeration remains bounded.'))
