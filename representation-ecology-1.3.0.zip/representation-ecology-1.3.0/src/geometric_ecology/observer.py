"""Export observer assets; reuse exact source-space terrain lenses at cached anchors."""
from pathlib import Path
from .terrain import local_lens
from .io import dump_json


def export_observer(model, directory, atlas):
    directory = Path(directory)
    anchors = atlas['terrain']['lenses']
    scales = sorted(set(model['manifest']['scales'] + [model['manifest']['signature_k']]))
    lenses = {}
    for k in scales:
        lenses[str(k)] = {
            str(i): (anchors[str(i)] if k == model['manifest']['signature_k'] else
                     local_lens(model['x'], int(i), model['neighbors'][int(i), :k]))
            for i in anchors
        }
    dump_json(directory / 'observer_lenses.json', {'scales': scales, 'lenses': lenses})
    for name in ['observer.html', 'observer.js', 'observer_core.js']:
        (directory / name).write_text(Path(__file__).with_name(name).read_text(), encoding='utf-8')
