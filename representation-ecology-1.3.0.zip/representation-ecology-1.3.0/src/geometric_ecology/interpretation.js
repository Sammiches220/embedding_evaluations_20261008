/* Shared table-based translations in the atlas and its independent reference tab. */
(()=>{
 const data=__INTERPRETATION_DATA__, $=id=>document.getElementById(id);
 const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const mountains=data.tables.find(t=>t.title==='3D mesh: what a mountain means');
 const keys=data.height_keys;
 const flat=data.tables.find(t=>t.title==='Flat atlas: how to read each measurement layer');
 const flatKeys=['hidden_two','covariance_dimensions','density','substitutes','route_count','resampling_loss','compression_loss','variation','fog'];
 function table(t,key){return `<div class="reference-table-wrap"><table class="reference-table"><thead><tr>${t.columns.map(c=>`<th scope="col">${escape(c)}</th>`).join('')}</tr></thead><tbody>${t.rows.map((row,i)=>`<tr ${t===mountains?`data-height="${keys[i]}" class="${keys[i]===key?'selected-height':''}"`:''}>${row.map((c,j)=>j?`<td>${escape(c)}</td>`:`<th scope="row">${escape(c)}</th>`).join('')}</tr>`).join('')}</tbody></table></div>`;}
 const byId=id=>data.tables.find(t=>t.id===id);
 const topics={height:['Height encodings',['height']],flat:['Flat measurements',['flat']],scales:['Scaling and selection',['scales','controls']],geography:['Graph features and routes',['geography','routes']],workflow:['Predictive use and limits',['workflow','applicability']],demos:['Controlled demonstrations',['demos']]};
 const options=Object.entries(topics).map(([id,[label]])=>`<option value="${id}">${label}</option>`).join('');
 function content(topic,key){return (topics[topic]?.[1]||['height']).map(id=>{const t=byId(id);return `<h3>${escape(t.title)}</h3>${table(t,key)}`}).join('');}
 const caveat='Predictive and navigation intuition suggests what to investigate; it is not a guarantee of accuracy, causal meaning or safe interpolation. Check support, fog, raw effect sizes and held-out outcomes.';
 if(document.body.dataset.reference==='true'){
  const select=$('reference-height');select.innerHTML=mountains.rows.map((r,i)=>`<option value="${keys[i]}">${escape(r[0])}</option>`).join('');
  const query=new URLSearchParams(location.search).get('height');select.value=keys.includes(query)?query:keys[0];
  $('reference-sections').innerHTML=data.tables.map(t=>`<section id="${t.id}"><p class="source-label">${escape(t.document)}</p><h2>${escape(t.title)}</h2>${table(t,select.value)}</section>`).join('');
  $('reference-nav').innerHTML=data.tables.map(t=>`<a href="#${t.id}">${escape(t.title)}</a>`).join('');
  $('reference-caveat').textContent=caveat;
  select.onchange=()=>{document.querySelectorAll('[data-height]').forEach(row=>row.classList.toggle('selected-height',row.dataset.height===select.value));history.replaceState(null,'','?height='+select.value+location.hash);};
 }else if(document.body.dataset.lab==='true'){
  const host=$('lab-reference');host.innerHTML='<h2>Interpret this demonstration</h2><label>Reference topic <select id="lab-reference-topic"><option value="follow">Follow demonstration</option>'+options+'</select></label><p id="lab-reference-context"></p><div id="lab-reference-content"></div><a href="atlas_reference.html" target="_blank" rel="noopener">Open the complete application reference ↗</a>';
  function updateLab(){const scene=document.body.dataset.demoCase||'mountain',topic=$('lab-reference-topic').value;const relevant=['plain','mountain'].includes(scene)?'height':scene==='fog'?'flat':'geography';$('lab-reference-context').textContent='Teaching fixture: '+scene+'. These examples explain measured geometry; they do not run a predictive model. Reference-removal experiments here do not change the explorer’s display subset.';if(topic==='follow'){const t=byId(relevant==='height'?'height':relevant==='flat'?'flat':'geography'),labels={cliff:'Cliff',pass:'Pass',maze:'Maze',island:'Island / water',ridge:'Ridge / boundary',fog:'Combined disagreement'},rows=relevant==='height'?[t.rows[0]]:t.rows.filter(row=>scene==='fog'?/disagreement/i.test(row[0]):row[0]===labels[scene]);const demos=byId('demos'),demoRows=demos.rows.filter(row=>row[0].toLowerCase().includes(scene==='mountain'?'mountain':scene));$('lab-reference-content').innerHTML='<h3>'+escape(t.title)+'</h3>'+table({...t,rows},'covariance_dimensions')+'<h3>What this fixture establishes</h3>'+table({...demos,rows:demoRows});}else $('lab-reference-content').innerHTML=content(topic,'covariance_dimensions');}
  $('lab-reference-topic').onchange=updateLab;document.addEventListener('terrain-demo',updateLab);$('lab-reference-topic').value='follow';updateLab();
 }else{
  const panel=document.createElement('section');panel.id='terrain-translation';panel.innerHTML='<h2>Translate this terrain</h2><p id="translation-field"></p><div id="translation-table"></div><p class="small" id="translation-scale"></p><p class="small">'+caveat+'</p><a id="open-atlas-reference" target="_blank" rel="noopener" href="atlas_reference.html">Open all interpretation tables in a separate tab ↗</a>';
  document.querySelector('.inspector').prepend(panel);
  const dock=$('neighborhood-dock');
  if(dock){
   const tabs=document.createElement('div');tabs.className='dock-tabs';tabs.setAttribute('role','tablist');tabs.innerHTML='<button id="dock-neighbors" role="tab" aria-selected="true" aria-controls="dock-neighbor-panel">Neighborhood</button><button id="dock-reference" role="tab" aria-selected="false" aria-controls="dock-reference-panel">Reference</button>';
   dock.prepend(tabs);const neighbor=dock.querySelector('.dock-body');neighbor.id='dock-neighbor-panel';neighbor.setAttribute('role','tabpanel');
   const ref=document.createElement('div');ref.id='dock-reference-panel';ref.className='dock-reference-panel';ref.hidden=true;ref.setAttribute('role','tabpanel');ref.innerHTML='<label>Read about <select id="dock-reference-topic"><option value="current">Current field</option>'+options+'</select></label><a target="_blank" rel="noopener" href="atlas_reference.html">Full reference ↗</a><div id="dock-reference-content"></div>';dock.append(ref);
   function openReference(active){neighbor.hidden=active;ref.hidden=!active;dock.classList.toggle('reference-open',active);$('dock-neighbors').setAttribute('aria-selected',String(!active));$('dock-reference').setAttribute('aria-selected',String(active));dock.classList.remove('collapsed');$('map-shell').classList.remove('dock-collapsed');$('collapse-geometry').textContent='Minimize';$('collapse-geometry').setAttribute('aria-expanded','true');window.terrainUI.drawLens();window.ecology.requestDraw();}
   $('dock-neighbors').onclick=()=>openReference(false);$('dock-reference').onclick=()=>openReference(true);$('dock-reference-topic').onchange=()=>update();const openGeometry=$('open-geometry').onclick;$('open-geometry').onclick=()=>{openGeometry();openReference(false);};
  }
  function update(){const key=$('height-channel').value,isFlat=window.ecology.getMode()==='atlas',field=isFlat?(window.flatAtlas?.getState().color||'hidden_two'):key,source=isFlat?flat:mountains,index=(isFlat?flatKeys:keys).indexOf(field),r=index>=0?source.rows[index]:[field,window.ecology.data?.atlas?.flat?.fields.find(d=>d.key===field)?.description||field,'Measured source geometry','Display slope is not a graph barrier'];if($('dock-reference-content')){const topic=$('dock-reference-topic').value;$('dock-reference-content').innerHTML=topic==='current'?table({columns:source.columns,rows:[r]},key):content(topic,key);}
   $('translation-field').textContent=(isFlat?'Selected flat field: ':'Selected height: ')+r[0];$('translation-table').innerHTML=table({columns:['Terrain / question','Translation'],rows:[[isFlat?'High-value region':'Mountain / high terrain',r[1]],[isFlat?'Low-value region':'Plain / low terrain',r[2]],[isFlat?'Intuitive use':'Predictive / navigation intuition',r[3]]]},key);$('open-atlas-reference').href='atlas_reference.html?height='+encodeURIComponent(key)+'#'+source.id;
   const s=window.atlasScale,reference=s?.mode||'global';$('translation-scale').textContent=`${isFlat?'Color':'Height'} reference: ${reference}. ${reference==='subset'?'High and low regions compare only with the captured subset; small corpus differences can look dramatic.':'Compare raw values with the stated corpus reference.'} Relief exaggeration changes visual height, not geometry or predictive ability.`;
  }
  document.addEventListener('change',e=>{if(['height-channel','display-mode','flat-color'].includes(e.target.id))update();});document.addEventListener('atlas-scale',update);document.addEventListener('atlas-field',update);document.addEventListener('ecology-view',update);update();
 }
 window.atlasInterpretation={tables:data.tables};
})();
