"""Independent measured fields and masked isolines for the flat atlas."""
import time
import contourpy
import numpy as np
from .terrain import sample_fields


def field_definitions():
    """Shared scales across components; levels are values, not plot heights."""
    return [
        dict(key="dimension",name="Distance-growth dimension",unit="dimensions",
             minimum=0,maximum=20,levels=[1,2,4,8,16],palette="dimension",
             description="Growth of source-space neighborhood population with radius; distinct from covariance directions."),
        dict(key='hidden_two',name='Variation hidden by two axes',unit='fraction',
             minimum=0,maximum=1,levels=[.1,.2,.3,.4,.5,.6,.7,.8,.9],palette='dimension',
             description='Fraction of original-neighborhood covariance outside its first two axes. Teal retains most variation; purple hides much more.'),
        dict(key='covariance_dimensions',name='Effective local directions',unit='directions',
             minimum=1,maximum=20,levels=[1.5,2,2.5,3,4,5,6,7,8,10,12,16,20],palette='dimension',
             description='Covariance participation ratio. Contours labelled 2, 4 or 8 enclose those measured direction counts; it is not an integer rank.'),
        dict(key='density',name='Original-space density rank',unit='percentile',
             minimum=0,maximum=1,levels=[.1,.25,.5,.75,.9],palette='density',
             description='Inverse neighbor-radius percentile in the original space. This is independent of how crowded the display looks.'),
        dict(key='substitutes',name='Near-substitute fraction',unit='fraction',
             minimum=0,maximum=1,levels=[.05,.1,.25,.5,.75,.9],palette='density',
             description='Share of signature neighbors within the declared chord tolerance. A dense plain also needs low dimension and redundancy.'),
        dict(key='route_count',name='Regional route alternatives',unit='routes',
             minimum=1,maximum=12,levels=[1.5,2,3,4,6,8,10,11.5],palette='routes',
             description='Median effective count of up to 12 near-shortest regional routes to reference destinations. Bundles identify their actual destination.'),
        dict(key='resampling_loss',name='Reference-subset disagreement',unit='fraction',
             minimum=0,maximum=1,levels=[.1,.25,.5,.75,.9],palette='stability',
             description='One minus conditional neighbor overlap under reference resampling. Missing references are handled by the backend comparison.'),
        dict(key='compression_loss',name='Compression disagreement',unit='fraction',
             minimum=0,maximum=1,levels=[.1,.25,.5,.75,.9],palette='stability',
             description='One minus neighbor overlap under the recorded moderate PCA compression. It can reflect discarded structure or noise.'),
        dict(key='variation',name='Metric-variation rank',unit='percentile',
             minimum=0,maximum=1,levels=[.1,.25,.5,.75,.9],palette='variation',
             description='Percentile of local neighbor-distance coefficient of variation. This is a separate measure from dimension.'),
        dict(key='fog',name='Combined geometry disagreement',unit='fraction',
             minimum=0,maximum=1,levels=[.1,.25,.5,.75,.9],palette='stability',
             description='Maximum reference-subset and moderate-compression disagreement. Hatching can display it independently of the color field.')]


def field_contours(field, key, levels):
    """Trace isolines only inside quads with four supported corner samples."""
    values=np.asarray(field['values'][key],dtype=float)
    valid=np.asarray(field['valid'],dtype=bool)&np.isfinite(values)
    if key in ('hidden_two','covariance_dimensions') and 'covariance_valid' in field['values']:
        valid &= np.asarray(field['values']['covariance_valid'])>.5
    b=field['bounds'];n=field['size']
    generator=contourpy.contour_generator(x=np.linspace(b[0],b[2],n),
        y=np.linspace(b[1],b[3],n),z=np.ma.array(values,mask=~valid),
        name='serial',corner_mask=False,line_type='Separate')
    return [dict(level=float(level),paths=[np.round(path,5).tolist() for path in generator.lines(level)
                                         if len(path)>=2]) for level in levels]


def enrich_flat(model,atlas):
    start=time.perf_counter();xy=np.asarray(atlas['xy']);t=atlas['terrain']
    definitions=field_definitions()
    dimension=next(d for d in definitions if d['key']=='covariance_dimensions')
    from .display import display_fields
    channels=display_fields(model,atlas)
    dimension['maximum']=channels['covariance_dimensions']['global_range'][1]
    for definition in definitions:
        channel=channels[definition['key']]
        definition['minimum'],definition['maximum']=channel['global_range']
        finite=np.asarray(channel['values']);finite=finite[np.isfinite(finite)]
        definition['levels']=np.unique(np.quantile(finite,np.linspace(.1,.9,9))).tolist() if len(finite) else []
    next(d for d in definitions if d['key']=='route_count')['description']='Median effective route count to recorded reference destinations. Counts are bounded by the configured enumeration budget; see route details and cap flags.' 
    dimension['levels']=[v for v in dimension['levels'] if v<=dimension['maximum']]
    # Re-bin the measured point values, rather than subdividing interpolated triangles.
    resolutions=[27,54,108]
    for island in atlas['islands']:
        inds=np.flatnonzero(model['component']==island['component'])
        values={key:np.asarray(channel['values'],dtype=float)[inds]
                for key,channel in channels.items()}
        values['covariance_valid']=np.asarray(atlas['mesh']['valid'],dtype=float)[inds]
        island['field_levels']={}
        for grid in resolutions:
            field=sample_fields(xy[inds],values,model['region'][inds],grid=grid)
            field['isolines']={d['key']:field_contours(field,d['key'],d['levels'])
                              for d in definitions}
            island['field_levels'][str(grid)]=field
        island['field']=island['field_levels']['54']
    return dict(schema_version=2,resolutions=resolutions,default_resolution=54,fields=definitions,elapsed_s=time.perf_counter()-start,
        note='Color and contour channels are independent. All positions remain strictly 2D; masked fields and contours never join disconnected component charts.')
