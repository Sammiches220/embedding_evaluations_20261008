"""Raw, corpus-aligned channels and explicit display-only reference ranges."""
import numpy as np
from .core import percentile


def display_fields(model, atlas):
    t, m = atlas['terrain'], atlas['mesh']
    values = dict(hidden_two=m['hidden_two'], covariance_dimensions=m['covariance_dimensions'],
                  dimension=model['profiles']['local_dimension'], density=atlas['density_percentile'],
                  substitutes=t['substitute_fraction'], route_count=t['route_count'],
                  resampling_loss=t['resampling_loss'], compression_loss=t['compression_loss'],
                  variation=percentile(t['metric_variation']), fog=t['fog'])
    result={}
    for key, raw in values.items():
        raw=np.asarray(raw,float).copy()
        if key in ('hidden_two','covariance_dimensions'):
            raw[~np.asarray(m['valid'],bool)]=np.nan
        finite=raw[np.isfinite(raw)]
        observed=[float(finite.min()),float(finite.max())] if len(finite) else [0.,0.]
        semantic=([1.,float(t['route_ambiguity']['limit'])] if key=='route_count' else
                  [0.,1.] if key not in ('covariance_dimensions','dimension') else observed)
        result[key]=dict(values=raw,observed=observed,global_range=semantic,
                         robust_range=np.quantile(finite,[.05,.95]).tolist() if len(finite) else observed,
                         finite_count=len(finite), robust_policy='5–95% display quantiles; not inference thresholds')
    return result
