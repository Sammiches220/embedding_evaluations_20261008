"""Corpus-relative geometry. Public functions use arrays and dictionaries."""
from .core import build_map, score_queries, normalize, route
__version__ = "0.6.2"
__all__ = ["build_map", "score_queries", "normalize", "route"]
