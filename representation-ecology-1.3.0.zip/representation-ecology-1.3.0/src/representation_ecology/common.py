"""Portable artifact helpers and strict run configuration."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from geometric_ecology.io import clean

DEFAULTS = dict(scales=[6,12,24], support=.5, resamples=3, landmarks=24,
    regions=8, seed=42, max_rows=5000, max_features=200, max_pairs=20000,
    min_pair_features=1, feature_families={}, folds=4, min_known=12,
    min_local=5, min_stability=.5, residual_margin=.1,
    pair_models=['ridge','forest'], probe_models=['baseline','linear'],
    validation=True, nulls=True, max_payload_bytes=80000000,
    topology=False, tangent=True, accessibility={}, max_distance_work=50_000_000_000, max_output_bytes=4_000_000_000)

def configuration(path=None):
    supplied={} if path is None else json.loads(Path(path).read_text())
    unknown=set(supplied)-set(DEFAULTS)
    if unknown: raise ValueError(f'Unknown combined options: {sorted(unknown)}')
    cfg={**DEFAULTS,**supplied}
    for key,minimum in [('resamples',2),('landmarks',1),('regions',1),('max_rows',12),('max_features',1),('max_pairs',20),('min_pair_features',1),('folds',2),('min_known',8),('min_local',2),('max_payload_bytes',1000)]:
        if type(cfg[key]) is not int or cfg[key]<minimum: raise ValueError(f'{key} must be integer >= {minimum}')
    if not isinstance(cfg['scales'],list) or not cfg['scales'] or any(type(k) is not int or k<4 for k in cfg['scales']): raise ValueError('scales must be nonempty integers >=4')
    from .accessibility import options
    cfg['accessibility']=options(cfg['accessibility'])
    for key in ['max_distance_work','max_output_bytes']:
        if type(cfg[key]) is not int or cfg[key]<1: raise ValueError(key+' must be positive integer')
    cfg['scales']=sorted(set(cfg['scales']))
    for key in ['support','min_stability','residual_margin']:
        if not isinstance(cfg[key],(float,int)) or not 0<=cfg[key]<=1: raise ValueError(f'{key} must be in [0,1]')
    if not cfg['support']: raise ValueError('support must be positive')
    if not isinstance(cfg['pair_models'],list) or not cfg['pair_models'] or set(cfg['pair_models'])-{'ridge','forest'}: raise ValueError('pair_models: choose ridge and/or forest')
    if type(cfg['seed']) is not int: raise ValueError('seed must be integer')
    for key in ['validation','nulls','topology','tangent']:
        if type(cfg[key]) is not bool: raise ValueError(f'{key} must be boolean')
    if not isinstance(cfg['feature_families'],dict) or any(not isinstance(v,(int,float)) or v<=0 or not np.isfinite(v) for v in cfg['feature_families'].values()): raise ValueError('feature_families maps family names to positive weights')
    return cfg

def digest(value):
    if isinstance(value,np.ndarray): value=np.ascontiguousarray(value).tobytes()
    elif not isinstance(value,bytes): value=json.dumps(clean(value),sort_keys=True,ensure_ascii=False).encode()
    return hashlib.sha256(value).hexdigest()

def dump(path,value):
    Path(path).write_text(json.dumps(clean(value),ensure_ascii=False,allow_nan=False,indent=2),encoding='utf8')

def table(path,rows,columns=None):
    frame=rows if isinstance(rows,pd.DataFrame) else pd.DataFrame(rows,columns=columns)
    if not len(frame.columns): frame=pd.DataFrame({'status':pd.Series(dtype=str)})
    frame.to_parquet(path,index=False)
    return frame


def file_digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(8*1024**2),b''):h.update(chunk)
    return h.hexdigest()
