"""Guided observer workspace and a preserved expert interface over frozen evidence."""
import json
import re
from pathlib import Path
from importlib.resources import files
from hashlib import sha256
from geometric_ecology.io import clean

VIEWER_VERSION='1.3.0'

def export_viewer(out,payload,max_bytes):
    out=Path(out)
    report=out/'audit/report.html'
    if report.exists():
        def available(match):
            reference=match.group(1)
            if reference.startswith(('http:','https:','data:','#')) or (report.parent/reference).is_file(): return match.group(0)
            label=re.sub('<[^>]+>','',match.group(2))
            return '<span title="Analysis disabled or unsupported; file was not generated">'+label+' · unavailable</span>'
        report.write_text(re.sub(r'<a\s+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',available,report.read_text(),flags=re.DOTALL),encoding='utf8')
    assets=files('representation_ecology').joinpath('assets')
    payload=dict(payload,viewer_version=VIEWER_VERSION)
    raw=json.dumps(clean(payload),ensure_ascii=False,allow_nan=False,separators=(',',':'))
    if len(raw.encode())>max_bytes: raise ValueError('Combined browser payload exceeds max_payload_bytes; reduce cohort/features or explicitly raise limit')
    encoded=raw.replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    for template_name,css_name,js_name,destination in [('index.html','style.css','app.js','index.html'),('expert.html','expert.css','expert.js','expert.html')]:
        template=assets.joinpath(template_name).read_text()
        template=template.replace('__CSS__',assets.joinpath(css_name).read_text()).replace('__JS__',assets.joinpath(js_name).read_text()).replace('__SCALES__',assets.joinpath('scales.js').read_text()).replace('__CORE__',assets.joinpath('guide_core.js').read_text()).replace('__LANDSCAPE__',assets.joinpath('landscape.js').read_text()).replace('__GEOMETRY_GUIDE__',assets.joinpath('geometry_guide.js').read_text()).replace('__DATA__',encoded)
        (out/destination).write_text(template,encoding='utf8')
    (out/'viewer_payload.json').write_text(raw,encoding='utf8')
    (out/'viewer_manifest.json').write_text(json.dumps({'viewer_version':VIEWER_VERSION,
        'analysis_run_id':payload['run_id'],
        'analysis_vector_sha256':payload['manifest']['vector_sha256'],
        'assets_sha256':{name:sha256(assets.joinpath(name).read_bytes()).hexdigest() for name in ['index.html','app.js','style.css','guide_core.js','expert.html','expert.js','expert.css','landscape.js','geometry_guide.js','scales.js']},
        'policy':'Generated with the current analysis build; no migration or existing-run update path.'},indent=2),encoding='utf8')
