"""Combined project CLI; existing tools remain available independently."""
import argparse
import functools
import http.server
import json
from pathlib import Path
import sys
import webbrowser
from .workflow import run
from .demo import create_demo,SCENARIOS
from .investigation import compare_runs,save_investigation,interventions


def main(argv=None):
    p=argparse.ArgumentParser(description='Geometry, source features and their measured disagreements')
    sub=p.add_subparsers(dest='command',required=True)
    c=sub.add_parser('population-run');c.add_argument('--vectors',required=True);c.add_argument('--targets',required=True);c.add_argument('--out',required=True);c.add_argument('--features',nargs='+',required=True);c.add_argument('--groups');c.add_argument('--ids');c.add_argument('--display-rows',type=int,default=240);c.add_argument('--batch-rows',type=int,default=4096);c.add_argument('--seed',type=int,default=42);c.add_argument('--max-output-bytes',type=int,default=4000000000);c.add_argument('--plan-only',action='store_true')
    c=sub.add_parser('plan');c.add_argument('--schema',required=True);c.add_argument('--config',required=True);c.add_argument('--combined-config')
    c=sub.add_parser('offline-demo');c.add_argument('--out',required=True);c.add_argument('--n',type=int,default=100000);c.add_argument('--dimension',type=int,default=32);c.add_argument('--display-rows',type=int,default=240);c.add_argument('--batch-rows',type=int,default=4096);c.add_argument('--seed',type=int,default=42);c.add_argument('--max-output-bytes',type=int,default=4000000000);c.add_argument('--plan-only',action='store_true')
    c=sub.add_parser('run');c.add_argument('--schema',required=True);c.add_argument('--config',required=True);c.add_argument('--combined-config');c.add_argument('--out',required=True)
    c=sub.add_parser('demo');c.add_argument('--out',required=True);c.add_argument('--n',type=int,default=240);c.add_argument('--seed',type=int,default=42);c.add_argument('--scenario',choices=SCENARIOS,default='visual');c.add_argument('--inputs-only',action='store_true')
    c=sub.add_parser('serve');c.add_argument('--run',required=True);c.add_argument('--port',type=int,default=8765);c.add_argument('--open',action='store_true')
    c=sub.add_parser('compare');c.add_argument('--a',required=True);c.add_argument('--b',required=True);c.add_argument('--out',required=True)
    c=sub.add_parser('record');c.add_argument('--run',required=True);c.add_argument('--selection',required=True);c.add_argument('--note',required=True);c.add_argument('--candidate',action='append',default=[])
    c=sub.add_parser('interventions');c.add_argument('--run',required=True);c.add_argument('--records',required=True);c.add_argument('--vectors',required=True);c.add_argument('--encoder',required=True);c.add_argument('--out',required=True)
    args=p.parse_args(argv)
    try:
        if args.command=='population-run':
            from .offline import population_run
            print(json.dumps(population_run(args.vectors,args.targets,args.out,args.features,args.groups,args.ids,args.display_rows,args.batch_rows,args.seed,args.max_output_bytes,args.plan_only),indent=2))
        elif args.command=='plan':
            from .resources import bundle_plan
            from .common import configuration
            print(json.dumps(bundle_plan(args.schema,args.config,configuration(args.combined_config)),indent=2))
        elif args.command=='offline-demo':
            from .offline import offline_demo
            print(json.dumps(offline_demo(args.out,args.n,args.dimension,args.display_rows,args.batch_rows,args.seed,args.max_output_bytes,args.plan_only),indent=2))
        elif args.command=='run': run(args.schema,args.config,args.out,args.combined_config)
        elif args.command=='demo':
            root=Path(args.out).resolve()
            if root.exists() and any(root.iterdir()): raise ValueError('Demo output must be empty')
            source=create_demo(root/'inputs',args.n,args.seed,args.scenario)
            if not args.inputs_only: run(source/'schema.json',source/'audit_config.json',root/'run',source/'combined_config.json')
            else: print(source)
        elif args.command=='serve':
            directory=Path(args.run).resolve()
            if not (directory/'index.html').is_file(): raise ValueError('Run has no index.html')
            with http.server.ThreadingHTTPServer(('127.0.0.1',args.port),functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(directory))) as server:
                url=f'http://127.0.0.1:{server.server_port}/index.html';print(url,flush=True)
                if args.open:webbrowser.open(url)
                try:server.serve_forever()
                except KeyboardInterrupt:pass
        elif args.command=='compare': print(json.dumps(compare_runs(args.a,args.b,args.out),indent=2))
        elif args.command=='record': print(json.dumps(save_investigation(args.run,args.selection,args.note,args.candidate),indent=2))
        elif args.command=='interventions': print(json.dumps(interventions(args.run,args.records,args.vectors,args.out,args.encoder),indent=2))
    except (ValueError,FileNotFoundError,KeyError,json.JSONDecodeError) as exc:
        p.exit(2,f'Error: {exc}\n')

if __name__=='__main__':main()
