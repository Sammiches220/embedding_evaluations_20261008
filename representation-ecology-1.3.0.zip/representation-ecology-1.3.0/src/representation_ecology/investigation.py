"""Immutable investigation outputs and strictly comparable run comparisons."""
import json
import uuid
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import pandas as pd
from geometric_ecology.core import normalize,score_queries
from geometric_ecology.io import load_model
from .common import dump,digest,table


def compare_runs(a,b,out):
    a,b,out=Path(a),Path(b),Path(out)
    ma=json.loads((a/'manifest.json').read_text());mb=json.loads((b/'manifest.json').read_text())
    comparable=all(ma.get(k)==mb.get(k) for k in ['ids_sha256','vector_sha256','graph_sha256','metric'])
    ea=pd.read_parquet(a/'bridge/edge_explanations.parquet');eb=pd.read_parquet(b/'bridge/edge_explanations.parquet')
    out.mkdir(parents=True,exist_ok=True)
    if any(out.iterdir()): raise ValueError('Comparison output must be empty')
    summary=dict(run_a=ma['run_id'],run_b=mb['run_id'],same_geometry=comparable,
        same_feature_schema=ma['feature_schema_sha256']==mb['feature_schema_sha256'],
        same_evaluation_policy=ma.get('evaluation_sha256')==mb.get('evaluation_sha256') and all(ma['config'].get(k)==mb['config'].get(k) for k in ['seed','folds','max_pairs']),
        claim='Vocabulary progress only when frozen geometry and evaluation policy match; otherwise descriptive run comparison')
    rows=pd.DataFrame()
    if comparable and all(c in ea and c in eb for c in ['i','j','fold','model','absolute_residual']):
        rows=ea.merge(eb,on=['i','j','fold','model'],suffixes=('_a','_b'))
        rows['absolute_error_delta']=rows.absolute_residual_b-rows.absolute_residual_a
        summary['matched_relations']=len(rows)
        summary['mean_absolute_error_delta']=float(rows.absolute_error_delta.mean()) if len(rows) else None
    table(out/'matched_relations.parquet',rows);dump(out/'comparison.json',summary)
    return summary


def save_investigation(run,selection,note,candidates=None):
    run=Path(run);manifest=json.loads((run/'manifest.json').read_text());model=load_model(run/'geometry')
    ids=json.loads(Path(selection).read_text())
    if not isinstance(ids,list) or len(ids)!=len(set(ids)) or any(not isinstance(i,str) or i not in set(model['ids']) for i in ids): raise ValueError('Selection must be a unique JSON array of canonical corpus IDs')
    history_path=run/'investigations/history.json';history=json.loads(history_path.read_text())
    record=dict(id=uuid.uuid4().hex,at=datetime.now(timezone.utc).isoformat(),run_id=manifest['run_id'],
        item_ids=ids,note=note,candidate_features=candidates or [],geometry_sha256=manifest['vector_sha256'],feature_sha256=manifest['feature_sha256'])
    history.append(record)
    temp=history_path.with_suffix('.tmp');dump(temp,history);temp.replace(history_path)
    return record


def interventions(run,records_path,vectors_path,out,encoder):
    run,out=Path(run),Path(out);model=load_model(run/'geometry')
    if encoder!=model['manifest']['encoder']: raise ValueError('Encoder identifier does not match frozen atlas')
    records=pd.read_parquet(records_path) if str(records_path).endswith('.parquet') else pd.read_csv(records_path)
    required={'source_id','transformed_id','transform','parameters','collateral_changes'}
    if required-set(records): raise ValueError(f'Intervention table requires {sorted(required)}')
    if records[list(required)].isna().any().any(): raise ValueError('Intervention metadata must be nonmissing')
    if records.transformed_id.astype(str).duplicated().any(): raise ValueError('Transformed IDs must be unique')
    z=normalize(np.load(vectors_path,allow_pickle=False));lookup={v:i for i,v in enumerate(model['ids'])}
    if len(z)!=len(records) or z.shape[1]!=model['x'].shape[1]: raise ValueError('Transformed vector shape does not match table/encoder')
    if set(records.source_id.astype(str))-set(lookup): raise ValueError('Unknown intervention source IDs')
    if out.exists() and any(out.iterdir()): raise ValueError('Intervention output must be empty')
    out.mkdir(parents=True,exist_ok=True)
    k=model['manifest']['signature_k'];rows=[];deltas=[]
    for q,row in enumerate(records.to_dict('records')):
        i=lookup[str(row['source_id'])];d=np.linalg.norm(model['x']-z[q],axis=1);order=np.lexsort((np.arange(len(d)),d));nn=[int(j) for j in order if j!=i][:k]
        original=set(map(int,model['neighbors'][i,:k]));delta=z[q]-model['x'][i];deltas.append(delta)
        rows.append({**row,'source_row':i,'displacement_chord':float(np.linalg.norm(delta)),
            'neighbor_retention':len(original&set(nn))/k,'nearest_anchor':model['ids'][int(order[0])],
            'nearest_anchor_component':int(model['component'][order[0]]),
            'anchor_component_changed':bool(model['component'][i]!=model['component'][order[0]]),
            'component_claim':'Attachment proxy; no new transformed component inferred',
            'neighbors':[model['ids'][j] for j in nn]})
    table(out/'responses.parquet',rows);dump(out/'frozen_attachments.json',score_queries(model,z))
    np.save(out/'unit_deltas.npy',np.array(deltas));summary=[]
    d=np.array(deltas);norm=np.linalg.norm(d,axis=1);directions=np.divide(d,norm[:,None],out=np.zeros_like(d),where=norm[:,None]>1e-12)
    for name,group in records.groupby('transform',sort=False):
        indices=group.index.to_numpy();valid=norm[indices]>1e-12
        summary.append(dict(transform=name,n=len(indices),nonzero=int(valid.sum()),
            mean_displacement=float(norm[indices].mean()),directional_consistency=float(np.linalg.norm(directions[indices][valid].mean(0))) if valid.any() else None,
            interpretation='Repeated measured responses; does not isolate collateral changes or establish causality'))
    dump(out/'summary.json',summary);dump(out/'manifest.json',dict(encoder=encoder,records_sha256=digest(Path(records_path).read_bytes()),vectors_sha256=digest(z),corpus_sha256=model['manifest']['corpus_sha256']))
    return summary
