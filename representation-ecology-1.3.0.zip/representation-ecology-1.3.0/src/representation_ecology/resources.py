"""Conservative arithmetic preflight, not a wall-time forecast."""
import numpy as np
from .common import dump

def estimate(n,d,features=3,dimensions=4,folds=3,mode='bounded',display_rows=240):
    if min(n,d)<1:raise ValueError('Resource estimate requires positive sizes')
    return dict(mode=mode,rows=int(n),embedding_dimensions=int(d),numeric_targets=int(features),
        vector_bytes=int(n*d*4),dense_distance_bytes=int(n*n*4),
        working_array_estimate_bytes=int(n*64+4096*d*32+2048*d*32+d*d*16),
        exact_distance_coordinate_work=int(n*n*d*10) if mode=='bounded' else 0,
        decoder_coordinate_work=int(n*d*8*folds),
        prediction_records=int(n*features*dimensions),prediction_uncompressed_bytes=int(n*features*dimensions*96),
        display_rows=int(display_rows),
        note='Arithmetic/storage estimates; excludes libraries, model fitting, indexes and temporary copies. No hardware runtime promise.')

def enforce(plan,max_work=50_000_000_000,max_output_bytes=4_000_000_000):
    if plan['working_array_estimate_bytes']>2_000_000_000:raise ValueError('Estimated working arrays exceed the 2 GB guard; reduce dimensions or cohort size. This is a conservative bound, not a measured RSS ceiling.')
    if plan['exact_distance_coordinate_work']>max_work:raise ValueError('Exact cohort work exceeds resource budget; reduce evaluation sample or use offline-demo batched mode')
    if plan['prediction_uncompressed_bytes']>max_output_bytes:raise ValueError('Prediction output estimate exceeds resource budget; reduce rows/targets/dimensions or explicitly raise max_output_bytes')

def bundle_plan(schema_path,config_path,cfg,out=None):
    from parquet_audit.config import validate_bundle
    # The audit validator checks source metadata/alignment, not all-pairs geometry.
    data=validate_bundle(schema_path,config_path)
    n=min(data['n_rows'],data['config']['sample']['max_rows'])
    dims=[]
    for asset in data['schema']['embeddings']:
        if asset.get('matrix_path'): dims.append(np.load(asset['matrix_path'],mmap_mode='r',allow_pickle=False).shape[1])
        else: dims.append(asset['expected_dimension'])
    d=max(dims)
    from parquet_audit.semantics import KINDS
    plan=estimate(n,d,sum(s['role']=='feature' and KINDS.get(s.get('kind'))=='continuous' for s in data['schema']['columns'].values()),len(cfg['accessibility']['dimensions']),cfg['accessibility']['folds'],display_rows=n)
    plan['exact_distance_coordinate_work']*=len(dims)
    plan['embedding_views']=len(dims)
    if out:dump(out,plan)
    enforce(plan,cfg['max_distance_work'],cfg['max_output_bytes'])
    return plan
