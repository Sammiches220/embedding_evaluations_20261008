"""Out-of-sample relational models, probe maps and explicitly qualified profiles."""
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.decomposition import PCA
from sklearn.metrics import mean_absolute_error
from embedding_feature_audit.modeling import run_probes
from embedding_feature_audit.dataframe import encode_feature
from parquet_audit.semantics import KINDS, computation_spec
from .features import FeatureSpace, item_folds


def sample_pairs(neighbors,retained,max_pairs,seed):
    """Bounded mixture; results are conditional on this deliberately enriched design."""
    rng=np.random.default_rng(seed);n=len(neighbors);classes={}
    retained_set={tuple(sorted(map(int,e))) for e in retained}
    directed={tuple(sorted((i,int(j)))) for i,row in enumerate(neighbors) for j in row}
    ordered=sorted(directed|retained_set)
    budget=max_pairs//2
    if len(ordered)>budget: ordered=[ordered[i] for i in sorted(rng.choice(len(ordered),budget,replace=False))]
    for p in ordered: classes[p]='retained_edge' if p in retained_set else 'near_pair'
    attempts=0
    while len(classes)<min(max_pairs,n*(n-1)//2) and attempts<max_pairs*20:
        a,b=sorted(map(int,rng.choice(n,2,replace=False)));attempts+=1
        classes.setdefault((a,b),'reference_pair')
    pairs=np.array(sorted(classes),int).reshape(-1,2)
    return pairs,[classes[tuple(p)] for p in pairs]


def relational_models(frame,specs,z,neighbors,retained,cfg,groups=None,split=None):
    pairs,kinds=sample_pairs(neighbors,retained,cfg['max_pairs'],cfg['seed'])
    target=np.linalg.norm(z[pairs[:,0]]-z[pairs[:,1]],axis=1)
    folds=item_folds(len(frame),groups,cfg['folds'],cfg['seed'],split)
    records=[];scores=[];fold_records=[];statuses=[]
    if not folds: statuses.append(dict(status='insufficient_evidence',reason='Fewer than two independent groups'))
    for fold,(train,test) in enumerate(folds):
        membership=np.full(len(frame),'unused',object);membership[train]='train';membership[test]='test'
        fold_records.extend(dict(row=i,fold=fold,partition=str(v)) for i,v in enumerate(membership))
        space=FeatureSpace(frame,specs,train,cfg['feature_families'],cfg['min_pair_features'])
        if not space.names:
            statuses.append(dict(fold=fold,status='insufficient_evidence',reason='No variable supported explanatory features on training items'));continue
        x=space.pair_features(pairs);counts=np.isfinite(x).sum(1)
        good=counts>=cfg['min_pair_features']
        trainmask=np.isin(pairs[:,0],train)&np.isin(pairs[:,1],train)&good
        testmask=np.isin(pairs[:,0],test)&np.isin(pairs[:,1],test)&good
        if trainmask.sum()<max(8,len(space.names)+2) or testmask.sum()<2:
            statuses.append(dict(fold=fold,status='insufficient_evidence',reason='Too few endpoint-disjoint supported pairs',n_train_pairs=int(trainmask.sum()),n_test_pairs=int(testmask.sum())));continue
        baseline=float(target[trainmask].mean());y=target[testmask];base_error=np.abs(y-baseline)
        for name in cfg['pair_models']:
            estimator=Ridge(alpha=10.) if name=='ridge' else RandomForestRegressor(n_estimators=64,max_depth=6,min_samples_leaf=4,n_jobs=1,random_state=cfg['seed']+fold)
            model=make_pipeline(SimpleImputer(strategy='constant',fill_value=0,add_indicator=True),StandardScaler(),estimator)
            model.fit(x[trainmask],target[trainmask]);pred=model.predict(x[testmask]);res=y-pred
            scores.append(dict(fold=fold,model=name,n_train_pairs=int(trainmask.sum()),n_test_pairs=int(testmask.sum()),
                baseline_mae=float(base_error.mean()),mae=float(np.abs(res).mean()),
                gain=float(base_error.mean()-np.abs(res).mean()),feature_names=space.names,
                scope='Held-out endpoints; enriched pair sampling; training-only scaling'))
            for idx,p,actual,estimate,r,bc in zip(np.flatnonzero(testmask),pairs[testmask],y,pred,res,base_error):
                records.append(dict(i=int(p[0]),j=int(p[1]),fold=fold,model=name,pair_class=kinds[idx],actual=float(actual),predicted=float(estimate),residual=float(r),absolute_residual=float(abs(r)),baseline_error=float(bc),comparable_features=int(counts[idx]),feature_mask='|'.join(np.array(space.names)[np.isfinite(x[idx])]),status='held_out'))
    return records,scores,fold_records,statuses


def crossfit_probes(frame,specs,z,cfg,groups=None,split=None):
    records=[];scores=[];statuses=[]
    for name,spec in specs.items():
        kind=KINDS[spec['kind']]
        if kind is None or not spec.get('probe',True): continue
        y,known,labels=encode_feature(frame[name],computation_spec(spec))
        if known.sum()<cfg['min_known']:
            statuses.append(dict(feature=name,status='insufficient_evidence',reason='Too few known rows'));continue
        folds=item_folds(len(frame),groups,cfg['folds'],cfg['seed'],split)
        if not folds:
            statuses.append(dict(feature=name,status='insufficient_evidence',reason='Fewer than two independent groups'))
        for fold,(train,test) in enumerate(folds):
            assignment=np.full(len(frame),'unused',object);assignment[train]='train';assignment[test]='test'
            try:
                aggregate,_,pred,_,_=run_probes(z,y,known,labels,kind,cfg['seed']+fold,groups,assignment,models=cfg['probe_models'])
            except ValueError as exc:
                statuses.append(dict(feature=name,fold=fold,status='insufficient_evidence',reason=str(exc)));continue
            scores.extend(dict(feature=name,fold=fold,**row) for row in aggregate.to_dict('records'))
            for row in pred.to_dict('records'):
                loss=abs(float(row['true'])-float(row['predicted'])) if kind=='continuous' else float(row['true']!=row['predicted'])
                records.append(dict(feature=name,fold=fold,row=int(row['row_position']),model=row['model'],label=row.get('label'),true=row['true'],predicted=row['predicted'],loss=loss,probabilities=row.get('probabilities'),status='held_out'))
    return records,scores,statuses


def tangent_fields(frame,specs,model,cfg,groups=None):
    rows=[];z=model['x'];k=model['manifest']['signature_k']
    for name,spec in specs.items():
        if KINDS[spec['kind']]!='continuous' or not spec.get('probe',True): continue
        y,known,_=encode_feature(frame[name],computation_spec(spec))
        for i in range(len(z)):
            ns=model['neighbors'][i,:k];ns=ns[known[ns]]
            if groups is not None: ns=ns[groups[ns]!=groups[i]]
            if not known[i] or len(ns)<max(8,cfg['min_local']): continue
            center=z[ns].mean(0);a=z[ns]-center
            pca=PCA(n_components=min(3,len(ns)-2,z.shape[1])).fit(a)
            xx=pca.transform(a);reg=Ridge(alpha=1.).fit(xx,y[ns])
            pred=float(reg.predict(pca.transform((z[i]-center)[None]))[0]);baseline=float(y[ns].mean())
            direction=reg.coef_@pca.components_
            projected=model['display_axes']@direction
            rows.append(dict(row=i,feature=name,n_train=len(ns),predicted=pred,true=float(y[i]),
                loss=abs(pred-y[i]),baseline_loss=abs(baseline-y[i]),
                direction=direction.tolist(),raw_pca_direction=projected.tolist(),
                explained_local_variance=float(pca.explained_variance_ratio_.sum()),
                scope='Center/group excluded; descriptive local fit, not a global semantic vector'))
    return rows


def evidence_profiles(model,neighborhoods,edges,cfg):
    k=model['manifest']['signature_k'];n=len(model['ids']);fields={};rows=[]
    by={r['row']:r for r in neighborhoods if r['k']==k}
    indexed={}
    for edge in edges:
        for endpoint in (edge['i'],edge['j']): indexed.setdefault((edge['model'],endpoint),[]).append(edge)
    models=cfg['pair_models']
    for name in models:
        for field in ['mean_signed','mean_absolute','relative_gain','pair_support']:
            fields[f'{name} · {field}']=np.full(n,np.nan)
        for i in range(n):
            local=indexed.get((name,i),[])
            stable=float(model['profiles']['perturbation_jaccard'][i]);resampling=float(model['profiles']['resample_jaccard'][i])
            neighbor=by.get(i,{});statuses=[]
            if len(local)<cfg['min_local'] or neighbor.get('status')!='ok': statuses.append('insufficient_evidence')
            if stable<cfg['min_stability']: statuses.append('instability')
            if local:
                signed=float(np.mean([r['residual'] for r in local]));absolute=float(np.mean([r['absolute_residual'] for r in local]));base=float(np.mean([r['baseline_error'] for r in local]));gain=1-absolute/base if base>1e-12 else np.nan
                if not statuses:
                    # Operational candidate flags only; tie upper/lower bounds protect interpretation.
                    if signed>cfg['residual_margin'] and neighbor.get('overlap_high',1)<.5: statuses.append('excess_candidate')
                    if signed < -cfg['residual_margin']: statuses.append('suppression_candidate')
                    if gain>0 and neighbor.get('overlap_low',0)>=.5: statuses.append('agreement_evidence')
                    if not statuses: statuses.append('unresolved_model_discrepancy')
                for key,v in [('mean_signed',signed),('mean_absolute',absolute),('relative_gain',gain),('pair_support',len(local))]:fields[f'{name} · {key}'][i]=v
            else: signed=absolute=gain=np.nan
            rows.append(dict(row=i,model=name,statuses=statuses,perturbation_overlap=stable,
                resampling_overlap=resampling,rank_support=float(model['profiles']['scale_support'][i]),
                pair_support=len(local),mean_signed=signed,mean_absolute=absolute,relative_gain=gain,
                overlap_low=neighbor.get('overlap_low'),overlap_high=neighbor.get('overlap_high'),
                qualification='Operational exploratory profile; not a semantic or causal finding'))
    return rows,fields
