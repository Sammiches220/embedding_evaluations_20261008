"""Offline population demo: streaming generation/evaluation + bounded full atlas.

No network or ANN dependency. The population pass never computes all-pairs
neighbors or topology. Detailed geometry remains on the declared display sample.
"""
from pathlib import Path
from importlib.resources import files
import json,time
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from .common import dump
from .accessibility import analyze,options,unit
from .resources import estimate,enforce

TARGETS=['global_signal','context_signal','noise_signal']

class PredictionWriter:
    def __init__(self,path):self.path=path;self.writer=None
    def __call__(self,columns):
        table=pa.table(columns)
        if self.writer is None:self.writer=pq.ParquetWriter(self.path,table.schema,compression='zstd')
        self.writer.write_table(table)
    def close(self):
        if self.writer:self.writer.close()

def offline_demo(out,n=100_000,dimension=32,display_rows=240,batch_rows=4096,seed=42,max_output_bytes=4_000_000_000,plan_only=False):
    if n<160 or dimension<8 or display_rows<80 or display_rows>512 or display_rows>n or batch_rows<64:raise ValueError('Need n>=160, dimension>=8, display_rows=80..512 <=n, batch_rows>=64')
    c=options(dict(batch_rows=batch_rows,regions=4,train_cap=2048))
    plan=estimate(n,dimension,len(TARGETS),len(c['dimensions']),c['folds'],mode='streamed',display_rows=display_rows)
    # Includes simultaneously resident mmap views, batch temporaries, and bounded
    # fits approximately; OS file cache/library allocations are additional.
    plan['bounded_batch_array_estimate_bytes']=int(batch_rows*dimension*4*8+c['train_cap']*dimension*8*4+n*32)
    plan['scope']='Full population: synthetic numeric reconstruction. Geometry/filtration: bounded display sample only.'
    plan['working_array_estimate_bytes']+=max(0,batch_rows-4096)*dimension*32
    enforce(plan,max_output_bytes=max_output_bytes)
    if plan_only:return plan
    root=Path(out).resolve()
    if root.exists() and any(root.iterdir()):raise ValueError('Offline demo output must be new/empty')
    root.mkdir(parents=True,exist_ok=True);dump(root/'resource_plan.json',plan);dump(root/'status.json',{'status':'running'})
    started=time.perf_counter();rng=np.random.default_rng(seed)
    try:
        x=np.lib.format.open_memmap(root/'population_vectors.npy',mode='w+',dtype='float32',shape=(n,dimension))
        y=np.lib.format.open_memmap(root/'population_targets.npy',mode='w+',dtype='float32',shape=(n,3))
        writer=None;sums=np.zeros(3);squares=np.zeros(3)
        try:
            for start in range(0,n,batch_rows):
                end=min(n,start+batch_rows);z=rng.normal(0,.12,(end-start,dimension)).astype('float32')
                z[:,0:2]=rng.normal(size=(end-start,2));context=rng.choice([-1.,1.],end-start);z[:,2]=context*2;z[:,3]=4
                z=unit(z);t=np.column_stack([3*z[:,0]+.015*rng.normal(size=end-start),context*4*z[:,1]+.015*rng.normal(size=end-start),rng.normal(size=end-start)]).astype('float32')
                x[start:end]=z;y[start:end]=t;sums+=t.sum(0);squares+=(t*t).sum(0)
                data={'item_id':[f'population-{i:09d}' for i in range(start,end)],'family':np.arange(start,end)//3,**{name:t[:,j] for j,name in enumerate(TARGETS)}}
                table=pa.table(data)
                if writer is None:writer=pq.ParquetWriter(root/'population_source.parquet',table.schema,compression='zstd')
                writer.write_table(table)
        finally:
            if writer:writer.close()
        x.flush();y.flush();dump(root/'population_summary.json',dict(rows=n,means=dict(zip(TARGETS,(sums/n).tolist())),standard_deviations=dict(zip(TARGETS,np.sqrt(np.maximum(0,squares/n-(sums/n)**2)).tolist()))))
        selected=np.sort(np.random.default_rng(seed+1).choice(n,display_rows,replace=False))
        sink=PredictionWriter(root/'held_out_predictions.parquet')
        print(f'Generated {n:,} rows; evaluating batched broad/local accounts. Detailed atlas limited to {display_rows} rows.',flush=True)
        try:access=analyze(x,{name:y[:,j] for j,name in enumerate(TARGETS)},np.arange(n,dtype=np.int64)//3,c,seed,selected,sink)
        finally:sink.close()
        access['coverage']['geometry_rows']=display_rows;access['coverage']['population_resource_plan']='../resource_plan.json';access['coverage']['population_artifact']='../population_source.parquet'
        dump(root/'accessibility_summary.json',{k:v for k,v in access.items() if k not in ['views','selected_loss']})
        inputs=root/'inputs';inputs.mkdir()
        np.save(inputs/'vectors.npy',x[selected]);np.save(inputs/'ids.npy',np.array([f'population-{i:09d}' for i in selected]))
        pd.DataFrame({'item_id':[f'population-{i:09d}' for i in selected],'family':(selected//3).astype(str),**{name:y[selected,j] for j,name in enumerate(TARGETS)}}).to_parquet(inputs/'source.parquet',index=False)
        schema=dict(schema_version=1,status='ready',dataset=dict(path='source.parquet',identity_columns=['item_id'],unmapped_columns='error'),columns={'item_id':dict(role='id',id_type='string'),'family':dict(role='group'),**{name:dict(role='feature',kind='numeric',family=name) for name in TARGETS}},embeddings=[dict(name='offline-synthetic-v1',matrix_path='vectors.npy',ids_path='ids.npy',expected_dimension=dimension,main_normalization='l2')],prediction_pipelines={})
        audit=json.loads(files('parquet_audit').joinpath('templates/audit_config.json').read_text());audit['sample']={'strategy':'all','max_rows':display_rows};audit['geometry']['ks']=[6,12,24];audit['report']['overview']['trusted_ks']=[6,12,24];audit['nulls']['permutations']=2
        combined=dict(max_rows=512,validation=False,nulls=False,tangent=False,max_pairs=2000,accessibility=c)
        dump(inputs/'schema.json',schema);dump(inputs/'audit_config.json',audit);dump(inputs/'combined_config.json',combined)
        dump(root/'ground_truth.json',dict(global_signal='Linear in normalized coordinate 0',context_signal='Sign(context coordinate 2) times coordinate 1; local linear, global interaction',noise_signal='Independent random target; refinement should not systematically help',population_rows=n,geometry_sample_indices=selected.tolist(),note='Synthetic mechanisms, not real source encodings. Full-population geometry/topology is not computed.'))
        from .workflow import run
        run(inputs/'schema.json',inputs/'audit_config.json',root/'run',inputs/'combined_config.json',accessibility_override=access)
        dump(root/'status.json',dict(status='complete',population_rows=n,geometry_rows=display_rows,elapsed_seconds=time.perf_counter()-started))
        return dict(output=str(root),viewer=str(root/'run/index.html'),population_rows=n,geometry_rows=display_rows)
    except Exception as exc:
        dump(root/'status.json',dict(status='failed',error=str(exc)));raise

def population_run(vectors,targets,out,names,groups=None,ids=None,display_rows=240,batch_rows=4096,seed=42,max_output_bytes=4_000_000_000,plan_only=False):
    """Real-data numeric population pass over row-aligned non-pickled NPY files.

    Input files remain read-only; only the bounded atlas sample is copied.
    This is intentionally not a substitute for the full source-schema audit.
    """
    x=np.load(vectors,mmap_mode='r',allow_pickle=False);y=np.load(targets,mmap_mode='r',allow_pickle=False)
    if x.ndim!=2 or y.ndim!=2 or len(x)!=len(y) or y.shape[1]!=len(names) or x.dtype.kind not in 'fiu' or y.dtype.kind not in 'fiu':raise ValueError('Need aligned numeric matrices: vectors N×D, targets N×F, and F names')
    n,d=x.shape
    if d<2:raise ValueError('Population vectors need at least two dimensions')
    if n<80 or not 80<=display_rows<=min(512,n) or batch_rows<64 or len(set(names))!=len(names) or not names or len(names)>32 or any(not name or name in ['item_id','family'] for name in names):raise ValueError('Population run requires unique nonreserved target names (1..32), n>=80, display rows 80..512 and batch rows >=64')
    group=np.arange(n,dtype=np.int64) if groups is None else np.load(groups,mmap_mode='r',allow_pickle=False)
    identity=None if ids is None else np.load(ids,mmap_mode='r',allow_pickle=False)
    if group.shape!=(n,) or not np.issubdtype(group.dtype,np.integer):raise ValueError('Groups must be an aligned integer NPY vector')
    if identity is not None and (identity.shape!=(n,) or identity.dtype.kind not in 'US'):raise ValueError('IDs must be an aligned unique non-pickled string NPY vector')
    c=options(dict(batch_rows=batch_rows));plan=estimate(n,d,len(names),len([q for q in c['dimensions'] if q<=d]),c['folds'],mode='streamed',display_rows=display_rows);plan['working_array_estimate_bytes']+=max(0,batch_rows-4096)*d*32;enforce(plan,max_output_bytes=max_output_bytes)
    if plan_only:return plan
    if identity is not None and len(np.unique(identity))!=n:raise ValueError('Population IDs must be unique')
    root=Path(out).resolve()
    if root.exists() and any(root.iterdir()):raise ValueError('Population output must be new/empty')
    root.mkdir(parents=True,exist_ok=True);dump(root/'resource_plan.json',plan);dump(root/'status.json',dict(status='running'))
    try:
        # Validate every source row in bounded batches before model fitting.
        for start in range(0,n,batch_rows):
            unit(x[start:start+batch_rows])
            if np.isinf(y[start:start+batch_rows]).any():raise ValueError('Targets may contain NaN missingness, not infinities')
        selected=np.sort(np.random.default_rng(seed+1).choice(n,display_rows,replace=False));sink=PredictionWriter(root/'held_out_predictions.parquet')
        try:access=analyze(x,{name:y[:,j] for j,name in enumerate(names)},group,c,seed,selected,sink)
        finally:sink.close()
        access['coverage']['geometry_rows']=display_rows;access['coverage']['population_resource_plan']='../resource_plan.json'
        dump(root/'accessibility_summary.json',{k:v for k,v in access.items() if k not in ['views','selected_loss']})
        inputs=root/'inputs';inputs.mkdir();sample_ids=np.asarray([f'row-{i}' for i in selected]) if identity is None else identity[selected].astype(str)
        np.save(inputs/'vectors.npy',x[selected]);np.save(inputs/'ids.npy',sample_ids)
        pd.DataFrame({'item_id':sample_ids,'family':group[selected].astype(str),**{name:y[selected,j] for j,name in enumerate(names)}}).to_parquet(inputs/'source.parquet',index=False)
        schema=dict(schema_version=1,status='ready',dataset=dict(path='source.parquet',identity_columns=['item_id'],unmapped_columns='error'),columns={'item_id':dict(role='id',id_type='string'),'family':dict(role='group'),**{name:dict(role='feature',kind='numeric',family=name) for name in names}},embeddings=[dict(name='population-input',matrix_path='vectors.npy',ids_path='ids.npy',expected_dimension=d,main_normalization='l2')],prediction_pipelines={})
        audit=json.loads(files('parquet_audit').joinpath('templates/audit_config.json').read_text());audit['sample']={'strategy':'all','max_rows':display_rows};audit['geometry']['ks']=[6,12,24];audit['report']['overview']['trusted_ks']=[6,12,24];audit['nulls']['permutations']=2
        combined=dict(max_rows=512,validation=False,nulls=False,tangent=False,max_pairs=2000,accessibility=c)
        dump(inputs/'schema.json',schema);dump(inputs/'audit_config.json',audit);dump(inputs/'combined_config.json',combined)
        dump(root/'input_scope.json',dict(vectors=str(Path(vectors).resolve()),targets=str(Path(targets).resolve()),groups=None if groups is None else str(Path(groups).resolve()),ids=None if ids is None else str(Path(ids).resolve()),population_rows=n,geometry_sample_indices=selected.tolist(),alignment='Caller supplies row-aligned arrays; structural validation cannot establish semantic alignment',source_statistics='Detailed source audit is for sample only; numeric reconstruction evaluated across population'))
        from .workflow import run
        run(inputs/'schema.json',inputs/'audit_config.json',root/'run',inputs/'combined_config.json',accessibility_override=access)
        dump(root/'status.json',dict(status='complete',population_rows=n,geometry_rows=display_rows))
        return dict(output=str(root),viewer=str(root/'run/index.html'),population_rows=n,geometry_rows=display_rows)
    except Exception as exc:
        dump(root/'status.json',dict(status='failed',error=str(exc)));raise
