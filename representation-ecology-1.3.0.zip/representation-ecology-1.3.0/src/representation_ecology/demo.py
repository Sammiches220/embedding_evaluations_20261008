"""Reproducible source/encoder counterexamples with explicit known mechanisms."""
import json
from pathlib import Path
from importlib.resources import files
import numpy as np
import pandas as pd
from .common import dump

SCENARIOS=['agreement','omitted','suppression','interaction','missingness','visual']

def create_demo(out,n=240,seed=42,scenario='omitted'):
    if scenario not in SCENARIOS: raise ValueError(f'Unknown scenario {scenario}')
    if n<80: raise ValueError('Demo needs >=80 items for group-held-out analysis')
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    if any(out.iterdir()): raise ValueError('Demo input folder must be empty')
    rng=np.random.default_rng(seed);x=rng.normal(size=n);y=rng.normal(size=n);hidden=rng.choice([-1.,1.],n)
    group=np.arange(n)//3;ids=np.array([f'item-{i:05d}' for i in range(n)])
    noise=rng.normal(0,.025,(n,8))
    latent=np.column_stack([np.ones(n)*2,x,y,hidden*1.6,np.sin(x),np.cos(y),x*y,np.zeros(n)])+noise
    if scenario=='agreement': latent=np.column_stack([np.ones(n)*2,x,y,x*.2,y*.2,x*0,y*0,x*0])+noise
    if scenario=='interaction': latent=np.column_stack([np.ones(n)*2,x*y,x*y,x*.03,y*.03,x*0,y*0,x*0])+noise
    frame=pd.DataFrame({'item_id':ids,'x':x,'y':y,'category':np.where(x>0,'positive','negative'),
        'tags':[['upper' if v>0 else 'lower','right' if u>0 else 'left'] for u,v in zip(x,y)],
        'family':group.astype(str),'hidden_factor':hidden,'source_only':rng.normal(size=n)})
    if scenario=='missingness': frame.loc[x>.4,'x']=np.nan
    if scenario=='suppression': frame['source_only']=np.linspace(-3,3,n)
    np.save(out/'vectors.npy',latent);np.save(out/'ids.npy',ids)
    alternate=latent.copy();alternate[:,3]=rng.normal(size=n)*.2
    np.save(out/'comparison.npy',alternate)
    columns={'item_id':{'role':'id','id_type':'string'},'family':{'role':'group'},'hidden_factor':{'role':'ignore'},
        'x':{'role':'feature','kind':'numeric','family':'coordinates','units':'source units'},
        'y':{'role':'feature','kind':'numeric','family':'coordinates','units':'source units'},
        'category':{'role':'feature','kind':'categorical','id_type':'string','family':'derived'},
        'tags':{'role':'feature','kind':'multilabel','encoding':'list','empty_is_unknown':False,'family':'derived','max_labels':10},
        'source_only':{'role':'feature','kind':'numeric','family':'independent'}}
    if scenario=='visual':
        mapping={'x':'exposure_score','y':'detail_score','category':'palette_group','tags':'visual_tags','source_only':'catalog_age_days','hidden_factor':'capture_pipeline'}
        frame=frame.rename(columns=mapping)
        frame['palette_group']=np.where(x>0,'warm','cool')
        frame['visual_tags']=[['detailed' if v>0 else 'simple','bright' if u>0 else 'dim'] for u,v in zip(x,y)]
        frame['catalog_age_days']=rng.integers(0,366,n)
        columns={mapping.get(name,name):spec for name,spec in columns.items()}
        for name in ['exposure_score','detail_score']:
            columns[name]['units']='standardized score'
            columns[name]['description']='Synthetic visual descriptor; no real media or encoder is bundled.'
        columns['catalog_age_days'].update(kind='count',units='days',description='Synthetic source measurement intentionally absent from the embedding mechanism.')
    frame.to_parquet(out/'source.parquet',index=False)
    schema=dict(schema_version=1,status='ready',dataset={'path':'source.parquet','identity_columns':['item_id'],'unmapped_columns':'error'},
        columns=columns,embeddings=[dict(name='synthetic-v1',matrix_path='vectors.npy',ids_path='ids.npy',expected_dimension=8,main_normalization='l2'),
            dict(name='synthetic-alternate-v1',matrix_path='comparison.npy',ids_path='ids.npy',expected_dimension=8,main_normalization='l2')],prediction_pipelines={})
    audit=json.loads(files('parquet_audit').joinpath('templates/audit_config.json').read_text())
    audit['sample']={'strategy':'all','max_rows':n};audit['geometry']['ks']=[6,12,24]
    audit['report']['overview']['trusted_ks']=[6,12,24]
    audit['nulls']['permutations']=5;audit['probes']['group_column']='family'
    combined={'scales':[6,12,24],'max_rows':max(n,5000),'max_pairs':min(12000,n*(n-1)//2),'folds':4,'validation':True,'nulls':True,'topology':False}
    dump(out/'schema.json',schema);dump(out/'audit_config.json',audit);dump(out/'combined_config.json',combined)
    dump(out/'ground_truth.json',dict(scenario=scenario,hidden_factor_column='capture_pipeline' if scenario=='visual' else 'hidden_factor',
        note='Hidden factor is deliberately withheld from feature analyses. Reclassify it as numeric to test a new explanatory vocabulary; groups and vectors remain fixed.',
        suppressed_feature='catalog_age_days' if scenario=='visual' else 'source_only',encoder='synthetic-v1',seed=seed))
    # A source-grounded numerical intervention fixture; no image manipulation claims.
    transformed=latent.copy();transformed[:,1]+=.4
    np.save(out/'intervention_vectors.npy',transformed)
    pd.DataFrame({'source_id':ids,'transformed_id':[f'{i}:shift' for i in ids],
        'transform':['synthetic_latent_coordinate_shift']*n,'parameters':[json.dumps({'coordinate':1,'delta':.4})]*n,
        'collateral_changes':['Other latent coordinates held fixed; unit normalization couples resulting coordinates']*n}).to_parquet(out/'interventions.parquet',index=False)
    return out
