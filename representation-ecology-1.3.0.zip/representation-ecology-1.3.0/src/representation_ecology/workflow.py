"""One cohort and exact graph feed both existing engines and the new bridge."""
import copy
import json
import platform
import shutil
import time
import uuid
from pathlib import Path
from importlib.metadata import version
import numpy as np
import pandas as pd
from geometric_ecology.core import build_map,normalize,knn
from geometric_ecology.io import save_model,export_explorer
from geometric_ecology.validation import evaluate
from parquet_audit.config import validate_bundle,roles
from parquet_audit.ingest import source_statistics,sample_positions,gather_parquet,external_vectors,embedded_vectors,identity_columns,sample_source_summaries
from parquet_audit.predictions import attach_predictions,probability_metrics
from parquet_audit.semantics import KINDS,computation_spec,is_null
from embedding_feature_audit.dataframe_report import audit_dataframe
from embedding_feature_audit.exploration import row_feature
from .common import configuration,digest,dump,table,file_digest
from .features import FeatureSpace,local_fields
from .analysis import relational_models,crossfit_probes,evidence_profiles,tangent_fields


def prepare(schema_path,config_path,cfg):
    checked=validate_bundle(schema_path,config_path);schema=checked['schema'];audit=checked['config']
    if audit['mode']!='embedding': raise ValueError('Combined runs need embedding mode; parquet-audit still supports source_only')
    if len(schema['embeddings'])>2: raise ValueError('At most two embedding views per combined run')
    if audit['sample']['max_rows']>cfg['max_rows'] and min(checked['n_rows'],audit['sample']['max_rows'])>cfg['max_rows']: raise ValueError('Evaluation sample exceeds combined max_rows; lower sample.max_rows in audit config')
    summaries,source_tables,source_info=source_statistics(schema,audit)
    positions=sample_positions(checked['n_rows'],audit)
    if len(positions)>cfg['max_rows']: raise ValueError('Evaluation cohort exceeds max_rows')
    frame,derived=gather_parquet(schema,audit,positions,source_fingerprint=source_info['fingerprint'])
    idcols=identity_columns(schema);ids=frame['_audit_item_identity'].to_numpy(dtype=str)
    specs={n:s for n,s in schema['columns'].items() if s['role']=='feature'};specs.update(derived)
    if len(specs)>cfg['max_features']: raise ValueError('Feature count exceeds combined max_features')
    arrays=[];good=np.ones(len(frame),bool);alignment=[]
    for asset in schema['embeddings']:
        if 'column' in asset: z=embedded_vectors(frame,asset,schema['columns'][asset['column']]);absent=np.zeros(len(frame),bool)
        else: z,absent=external_vectors(asset,ids,schema['columns'][idcols[0]],audit)
        valid=np.isfinite(z).all(1)&(np.linalg.norm(np.nan_to_num(z),axis=1)>1e-8)&~absent
        for i in range(len(frame)): alignment.append(dict(item_id=ids[i],view=asset['name'],source_position=int(positions[i]),valid=bool(valid[i]),reason=None if valid[i] else 'missing_nonfinite_or_zero_direction'))
        good &= valid;arrays.append(z)
    if not good.all() and audit['geometry']['invalid_embeddings']=='error': raise ValueError('Invalid/zero vectors in common cohort; choose explicit invalid_embeddings=exclude')
    excluded=[dict(item_id=ids[i],source_position=int(positions[i])) for i in np.flatnonzero(~good)]
    frame=frame.iloc[np.flatnonzero(good)].reset_index(drop=True);arrays=[a[good] for a in arrays];ids=ids[good]
    if len(frame)<12 or max(cfg['scales'])>=len(frame)-1: raise ValueError('Need >=12 common valid rows and every combined scale < N-1')
    if min(int(.8*len(frame)),len(frame)-12)<=max(cfg['scales'])+1 and cfg['validation']:
        raise ValueError('Validation training split too small for scales; reduce scales or disable validation explicitly')
    if audit['source']['scope']=='evaluation':
        summaries,source_tables=sample_source_summaries(frame,specs)
    if audit['source']['scope']=='full':
        for name,spec in specs.items():
            if spec['kind']=='multilabel' and 'vocabulary' not in spec:
                counts=source_tables.get(name,pd.DataFrame())
                if len(counts): spec['vocabulary']=counts[counts['count']>=spec.get('min_count',1)].label.head(spec.get('max_labels',100)).tolist()
    frame,pred_specs=attach_predictions(frame,schema,audit)
    group=audit['probes'].get('group_column') or (roles(schema,'group')+[None])[0]
    split=audit['probes'].get('split_column') or (roles(schema,'split')+[None])[0]
    groups=None if not group else np.array([f'row:{i}' if is_null(v) else 'group:'+str(v) for i,v in enumerate(frame[group])])
    splits=None if not split else frame[split].to_numpy()
    if groups is not None and splits is not None and set(groups[splits=='train'])&set(groups[splits=='test']): raise ValueError('Explicit split leaks related groups')
    return dict(schema=schema,audit=audit,frame=frame,specs=specs,arrays=arrays,ids=ids,
        summaries=summaries,source_tables=source_tables,source_info=source_info,
        alignment=alignment,excluded=excluded,pred_specs=pred_specs,
        group=group,split=split,groups=groups,splits=splits)


def audit_config(data,cfg):
    a=data['audit'];specs=data['specs'];predictions={}
    for name,spec in data['pred_specs'].items():
        if spec['role']=='prediction': predictions[spec['target']]={'column':name,'uses_embedding':data['schema']['prediction_pipelines'][spec['pipeline']]['uses_embedding'],'missing_values':[]}
    baseline={}
    if a['geometry']['reference']=='full_source' and a['source']['scope']=='full':
        baseline={n:dict(zip(t.label,t.prevalence)) for n,t in data['source_tables'].items() if len(t)}
    computed={n:computation_spec(s) for n,s in specs.items() if KINDS[s['kind']] is not None}
    for name,spec in computed.items():
        if spec['kind']=='multilabel' and 'vocabulary' not in spec and a['source']['scope']=='full':
            t=data['source_tables'].get(name,pd.DataFrame())
            if len(t): spec['vocabulary']=t[t['count']>=spec['min_count']].label.head(spec['max_labels']).tolist()
    source_only=[n for n in computed if not specs[n].get('geometry',True)]
    probe_names=[n for n in computed if specs[n].get('probe',True)]
    return computed,dict(generic_schema=True,id_column='_audit_item_identity',metric='euclidean',ks=cfg['scales'],
        seed=cfg['seed'],verbose=False,embedding_normalization='none',
        probe_features=probe_names if a['probes']['enabled'] else False,
        probe_models=a['probes']['models'],trees=a['probes']['trees'],max_probe_labels=a['probes']['max_labels'],
        probe_regularization_grid=a['probes']['regularization_grid'],
        source_only_targets=source_only,permutations=a['nulls']['permutations'],
        null_modes=a['nulls']['modes'],null_correction=a['nulls']['correction'],
        strata_column=a['nulls'].get('stratum_column'),group_column=data['group'],split_column=data['split'],
        missingness_features=a['missingness']['features'] if a['missingness']['enabled'] else False,
        missingness_fractions=a['missingness']['fractions'],missingness_modes=a['missingness']['modes'],
        predictions=predictions,population_prevalence=baseline,
        pca_overview=True,explorer=True,explorer_max_rows=cfg['max_rows'],explorer_max_bytes=cfg['max_payload_bytes'],
        comparison_bootstraps=a.get('comparison',{}).get('bootstraps',100),
        embedding_name=data['schema']['embeddings'][0]['name'],
        comparison_name=data['schema']['embeddings'][1]['name'] if len(data['arrays'])>1 else None,
        overview={**a['report']['overview'],'trusted_ks':cfg['scales']},
        distance_cap=a['geometry']['distance_cap'],distance_pairs=a['geometry']['distance_pairs'],
        normalization_analysis={'enabled':False},
        topology={**a['topology'],'enabled':cfg['topology']})


def run(schema_path,config_path,out,combined_config=None,*,accessibility_override=None):
    cfg=configuration(combined_config);out=Path(out).resolve()
    if out.exists() and any(out.iterdir()): raise ValueError('Output must be a new/empty directory; incomplete runs are never silently overwritten')
    out.mkdir(parents=True,exist_ok=True);started=time.perf_counter();run_id=uuid.uuid4().hex
    dump(out/'run_status.json',dict(status='running',run_id=run_id))
    try:
        from .resources import bundle_plan
        bundle_plan(schema_path,config_path,cfg,out/'resource_plan.json')
        print('Validating source, freezing common cohort and feature semantics…',flush=True)
        data=prepare(schema_path,config_path,cfg);frame=data['frame'];ids=data['ids'];specs=data['specs']
        bridge=out/'bridge';bridge.mkdir();population=out/'source_population';population.mkdir()
        dump(population/'summaries.json',data['summaries']);dump(population/'scope.json',data['source_info'])
        for index,(name,t) in enumerate(data['source_tables'].items()): table(population/f'{index:03d}.parquet',t)
        dump(population/'index.json',{name:f'{i:03d}.parquet' for i,name in enumerate(data['source_tables'])})
        table(bridge/'asset_alignment.parquet',data['alignment']);table(bridge/'excluded_items.parquet',data['excluded'])
        # Cohort preserves normalized observed values; embeddings are separate binary arrays.
        drop=[c for c,s in data['schema']['columns'].items() if s['role']=='embedding']
        frame.drop(columns=drop,errors='ignore').to_parquet(out/'cohort.parquet',index=False)
        dump(out/'feature_schema.json',specs);dump(out/'combined_config.json',cfg)
        dump(out/'source_schema.json',data['schema']);dump(out/'source_audit_config.json',data['audit'])
        models=[];unit=[];graphs=[]
        for view,raw in enumerate(data['arrays']):
            print(f'Computing shared exact geometry for view {view+1} ({len(ids)} items)…',flush=True)
            z=normalize(raw);dd,nn=knn(z,max(cfg['scales'])+1,exclude_self=True)
            model=build_map(raw,ids,scales=cfg['scales'],support=cfg['support'],repeats=cfg['resamples'],
                landmarks=cfg['landmarks'],regions=cfg['regions'],seed=cfg['seed'],
                encoder=data['schema']['embeddings'][view]['name'],neighbor_data=(dd,nn))
            # build_map normalization is deterministic but re-normalization may round: freeze its exact x.
            z=model['x'];unit.append(z);graphs.append(model['neighbors'][:,:max(cfg['scales'])]);models.append(model)
            directory=out/('geometry' if view==0 else 'geometry_comparison')
            save_model(model,directory)
            validation=evaluate(model,include_nulls=cfg['nulls']) if cfg['validation'] else None
            export_explorer(model,directory,validation)
            np.save(out/f'embeddings_{view}.npy',z,allow_pickle=False)
            np.save(out/f'raw_embeddings_{view}.npy',raw,allow_pickle=False)
        norms=pd.DataFrame({'item_id':ids,**{f'view_{i}_raw_norm':np.linalg.norm(z,axis=1) for i,z in enumerate(data['arrays'])}})
        table(bridge/'raw_norms.parquet',norms)
        print('Running preserved feature audit on the shared graphs…',flush=True)
        computed,acfg=audit_config(data,cfg)
        result=audit_dataframe(frame,out/'audit',features=computed,config=acfg,
            embeddings=unit[0],neighbors=graphs[0],
            comparison_embeddings=unit[1] if len(unit)>1 else None,
            comparison_neighbors=graphs[1] if len(graphs)>1 else None)
        if not np.array_equal(np.load(out/'audit'/'neighbors.npy'),graphs[0]): raise RuntimeError('Audit and Ecology graph alignment failed')
        probability_scores={}
        for name,pred_spec in data['pred_specs'].items():
            if pred_spec['role']=='probabilities':
                probability_scores[name]=probability_metrics(frame[pred_spec['target']],frame[name],data['schema']['columns'][pred_spec['target']],pred_spec)
        dump(bridge/'supplied_probability_metrics.json',probability_scores)
        model=models[0];z=unit[0]
        print('Measuring feature neighborhoods, held-out pair residuals and cross-fitted probes…',flush=True)
        local,registry,fields=local_fields(frame,specs,graphs[0],cfg['scales'])
        space=FeatureSpace(frame,specs,np.arange(len(frame)),cfg['feature_families'],cfg['min_pair_features'])
        neighborhoods,expected=space.neighborhoods(z,graphs[0],cfg['scales'])
        edges,pair_scores,folds,pair_status=relational_models(frame,specs,z,graphs[0],model['stable_edges'],cfg,data['groups'],data['splits'])
        probes,probe_scores,probe_status=crossfit_probes(frame,specs,z,cfg,data['groups'],data['splits'])
        evidence,residual_fields=evidence_profiles(model,neighborhoods,edges,cfg);fields.update(residual_fields)
        for k in cfg['scales']:
            for metric in ['overlap_low','overlap_high']:
                fields[f'Feature neighborhood · {metric} k={k}']=np.array([r[metric] for r in neighborhoods if r['k']==k])
        for feature in specs:
            for probe in cfg['probe_models']:
                selected=[r for r in probes if r['feature']==feature and r['model']==probe]
                if selected:
                    values=np.full(len(frame),np.nan)
                    for i in {r['row'] for r in selected}: values[i]=np.mean([r['loss'] for r in selected if r['row']==i])
                    fields[f'{feature} · {probe} held-out loss']=values
        from .accessibility import analyze,filtration
        access=accessibility_override
        if access is None and cfg['accessibility']['enabled']:
            numeric={name:np.asarray(frame[name],float) for name,spec in specs.items() if KINDS[spec['kind']]=='continuous' and spec.get('probe',True)}
            access=analyze(z,numeric,data['groups'] if data['groups'] is not None else np.arange(len(z)),cfg['accessibility'],cfg['seed'])
        if access is not None:dump(bridge/'accessibility.json',access)
        scale_structure=filtration(len(z),model['edges'],model['lengths'])
        dump(bridge/'filtration.json',scale_structure)
        tangents=tangent_fields(frame,specs,model,cfg,data['groups']) if cfg['tangent'] else []
        for filename,rows in [('node_feature_fields',local),('neighborhood_comparisons',neighborhoods),('edge_explanations',edges),('pair_model_scores',pair_scores),('item_folds',folds),('probe_predictions',probes),('probe_scores',probe_scores),('evidence_status',evidence),('tangent_fits',tangents)]:
            export_rows=rows
            if filename=='probe_predictions':
                # Mixed semantic targets cannot share an untyped Arrow scalar column.
                export_rows=[]
                for row in rows:
                    record=dict(row)
                    for key in ['true','predicted','probabilities']:
                        record[key+'_json']=json.dumps(record.pop(key),ensure_ascii=False)
                    export_rows.append(record)
            table(bridge/(filename+'.parquet'),export_rows)
        dump(bridge/'feature_registry.json',registry);dump(bridge/'expected_neighbors.json',expected)
        dump(bridge/'analysis_status.json',{'pair_models':pair_status,'probes':probe_status})
        dump(bridge/'node_fields.json',fields)
        atlas=json.loads((out/'geometry'/'atlas.json').read_text())
        feature_values={n:row_feature(frame[n],s) for n,s in computed.items()}
        # Text/datetime remain inspectable but are never silently made numeric.
        for n,s in specs.items():
            if n not in feature_values: feature_values[n]={'kind':s['kind'],'values':[None if is_null(v) else str(v) for v in frame[n]],'spec':s}
        payload=dict(ids=ids.tolist(),features=feature_values,fields=fields,ks=cfg['scales'],
            expected=expected,neighborhoods=neighborhoods,edges=edges,probes=probes,evidence=evidence,
            pair_scores=pair_scores,probe_scores=probe_scores,status={'pairs':pair_status,'probes':probe_status},
            geometry=dict(xy=atlas['xy'],component=model['component'],region=model['region'],neighbors=graphs[0],
                perturbation=model['profiles']['perturbation_jaccard'],rank_support=model['profiles']['scale_support'],distances=model['distances'][:,:max(cfg['scales'])]),
            source_population=data['summaries'],tangents=tangents,accessibility=access,filtration=scale_structure,
            comparison=None if len(models)<2 else dict(name=data['schema']['embeddings'][1]['name'],
                neighbor_overlap=np.array([len(set(a[:model['manifest']['signature_k']])&set(b[:model['manifest']['signature_k']]))/model['manifest']['signature_k'] for a,b in zip(graphs[0],graphs[1])])),
            run_id=run_id)
        manifest=dict(schema_version=1,run_id=run_id,package_version='1.3.0',n=len(ids),
            source_population_rows=int(data['source_info'].get('source_rows',len(frame))),
            ids_sha256=digest(ids.tolist()),vector_sha256=digest(z),feature_sha256=digest(feature_values),
            feature_schema_sha256=digest(specs),graph_sha256=digest(graphs[0]),
            config=cfg,metric='unit-normalized Euclidean chord',normalization='L2 float32 canonical vectors',
            source_identity_schema={c:data['schema']['columns'][c] for c in identity_columns(data['schema'])},
            original_audit_metric=data['audit']['geometry']['metric'],
            source_data_sha256=file_digest(data['schema']['dataset']['path']),
            evaluation_sha256=digest(folds),
            accessibility_evaluation_sha256=None if access is None else digest({'folds':access['folds'],'transforms':access['transforms'],'coverage':{k:v for k,v in access['coverage'].items() if k!='elapsed_seconds'}}),
            source_code_sha256=digest({str(p.relative_to(Path(__file__).parents[1])):file_digest(p) for p in Path(__file__).parents[1].rglob('*') if p.is_file() and p.suffix in ['.py','.js','.html','.json','.css'] and '__pycache__' not in p.parts}),
            source_scope=data['audit']['source']['scope'],geometry_scope='Frozen evaluated common valid cohort',
            geometry_evaluation='Transductive descriptive atlas; pair models and probes hold out labels/items/groups, not unlabeled map vectors',
            original_graphs='Rebuilt once per view to enforce common canonical metric; original supplied graphs not reused',
            pair_sampling='Mixture of retained/near edges and random reference pairs; no population-weighted inference',
            raw_norm_analysis='Raw arrays and norms preserved separately; combined audit uses canonical unit vectors; original parquet-audit supports raw normalization experiments',
            versions={p:version(p) for p in ['numpy','scipy','scikit-learn','pandas','pyarrow']},python=platform.python_version(),
            limitations=['Exact bounded in-memory backend, not ANN','Operational exploratory evidence profiles; no causal or semantic certification','Complete-distance sampled topology differs from sparse Ecology H0','Cross-model plural explanation is inspectable, not uniquely identified','Local tangent fits are descriptive center/group-excluded fits'],
            elapsed_seconds=time.perf_counter()-started)
        dump(out/'manifest.json',manifest);payload['manifest']=manifest
        from .viewer import export_viewer
        export_viewer(out,payload,cfg['max_payload_bytes'])
        (out/'investigations').mkdir();dump(out/'investigations'/'history.json',[])
        dump(out/'run_status.json',dict(status='complete',run_id=run_id,elapsed_seconds=time.perf_counter()-started))
        print(f'Complete: {out / "index.html"}',flush=True)
        return out
    except Exception as exc:
        dump(out/'run_status.json',dict(status='failed',run_id=run_id,error=str(exc)))
        raise
