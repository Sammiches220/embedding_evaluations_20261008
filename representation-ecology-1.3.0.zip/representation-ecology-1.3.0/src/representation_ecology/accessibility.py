"""Bounded, group-cross-fitted broad/local accounts. No all-pairs operations.

Regions are frozen from unlabeled reference vectors (transductive routing).
PCA, target models and adequacy choices are fitted within each training fold.
"""
import time
import numpy as np
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge
from threadpoolctl import threadpool_limits

DEFAULTS = dict(dimensions=[1,2,4,8], folds=3, train_cap=2048, regions=4,
                min_train=16, batch_rows=4096, adequate_ratio=.8, enabled=True)

def options(raw=None):
    raw={} if raw is None else raw
    if not isinstance(raw,dict) or set(raw)-set(DEFAULTS): raise ValueError('Unknown accessibility options')
    c={**DEFAULTS,**raw}
    for k in ['folds','train_cap','regions','min_train','batch_rows']:
        if type(c[k]) is not int or c[k]<1: raise ValueError('Invalid accessibility '+k)
    if c['folds']<3 or c['folds']>10: raise ValueError('accessibility folds must be 3..10')
    if c['train_cap']<c['min_train']*2 or c['regions']>32: raise ValueError('Accessibility training/region budget invalid')
    if type(c['enabled']) is not bool: raise ValueError('accessibility enabled must be boolean')
    if not isinstance(c['dimensions'],list) or not c['dimensions'] or any(type(q) is not int or q<1 for q in c['dimensions']): raise ValueError('Accessibility dimensions must be positive integers')
    if type(c['adequate_ratio']) not in [int,float] or not np.isfinite(c['adequate_ratio']) or not 0<c['adequate_ratio']<1: raise ValueError('Accessibility adequate_ratio must be in (0,1)')
    c['dimensions']=sorted(set(c['dimensions']))
    return c

def fold_ids(groups,folds):
    # Same group -> same test fold; deterministic, independent of targets.
    values=np.asarray(groups)
    if np.issubdtype(values.dtype,np.integer):
        bits=values.astype(np.uint64)
        bits=(bits ^ (bits >> np.uint64(30)))*np.uint64(0xbf58476d1ce4e5b9)
        bits=(bits ^ (bits >> np.uint64(27)))*np.uint64(0x94d049bb133111eb)
        return ((bits ^ (bits >> np.uint64(31)))%np.uint64(folds)).astype(np.int8)
    import hashlib
    unique,inverse=np.unique(np.asarray(groups).astype(str),return_inverse=True)
    mapping=np.array([int.from_bytes(hashlib.blake2b(v.encode(),digest_size=8).digest(),'little')%folds for v in unique])
    return mapping[inverse]

def unit(x):
    x=np.asarray(x,dtype=np.float32)
    norms=np.linalg.norm(x,axis=1,keepdims=True)
    if not np.isfinite(x).all() or np.any(norms<=1e-8): raise ValueError('Accessibility requires finite nonzero vectors')
    return x/norms

def labels(x,centers):
    # Avoid batch x regions x dimensions temporary arrays.
    return np.argmin(np.maximum(0,(x*x).sum(1)[:,None]+(centers*centers).sum(1)[None,:]-2*x@centers.T),axis=1)

def filtration(n,edges,lengths,levels=9):
    """Exact threshold components on supplied sparse candidate edges."""
    edges=np.asarray(edges,int).reshape(-1,2);lengths=np.asarray(lengths,float)
    if len(edges)!=len(lengths) or not np.isfinite(lengths).all() or np.any(lengths<0): raise ValueError('Invalid filtration edges')
    radii=np.unique(np.r_[0.,np.quantile(lengths,np.linspace(0,1,levels))]) if len(lengths) else np.array([0.])
    order=np.argsort(lengths,kind='stable');parent=np.arange(n);size=np.ones(n,int);cursor=0;merges=[];snapshots=[]
    def root(i):
        while parent[i]!=i: parent[i]=parent[parent[i]];i=parent[i]
        return i
    for radius in radii:
        while cursor<len(order) and lengths[order[cursor]]<=radius:
            e=order[cursor];cursor+=1;a,b=[root(int(i)) for i in edges[e]]
            if a==b:continue
            if size[a]<size[b]:a,b=b,a
            merges.append(dict(radius=float(lengths[e]),left=int(a),right=int(b),size=int(size[a]+size[b])))
            parent[b]=a;size[a]+=size[b]
        membership=np.array([root(i) for i in range(n)]);_,counts=np.unique(membership,return_counts=True)
        snapshots.append(dict(radius=float(radius),labels=membership.tolist(),components=len(counts),largest=int(counts.max()),edges=cursor))
    return dict(scope='Exact H0 on maximum-k mutual candidate graph; omitted edges never enter',
        truncation='Unmerged components are unresolved outside the candidate graph, not permanent metric separations',levels=snapshots,merges=merges)

def analyze(matrix,targets,groups,cfg=None,seed=42,sample_indices=None,sink=None):
    """Stream held-out evaluation, retain per-item fields only for selected IDs.

    sink receives one batch of typed columns. Targets support numeric values and
    NaN missingness. All test items are evaluated once; inner validation chooses
    an account before its outer test predictions are observed.
    """
    c=options(cfg);n,d=matrix.shape;started=time.perf_counter();rng=np.random.default_rng(seed)
    sample=np.asarray(np.arange(n) if sample_indices is None else sample_indices,int)
    if len(np.unique(sample))!=len(sample) or np.any(sample<0) or np.any(sample>=n):raise ValueError('Invalid sample_indices')
    if len(groups)!=n or any(np.asarray(y).shape!=(n,) for y in targets.values()):raise ValueError('Accessibility alignment mismatch')
    fold=fold_ids(groups,c['folds']);qs=[q for q in c['dimensions'] if q<=d]
    if not qs:raise ValueError('No accessible dimension fits the input dimension')
    ref=rng.choice(n,min(n,c['train_cap']),replace=False);zx=unit(matrix[ref])
    with threadpool_limits(limits=1):
        router=KMeans(n_clusters=min(c['regions'],len(ref)),n_init=3,random_state=seed).fit(zx)
    centers=router.cluster_centers_;r=len(centers)
    views={name:{str(q):{k:np.full(len(sample),np.nan) for k in ['broad','local','gain','baseline']} for q in qs} for name in targets}
    chosen={name:np.full(len(sample),np.nan) for name in targets};sample_regions=np.zeros(len(sample),int)
    for start in range(0,len(sample),c['batch_rows']):sample_regions[start:start+c['batch_rows']]=labels(unit(matrix[sample[start:start+c['batch_rows']]]),centers)
    summaries={};transfers={};selections=[];status=[];fold_records=[];operations=[];accounts=[];transforms=[]
    def accumulate(bucket,key,values):
        a=np.asarray(values);a=a[np.isfinite(a)]
        if len(a):
            old=bucket.setdefault(key,[0.,0]);old[0]+=float(a.sum());old[1]+=len(a)
    for f in range(c['folds']):
        # Fold f is test, next is validation, remaining groups are training.
        train=np.flatnonzero((fold!=f)&(fold!=(f+1)%c['folds']));val=np.flatnonzero(fold==(f+1)%c['folds'])
        if len(train)>c['train_cap']:train=np.sort(rng.choice(train,c['train_cap'],replace=False))
        if len(val)>c['train_cap']:val=np.sort(rng.choice(val,c['train_cap'],replace=False))
        fold_records.append(dict(fold=f,train_rows=len(train),validation_rows=len(val),test_rows=int((fold==f).sum())))
        if len(train)<c['min_train'] or len(val)<2:
            status.append(dict(fold=f,status='insufficient_training_or_validation'));continue
        x=unit(matrix[train]);v=unit(matrix[val]);reg=labels(x,centers);vr=labels(v,centers)
        fit_start=time.perf_counter()
        with threadpool_limits(limits=1):pca=PCA(n_components=min(max(qs),len(train)-1,d),svd_solver='full').fit(x)
        transforms.append(dict(fold=f,train_indices=train.tolist(),validation_indices=val.tolist(),mean=pca.mean_.tolist(),components=pca.components_.tolist()))
        xx=pca.transform(x);vv=pca.transform(v);models={};selected={}
        for name,target in targets.items():
            y=np.asarray(target[train],float);yv=np.asarray(target[val],float);known=np.isfinite(y);vk=np.isfinite(yv)
            if known.sum()<c['min_train'] or vk.sum()<2:
                status.append(dict(feature=name,fold=f,status='insufficient_target_support'));continue
            baseline=float(y[known].mean());base_mae=float(np.abs(yv[vk]-baseline).mean());candidates=[]
            for q in qs:
                if q>xx.shape[1]:continue
                broad=Ridge(alpha=.01).fit(xx[known,:q],y[known]);local={}
                for region in range(r):
                    mask=known&(reg==region)
                    if mask.sum()>=c['min_train']:local[region]=Ridge(alpha=.01).fit(xx[mask,:q],y[mask])
                accounts.append(dict(feature=name,fold=f,dimension=q,baseline=baseline,broad=dict(coefficients=broad.coef_.tolist(),intercept=float(broad.intercept_),n_train=int(known.sum())),local={int(region):dict(coefficients=m.coef_.tolist(),intercept=float(m.intercept_),n_train=int((known&(reg==region)).sum())) for region,m in local.items()}))
                models[name,q]=(baseline,broad,local)
                bv=broad.predict(vv[:,:q]);lv=np.full(len(val),np.nan)
                for region,m in local.items():
                    mask=vr==region
                    if mask.any():lv[mask]=m.predict(vv[mask,:q])
                for account,pred in [('broad',bv),('local',lv)]:
                    good=vk&np.isfinite(pred);mae=float(np.abs(yv[good]-pred[good]).mean()) if good.any() else None
                    # Partial local coverage cannot qualify as a population account.
                    adequate=bool(base_mae>1e-12 and good.sum()==vk.sum() and mae<=c['adequate_ratio']*base_mae)
                    candidates.append(dict(account=account,dimension=q,validation_mae=mae,validation_n=int(good.sum()),validation_baseline=base_mae,adequate=adequate))
            # Declared policy: broad dimension ladder first, then routed local ladder.
            ordered=sorted(candidates,key=lambda z:(z['account']=='local',z['dimension']))
            pick=next((a for a in ordered if a['adequate']),None);selected[name]=pick
            selections.append(dict(feature=name,fold=f,selected=pick,candidates=ordered))
        operations.append(dict(fold=f,fit_seconds=time.perf_counter()-fit_start))
        eval_start=time.perf_counter()
        for start in range(0,n,c['batch_rows']):
            ix=np.arange(start,min(n,start+c['batch_rows']));ix=ix[fold[ix]==f]
            if not len(ix):continue
            z=unit(matrix[ix]);rr=labels(z,centers);a=pca.transform(z)
            positions=np.searchsorted(ix,sample);validpos=positions<len(ix);validpos[validpos]=ix[positions[validpos]]==sample[validpos];dest=np.flatnonzero(validpos);src=positions[validpos]
            for (name,q),(baseline,broad,local) in models.items():
                truth=np.asarray(targets[name][ix],float);known=np.isfinite(truth);bp=broad.predict(a[:,:q]);lp=np.full(len(ix),np.nan)
                for region,m in local.items():
                    mask=rr==region
                    if mask.any():lp[mask]=m.predict(a[mask,:q])
                be=np.where(known,np.abs(truth-bp),np.nan);le=np.where(known,np.abs(truth-lp),np.nan);base=np.where(known,np.abs(truth-baseline),np.nan)
                for key,values in [('broad',be),('local',le),('gain',be-le),('baseline',base)]:
                    views[name][str(q)][key][dest]=values[src]
                    accumulate(summaries,(name,q,key,-1),values)
                    for region in range(r):accumulate(summaries,(name,q,key,region),values[rr==region])
                if q==max(qs):
                    for source,m in local.items():
                        loss=np.where(known,np.abs(truth-m.predict(a[:,:q])),np.nan)
                        for region in range(r):accumulate(transfers,(name,source,region),loss[rr==region])
                pick=selected[name]
                if pick and pick['dimension']==q:chosen[name][dest]=(be if pick['account']=='broad' else le)[src]
                if sink:sink(dict(row=ix,fold=np.full(len(ix),f),region=rr,feature=np.full(len(ix),name),dimension=np.full(len(ix),q),target_value=truth,broad_prediction=bp,local_prediction=lp,broad_loss=be,local_loss=le,baseline_loss=base))
        operations[-1]['evaluation_seconds']=time.perf_counter()-eval_start
    return dict(version=1,dimensions=qs,regions=sample_regions,views=views,selected_loss=chosen,
        summaries=[dict(feature=k[0],dimension=k[1],measure=k[2],region=k[3],mean=v[0]/v[1],n=v[1]) for k,v in summaries.items()],
        transfer=[dict(feature=k[0],source_region=k[1],target_region=k[2],dimension=max(qs),mae=v[0]/v[1],n=v[1]) for k,v in transfers.items()],
        selections=selections,status=status,folds=fold_records,timings=operations,accounts=accounts,transforms=transforms,router=dict(centers=centers.tolist(),reference_indices=ref.tolist()),
        coverage=dict(population_rows=n,display_rows=len(sample),numeric_targets=list(targets),test_policy='Every group has one outer test fold; next fold validates; other folds train',
          routing='Frozen KMeans on bounded unlabeled reference vectors; transductive, independent of labels',
          selection='First adequate broad dimension, then local dimension; inner validation only; no claim of optimal complexity',
          criterion=c['adequate_ratio'],elapsed_seconds=time.perf_counter()-started))
