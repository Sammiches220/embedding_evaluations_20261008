"""Independent accounts of a shared, frozen corpus."""
__version__ = '1.3.0'
