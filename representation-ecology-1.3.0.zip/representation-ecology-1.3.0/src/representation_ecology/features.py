"""Feature metrics preserve known masks and equalize feature families."""
import numpy as np
from sklearn.model_selection import GroupKFold, KFold
from embedding_feature_audit.dataframe import encode_feature
from parquet_audit.semantics import KINDS, computation_spec, typed_key

class FeatureSpace:
    def __init__(self,frame,specs,train,weights=None,min_features=1):
        self.frame=frame; self.specs=specs; self.data={}; self.min_features=min_features
        weights=weights or {}
        for name,spec in specs.items():
            if KINDS[spec['kind']] is None or spec.get('geometry',True) is False: continue
            y,valid,labels=encode_feature(frame[name],computation_spec(spec))
            kind=KINDS[spec['kind']]
            if kind=='multilabel':
                # Relational set distance uses all observed tags, not a probe vocabulary cap.
                y=np.array([set(v) if v is not None else set() for v in frame[name]],dtype=object)
            if spec['kind']=='ordinal':
                lookup={typed_key(v,spec.get('id_type','string')):i for i,v in enumerate(spec['order'])}
                y=np.array([float(lookup.get(v,np.nan)) if known else np.nan for v,known in zip(frame[name],valid)])
                kind='ordinal'
            known=np.asarray(train)[valid[train]]
            if len(known)<2: continue
            if kind in ['continuous','ordinal']:
                a=np.asarray(y[known],float); scale=float(np.subtract(*np.quantile(a,[.75,.25])))
                if scale<=1e-12: scale=float(np.std(a))
                if scale<=1e-12: continue
            else: scale=1.
            family=spec.get('family') or name
            self.data[name]=dict(y=y,valid=valid,kind=kind,scale=scale,family=family)
        families={d['family'] for d in self.data.values()}
        total=sum(weights.get(f,1.) for f in families) or 1.
        counts={f:sum(d['family']==f for d in self.data.values()) for f in families}
        for d in self.data.values(): d['weight']=weights.get(d['family'],1.)/total/counts[d['family']]
        self.names=list(self.data)

    def pair_features(self,pairs):
        pairs=np.asarray(pairs,int).reshape(-1,2);a,b=pairs.T
        out=np.full((len(pairs),len(self.data)),np.nan)
        for c,d in enumerate(self.data.values()):
            known=d['valid'][a]&d['valid'][b];i=a[known];j=b[known]
            if d['kind'] in ['continuous','ordinal']: v=np.abs(d['y'][i]-d['y'][j])/d['scale']
            elif d['kind']=='multilabel': v=np.array([1-len(x&y)/len(x|y) if x|y else 0. for x,y in zip(d['y'][i],d['y'][j])])
            else: v=(d['y'][i]!=d['y'][j]).astype(float)
            out[known,c]=v
        return out

    def distance(self,pairs):
        x=self.pair_features(pairs);known=np.isfinite(x);count=known.sum(1)
        weights=np.array([d['weight'] for d in self.data.values()])
        denominator=known@weights
        out=np.divide(np.nan_to_num(x)@weights,denominator,out=np.full(len(x),np.nan),where=(denominator>0)&(count>=self.min_features))
        return out,count

    def neighborhoods(self,z,neighbors,ks):
        """Both rankings use the exact same feature-comparable pool; ties are bounded."""
        rows=[]; expected={}
        for i in range(len(z)):
            candidates=np.delete(np.arange(len(z)),i)
            pairs=np.column_stack([np.full(len(candidates),i),candidates]);dist,count=self.distance(pairs)
            usable=np.isfinite(dist);pool=candidates[usable];fd=dist[usable]
            zd=np.linalg.norm(z[pool]-z[i],axis=1)
            order=np.lexsort((pool,zd)); feature_order=np.lexsort((pool,fd))
            for k in ks:
                if len(pool)<k:
                    rows.append(dict(row=i,k=k,pool=len(pool),status='insufficient_evidence',overlap_low=np.nan,overlap_high=np.nan,overlap=np.nan));continue
                actual=pool[order[:k]];chosen=pool[feature_order[:k]];cut=fd[feature_order[k-1]]
                strict=set(pool[fd<cut-1e-10]); tied=set(pool[np.abs(fd-cut)<=1e-10]);actual_set=set(actual)
                slots=k-len(strict);sure=len(strict&actual_set);tie_hits=len(tied&actual_set)
                lo=(sure+max(0,slots-(len(tied)-tie_hits)))/k
                hi=(sure+min(slots,tie_hits))/k
                # Feature distance may use different masks; retain their explicit support.
                masks=self.pair_features(np.column_stack([np.full(k,i),chosen]))
                rows.append(dict(row=i,k=k,pool=len(pool),status='ok',overlap_low=lo,overlap_high=hi,
                    overlap=len(actual_set&set(chosen))/k,tie_count=len(tied),
                    mean_comparable_features=float(np.isfinite(masks).sum(1).mean())))
                expected[f'{i}:{k}']=dict(actual=actual.tolist(),expected=chosen.tolist(),
                    feature_distances=fd[feature_order[:k]].tolist(),tied=sorted(tied)[:256],tied_total=len(tied),
                    unexpected=sorted(actual_set-set(chosen)),absent=sorted(set(chosen)-actual_set),
                    tie_policy='ID-order representative; overlap_low/high bound all cutoff ties')
        return rows,expected

def item_folds(n,groups,folds,seed,split=None):
    """Fold assignment is item/group based, never an edge split."""
    if split is not None:
        split=np.asarray(split)
        if set(split)-{'train','test'}: raise ValueError('Explicit split requires train/test')
        if groups is not None and set(groups[split=='train'])&set(groups[split=='test']): raise ValueError('Explicit split leaks groups')
        if not (split=='train').any() or not (split=='test').any(): raise ValueError('Explicit split needs train and test')
        return [(np.flatnonzero(split=='train'),np.flatnonzero(split=='test'))]
    if groups is not None:
        count=min(folds,len(np.unique(groups)))
        if count<2: return []
        return list(GroupKFold(count).split(np.arange(n),groups=groups))
    return list(KFold(min(folds,n),shuffle=True,random_state=seed).split(np.arange(n)))

def local_fields(frame,specs,neighbors,ks):
    rows=[];registry={};fields={}
    for name,spec in specs.items():
        kind=KINDS[spec['kind']]
        if kind is None: continue
        y,valid,labels=encode_feature(frame[name],computation_spec(spec))
        registry[name]={**spec,'audited_labels':list(labels),'known':int(valid.sum())}
        fields[f'{name} · known']=[float(v) for v in valid]
        if kind=='continuous': fields[f'{name} · observed']=np.where(valid,y,np.nan)
        else:
            # Label selectors remain independent; categorical IDs are never averaged.
            for c,label in enumerate(labels):
                v=y[:,c] if kind=='multilabel' else y==label
                fields[f'{name} = {label}']=np.where(valid,v,np.nan)
        if spec.get('geometry',True) is False: continue
        for k in ks:
            idx=neighbors[:,:k]; known=valid[idx];counts=known.sum(1)
            share=counts/k
            fields[f'{name} · known share k={k}']=share
            if kind=='continuous':
                diffs=np.where(valid[:,None]&known,np.abs(y[:,None]-y[idx]),np.nan)
                total=np.nansum(diffs,axis=1)
                values=np.divide(total,counts,out=np.full(len(frame),np.nan),where=valid&(counts>0))
                measure='mean_absolute_difference'
            else:
                if kind=='categorical': same=y[idx]==y[:,None]
                else:
                    same=np.array([[len(set(frame[name].iloc[i] or [])&set(frame[name].iloc[j] or []))/max(1,len(set(frame[name].iloc[i] or [])|set(frame[name].iloc[j] or []))) for j in row] for i,row in enumerate(idx)])
                values=np.divide((same*known).sum(1),counts,out=np.full(len(frame),np.nan),where=valid&(counts>0));measure='same_label_share' if kind=='categorical' else 'tag_jaccard'
            fields[f'{name} · {measure} k={k}']=values
            rows.extend(dict(row=i,feature=name,k=k,known=bool(valid[i]),known_neighbors=int(counts[i]),known_share=float(share[i]),measure=measure,value=values[i]) for i in range(len(frame)))
    return rows,registry,fields
