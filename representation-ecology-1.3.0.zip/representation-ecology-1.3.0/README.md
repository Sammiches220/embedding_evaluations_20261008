# Representation Ecology 1.2 · Geometry and feature field guide

Version **1.3.0** adds linked distance-filtration extents, broad/local group-held-out reconstruction, dimension ladders, transfer maps, resource preflight, and batched numeric population workflows.

Start with the included small context demo:

```bash
python -m pip install -e .
representation-ecology serve --run examples/offline-small/run --open
```

Choose **context_signal**, then **Broad − local error**. Compare it with global_signal and noise_signal. The visible distance slider changes structural extent; retained dimensions and prediction account are independent.

A larger **offline** generator is included for you to run. It was not executed at large scale during release preparation:

```bash
representation-ecology offline-demo --out large-population --n 100000 --dimension 32 --plan-only
representation-ecology offline-demo --out large-population --n 100000 --dimension 32
representation-ecology serve --run large-population/run --open
```

For real numeric inputs, use `population-run` with aligned vectors/targets and optional groups/IDs. Whole-population reconstruction is batched; detailed geometry/filtration remains on a bounded declared sample. Million-point capability has **not** been benchmarked. See [scale and population workflows](docs/SCALES_AND_POPULATIONS.md) for the protocol, output contracts, budgets, commands and limitations.


A complete local project combining **Geometric Ecology**, **Parquet Representation Audit**, and a new layer for studying their agreements and disagreements.

Start with the guided example at `examples/field-guide/run/index.html`, served over localhost. It uses named synthetic visual descriptors so the walkthrough has an interpretable feature vocabulary. Both original tools and their source code remain included. No hosted service, API key, or encoder download is required.

## Install and open the included example

Use Python 3.10 or newer. Python 3.11/3.12 is a practical choice for an isolated environment.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e .
python -m representation_ecology serve --run examples/field-guide/run --open
```

On Windows, activate with `.venv\Scripts\Activate.ps1` in PowerShell. The remaining `python -m ...` commands work on either platform. Multiline examples use Bash continuations; in PowerShell put the command on one line or use PowerShell backticks. The server listens on localhost only; Ctrl+C stops it. Use `--port 8766` if the default port is occupied.

The opening screen is a single **observer field guide**, with four connected questions:

1. **What shape is this?** Read variation, support, graph access and sensitivity together, with continuous terrain, contours, local point clouds and spectra.
2. **What changes here?** Follow a measured feature through a continuous field, distributions and a directional profile. Declared categories retain point identities.
3. **What doesn't fit?** Compare signed and absolute relational error fields, then inspect a scored relation.
4. **Will it predict here?** Inspect local held-out target errors and matched baselines; geometric shape alone is not a prediction test.

Click **Start walking**, then use WASD to move, left/right arrows to turn, and Escape to release. Double-click the map to place the observer. The three profiles always survey the same here-to-ahead regions. Click a feature card to change the focus without changing the active question. The interpretation card explains what the current measurements may mean and offers one concrete next action.

The default screen shows at most three feature cards. **Explore & compare** contains feature search, region capture, query, model and observation controls. **Full workspace** opens the previous flexible interface, including all raw evidence layers, arbitrary subsets, route capture and tables. Standalone Ecology and its geometry-only observer remain available.

## Read geometry before interpreting a model

The opening view, **What shape is this?**, restores continuous geometry fields, raw-value contours, and all twelve geometric readings grouped into variation, support, access and sensitivity. Actual local PCA-3 clouds and full variance spectra stay beside the directional profiles. Each field has a high/low interpretation, a practical use, and a statement of what it cannot establish.

**Relief** is a visible map control. Zero flattens rendered height; increasing it exaggerates height without changing measurements, graph edges or predictive scores. By default height follows the selected geometry. **Field as height** lets a numeric feature, relational discrepancy or prediction-error field become the 3D surface, with unsupported regions left unfilled.

A spectrum counts independent directions of local variation. A route bundle counts competitive paths through a retained graph under its cost band and enumeration cap. Neither is a count of causal explanations for a prediction. The feature and held-out-error views are what connect those geometric possibilities to the target you actually care about.

Build each analysis with the current code. There are no existing-run update commands, historical snapshot adapters or conversion utilities. Comparison, scoring, records, current-build rendering and all analysis tools remain available.

See [the field guide and design decisions](docs/FIELD_GUIDE.md).

## Generate a fresh complete demo

```bash
python -m representation_ecology demo --out my_demo --scenario visual --n 240
python -m representation_ecology serve --run my_demo/run --open
```

Scenarios: `visual` (the CLI default), `agreement`, `omitted`, `suppression`, `interaction`, and `missingness`. The visual fixture names its synthetic measurements `exposure_score`, `detail_score`, `palette_group`, `visual_tags`, and `catalog_age_days`. No real media, image measurements or encoder are implied. These are explicit synthetic mechanisms, not benchmark claims about real encoders. `omitted` withholds a synthetic variable that affects geometry. `source_only` is independent of the embedding, and the alternate embedding changes one latent coordinate. See the generated `inputs/ground_truth.json`.

To generate inputs without running analysis:

```bash
python -m representation_ecology demo --out new_inputs --inputs-only
```

## Analyze your own data

The combined workflow accepts the original Parquet audit's schema and configuration format. One Parquet row is one source item. Feature semantics and IDs are explicit. Embeddings may be Arrow list columns or external `.npy` matrices with aligned `.npy` ID arrays. The original audit validates types, identities, budgets, feature conversion, groups, missingness and splits.

```bash
python -m representation_ecology run \
  --schema path/to/dataset_schema.json \
  --config path/to/audit_config.json \
  --combined-config examples/combined_config.json \
  --out my_combined_run
python -m representation_ecology serve --run my_combined_run --open
```

Use a fresh output directory for every run. Interrupted or failed runs retain `run_status.json` with an error; choose a new output rather than mixing partial artifacts. Paths in the input schema resolve relative to the schema file, as in the original project.

For a starting schema, inspect your Parquet file:

```bash
python -m parquet_audit inspect --parquet data.parquet --out inspection
```

Then use `inspection/prepare_prompt.md` and [the source data contract](docs/audit/data-model.md) to declare the feature semantics. `examples/omitted/inputs/schema.json` is a small fully configured example. Do not rely on column-name guesses.

The combined run freezes a **common valid cohort across up to two embeddings**, normalizes vectors to canonical float32 unit vectors, and uses **Euclidean chord distance** for both engines. Original source metadata, raw vectors and vector norms are retained. This deliberately overrides the input audit's main metric/normalization in the combined report; the manifest records the original metric. Use the standalone audit command for original raw-vector normalization experiments. Source population statistics remain distinct from the evaluated geometry sample.

For millions of source rows, set `sample.strategy=uniform_rows` and a bounded `sample.max_rows` in the audit config. Its full source statistics stream; expensive geometry remains bounded and exact. The default combined evaluation cap is 5,000 rows. This release does not provide ANN or GPU search.

## What is implemented

- Shared typed IDs, evaluation cohort, exclusions, vector hashes, graph hash, source fingerprint, code hash, and evaluation split provenance.
- Existing Ecology flat atlas, 3D mesh, relief, spectra, subsets, routes, display scaling, geometry lab and geometry-only observer.
- Existing feature audit report: source statistics, organization, probes, annotation nulls, missingness experiments, supplied predictions, paired embeddings and optional topology.
- Observed feature/membership overlays, local known-neighbor counts, numeric differences, tag/set agreement, and missing-value display.
- Feature-distance neighborhoods with training-independent descriptive scaling, equalized feature-family weights, explicit comparable pools, and tie-aware overlap bounds.
- Symmetric pair-distance models using ridge and random forest, with item/group-held-out endpoints, training-only numeric scales, and baseline comparison. Edges are deliberately sampled from near/retained relations and a random reference mixture.
- Group-aware cross-fitted feature probes and whole-map held-out losses. Explicit train/test splits are respected; those runs only score the designated test items.
- Separate signed residual, absolute residual, support, stability and operational evidence profiles. Insufficient evidence remains explicit.
- Center/group-excluded local numeric tangent fits with ambient and raw-PCA directions exported to Parquet.
- Source intervention response import: measured displacements, neighbor retention, frozen attachments and repeated-transform directional consistency.
- Versioned investigation records and matched run comparisons for tracking explanatory vocabulary changes.
- Offline linked viewer, unknown-aware feature predicates, cohort A/B summaries, route profiles, and browser selection/record downloads.

These are runnable components, not placeholder interfaces. The boundaries are equally explicit: no automatic source encoder, no causal certification, no learned metric that silently changes the atlas, no automatic discovery of semantic labels, and no claim that unexplained structure is meaningful. Cross-model agreement is inspectable; unique or plural causal explanations are not automatically identified.

## Combined configuration

See [examples/combined_config.json](examples/combined_config.json). Unknown keys are rejected. Useful options:

| Option | Meaning |
|---|---|
| `scales` | Neighborhood sizes shared by Ecology, feature audit and bridge; integers ≥4 and <N−1 |
| `max_rows` | Hard ceiling for expensive common-cohort analysis |
| `max_pairs` | Maximum unique sampled explanatory pairs across near/reference classes |
| `folds` | Item/group folds; explicit source splits take precedence |
| `feature_families` | Optional positive weights by feature family; columns in one family share its weight |
| `min_pair_features` | Minimum number of jointly known explanatory features for a pair |
| `pair_models` | `ridge`, `forest`, or both |
| `probe_models` | Original audit probe names for cross-fitted probes |
| `min_local` | Minimum scored pair support for node-level candidate interpretation |
| `min_stability` | Operational perturbation-overlap threshold, not a significance test |
| `residual_margin` | Signed chord-residual margin for candidate profiles |
| `validation`, `nulls` | Ecology geometric controls and descriptive null corpora |
| `topology` | Enable the audit's bounded complete-distance filtrations/H1 |
| `tangent` | Export local numeric fits; adequate neighbor/group support required |
| `max_payload_bytes` | Hard budget for the combined offline browser snapshot |

Scales in the combined config replace the audit scales for the combined analysis. Sample selection and source semantics still come from the audit config. Whole-corpus geometry is transductive description: holding out labels for probes does not make the map itself training-only. Use the original Ecology scoring workflow for separate frozen training-map attachment experiments.

Features with `geometry=false` are inspectable as source values but do not enter the bridge's feature-distance account. Features with `probe=false` are not cross-fitted. Text and datetime remain inspectable; declare derived numeric/categorical targets for analyses. Ordinal distance uses the explicitly declared order; the preserved audit's category-based ordinal measures retain their original interpretation.

## Import interventions

Supply a Parquet or CSV table with `source_id`, `transformed_id`, `transform`, `parameters`, and `collateral_changes`. Rows must align exactly with an `.npy` matrix of transformed embeddings from the same encoder/dimension. Source IDs must be canonical IDs from the run. The import validates IDs, metadata, dimensions and the supplied encoder identifier; the user remains responsible for truthfully declaring encoder provenance.

```bash
python -m representation_ecology interventions \
  --run examples/omitted/run \
  --records examples/omitted/inputs/interventions.parquet \
  --vectors examples/omitted/inputs/intervention_vectors.npy \
  --encoder synthetic-v1 \
  --out intervention_results
```

The included transformation is an explicit shift of one synthetic latent coordinate before unit normalization. It is not an image/text intervention. For real sources, perform the transformation and encoding externally, document collateral changes, then import the results. An attached anchor's component is an attachment proxy, not proof that a transformed item belongs to a newly inferred component.

## Expand the explanatory vocabulary

For the omitted-factor demo, change `hidden_factor` from `role: ignore` to `role: feature, kind: numeric` in a **copy** of its input schema. Keep source data, vectors, groups, seeds and pair budget fixed. Run again in a fresh output folder and compare:

```bash
python -m representation_ecology compare --a old_run --b new_run --out comparison
```

The comparison checks geometry, IDs and evaluation policy, matches held-out pairs by endpoints/fold/model, and exports old/new absolute errors. Changes are observational model comparisons; exploratory discovery still needs fresh confirmation data. When geometry or evaluation policy changes, the output explicitly does not establish vocabulary-only progress.

## Save an investigation

In the browser, **Export IDs** downloads a JSON array. **Record → Export investigation** downloads a richer note carrying run/geometry/feature identities. Downloads do not mutate the source dataset.

To append a note to a run:

```bash
python -m representation_ecology record --run my_run --selection selection.json \
  --note "Stable boundary; test acquisition source as a candidate explanation" \
  --candidate acquisition_source
```

This writes an atomic history update at `investigations/history.json`. Use one writer per run; concurrent writers are not coordinated.

## Output map

- `index.html`: consolidated observer field guide; use localhost serving for linked rendering.
- `expert.html`: previous full workspace with all raw controls.
- `viewer_payload.json`, `viewer_manifest.json`: current-build display data and asset provenance.
- `geometry/`, `geometry_comparison/`: original frozen map artifacts and independent viewers.
- `audit/report.html`: preserved feature report and detailed figures/tables.
- `cohort.parquet`, `feature_schema.json`: evaluated source observations and their declared semantics.
- `embeddings_*.npy`, `raw_embeddings_*.npy`: canonical and original evaluated vectors.
- `source_population/`: source-scope summaries and table index.
- `bridge/`: local feature tables, expected neighbors, pair models, probe predictions, statuses, tangents and browser fields.
- `manifest.json`: source/code/vector/graph/feature/evaluation identities and limitations.
- `run_status.json`: complete or failed status, timing and error.
- `investigations/history.json`: appended investigation notes.

Mixed numeric/categorical probe targets in `bridge/probe_predictions.parquet` use `true_json`, `predicted_json`, and `probabilities_json`. JSON preserves their value types without forcing unrelated target kinds into one Arrow scalar type. Browser values remain native JSON numbers/strings/lists.

## Tests

```bash
python -m unittest discover -s tests -p test_combined.py -v
python -m unittest discover -s tests/ecology -v
node tests/landscape_state.cjs
node tests/guide_state.cjs
node tests/ecology/scale_state.cjs
node tests/ecology/reference_state.cjs
node tests/ecology/observer_state.cjs
```

Optional browser checks:

```bash
python -m pip install -e '.[test]'
python -m playwright install chromium
python tests/browser_combined.py --run examples/field-guide/run
python tests/browser_expert.py --run examples/field-guide/run
python tests/browser_scales.py --run examples/offline-small/run
```

The browser checks start their own local servers. They verify all twelve geometry fields, local spectra, continuous feature/error surfaces, finite-support masks, raw-value isolines, signed symmetry, relief flattening and exaggeration, keyboard movement, fixed coordinates, and the full workspace. See [verification and implementation notes](docs/IMPLEMENTATION.md).

## Project organization

`src/representation_ecology/` owns the new coordination, feature metrics, disagreement models, viewer and investigation workflows. `src/geometric_ecology/`, `src/parquet_audit/`, and `src/embedding_feature_audit/` preserve the supplied implementations. Ecology has a narrow validated precomputed-neighbor hook and a geometry-only observer selection API for host integration. The original state tests have been relocated with corrected paths.

The attached conceptual direction and the assessment that motivated this implementation are preserved in `docs/`. Original project guides remain under `docs/ecology/` and `docs/audit/`.
