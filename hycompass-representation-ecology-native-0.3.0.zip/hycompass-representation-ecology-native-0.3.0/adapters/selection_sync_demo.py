#!/usr/bin/env python3
"""Demonstrate revisioned WorkingSelection synchronization.

The script subscribes to SSE, then requests a small delta from the last known
selection revision. If the server cannot provide that delta, it falls back to a
revision-pinned paginated snapshot. It uses only the Python standard library.
"""
from __future__ import annotations

import argparse
import json
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


def get_json(url: str):
    with urlopen(url) as r:return json.load(r)


def snapshot(base: str, view: str, revision: int) -> list[str]:
    ids=[]; offset=0
    while True:
        q=urlencode({"revision":revision,"offset":offset,"limit":10000})
        page=get_json(f"{base}/views/{view}/working-selection?{q}")
        ids.extend(page["item_ids"])
        nxt=page.get("next_offset")
        if nxt is None:return ids
        offset=int(nxt)


def main():
    p=argparse.ArgumentParser(); p.add_argument("--base-url",default="http://127.0.0.1:8765"); p.add_argument("--view",required=True); a=p.parse_args()
    base=a.base_url.rstrip("/")
    state=get_json(f"{base}/views/{a.view}/working-selection/state")
    revision=int(state["revision"]); ids=snapshot(base,a.view,revision)
    print(f"initial revision={revision} count={len(ids):,}",flush=True)

    url=f"{base}/events?"+urlencode({"view":a.view,"types":"working_selection.changed","heartbeat":15})
    with urlopen(Request(url,headers={"Accept":"text/event-stream"})) as response:
        event_type=None; data=[]
        for raw in response:
            line=raw.decode().rstrip("\r\n")
            if not line:
                if event_type=="working_selection.changed" and data:
                    event=json.loads("\n".join(data)); target=int(event["revision"])
                    delta=get_json(f"{base}/views/{a.view}/working-selection/delta?"+urlencode({"since_revision":revision,"include_item_ids":"true"}))
                    if delta.get("snapshot_required"):
                        ids=snapshot(base,a.view,target)
                        print(f"snapshot revision={target} count={len(ids):,}",flush=True)
                    else:
                        current=set(ids)
                        current.difference_update(delta.get("removed_item_ids",[])); current.update(delta.get("added_item_ids",[]))
                        ids=list(current)
                        print(f"delta {revision}->{target} +{len(delta.get('added_item_ids',[]))} -{len(delta.get('removed_item_ids',[]))} count={len(ids):,}",flush=True)
                    revision=target
                event_type=None; data=[]; continue
            if line.startswith(":"):continue
            field,_,value=line.partition(":"); value=value.lstrip()
            if field=="event":event_type=value
            elif field=="data":data.append(value)


if __name__=="__main__":main()
