#!/usr/bin/env python3
"""Export Latent Observer rows/features for Embedding Atlas.

WorkingSelection export targets a concrete runtime View because interaction state
belongs to that View. Query export may instead use either a View or an ad-hoc
Domain + Projection (+ optional Timeline) context, matching the REST data plane.
An optional external enricher (module:function) may add Hydrus or arbitrary
metadata before output; Latent Observer never interprets those columns.

`adapters/export_embedding_atlas.py` exports a WorkingSelection or PointQuery to CSV, JSONL, or Parquet while preserving the app's precomputed `x` / `y` coordinates.

```bash
python adapters/export_embedding_atlas.py \
  --view default \
  --source working \
  --features position,timeline,density:global-density,segmentation:global-watershed \
  --output selected.parquet
```

Query-based export does not require a View:

```bash
python adapters/export_embedding_atlas.py \
  --source query \
  --domain alpha \
  --projection alpha-ipca \
  --timeline alpha-time \
  --query-json query.json \
  --features position,timeline,cluster:alpha-birch,density:alpha-ipca-density \
  --output selected.parquet
```

A WorkingSelection is interactive View state, so `--source working` still requires `--view`.

An optional external `--enricher module:function` receives `list[dict]` and may append Hydrus or arbitrary metadata before export. Latent Observer itself never interprets those columns.
"""
from __future__ import annotations

import argparse
import csv
import importlib
import json
import urllib.request
from pathlib import Path


def request_json(url, method="GET", payload=None):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as response:
        return json.loads(response.read().decode("utf-8"))


def load_enricher(name):
    if not name:
        return None
    module, func = name.split(":", 1)
    return getattr(importlib.import_module(module), func)


def data_context(args) -> dict:
    if args.view:
        return {"view": args.view}
    if not args.domain or not args.projection:
        raise SystemExit("query export requires --view OR both --domain and --projection")
    result = {"domain": args.domain, "projection": args.projection}
    if args.timeline:
        result["timeline"] = args.timeline
    if args.timeline_progress is not None:
        result["timeline_progress"] = float(args.timeline_progress)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--api-url", default="http://127.0.0.1:8765")
    p.add_argument("--view", help="runtime/saved View context")
    p.add_argument("--domain", help="ad-hoc query context Domain (query source only)")
    p.add_argument("--projection", help="ad-hoc query context Projection (query source only)")
    p.add_argument("--timeline", help="optional Timeline for temporal query/features")
    p.add_argument("--timeline-progress", type=float, default=None)
    p.add_argument("--source", choices=("working", "query"), default="working")
    p.add_argument("--query-json", type=Path)
    p.add_argument("--features", default="position,timeline")
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--enricher", help="optional module:function receiving/returning list[dict]")
    args = p.parse_args()
    base = args.api_url.rstrip("/")

    if args.source == "working" and not args.view:
        raise SystemExit("WorkingSelection is runtime View state; --source working requires --view")
    context = data_context(args)
    where = json.loads(args.query_json.read_text()) if args.query_json else {"op": "all"}
    features = [x.strip() for x in args.features.split(",") if x.strip()]

    records: list[dict] = []
    offset = 0
    while True:
        if args.source == "working":
            page = request_json(f"{base}/views/{args.view}/working-selection?offset={offset}&limit=10000")
            rows = page["rows"]
            if rows:
                payload = {**context, "rows": rows, "features": features}
                records.extend(request_json(f"{base}/items/features", "POST", payload)["items"])
        else:
            # Query/features avoids a second row-resolution round trip and works
            # without an open GUI View when domain/projection are provided.
            payload = {**context, "where": where, "offset": offset, "limit": 10000, "features": features}
            page = request_json(f"{base}/query/features", "POST", payload)
            records.extend(page["items"])
        nxt = page.get("next_offset")
        if nxt is None:
            break
        offset = int(nxt)

    enricher = load_enricher(args.enricher)
    if enricher is not None:
        enriched = enricher(records)
        records = records if enriched is None else enriched

    args.output.parent.mkdir(parents=True, exist_ok=True)
    suffix = args.output.suffix.lower()
    if suffix in {".jsonl", ".ndjson"}:
        with args.output.open("w", encoding="utf-8") as f:
            for record in records:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
    elif suffix == ".parquet":
        try:
            import pandas as pd
        except ImportError as exc:
            raise SystemExit("Parquet output requires pandas + pyarrow") from exc
        pd.DataFrame.from_records(records).to_parquet(args.output, index=False)
    else:
        keys: list[str] = []
        for record in records:
            for key in record:
                if key not in keys:
                    keys.append(key)
        with args.output.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(records)
    print(f"Wrote {len(records):,} rows to {args.output}")


if __name__ == "__main__":
    main()
