#!/usr/bin/env python3
"""Minimal stdlib SSE client for Latent Observer v0.5.4.

Examples:
  python adapters/watch_events.py --view default
  python adapters/watch_events.py --types working_selection.changed,active_view.changed

This deliberately keeps SSE as the notification channel. When a WorkingSelection
changes, use the normal REST snapshot/delta/feature endpoints for bulk data.
"""
from __future__ import annotations

import argparse
import json
from urllib.parse import urlencode
from urllib.request import Request, urlopen


def parse_args():
    p=argparse.ArgumentParser()
    p.add_argument("--base-url",default="http://127.0.0.1:8765")
    p.add_argument("--view")
    p.add_argument("--domain")
    p.add_argument("--types",default="working_selection.changed,point_predicate.changed,active_view.changed")
    p.add_argument("--last-event-id",type=int)
    return p.parse_args()


def main():
    a=parse_args()
    query={"heartbeat":15}
    if a.view:query["view"]=a.view
    if a.domain:query["domain"]=a.domain
    if a.types:query["types"]=a.types
    url=a.base_url.rstrip("/")+"/events?"+urlencode(query)
    headers={"Accept":"text/event-stream"}
    if a.last_event_id is not None:headers["Last-Event-ID"]=str(a.last_event_id)
    req=Request(url,headers=headers)
    event_type="message"; event_id=None; data=[]
    with urlopen(req,timeout=None) as response:
        for raw in response:
            line=raw.decode("utf-8").rstrip("\r\n")
            if not line:
                if data:
                    payload=json.loads("\n".join(data))
                    print(json.dumps({"id":event_id,"event":event_type,"payload":payload},indent=2,ensure_ascii=False),flush=True)
                event_type="message"; event_id=None; data=[]
                continue
            if line.startswith(":"):continue
            field,_,value=line.partition(":")
            value=value.lstrip()
            if field=="id":event_id=value
            elif field=="event":event_type=value
            elif field=="data":data.append(value)


if __name__=="__main__":
    main()
