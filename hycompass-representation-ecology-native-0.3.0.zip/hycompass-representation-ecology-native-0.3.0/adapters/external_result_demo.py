#!/usr/bin/env python3
"""Minimal example of an *external* analysis loop.

This file intentionally lives under adapters/, outside the Latent Observer core.
It fetches app-native features, applies an arbitrary ranking, sends the ordered
items back as an ExternalResultSet, highlights them, and focuses the first item.
Replace the toy ranking with Hydrus metadata, model scores, a notebook, etc.

`adapters/external_result_demo.py` demonstrates the reverse path: retrieve rows, perform an intentionally external toy ranking, create an ordered ResultSet, highlight it, and focus rank 1.

For large data transfers, page `/query` and request features in batches rather than emitting giant JSON responses in one call.
"""
from __future__ import annotations

import argparse
import json
import urllib.request


def request_json(url: str, method: str = "GET", payload=None):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as response:
        return json.loads(response.read().decode("utf-8"))


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--api-url", default="http://127.0.0.1:8765")
    p.add_argument("--view", default="default")
    p.add_argument("--density", required=True, help="density asset used only for this external demonstration")
    p.add_argument("--top", type=int, default=25)
    args = p.parse_args()
    base = args.api_url.rstrip("/")

    working = request_json(f"{base}/views/{args.view}/working-selection?limit=10000")
    rows = working["rows"]
    if not rows:
        raise SystemExit("WorkingSelection is empty. Select some points first.")
    if working.get("next_offset") is not None:
        raise SystemExit("Demo intentionally limits itself to the first 10,000 selected rows.")

    response = request_json(
        f"{base}/items/features",
        "POST",
        {"view": args.view, "rows": rows, "features": [f"density:{args.density}"]},
    )
    key = f"density:{args.density}"
    records = [r for r in response["items"] if r.get(key) is not None]
    # Toy external ranking. This logic is deliberately NOT part of Latent Observer.
    records.sort(key=lambda r: float(r[key]), reverse=True)
    chosen = records[: max(1, args.top)]

    request_json(
        f"{base}/views/{args.view}/result-sets/external-demo",
        "POST",
        {
            "rows": [r["row"] for r in chosen],
            "scores": [r[key] for r in chosen],
            "labels": [f"external rank {i+1}" for i in range(len(chosen))],
            "highlight": True,
            "metadata": {"note": "toy ranking performed by adapters/external_result_demo.py"},
        },
    )
    if chosen:
        request_json(
            f"{base}/views/{args.view}/focus",
            "POST",
            {"result_set": "external-demo", "index": 0},
        )
    print(f"Submitted {len(chosen)} externally ordered results and focused rank 1.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
