from __future__ import annotations

from api.app import create_app


EXPECTED_ROUTES = {
    ("GET", "/assets/contracts"),
    ("GET", "/assets/catalog"),
    ("GET", "/health"),
    ("GET", "/events"),
    ("GET", "/state"),
    ("GET", "/active-view/state"),
    ("GET", "/views/{view_id}/state"),
    ("GET", "/views/{view_id}/working-selection/state"),
    ("GET", "/views/{view_id}/working-selection/delta"),
    ("GET", "/views/{view_id}/predicate/state"),
    ("GET", "/workspace"),
    ("GET", "/views"),
    ("POST", "/query"),
    ("POST", "/items/features"),
    ("POST", "/features/catalog"),
    ("POST", "/query/features"),
    ("GET", "/views/{view_id}/working-selection"),
    ("POST", "/views/{view_id}/working-selection/features"),
    ("POST", "/views/{view_id}/working-selection"),
    ("DELETE", "/views/{view_id}/working-selection"),
    ("POST", "/views/{view_id}/highlights"),
    ("DELETE", "/views/{view_id}/highlights"),
    ("POST", "/views/{view_id}/result-sets/{result_id}"),
    ("POST", "/views/{view_id}/focus"),
    ("POST", "/views/{view_id}/fit"),
    ("POST", "/views/{view_id}/visibility/query"),
    ("DELETE", "/views/{view_id}/visibility"),
    ("POST", "/assets/domains/register"),
    ("POST", "/assets/projections/register"),
    ("POST", "/assets/clusterings/register"),
    ("POST", "/assets/densities/register"),
    ("POST", "/assets/segmentations/register"),
    ("POST", "/assets/explorations/register"),
    ("POST", "/assets/selections/register"),
    ("POST", "/assets/timelines/register"),
    ("GET", "/saved-queries"),
    ("POST", "/saved-queries"),
    ("DELETE", "/saved-queries/{query_id}"),
    ("GET", "/saved-views"),
    ("DELETE", "/saved-views/{view_id}"),
    ("POST", "/workspace/reload"),
}


def test_schema_only_app_builds_without_workspace() -> None:
    app = create_app()
    schema = app.openapi()
    assert schema["info"]["version"] == "0.6.0"


def test_public_route_inventory_is_preserved() -> None:
    schema = create_app().openapi()
    observed = {
        (method.upper(), path)
        for path, path_item in schema["paths"].items()
        for method in path_item
        if method.upper() in {"GET", "POST", "DELETE", "PUT", "PATCH"}
    }
    assert observed == EXPECTED_ROUTES | {
        ("GET","/ecology/catalog"),("POST","/ecology/correspondence"),("POST","/ecology/features"),
        ("GET","/ecology/explorations"),("POST","/ecology/explorations"),
        ("GET","/ecology/explorations/{key}"),("GET","/ecology/explorations/{key}/plan"),("GET","/ecology/compare")}


def test_important_request_bodies_are_typed() -> None:
    schema = create_app().openapi()
    for path in [
        "/query",
        "/items/features",
        "/query/features",
        "/views/{view_id}/working-selection",
        "/assets/domains/register",
        "/assets/projections/register",
        "/saved-queries",
    ]:
        request_schema = schema["paths"][path]["post"]["requestBody"]["content"]["application/json"]["schema"]
        assert "$ref" in request_schema


def test_operations_are_tagged() -> None:
    schema = create_app().openapi()
    for path_item in schema["paths"].values():
        for method, operation in path_item.items():
            if method.lower() in {"get", "post", "delete", "put", "patch"}:
                assert operation.get("tags")
                assert "Untagged" not in operation["tags"]


def test_sse_is_documented_as_event_stream() -> None:
    schema = create_app().openapi()
    content = schema["paths"]["/events"]["get"]["responses"]["200"]["content"]
    assert "text/event-stream" in content
