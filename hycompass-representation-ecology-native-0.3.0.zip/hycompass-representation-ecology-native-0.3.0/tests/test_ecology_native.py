"""Offscreen native checks: actual Qt widgets/canvases, no simulated web UI."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import numpy as np
import pytest
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from ecology.demo import demo
from ecology.native import ExplorationWidget,ComparisonWidget,mesh_heights,supported_triangles
from ecology.jobs import Jobs
from ecology.instruments import generate
from ecology.store import Store

@pytest.fixture(scope='module')
def app():
    app=QApplication.instance() or QApplication([]);return app

@pytest.fixture(scope='module')
def workspace(tmp_path_factory):
    p=demo(tmp_path_factory.mktemp('native')/'demo',n=120,generate_results=False);s=Store(p)
    for k in ['shared-base','shared-distorted']:generate(s,k,['geometry','reconstruction'])
    return p


def test_actual_native_mesh_keyboard_profiles_and_all_fields(app,workspace):
    jobs=Jobs(workspace);w=ExplorationWidget(workspace,'shared-base',jobs,lambda *_:None);w.resize(1500,1000);w.show();app.processEvents()
    assert 'geometry' in w.loaded
    original=w.landscape.position.copy();w.landscape.canvas.setFocus();QTest.keyPress(w.landscape.canvas,Qt.Key.Key_W);w.landscape._move();QTest.keyRelease(w.landscape.canvas,Qt.Key.Key_W)
    assert not np.array_equal(original,w.landscape.position)
    QTest.keyPress(w.landscape.canvas,Qt.Key.Key_Left);w.landscape._move();QTest.keyRelease(w.landscape.canvas,Qt.Key.Key_Left);assert w.landscape.yaw>0
    for field in list(w.fields):
        w.field.setCurrentText(field);w.landscape.canvas.draw()
    assert len(w.plots.axes)==5
    w.mode.setChecked(True);w.landscape.canvas.draw();assert w.landscape.ax.name=='3d'
    w.relief.setValue(0);assert np.all(mesh_heights(w.landscape.values,0)[np.isfinite(w.landscape.values)]==0)
    w.relief.setValue(1);assert np.nanmax(np.abs(mesh_heights(w.landscape.values,1)))>0
    w.cap.setValue(3);assert w.definition['n_members']>3
    expected=w.store.membership(w.key).copy();w.save_navigation();w.dispose();w.close();jobs.close()
    np.testing.assert_array_equal(expected,Store(workspace).membership('shared-base'))


def test_population_state_survives_tabs_and_canonical_links(app,workspace):
    from ui.main_window import MainWindow
    from model.workspace import WorkspaceSession
    from api.runtime import RuntimeState
    window=MainWindow(WorkspaceSession(workspace),RuntimeState());population=window._current();xy=population.dataset.positions.copy();camera=(population.map.camera.view_center[0],population.map.camera.view_center[1],population.map.camera.zoom)
    exploration=window.open_exploration('shared-base');window._highlight_collection('items',np.array([0,3,7]))
    assert population.highlight_rows.tolist()==[0,3,7]
    np.testing.assert_array_equal(population.dataset.positions,xy)
    assert camera==(population.map.camera.view_center[0],population.map.camera.view_center[1],population.map.camera.zoom)
    window.tabs.setCurrentWidget(population);assert window._current() is population
    window.close()


def test_paired_native_comparison_and_degenerate_layouts(app,workspace):
    w=ComparisonWidget(workspace);w.a.setCurrentIndex(0);w.b.setCurrentIndex(1);w.refresh();assert w.left.arrays is not None and w.right.arrays is not None
    w.left.canvas.draw();w.right.canvas.draw();w.link(w.left,w.right);assert w.right.highlights.ndim==1
    xy=np.c_[np.arange(8),np.zeros(8)];assert len(supported_triangles(xy))==0
    xy=np.array([[0.,0],[1,0],[0,1],[1,1]]);assert len(supported_triangles(xy,np.array([0,0,1,1])))==0
    w.dispose();w.close()
