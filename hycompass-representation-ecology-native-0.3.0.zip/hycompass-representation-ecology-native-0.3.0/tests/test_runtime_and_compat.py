from __future__ import annotations

import numpy as np

from api.routes.views import _combine
from api.runtime import EventHub, RuntimeState, SUBSCRIBER_QUEUE_LIMIT


def test_runtime_state_constructs() -> None:
    runtime = RuntimeState()
    assert runtime.events.head == 0
    assert runtime.workspace_revision == 0


def test_event_replay_preserves_filters() -> None:
    hub = EventHub()
    hub.publish("view.opened", revision=1, view="a", domain="d")
    hub.publish("working_selection.changed", revision=2, view="a", domain="d")
    hub.publish("view.opened", revision=1, view="b", domain="d")

    sub, replay, resync, head = hub.subscribe(
        since_event_id=0,
        types={"view.*"},
        view="a",
    )
    try:
        assert not resync
        assert head == 3
        assert [event["type"] for event in replay] == ["view.opened"]
    finally:
        hub.unsubscribe(sub.token)


def test_slow_subscriber_collapses_to_resync_instruction() -> None:
    hub = EventHub(history_limit=2048)
    sub, _, _, _ = hub.subscribe()
    try:
        for index in range(SUBSCRIBER_QUEUE_LIMIT + 1):
            hub.publish("test.event", revision=index)
        event = sub.queue.get_nowait()
        assert event["type"] == "stream.resync_required"
        assert event["data"]["reason"] == "subscriber_queue_overflow"
    finally:
        hub.unsubscribe(sub.token)


def test_selection_combine_modes_match_legacy_behavior() -> None:
    current = np.array([1, 2, 4], dtype=np.uint32)
    incoming = np.array([2, 3, 3], dtype=np.uint32)

    assert _combine(current, incoming, "add").tolist() == [1, 2, 3, 4]
    assert _combine(current, incoming, "subtract").tolist() == [1, 4]
    assert _combine(current, incoming, "intersect").tolist() == [2]
    assert _combine(current, incoming, "anything-else").tolist() == [2, 3]
