#!/usr/bin/env python3
"""Manage modular workspace assets without rebuilding the complete domain."""
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from model.workspace import (
    ClusteringSpec,
    DensitySpec,
    DomainSpec,
    ExplorationSpec,
    ProjectionSpec,
    SegmentationSpec,
    SelectionSpec,
    ThemeSpec,
    TimelineSpec,
    ViewSpec,
    WorkspaceManifest,
    RegistrationError,
    register_domain,
    register_selection,
    register_timeline,
    register_projection,
    register_clustering,
    register_density,
    register_segmentation,
    register_exploration,
)
from model.projection import GaussianRandomProjection, IncrementalPCAProjection, PassthroughProjection, TSNEProjection, UMAPProjection
from model.clustering import BirchClustering, MiniBatchKMeansClustering
from model.source import IndexedNumpyEmbeddingSource, NumpyEmbeddingSource
from model.workspace.preparation import (
    _auto_density_grid,
    _auto_density_sigma,
    _auto_min_landmark_population,
    _auto_peak_distance,
    build_density_asset,
    build_exploration,
    build_segmentation_asset,
)


def _copy_mask(source: Path, destination: Path, n: int, chunk: int) -> None:
    arr = np.load(source, mmap_mode="r", allow_pickle=False)
    if arr.ndim != 1 or len(arr) != n or arr.dtype.kind not in "biu":
        raise ValueError(f"selection mask must be bool/integer [{n}]")
    destination.parent.mkdir(parents=True, exist_ok=True)
    out = np.lib.format.open_memmap(destination, mode="w+", dtype=np.uint8, shape=(n,))
    for lo in range(0, n, chunk):
        hi = min(n, lo + chunk)
        out[lo:hi] = np.asarray(arr[lo:hi], dtype=bool).astype(np.uint8)
    out.flush()


def _copy_timestamps(source: Path, destination: Path, n: int, chunk: int) -> None:
    arr = np.load(source, mmap_mode="r", allow_pickle=False)
    if arr.ndim != 1 or len(arr) != n or arr.dtype.kind not in "iu":
        raise ValueError(f"timestamps must be integer UNIX seconds [{n}]")
    destination.parent.mkdir(parents=True, exist_ok=True)
    out = np.lib.format.open_memmap(destination, mode="w+", dtype=np.int64, shape=(n,))
    for lo in range(0, n, chunk):
        hi = min(n, lo + chunk)
        out[lo:hi] = np.asarray(arr[lo:hi], dtype=np.int64)
    out.flush()


def _domain_size(manifest: WorkspaceManifest, domain_id: str) -> int:
    domain = manifest.domains[domain_id]
    if domain.n_items is not None:
        return int(domain.n_items)
    ids = np.load(manifest.resolve(domain.item_ids), mmap_mode="r", allow_pickle=False)
    return int(len(ids))


def _selection_mask(manifest: WorkspaceManifest, selection_id: str | None, domain_id: str) -> np.ndarray | None:
    if selection_id in (None, "all"):
        return None
    if selection_id not in manifest.selections:
        raise ValueError(f"unknown selection: {selection_id}")
    spec = manifest.selections[selection_id]
    if spec.domain != domain_id:
        raise ValueError("selection belongs to another domain")
    if spec.kind == "all":
        return None
    return np.load(manifest.resolve(spec.mask), mmap_mode="r", allow_pickle=False)


def _metadata_json(path: Path | None) -> dict:
    if path is None:
        return {}
    value = json.loads(path.expanduser().resolve().read_text())
    if not isinstance(value, dict):
        raise ValueError("metadata JSON must contain an object")
    return value


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Manage Latent Observer workspace assets")
    p.add_argument("--workspace", type=Path, required=True)
    sub = p.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="create an empty workspace for external/precomputed asset registration")
    init.add_argument("--force", action="store_true")

    sub.add_parser("list")

    ad = sub.add_parser("add-domain")
    ad.add_argument("--id", required=True)
    ad.add_argument("--version", type=int, default=1)
    ad.add_argument("--embeddings", type=Path, required=True)
    ad.add_argument("--item-ids", type=Path, required=True)
    ad.add_argument("--copy-files", action="store_true", help="copy large domain files into the workspace instead of referencing them")
    ad.add_argument("--replace", action="store_true")

    bp = sub.add_parser("build-projection")
    bp.add_argument("--id", required=True)
    bp.add_argument("--domain", required=True)
    bp.add_argument("--selection", help="optional subset-local projection scope; omit/all = complete domain")
    bp.add_argument("--method", choices=("auto", "passthrough", "ipca", "random", "tsne", "umap"), default="auto")
    bp.add_argument("--chunk-size", type=int, default=250_000)
    bp.add_argument("--random-projection-seed", type=int, default=42)
    bp.add_argument("--tsne-perplexity", type=float, default=30.0)
    bp.add_argument("--tsne-max-iter", type=int, default=750)
    bp.add_argument("--tsne-metric", default="euclidean")
    bp.add_argument("--umap-neighbors", type=int, default=15)
    bp.add_argument("--umap-min-dist", type=float, default=0.1)
    bp.add_argument("--umap-metric", default="cosine")
    bp.add_argument("--no-spatial-index", action="store_true")
    bp.add_argument("--replace", action="store_true")

    ap = sub.add_parser("add-projection", help="register externally computed domain-aligned [N,2] positions")
    ap.add_argument("--id", required=True)
    ap.add_argument("--domain", required=True)
    ap.add_argument("--positions", type=Path, required=True)
    ap.add_argument("--selection", help="subset scope; finite position rows must exactly match this selection")
    ap.add_argument("--x-order", type=Path, help="optional precomputed spatial-index row order")
    ap.add_argument("--x-sorted", type=Path, help="optional precomputed sorted x coordinates")
    ap.add_argument("--no-spatial-index", action="store_true", help="do not derive x_order/x_sorted when they are omitted")
    ap.add_argument("--world-bounds", type=float, nargs=4, metavar=("XMIN","XMAX","YMIN","YMAX"))
    ap.add_argument("--method", default="external")
    ap.add_argument("--storage", choices=("copy","reference"), default="copy")
    ap.add_argument("--metadata-json", type=Path)
    ap.add_argument("--chunk-size", type=int, default=1_000_000)
    ap.add_argument("--replace", action="store_true")

    s = sub.add_parser("add-selection")
    s.add_argument("--id", required=True)
    s.add_argument("--domain", required=True)
    s.add_argument("--mask", type=Path, required=True)
    s.add_argument("--source")
    s.add_argument("--storage", choices=("copy","reference"), default="copy")
    s.add_argument("--metadata-json", type=Path)
    s.add_argument("--replace", action="store_true")
    s.add_argument("--chunk-size", type=int, default=1_000_000)

    t = sub.add_parser("add-timeline")
    t.add_argument("--id", required=True)
    t.add_argument("--domain", required=True)
    t.add_argument("--timestamps", type=Path, required=True)
    t.add_argument("--missing-value", type=int, default=-1)
    t.add_argument("--storage", choices=("copy","reference"), default="copy")
    t.add_argument("--metadata-json", type=Path)
    t.add_argument("--replace", action="store_true")
    t.add_argument("--chunk-size", type=int, default=1_000_000)

    ac = sub.add_parser("add-clustering")
    ac.add_argument("--id", required=True)
    ac.add_argument("--domain", required=True)
    ac.add_argument("--labels", type=Path, required=True)
    ac.add_argument("--projection")
    ac.add_argument("--selection")
    ac.add_argument("--method", default="external")
    ac.add_argument("--storage", choices=("copy","reference"), default="copy")
    ac.add_argument("--metadata-json", type=Path)
    ac.add_argument("--replace", action="store_true")
    ac.add_argument("--chunk-size", type=int, default=1_000_000)

    bc = sub.add_parser("build-clustering")
    bc.add_argument("--id", required=True)
    bc.add_argument("--domain", required=True)
    bc.add_argument("--selection", help="optional membership scope used for fitting; labels remain domain-aligned")
    bc.add_argument("--method", choices=("minibatch-kmeans", "birch"), default="minibatch-kmeans")
    bc.add_argument("--clusters", type=int, default=32)
    bc.add_argument("--birch-threshold", type=float, default=0.7)
    bc.add_argument("--chunk-size", type=int, default=250_000)
    bc.add_argument("--replace", action="store_true")

    adens = sub.add_parser("add-density", help="register an externally computed scalar [H,W] density field")
    adens.add_argument("--id", required=True)
    adens.add_argument("--projection", required=True)
    adens.add_argument("--field", type=Path, required=True)
    adens.add_argument("--selection")
    adens.add_argument("--method", default="external")
    adens.add_argument("--storage", choices=("copy","reference"), default="copy")
    adens.add_argument("--value-range", choices=("unit","finite"), default="unit", help="unit validates the renderer/query [0,1] field contract")
    adens.add_argument("--metadata-json", type=Path)
    adens.add_argument("--replace", action="store_true")

    d = sub.add_parser("build-density")
    d.add_argument("--id")
    d.add_argument("--projection", required=True)
    d.add_argument("--selection", help="optional membership scope; omit/all = all projected rows")
    d.add_argument("--method", choices=("gaussian","adaptive-gaussian","histogram"), default="gaussian")
    d.add_argument("--grid", type=int)
    d.add_argument("--sigma", type=float)
    d.add_argument("--normalization-percentile", type=float, default=99.5)
    d.add_argument("--chunk-size", type=int, default=250_000)
    d.add_argument("--replace", action="store_true")

    aseg = sub.add_parser("add-segmentation", help="register external categorical [H,W] segmentation labels")
    aseg.add_argument("--id", required=True)
    aseg.add_argument("--projection", required=True)
    aseg.add_argument("--labels", type=Path, required=True)
    aseg.add_argument("--stats", type=Path, help="optional stats JSON; missing display statistics are derived")
    aseg.add_argument("--density", help="optional compatible density asset used for peak-density statistics")
    aseg.add_argument("--selection")
    aseg.add_argument("--method", default="external")
    aseg.add_argument("--storage", choices=("copy","reference"), default="copy")
    aseg.add_argument("--metadata-json", type=Path)
    aseg.add_argument("--chunk-size", type=int, default=250_000)
    aseg.add_argument("--replace", action="store_true")

    sg = sub.add_parser("build-segmentation")
    sg.add_argument("--id")
    sg.add_argument("--density", required=True)
    sg.add_argument("--method", choices=("watershed","connected-components"), default="watershed")
    sg.add_argument("--max-segments", type=int, default=128)
    sg.add_argument("--density-threshold", type=float, default=0.04)
    sg.add_argument("--peak-distance", type=int)
    sg.add_argument("--prominence", type=float, default=0.02)
    sg.add_argument("--min-population", type=int)
    sg.add_argument("--chunk-size", type=int, default=250_000)
    sg.add_argument("--replace", action="store_true")

    aexp = sub.add_parser("add-exploration", help="register external static [H,W] or temporal [T,H,W] exploration fields")
    aexp.add_argument("--id", required=True)
    aexp.add_argument("--projection", required=True)
    aexp.add_argument("--selection", required=True)
    aexp.add_argument("--frames", type=Path, required=True)
    aexp.add_argument("--timeline")
    aexp.add_argument("--timeline-start", type=int)
    aexp.add_argument("--timeline-end", type=int)
    aexp.add_argument("--method", default="external")
    aexp.add_argument("--storage", choices=("copy","reference"), default="copy")
    aexp.add_argument("--value-range", choices=("unit","finite"), default="unit")
    aexp.add_argument("--metadata-json", type=Path)
    aexp.add_argument("--replace", action="store_true")

    e = sub.add_parser("build-exploration")
    e.add_argument("--id")
    e.add_argument("--projection", required=True)
    e.add_argument("--selection", required=True)
    e.add_argument("--method", choices=("box-blur","gaussian","distance"), default="box-blur")
    e.add_argument("--timeline")
    e.add_argument("--frames", type=int, default=64)
    e.add_argument("--grid", type=int, default=256)
    e.add_argument("--radius", type=int, default=5)
    e.add_argument("--chunk-size", type=int, default=250_000)
    e.add_argument("--replace", action="store_true")

    th = sub.add_parser("add-theme")
    th.add_argument("--id", required=True)
    th.add_argument("--config", type=Path, required=True)
    th.add_argument("--replace", action="store_true")

    v = sub.add_parser("add-view")
    v.add_argument("--id", required=True)
    v.add_argument("--title")
    v.add_argument("--folder", default="")
    v.add_argument("--domain", required=True)
    v.add_argument("--projection", required=True)
    v.add_argument("--selection")
    v.add_argument("--timeline")
    v.add_argument("--clustering")
    v.add_argument("--density", action="append", default=[])
    v.add_argument("--segmentation", action="append", default=[])
    v.add_argument("--exploration")
    v.add_argument("--theme")
    return p


def main() -> int:
    args = parser().parse_args()
    if args.command == "init":
        root=args.workspace.expanduser().resolve()
        path=root/"workspace.json"
        if path.exists() and not args.force:
            raise ValueError(f"workspace already exists: {path}; use --force to replace the empty catalog")
        if args.force and root.exists():
            # Force replaces only the catalog; intentionally do not recursively
            # delete potentially huge externally managed asset files.
            path.unlink(missing_ok=True)
        manifest=WorkspaceManifest.empty(root); manifest.save()
        print(f"Initialized empty workspace: {root}")
        return 0

    manifest = WorkspaceManifest.load(args.workspace)

    if args.command == "list":
        for name, mapping in (
            ("domains", manifest.domains),
            ("projections", manifest.projections),
            ("selections", manifest.selections),
            ("timelines", manifest.timelines),
            ("clusterings", manifest.clusterings),
            ("densities", manifest.densities),
            ("segmentations", manifest.segmentations),
            ("explorations", manifest.explorations),
            ("themes", manifest.themes),
            ("saved_queries", manifest.saved_queries),
        ):
            print(f"{name}: {', '.join(mapping) or 'none'}")
        print("views: " + (", ".join(v.id for v in manifest.views) or "none"))
        return 0

    if args.command == "add-domain":
        spec=register_domain(
            manifest,asset_id=args.id,embeddings_path=args.embeddings,item_ids_path=args.item_ids,
            version=max(1,int(args.version)),storage=("copy" if args.copy_files else "reference"),
            replace=args.replace,chunk_size=250_000,
        )
        print(f"Registered domain {spec.id}@{spec.version}: {spec.n_items:,} × {spec.dimensions}")
        print(f"Complete-domain selection: {spec.id}-all")
        return 0

    if args.command == "build-projection":
        if args.domain not in manifest.domains:
            raise ValueError(f"unknown domain: {args.domain}")
        if args.id in manifest.projections and not args.replace:
            raise ValueError(f"projection {args.id!r} already exists; use --replace")
        domain = manifest.domains[args.domain]
        base_source = NumpyEmbeddingSource(manifest.resolve(domain.embeddings))
        n = base_source.n_items
        scope_id = args.selection
        if scope_id in (None, "all"):
            rows = np.arange(n, dtype=np.uint32)
            scope_id = None
            source = base_source
        else:
            if scope_id not in manifest.selections:
                raise ValueError(f"unknown selection: {scope_id}")
            selection = manifest.selections[scope_id]
            if selection.domain != domain.id:
                raise ValueError("selection belongs to another domain")
            if selection.kind == "all":
                rows = np.arange(n, dtype=np.uint32)
                scope_id = None
                source = base_source
            else:
                mask = np.load(manifest.resolve(selection.mask), mmap_mode="r", allow_pickle=False)
                rows = np.flatnonzero(np.asarray(mask, dtype=bool)).astype(np.uint32)
                if len(rows) < 2:
                    raise ValueError("subset-local projection requires at least two selected rows")
                source = IndexedNumpyEmbeddingSource(manifest.resolve(domain.embeddings), rows)

        method_name = args.method
        if method_name == "auto":
            method_name = "passthrough" if source.dimensions == 2 else "ipca"
        if method_name == "passthrough":
            method = PassthroughProjection()
        elif method_name == "ipca":
            method = IncrementalPCAProjection()
        elif method_name == "random":
            method = GaussianRandomProjection(seed=args.random_projection_seed)
        elif method_name == "tsne":
            method = TSNEProjection(
                perplexity=args.tsne_perplexity,
                max_iter=args.tsne_max_iter,
                metric=args.tsne_metric,
            )
        else:
            method = UMAPProjection(
                n_neighbors=args.umap_neighbors,
                min_dist=args.umap_min_dist,
                metric=args.umap_metric,
            )

        out_dir = manifest.root / "assets" / "projections" / args.id
        out_dir.mkdir(parents=True, exist_ok=True)
        local_path = out_dir / "_local_positions.npy"
        local = method.project(source, local_path, chunk_size=max(2, args.chunk_size))
        positions_path = out_dir / "positions.npy"
        full = np.lib.format.open_memmap(positions_path, mode="w+", dtype=np.float32, shape=(n, 2))
        full[:] = np.nan
        chunk = max(2, args.chunk_size)
        for lo in range(0, len(rows), chunk):
            hi = min(len(rows), lo + chunk)
            full[rows[lo:hi]] = np.asarray(local[lo:hi], dtype=np.float32)
        full.flush()
        local_xy = np.asarray(local, dtype=np.float32)
        xmin, xmax = float(local_xy[:,0].min()), float(local_xy[:,0].max())
        ymin, ymax = float(local_xy[:,1].min()), float(local_xy[:,1].max())
        if xmax <= xmin: xmin, xmax = xmin - .5, xmax + .5
        if ymax <= ymin: ymin, ymax = ymin - .5, ymax + .5
        del local
        local_path.unlink(missing_ok=True)

        x_order_ref = x_sorted_ref = None
        if not args.no_spatial_index:
            local_values = np.asarray(full[rows, 0], dtype=np.float32)
            order_local = np.argsort(local_values, kind="stable")
            x_order = rows[order_local].astype(np.uint32, copy=False)
            x_sorted = local_values[order_local].astype(np.float32, copy=False)
            np.save(out_dir / "x_order.npy", x_order, allow_pickle=False)
            np.save(out_dir / "x_sorted.npy", x_sorted, allow_pickle=False)
            x_order_ref = manifest.relative_or_absolute(out_dir / "x_order.npy")
            x_sorted_ref = manifest.relative_or_absolute(out_dir / "x_sorted.npy")

        manifest.projections[args.id] = ProjectionSpec(
            id=args.id,
            domain=domain.id,
            positions=manifest.relative_or_absolute(positions_path),
            domain_version=domain.version,
            x_order=x_order_ref,
            x_sorted=x_sorted_ref,
            selection=scope_id,
            world_bounds=(xmin, xmax, ymin, ymax),
            method=method.metadata().get("method"),
            metadata={**method.metadata(), "projected_items": int(len(rows)), "domain_items": int(n)},
        )
        manifest.save()
        WorkspaceManifest.load(manifest.root)
        print(f"Built projection {args.id}: {len(rows):,}/{n:,} domain rows")
        return 0

    if args.command == "add-projection":
        spec = register_projection(
            manifest, asset_id=args.id, domain_id=args.domain, positions_path=args.positions,
            selection_id=args.selection, x_order_path=args.x_order, x_sorted_path=args.x_sorted,
            build_spatial_index=not args.no_spatial_index, world_bounds=args.world_bounds,
            method=args.method, storage=args.storage, replace=args.replace,
            metadata=_metadata_json(args.metadata_json), chunk_size=max(1,args.chunk_size),
        )
        print(f"Registered external projection {spec.id}: {spec.positions}")
        if spec.x_order: print(f"Spatial index: {spec.x_order} / {spec.x_sorted}")
        return 0

    if args.command == "add-selection":
        spec=register_selection(
            manifest,asset_id=args.id,domain_id=args.domain,mask_path=args.mask,source=args.source,
            storage=args.storage,replace=args.replace,metadata=_metadata_json(args.metadata_json),
            chunk_size=max(1,args.chunk_size),
        )
        print(f"Registered selection {spec.id}: {spec.mask}")
        return 0

    if args.command == "add-timeline":
        spec=register_timeline(
            manifest,asset_id=args.id,domain_id=args.domain,timestamps_path=args.timestamps,
            missing_value=int(args.missing_value),storage=args.storage,replace=args.replace,
            metadata=_metadata_json(args.metadata_json),chunk_size=max(1,args.chunk_size),
        )
        print(f"Registered timeline {spec.id}: {spec.timestamps}")
        print("Temporal exploration assets depending on an older snapshot should be rebuilt or re-registered explicitly.")
        return 0

    if args.command == "add-clustering":
        spec = register_clustering(
            manifest, asset_id=args.id, domain_id=args.domain, labels_path=args.labels,
            projection_id=args.projection, selection_id=args.selection, method=args.method,
            storage=args.storage, replace=args.replace, metadata=_metadata_json(args.metadata_json),
            chunk_size=max(1,args.chunk_size),
        )
        print(f"Registered external clustering {spec.id}: {spec.labels}")
        return 0


    if args.command == "build-clustering":
        if args.domain not in manifest.domains:
            raise ValueError(f"unknown domain: {args.domain}")
        if args.id in manifest.clusterings and not args.replace:
            raise ValueError(f"clustering {args.id!r} exists; use --replace")
        domain=manifest.domains[args.domain]
        base_source=NumpyEmbeddingSource(manifest.resolve(domain.embeddings))
        n=base_source.n_items
        scope_id=None if args.selection in (None,"all") else args.selection
        if scope_id is None:
            fit_source=base_source; fit_rows=np.arange(n,dtype=np.uint32)
        else:
            mask=_selection_mask(manifest,scope_id,args.domain)
            fit_rows=np.flatnonzero(np.asarray(mask,dtype=bool)).astype(np.uint32)
            if len(fit_rows)<2: raise ValueError("clustering selection requires at least two rows")
            fit_source=IndexedNumpyEmbeddingSource(manifest.resolve(domain.embeddings),fit_rows)
        k=min(max(2,int(args.clusters)),fit_source.n_items)
        method=BirchClustering(threshold=args.birch_threshold,n_clusters=k) if args.method=="birch" else MiniBatchKMeansClustering(k)
        out_dir=manifest.root/"assets"/"clustering"/args.id; out_dir.mkdir(parents=True,exist_ok=True)
        local_path=out_dir/"_local_labels.npy"
        local=method.cluster(fit_source,local_path,chunk_size=max(2,args.chunk_size))
        labels_path=out_dir/"labels.npy"
        full=np.lib.format.open_memmap(labels_path,mode="w+",dtype=np.uint32,shape=(n,))
        # 0 is reserved for rows outside a subset-fit clustering; fitted labels are shifted by one.
        if scope_id is None:
            full[:]=np.asarray(local,dtype=np.uint32)
        else:
            full[:]=0
            full[fit_rows]=np.asarray(local,dtype=np.uint32)+1
        full.flush(); del local; local_path.unlink(missing_ok=True)
        manifest.clusterings[args.id]=ClusteringSpec(id=args.id,domain=args.domain,labels=manifest.relative_or_absolute(labels_path),domain_version=domain.version,projection=None,selection=scope_id,method=method.metadata().get("method"),metadata=method.metadata())
        manifest.save(); WorkspaceManifest.load(manifest.root)
        print(f"Built clustering {args.id}: {labels_path}")
        return 0

    if args.command == "add-density":
        spec = register_density(
            manifest, asset_id=args.id, projection_id=args.projection, field_path=args.field,
            selection_id=args.selection, method=args.method, storage=args.storage,
            value_range=args.value_range, replace=args.replace, metadata=_metadata_json(args.metadata_json),
        )
        print(f"Registered external density {spec.id}: {spec.field}")
        return 0

    if args.command == "build-density":
        if args.projection not in manifest.projections:
            raise ValueError(f"unknown projection: {args.projection}")
        projection = manifest.projections[args.projection]
        selection_id = None if args.selection in (None, "all") else args.selection
        selection_mask = _selection_mask(manifest, selection_id, projection.domain)
        asset_id = args.id or f"{projection.id}-{selection_id or 'all'}-density"
        if asset_id in manifest.densities and not args.replace:
            raise ValueError(f"density {asset_id!r} exists; use --replace")
        positions = np.load(manifest.resolve(projection.positions), mmap_mode="r", allow_pickle=False)
        bounds = tuple(map(float, projection.world_bounds)) if projection.world_bounds else None
        if bounds is None:
            finite = np.isfinite(positions).all(axis=1)
            if not np.any(finite):
                raise ValueError("projection has no finite positions")
            xy = np.asarray(positions[finite], dtype=np.float32)
            bounds = (float(xy[:,0].min()), float(xy[:,0].max()), float(xy[:,1].min()), float(xy[:,1].max()))
        population = int(np.count_nonzero(np.isfinite(positions).all(axis=1)))
        if selection_mask is not None:
            population = int(np.count_nonzero(np.isfinite(positions).all(axis=1) & np.asarray(selection_mask, dtype=bool)))
        grid = args.grid if args.grid is not None else _auto_density_grid(population)
        sigma = args.sigma if args.sigma is not None else _auto_density_sigma(grid)
        dst = manifest.root / "assets" / "density" / asset_id / "density.npy"
        metadata = build_density_asset(
            positions=positions,
            bounds=bounds,
            output_path=dst,
            selection_mask=selection_mask,
            requested_grid=grid,
            requested_sigma=sigma,
            normalization_percentile=args.normalization_percentile,
            chunk_size=max(1, args.chunk_size),
            method=args.method,
        )
        manifest.densities[asset_id] = DensitySpec(
            id=asset_id,
            projection=projection.id,
            field=manifest.relative_or_absolute(dst),
            selection=selection_id,
            method=args.method,
            metadata=metadata,
        )
        manifest.save()
        WorkspaceManifest.load(manifest.root)
        print(f"Built density {asset_id}: {dst}")
        return 0

    if args.command == "add-segmentation":
        spec = register_segmentation(
            manifest, asset_id=args.id, projection_id=args.projection, labels_path=args.labels,
            stats_path=args.stats, density_id=args.density, selection_id=args.selection,
            method=args.method, storage=args.storage, replace=args.replace,
            metadata=_metadata_json(args.metadata_json), chunk_size=max(1,args.chunk_size),
        )
        print(f"Registered external segmentation {spec.id}: {spec.labels}")
        print(f"Stats: {spec.stats}")
        return 0

    if args.command == "build-segmentation":
        if args.density not in manifest.densities:
            raise ValueError(f"unknown density: {args.density}")
        density_spec = manifest.densities[args.density]
        projection = manifest.projections[density_spec.projection]
        selection_mask = _selection_mask(manifest, density_spec.selection, projection.domain)
        asset_id = args.id or f"{density_spec.id}-watershed"
        if asset_id in manifest.segmentations and not args.replace:
            raise ValueError(f"segmentation {asset_id!r} exists; use --replace")
        positions = np.load(manifest.resolve(projection.positions), mmap_mode="r", allow_pickle=False)
        density = np.load(manifest.resolve(density_spec.field), mmap_mode="r", allow_pickle=False)
        bounds = tuple(map(float, projection.world_bounds)) if projection.world_bounds else None
        if bounds is None:
            finite = np.isfinite(positions).all(axis=1)
            xy = np.asarray(positions[finite], dtype=np.float32)
            bounds = (float(xy[:,0].min()), float(xy[:,0].max()), float(xy[:,1].min()), float(xy[:,1].max()))
        population = int(np.count_nonzero(np.isfinite(positions).all(axis=1)))
        if selection_mask is not None:
            population = int(np.count_nonzero(np.isfinite(positions).all(axis=1) & np.asarray(selection_mask, dtype=bool)))
        out_dir = manifest.root / "assets" / "segmentation" / asset_id
        labels_path = out_dir / "labels.npy"
        stats_path = out_dir / "stats.json"
        metadata = build_segmentation_asset(
            positions=positions,
            density=density,
            bounds=bounds,
            labels_path=labels_path,
            stats_path=stats_path,
            selection_mask=selection_mask,
            max_segments=max(1, args.max_segments),
            threshold=args.density_threshold,
            peak_distance=(args.peak_distance if args.peak_distance is not None else _auto_peak_distance(max(density.shape))),
            prominence=max(0.0, args.prominence),
            min_population=(args.min_population if args.min_population is not None else _auto_min_landmark_population(population)),
            chunk_size=max(1, args.chunk_size),
            method=args.method,
        )
        manifest.segmentations[asset_id] = SegmentationSpec(
            id=asset_id,
            projection=projection.id,
            labels=manifest.relative_or_absolute(labels_path),
            stats=manifest.relative_or_absolute(stats_path),
            density=density_spec.id,
            selection=density_spec.selection,
            method=args.method,
            metadata=metadata,
        )
        manifest.save()
        WorkspaceManifest.load(manifest.root)
        print(f"Built segmentation {asset_id}: {labels_path}")
        return 0

    if args.command == "add-exploration":
        spec = register_exploration(
            manifest, asset_id=args.id, projection_id=args.projection, selection_id=args.selection,
            frames_path=args.frames, timeline_id=args.timeline, timeline_start=args.timeline_start,
            timeline_end=args.timeline_end, method=args.method, storage=args.storage,
            value_range=args.value_range, replace=args.replace, metadata=_metadata_json(args.metadata_json),
        )
        print(f"Registered external exploration {spec.id}: {spec.frames}")
        return 0

    if args.command == "build-exploration":
        if args.projection not in manifest.projections:
            raise ValueError(f"unknown projection: {args.projection}")
        projection = manifest.projections[args.projection]
        if args.selection not in manifest.selections:
            raise ValueError(f"unknown selection: {args.selection}")
        selection = manifest.selections[args.selection]
        if selection.domain != projection.domain:
            raise ValueError("selection and projection belong to different domains")
        timeline = None
        if args.timeline:
            timeline = manifest.timelines[args.timeline]
            if timeline.domain != projection.domain:
                raise ValueError("timeline and projection belong to different domains")
        asset_id = args.id or (
            f"{projection.id}-{selection.id}-{timeline.id}-exploration"
            if timeline else f"{projection.id}-{selection.id}-exploration"
        )
        if asset_id in manifest.explorations and not args.replace:
            raise ValueError(f"exploration {asset_id!r} exists; use --replace")

        positions = np.load(manifest.resolve(projection.positions), mmap_mode="r", allow_pickle=False)
        mask = None
        if selection.kind == "mask":
            mask = np.load(manifest.resolve(selection.mask), mmap_mode="r", allow_pickle=False)
        timestamps = None
        missing = -1
        if timeline:
            timestamps = np.load(manifest.resolve(timeline.timestamps), mmap_mode="r", allow_pickle=False)
            missing = timeline.missing_value
        bounds = projection.world_bounds
        if bounds is None:
            bounds = (
                float(np.min(positions[:, 0])), float(np.max(positions[:, 0])),
                float(np.min(positions[:, 1])), float(np.max(positions[:, 1])),
            )
        dst = manifest.root / "assets" / "exploration" / asset_id / "frames.npy"
        metadata = build_exploration(
            positions=positions,
            bounds=tuple(map(float, bounds)),
            output_path=dst,
            selection_mask=mask,
            timestamps=timestamps,
            missing_value=missing,
            frames=args.frames,
            grid=args.grid,
            radius=args.radius,
            chunk_size=max(1, args.chunk_size),
            method=args.method,
        )
        manifest.explorations[asset_id] = ExplorationSpec(
            id=asset_id,
            projection=projection.id,
            selection=selection.id,
            timeline=timeline.id if timeline else None,
            frames=manifest.relative_or_absolute(dst),
            method=args.method,
            metadata=metadata,
        )
        manifest.save()
        WorkspaceManifest.load(manifest.root)
        print(f"Built exploration {asset_id}: {dst}")
        return 0

    if args.command == "add-theme":
        if args.id in manifest.themes and not args.replace:
            raise ValueError(f"theme {args.id!r} exists; use --replace")
        source = args.config.expanduser().resolve()
        if not source.exists():
            raise FileNotFoundError(source)
        import json
        json.loads(source.read_text())  # validate JSON before copying
        dst = manifest.root / "themes" / f"{args.id}.json"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dst)
        manifest.themes[args.id] = ThemeSpec(id=args.id, config=manifest.relative_or_absolute(dst))
        manifest.save()
        print(f"Registered theme {args.id}: {dst}")
        return 0

    if args.command == "add-view":
        if any(v.id == args.id for v in manifest.views):
            raise ValueError(f"view {args.id!r} already exists")
        spec = ViewSpec(
            id=args.id,
            title=args.title or args.id,
            folder=args.folder,
            domain=args.domain,
            projection=args.projection,
            selection=args.selection,
            timeline=args.timeline,
            clustering=args.clustering,
            densities=list(args.density),
            segmentations=list(args.segmentation),
            exploration=args.exploration,
            theme=args.theme,
        )
        manifest.validate_view(spec)
        manifest.views.append(spec)
        manifest.save()
        print(f"Added view {args.id}")
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
