################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import numpy as np


################################################################################
# CLASSES
################################################################################
class Camera:
    def __init__(self, bounds: tuple[float, float, float, float]) -> None:
        self.bounds = bounds
        xmin, xmax, ymin, ymax = bounds
        self.data_center = np.array([(xmin + xmax) / 2, (ymin + ymax) / 2], np.float64)
        self.view_center = self.data_center.copy()
        self.zoom = 1.0

    def half_size(self, width: int, height: int) -> tuple[float, float]:
        xmin, xmax, ymin, ymax = self.bounds
        dw, dh = xmax - xmin, ymax - ymin
        aspect = max(width, 1) / max(height, 1)
        data_aspect = dw / dh
        if aspect >= data_aspect:
            half_h = 0.5 * dh * 1.05 / self.zoom
            half_w = half_h * aspect
        else:
            half_w = 0.5 * dw * 1.05 / self.zoom
            half_h = half_w / aspect
        return half_w, half_h

    def screen_to_world(self, x: float, y: float, width: int, height: int) -> np.ndarray:
        half_w, half_h = self.half_size(width, height)
        nx = float(x) / max(width, 1) * 2 - 1
        ny = 1 - float(y) / max(height, 1) * 2
        return np.array(
            [self.view_center[0] + nx * half_w, self.view_center[1] + ny * half_h],
            np.float64,
        )

    def reset(self) -> None:
        self.view_center = self.data_center.copy()
        self.zoom = 1.0

    def focus(self, position: np.ndarray, minimum_zoom: float = 18.0) -> None:
        self.view_center = np.asarray(position, dtype=np.float64).copy()
        self.zoom = max(self.zoom, minimum_zoom)

    def pan_pixels(self, dx: float, dy: float, width: int, height: int) -> None:
        half_w, half_h = self.half_size(width, height)
        self.view_center[0] -= dx * 2 * half_w / max(width, 1)
        self.view_center[1] += dy * 2 * half_h / max(height, 1)

    def zoom_at(
        self,
        steps: float,
        x: float,
        y: float,
        width: int,
        height: int,
    ) -> None:
        before = self.screen_to_world(x, y, width, height)
        self.zoom = float(np.clip(self.zoom * (1.22**steps), 0.15, 5000))
        after = self.screen_to_world(x, y, width, height)
        self.view_center += before - after

    def fit_points(self, positions: np.ndarray, width: int, height: int, padding: float = 1.15) -> None:
        pts = np.asarray(positions, dtype=np.float64)
        finite = np.isfinite(pts).all(axis=1)
        if not np.any(finite):
            return
        pts = pts[finite]
        xmin, xmax = float(pts[:, 0].min()), float(pts[:, 0].max())
        ymin, ymax = float(pts[:, 1].min()), float(pts[:, 1].max())
        self.view_center = np.array([(xmin + xmax) / 2.0, (ymin + ymax) / 2.0], dtype=np.float64)
        span_x = max(xmax - xmin, 1e-9) * padding
        span_y = max(ymax - ymin, 1e-9) * padding
        base_half_w, base_half_h = Camera(self.bounds).half_size(width, height)
        needed_zoom_x = (2.0 * base_half_w) / span_x
        needed_zoom_y = (2.0 * base_half_h) / span_y
        self.zoom = float(np.clip(min(needed_zoom_x, needed_zoom_y), 0.15, 5000.0))

    def world_to_screen(self, position: np.ndarray, width: int, height: int) -> tuple[float, float]:
        half_w, half_h = self.half_size(width, height)
        p = np.asarray(position, dtype=np.float64)
        nx = (p[0] - self.view_center[0]) / max(half_w, 1e-12)
        ny = (p[1] - self.view_center[1]) / max(half_h, 1e-12)
        return ((nx + 1.0) * 0.5 * width, (1.0 - ny) * 0.5 * height)


################################################################################
if __name__=="__main__":
    pass
