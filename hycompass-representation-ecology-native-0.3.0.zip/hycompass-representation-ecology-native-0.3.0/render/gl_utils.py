################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

try:
    from OpenGL import GL
except ImportError as exc:  # pragma: no cover - environment dependent
    raise SystemExit("PyOpenGL is required; install requirements.txt") from exc

##### Global Variables #####
SHADER_DIR = Path(__file__).with_name("shaders")


################################################################################
# FUNCTIONS
################################################################################
def load_shader(name: str) -> str:
    return (SHADER_DIR / name).read_text()


def compile_shader(src: str, kind: int) -> int:
    shader = GL.glCreateShader(kind)
    GL.glShaderSource(shader, src)
    GL.glCompileShader(shader)
    if not GL.glGetShaderiv(shader, GL.GL_COMPILE_STATUS):
        log = GL.glGetShaderInfoLog(shader).decode("utf-8", "replace")
        GL.glDeleteShader(shader)
        raise RuntimeError(log)
    return shader


def make_program(vertex_shader: str, fragment_shader: str) -> int:
    vertex = compile_shader(load_shader(vertex_shader), GL.GL_VERTEX_SHADER)
    fragment = compile_shader(load_shader(fragment_shader), GL.GL_FRAGMENT_SHADER)
    program = GL.glCreateProgram()
    GL.glAttachShader(program, vertex)
    GL.glAttachShader(program, fragment)
    GL.glLinkProgram(program)
    GL.glDeleteShader(vertex)
    GL.glDeleteShader(fragment)
    if not GL.glGetProgramiv(program, GL.GL_LINK_STATUS):
        log = GL.glGetProgramInfoLog(program).decode("utf-8", "replace")
        GL.glDeleteProgram(program)
        raise RuntimeError(log)
    return program


class UniformCache:
    def __init__(self) -> None:
        self._cache: dict[tuple[int, str], int] = {}

    def location(self, program: int, name: str) -> int:
        key = (int(program), name)
        if key not in self._cache:
            self._cache[key] = GL.glGetUniformLocation(program, name)
        return self._cache[key]


################################################################################
if __name__=="__main__":
    pass
