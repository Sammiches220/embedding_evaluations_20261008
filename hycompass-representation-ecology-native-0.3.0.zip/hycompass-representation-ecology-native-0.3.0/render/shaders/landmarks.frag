#version 330 core
in vec2 vUV;
uniform usampler2D uLabels;
uniform float uFillOpacity;
uniform int uShowFill;
uniform int uShowBoundary;
uniform float uBoundaryWidthPx;
uniform vec4 uBoundaryColor;
out vec4 fragColor;
vec3 hsv2rgb(vec3 c) {
    vec3 p=abs(fract(c.xxx+vec3(0.0,2.0/3.0,1.0/3.0))*6.0-3.0);
    return c.z*mix(vec3(1.0),clamp(p-1.0,0.0,1.0),c.y);
}
uint labelAt(vec2 uv) {
    ivec2 sz=textureSize(uLabels,0);
    vec2 clamped=clamp(uv,vec2(0.0),vec2(0.999999));
    ivec2 p=clamp(ivec2(clamped*vec2(sz)),ivec2(0),sz-ivec2(1));
    return texelFetch(uLabels,p,0).r;
}
void main() {
    uint id=labelAt(vUV);
    if (id==0u) discard;
    bool boundary=false;
    if (uShowBoundary != 0) {
        // fwidth(vUV) approximates one screen pixel in texture coordinates,
        // so width stays visually stable while zooming rather than expanding to
        // an entire segmentation raster cell.
        vec2 onePx=max(fwidth(vUV), vec2(1.0)/vec2(textureSize(uLabels,0)) * 0.15);
        vec2 d=onePx*max(uBoundaryWidthPx,0.5);
        boundary = labelAt(vUV+vec2(d.x,0))!=id || labelAt(vUV-vec2(d.x,0))!=id ||
                   labelAt(vUV+vec2(0,d.y))!=id || labelAt(vUV-vec2(0,d.y))!=id;
    }
    if (boundary) {
        fragColor=uBoundaryColor;
    } else if (uShowFill != 0) {
        float hue=fract(float(id)*0.61803398875);
        fragColor=vec4(hsv2rgb(vec3(hue,0.48,0.90)),uFillOpacity);
    } else discard;
}
