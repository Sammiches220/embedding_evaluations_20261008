#version 330 core

layout(location=0) in vec2 aPosition;
layout(location=1) in float aTimelineTime;
layout(location=2) in uint aCluster;
layout(location=3) in uint aSelected;
layout(location=4) in uint aVisible;

uniform vec2 uViewCenter;
uniform vec2 uHalfSize;
uniform float uTimeline;
uniform float uPointSize;
uniform int uHasTimeline;
uniform int uHasSelection;
uniform int uHasCluster;
uniform int uHasVisibility;
uniform int uClusterColors;
uniform int uShowActive;
uniform int uShowFuture;
uniform int uShowOutside;
uniform int uCapBackground;
uniform float uKeepFraction;
uniform vec4 uActiveColor;
uniform vec4 uFutureColor;
uniform vec4 uOutsideColor;

out vec3 vColor;
out float vAlpha;

vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(
        fract(
            c.xxx 
            + vec3(
                0.0, 
                2.0 / 3.0, 
                1.0 / 3.0
            )
        ) * 6.0 
        - 3.0
    );
    
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

float hash01(uint x) {
    x ^= x >> 16;
    x *= 0x7feb352du;
    x ^= x >> 15;
    x *= 0x846ca68bu;
    x ^= x >> 16;
    return float(x & 0x00ffffffu) / 16777215.0;
}

void hidePoint() {
    gl_Position = vec4(4.0, 4.0, 0.0, 1.0);
    gl_PointSize = 1.0;
}

void main() {
    if (isnan(aPosition.x) || isnan(aPosition.y) || (uHasVisibility != 0 && aVisible == 0u)) {
        hidePoint();
        return;
    }
    bool selected = (uHasSelection == 0) || (aSelected != 0u);
    bool seen = (uHasTimeline == 0) || (aTimelineTime <= uTimeline);
    bool isActivePoint = selected && seen;
    bool future = selected && !seen;
    bool outside = !selected;
    bool highlighting = (uHasSelection != 0) || (uHasTimeline != 0);

    bool visible = !highlighting ||
                   (isActivePoint && uShowActive != 0) ||
                   (future && uShowFuture != 0) ||
                   (outside && uShowOutside != 0);
    if (!visible) {
        hidePoint();
        return;
    }

    bool backgroundPoint = highlighting && !isActivePoint;
    if (backgroundPoint && uCapBackground != 0 && hash01(uint(gl_VertexID)) > uKeepFraction) {
        hidePoint();
        return;
    }

    vec2 ndc = (aPosition - uViewCenter) / uHalfSize;
    gl_Position = vec4(ndc, 0.0, 1.0);
    gl_PointSize = uPointSize;

    if (uClusterColors != 0 && uHasCluster != 0) {
        float hue = fract(float(aCluster + 1u) * 0.61803398875);
        vColor = hsv2rgb(vec3(hue, 0.62, 0.88));
        vAlpha = !highlighting ? 0.55 : (isActivePoint ? 0.90 : (future ? 0.25 : 0.10));
    } else if (!highlighting) {
        vColor = uFutureColor.rgb;
        vAlpha = max(uFutureColor.a, 0.42);
    } else if (isActivePoint) {
        vColor = uActiveColor.rgb;
        vAlpha = uActiveColor.a;
    } else if (future) {
        vColor = uFutureColor.rgb;
        vAlpha = uFutureColor.a;
    } else {
        vColor = uOutsideColor.rgb;
        vAlpha = uOutsideColor.a;
    }
}
