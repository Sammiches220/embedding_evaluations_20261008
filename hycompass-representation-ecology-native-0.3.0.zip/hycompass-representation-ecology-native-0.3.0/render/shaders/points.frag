#version 330 core
in vec3 vColor;
in float vAlpha;
uniform float uPointSize;
out vec4 fragColor;
void main() {
    if (uPointSize > 1.5) {
        vec2 p = gl_PointCoord * 2.0 - 1.0;
        if (dot(p,p) > 1.0) discard;
    }
    fragColor = vec4(vColor, vAlpha);
}
