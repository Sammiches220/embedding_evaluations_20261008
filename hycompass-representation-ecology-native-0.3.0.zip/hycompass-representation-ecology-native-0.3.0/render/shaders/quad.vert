#version 330 core
layout(location=0) in vec2 aPosition;
layout(location=1) in vec2 aUV;
uniform vec2 uViewCenter;
uniform vec2 uHalfSize;
out vec2 vUV;
void main() {
    gl_Position = vec4((aPosition-uViewCenter)/uHalfSize, 0.0, 1.0);
    vUV = aUV;
}
