#version 330 core
uniform vec4 uColor;
uniform int uRound;
out vec4 fragColor;
void main() {
    if (uRound!=0) {
        vec2 p=gl_PointCoord*2.0-1.0;
        if (dot(p,p)>1.0) discard;
    }
    fragColor=uColor;
}
