#version 330 core
layout(location=0) in vec2 aPosition;
uniform vec2 uViewCenter;
uniform vec2 uHalfSize;
uniform float uPointSize;
void main() {
    gl_Position=vec4((aPosition-uViewCenter)/uHalfSize,0.0,1.0);
    gl_PointSize=uPointSize;
}
