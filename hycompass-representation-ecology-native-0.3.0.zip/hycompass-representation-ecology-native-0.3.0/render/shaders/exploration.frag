#version 330 core
in vec2 vUV;
uniform sampler2DArray uFrames;
uniform float uTimeline;
uniform float uFrameCount;
uniform float uThreshold;
uniform float uOpacity;
uniform int uShowFill;
uniform int uShowBoundary;
uniform vec3 uPalette0;
uniform vec3 uPalette1;
uniform vec3 uPalette2;
uniform vec3 uPalette3;
uniform vec4 uBoundaryColor;
out vec4 fragColor;
vec3 palette(float x) {
    if (x<0.33) return mix(uPalette0,uPalette1,x/0.33);
    if (x<0.67) return mix(uPalette1,uPalette2,(x-0.33)/0.34);
    return mix(uPalette2,uPalette3,(x-0.67)/0.33);
}
void main() {
    float lf = uFrameCount <= 1.0 ? 0.0 : clamp(uTimeline,0.0,1.0)*(uFrameCount-1.0);
    float lo=floor(lf), hi=min(lo+1.0,max(uFrameCount-1.0,0.0)), f=fract(lf);
    float z=mix(texture(uFrames,vec3(vUV,lo)).r, texture(uFrames,vec3(vUV,hi)).r, f);
    if (z<uThreshold) discard;
    vec3 col=palette(z);
    float alpha = uShowFill != 0 ? uOpacity*(0.20+0.80*z) : 0.0;
    if (uShowBoundary != 0) {
        float w=max(fwidth(z)*2.5,0.004);
        float edge=1.0-smoothstep(0.0,w,z-uThreshold);
        if (edge > 0.0) {
            col=mix(col,uBoundaryColor.rgb,uBoundaryColor.a*edge);
            alpha=max(alpha,uBoundaryColor.a*edge);
        }
    }
    if (alpha <= 0.001) discard;
    fragColor=vec4(col,alpha);
}
