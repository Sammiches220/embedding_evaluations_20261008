#version 330 core
in vec2 vUV;
uniform sampler2D uField;
uniform float uOpacity;
uniform float uThreshold;
uniform float uContourLevels;
uniform int uShowFill;
uniform int uShowContours;
uniform vec3 uPalette0;
uniform vec3 uPalette1;
uniform vec3 uPalette2;
uniform vec3 uPalette3;
uniform vec4 uContourColor;
out vec4 fragColor;

vec3 palette(float x) {
    if (x<0.33) return mix(uPalette0,uPalette1,x/0.33);
    if (x<0.67) return mix(uPalette1,uPalette2,(x-0.33)/0.34);
    return mix(uPalette2,uPalette3,(x-0.67)/0.33);
}

void main() {
    float z=texture(uField,vUV).r;
    if (z<uThreshold || uOpacity<=0.0001) discard;

    vec3 fillColor=palette(z);
    float fillAlpha=0.0;
    if (uShowFill != 0) {
        // Opacity is a true layer-wide scalar.  The field may still taper near
        // the threshold, but every fill alpha is multiplied by uOpacity.
        float ramp=smoothstep(uThreshold, max(uThreshold+0.08, 0.12), z);
        fillAlpha=uOpacity*(0.10+0.90*ramp);
    }

    float contourMask=0.0;
    if (uShowContours != 0 && uContourLevels > 0.0) {
        // Place contours strictly inside (0,1).  The previous implementation
        // treated z==1 as a contour level; normalized plateaus at the maximum
        // could therefore become a solid filled "innermost contour".
        float scaled=z*(uContourLevels+1.0);
        float nearest=floor(scaled+0.5);
        bool interior = nearest>=1.0 && nearest<=uContourLevels;
        if (interior) {
            float dist=abs(scaled-nearest);
            float aa=max(fwidth(scaled),0.0035);
            contourMask=1.0-smoothstep(0.0,aa*1.15,dist);
        }
    }

    float contourAlpha=uOpacity*uContourColor.a*contourMask;
    float alpha=1.0-(1.0-fillAlpha)*(1.0-contourAlpha);
    if (alpha<=0.001) discard;

    vec3 color=fillColor;
    if (contourAlpha>0.0) {
        float mixAmount=contourAlpha/max(alpha,1e-6);
        color=mix(color,uContourColor.rgb,clamp(mixAmount,0.0,1.0));
    }
    fragColor=vec4(color,alpha);
}
