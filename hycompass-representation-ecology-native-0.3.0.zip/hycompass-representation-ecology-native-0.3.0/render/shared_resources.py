################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

##### Internal Imports #####
from .gl_utils import GL


################################################################################
# CLASSES
################################################################################
@dataclass(frozen=True)
class SharedBuffer:
    id: int
    nbytes: int


@dataclass(frozen=True)
class SharedTexture:
    id: int
    target: int
    nbytes: int


class SharedGLResourceCache:
    """Process-wide OpenGL buffer/texture cache.

    QOpenGLWidget contexts participate in Qt's global share group when
    ``AA_ShareOpenGLContexts`` is enabled before QApplication construction.
    Buffers and textures can therefore be reused across tabs / detached views.

    VAOs and dynamic selection/lasso buffers remain per renderer because VAO
    state is context-local and those buffers are tiny compared with domain data.
    The cache intentionally lives for the lifetime of the process.
    """

    _buffers: dict[tuple, SharedBuffer] = {}
    _textures: dict[tuple, SharedTexture] = {}

    @classmethod
    def buffer(cls, key: tuple, data: np.ndarray, *, kind: str = "raw") -> SharedBuffer:
        cache_key = ("buffer", kind, *key)
        hit = cls._buffers.get(cache_key)
        if hit is not None:
            return hit

        arr = np.asarray(data)
        if kind == "uint32":
            arr = np.asarray(arr, dtype=np.uint32)
        elif kind == "uint8":
            arr = np.asarray(arr, dtype=np.uint8)
        elif kind == "float32":
            arr = np.asarray(arr, dtype=np.float32)
        if not arr.flags.c_contiguous:
            arr = np.ascontiguousarray(arr)

        buffer_id = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, buffer_id)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, int(arr.nbytes), arr, GL.GL_STATIC_DRAW)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)
        result = SharedBuffer(int(buffer_id), int(arr.nbytes))
        cls._buffers[cache_key] = result
        return result

    @classmethod
    def texture_float2d(cls, key: tuple, data: np.ndarray) -> SharedTexture:
        cache_key = ("texture_float2d", *key)
        hit = cls._textures.get(cache_key)
        if hit is not None:
            return hit
        arr = np.asarray(data, dtype=np.float32)
        tex = GL.glGenTextures(1)
        GL.glBindTexture(GL.GL_TEXTURE_2D, tex)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_CLAMP_TO_EDGE)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_T, GL.GL_CLAMP_TO_EDGE)
        h, w = arr.shape
        GL.glTexImage2D(GL.GL_TEXTURE_2D, 0, GL.GL_R32F, w, h, 0, GL.GL_RED, GL.GL_FLOAT, arr)
        result = SharedTexture(int(tex), GL.GL_TEXTURE_2D, int(arr.nbytes))
        cls._textures[cache_key] = result
        return result

    @classmethod
    def texture_uint2d(cls, key: tuple, data: np.ndarray) -> SharedTexture:
        cache_key = ("texture_uint2d", *key)
        hit = cls._textures.get(cache_key)
        if hit is not None:
            return hit
        arr = np.asarray(data, dtype=np.uint32)
        tex = GL.glGenTextures(1)
        GL.glBindTexture(GL.GL_TEXTURE_2D, tex)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_NEAREST)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_NEAREST)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_CLAMP_TO_EDGE)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_T, GL.GL_CLAMP_TO_EDGE)
        h, w = arr.shape
        GL.glTexImage2D(
            GL.GL_TEXTURE_2D,
            0,
            GL.GL_R32UI,
            w,
            h,
            0,
            GL.GL_RED_INTEGER,
            GL.GL_UNSIGNED_INT,
            arr,
        )
        result = SharedTexture(int(tex), GL.GL_TEXTURE_2D, int(arr.nbytes))
        cls._textures[cache_key] = result
        return result

    @classmethod
    def texture_half_array(cls, key: tuple, data: np.ndarray) -> SharedTexture:
        cache_key = ("texture_half_array", *key)
        hit = cls._textures.get(cache_key)
        if hit is not None:
            return hit
        arr = np.asarray(data, dtype=np.float16)
        if arr.ndim == 2:
            arr = arr[np.newaxis, ...]
        tex = GL.glGenTextures(1)
        GL.glBindTexture(GL.GL_TEXTURE_2D_ARRAY, tex)
        GL.glTexParameteri(GL.GL_TEXTURE_2D_ARRAY, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D_ARRAY, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D_ARRAY, GL.GL_TEXTURE_WRAP_S, GL.GL_CLAMP_TO_EDGE)
        GL.glTexParameteri(GL.GL_TEXTURE_2D_ARRAY, GL.GL_TEXTURE_WRAP_T, GL.GL_CLAMP_TO_EDGE)
        frames, h, w = arr.shape
        GL.glTexImage3D(
            GL.GL_TEXTURE_2D_ARRAY,
            0,
            GL.GL_R16F,
            w,
            h,
            frames,
            0,
            GL.GL_RED,
            GL.GL_HALF_FLOAT,
            arr,
        )
        result = SharedTexture(int(tex), GL.GL_TEXTURE_2D_ARRAY, int(arr.nbytes))
        cls._textures[cache_key] = result
        return result


################################################################################
if __name__=="__main__":
    pass
