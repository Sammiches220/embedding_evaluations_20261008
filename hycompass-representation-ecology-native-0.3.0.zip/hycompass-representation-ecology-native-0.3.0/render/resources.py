################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import ctypes

import numpy as np

##### Internal Imports #####
from model.workspace.session import ViewData
from .gl_utils import GL
from .shared_resources import SharedGLResourceCache


################################################################################
# CLASSES
################################################################################
class GLResources:
    """Per-view VAOs/dynamic masks plus process-shared heavy static resources."""

    def __init__(self, dataset: ViewData) -> None:
        self.dataset = dataset
        self.vao = 0
        self.quad_vao = 0
        self.quad_vbo = 0
        self.ebo_selection = 0
        self.ebo_highlight = 0

        self.position_buffer = 0
        self.timeline_buffer = 0
        self.cluster_buffer = 0
        self.selection_buffer = 0
        self.visibility_buffer = 0
        self.visibility_mask: np.ndarray | None = None
        self.visibility_dirty = False

        self.density_textures: list[int] = []
        self.segmentation_textures: list[int] = []
        self.exploration_texture = 0

    def initialize(self) -> None:
        ds = self.dataset
        self.vao = GL.glGenVertexArrays(1)
        GL.glBindVertexArray(self.vao)

        position = SharedGLResourceCache.buffer((ds.positions_key,), ds.positions, kind="float32")
        self.position_buffer = position.id
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.position_buffer)
        GL.glEnableVertexAttribArray(0)
        GL.glVertexAttribPointer(0, 2, GL.GL_FLOAT, False, 0, None)

        if ds.normalized_timeline is not None:
            timeline = SharedGLResourceCache.buffer((ds.timeline_key or f"view:{ds.spec.id}:timeline",), ds.normalized_timeline, kind="float32")
            self.timeline_buffer = timeline.id
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.timeline_buffer)
            GL.glEnableVertexAttribArray(1)
            GL.glVertexAttribPointer(1, 1, GL.GL_FLOAT, False, 0, None)
        else:
            GL.glDisableVertexAttribArray(1)
            GL.glVertexAttrib1f(1, 2.0)

        if ds.cluster is not None:
            cluster = SharedGLResourceCache.buffer((ds.cluster_key or f"view:{ds.spec.id}:cluster",), ds.cluster, kind="uint32")
            self.cluster_buffer = cluster.id
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.cluster_buffer)
            GL.glEnableVertexAttribArray(2)
            GL.glVertexAttribIPointer(2, 1, GL.GL_UNSIGNED_INT, 0, None)
        else:
            GL.glDisableVertexAttribArray(2)
            GL.glVertexAttribI1ui(2, 0)

        if ds.selection_mask is not None:
            selection = SharedGLResourceCache.buffer((ds.selection_key or f"view:{ds.spec.id}:selection",), ds.selection_mask, kind="uint8")
            self.selection_buffer = selection.id
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.selection_buffer)
            GL.glEnableVertexAttribArray(3)
            GL.glVertexAttribIPointer(3, 1, GL.GL_UNSIGNED_BYTE, 0, None)
        else:
            GL.glDisableVertexAttribArray(3)
            GL.glVertexAttribI1ui(3, 1)

        # Attribute 4 is a per-view VisibilityFilter. It begins as a constant 1
        # and switches to a dynamic uint8 [N] buffer only when a filter exists.
        GL.glDisableVertexAttribArray(4)
        GL.glVertexAttribI1ui(4, 1)

        self.ebo_selection = GL.glGenBuffers(1)
        self.ebo_highlight = GL.glGenBuffers(1)
        GL.glBindVertexArray(0)

        xmin, xmax, ymin, ymax = ds.bounds
        quad = np.array(
            [[xmin, ymin, 0, 0], [xmax, ymin, 1, 0], [xmin, ymax, 0, 1], [xmax, ymax, 1, 1]],
            np.float32,
        )
        self.quad_vao = GL.glGenVertexArrays(1)
        self.quad_vbo = GL.glGenBuffers(1)
        GL.glBindVertexArray(self.quad_vao)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.quad_vbo)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, quad.nbytes, quad, GL.GL_STATIC_DRAW)
        GL.glEnableVertexAttribArray(0)
        GL.glVertexAttribPointer(0, 2, GL.GL_FLOAT, False, 16, None)
        GL.glEnableVertexAttribArray(1)
        GL.glVertexAttribPointer(1, 2, GL.GL_FLOAT, False, 16, ctypes.c_void_p(8))
        GL.glBindVertexArray(0)

        self.density_textures = [
            SharedGLResourceCache.texture_float2d((d.cache_key,), d.array).id for d in ds.densities
        ]
        self.segmentation_textures = [
            SharedGLResourceCache.texture_uint2d((s.cache_key,), s.labels).id for s in ds.segmentations
        ]
        if ds.exploration is not None:
            self.exploration_texture = SharedGLResourceCache.texture_half_array(
                (ds.exploration.cache_key,), ds.exploration.frames
            ).id

    def set_visibility_mask(self, mask: np.ndarray | None) -> None:
        if mask is None:
            self.visibility_mask = None
        else:
            arr = np.asarray(mask, dtype=np.uint8)
            if arr.ndim != 1 or len(arr) != self.dataset.n:
                raise ValueError("visibility mask must be uint8/bool [N]")
            self.visibility_mask = np.ascontiguousarray(arr)
        self.visibility_dirty = True

    def ensure_visibility_uploaded(self) -> None:
        if not self.visibility_dirty:
            return
        GL.glBindVertexArray(self.vao)
        if self.visibility_mask is None:
            GL.glDisableVertexAttribArray(4)
            GL.glVertexAttribI1ui(4, 1)
        else:
            if not self.visibility_buffer:
                self.visibility_buffer = GL.glGenBuffers(1)
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.visibility_buffer)
            GL.glBufferData(GL.GL_ARRAY_BUFFER, self.visibility_mask.nbytes, self.visibility_mask, GL.GL_DYNAMIC_DRAW)
            GL.glEnableVertexAttribArray(4)
            GL.glVertexAttribIPointer(4, 1, GL.GL_UNSIGNED_BYTE, 0, None)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)
        GL.glBindVertexArray(0)
        self.visibility_dirty = False


################################################################################
if __name__=="__main__":
    pass
