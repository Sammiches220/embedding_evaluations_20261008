################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

##### Internal Imports #####
from .base import RenderLayer


################################################################################
# CLASSES
################################################################################
class LassoLayer(RenderLayer):
    """Deprecated GL lasso layer.

    v0.5 draws the interactive lasso with QPainter in screen space. This avoids
    glLineWidth portability failures on core-profile drivers that only support a
    line width of 1.0.
    """
    def __init__(self) -> None:
        self.points = []

    def initialize(self, renderer) -> None:
        pass

    def draw(self, renderer) -> None:
        pass


################################################################################
if __name__=="__main__":
    pass
