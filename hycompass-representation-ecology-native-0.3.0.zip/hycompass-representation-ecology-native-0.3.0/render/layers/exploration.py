################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

##### Internal Imports #####
from render.gl_utils import GL, make_program
from .base import RenderLayer


################################################################################
# CLASSES
################################################################################
class ExplorationLayer(RenderLayer):
    def initialize(self, renderer) -> None:
        self.program = make_program("quad.vert", "exploration.frag")

    def draw(self, renderer) -> None:
        binding = renderer.dataset.exploration
        if binding is None or not renderer.state.show_exploration:
            return
        style = renderer.exploration_style()
        if style.get("visible", True) is False:
            return
        s, p = renderer.state, self.program
        GL.glUseProgram(p)
        renderer.set_view_uniforms(p)
        renderer.uniform1i(p, "uFrames", 0)
        renderer.uniform1f(p, "uTimeline", s.exploration_timeline)
        renderer.uniform1f(p, "uFrameCount", float(binding.frames.shape[0]))
        renderer.uniform1f(p, "uThreshold", float(style.get("threshold", s.exploration_threshold)))
        renderer.uniform1f(p, "uOpacity", float(style.get("opacity", s.exploration_opacity)))
        mode = str(style.get("display_mode", "both"))
        renderer.uniform1i(p, "uShowFill", int(mode in {"both", "field", "fill", "heatmap"}))
        renderer.uniform1i(p, "uShowBoundary", int(style.get("boundary", s.show_exploration_boundary) and mode in {"both", "boundary"}))
        palette = renderer.theme.palette("exploration_palette")
        for i, color in enumerate(palette):
            renderer.uniform3f(p, f"uPalette{i}", color)
        renderer.uniform4f(p, "uBoundaryColor", style.get("boundary_color", [1, 1, 1, 0.92]))
        renderer.draw_quad(renderer.resources.exploration_texture, GL.GL_TEXTURE_2D_ARRAY)


################################################################################
if __name__=="__main__":
    pass
