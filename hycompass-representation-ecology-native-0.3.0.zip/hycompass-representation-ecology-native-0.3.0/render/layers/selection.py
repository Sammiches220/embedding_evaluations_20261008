################################################################################
# CONFIGURATION
################################################################################

##### External Impors #####
from __future__ import annotations

import math
import numpy as np

##### Internal Imports #####
from render.gl_utils import GL, make_program
from .base import RenderLayer


################################################################################
# CLASSES
################################################################################
class SelectionLayer(RenderLayer):
    """Draw ephemeral WorkingSelection and external/API HighlightSet overlays."""

    def __init__(self) -> None:
        self.selection = np.empty(0, np.uint32)
        self.highlights = np.empty(0, np.uint32)
        self.selection_dirty = True
        self.highlight_dirty = True

    def initialize(self, renderer) -> None:
        self.program = make_program("overlay.vert", "overlay.frag")

    def set_selection(self, rows: np.ndarray) -> None:
        rows = np.asarray(rows, dtype=np.uint32)
        if len(rows) > 250_000:
            rows = rows[:: max(1, int(math.ceil(len(rows) / 250_000)))]
        self.selection = np.ascontiguousarray(rows)
        self.selection_dirty = True

    def set_highlights(self, rows: np.ndarray) -> None:
        rows = np.asarray(rows, dtype=np.uint32)
        if len(rows) > 250_000:
            rows = rows[:: max(1, int(math.ceil(len(rows) / 250_000)))]
        self.highlights = np.ascontiguousarray(rows)
        self.highlight_dirty = True

    # Backward-compatible alias used by older MapWidget calls.

    def _upload_if_needed(self, renderer) -> None:
        resources = renderer.resources
        GL.glBindVertexArray(resources.vao)
        if self.selection_dirty:
            GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, resources.ebo_selection)
            GL.glBufferData(GL.GL_ELEMENT_ARRAY_BUFFER, self.selection.nbytes, None if self.selection.nbytes == 0 else self.selection, GL.GL_DYNAMIC_DRAW)
            self.selection_dirty = False
        if self.highlight_dirty:
            GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, resources.ebo_highlight)
            GL.glBufferData(GL.GL_ELEMENT_ARRAY_BUFFER, self.highlights.nbytes, None if self.highlights.nbytes == 0 else self.highlights, GL.GL_DYNAMIC_DRAW)
            self.highlight_dirty = False
        GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, 0)
        GL.glBindVertexArray(0)

    def _draw_index_overlay(self, renderer, ebo: int, count: int, color, size: float) -> None:
        if count <= 0:
            return
        p = self.program
        GL.glUseProgram(p)
        renderer.set_view_uniforms(p)
        renderer.uniform1f(p, "uPointSize", size * renderer.device_pixel_ratio)
        renderer.uniform4f(p, "uColor", color)
        renderer.uniform1i(p, "uRound", 1)
        GL.glBindVertexArray(renderer.resources.vao)
        GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, ebo)
        GL.glDrawElements(GL.GL_POINTS, count, GL.GL_UNSIGNED_INT, None)
        GL.glBindVertexArray(0)

    def draw(self, renderer) -> None:
        self._upload_if_needed(renderer)
        selection_style = renderer.overlay_style("working_selection")
        if selection_style.get("visible", True):
            self._draw_index_overlay(
                renderer, renderer.resources.ebo_selection, len(self.selection),
                selection_style.get("color", renderer.theme.color("working_selection")),
                float(selection_style.get("size", 4.5)),
            )
        highlight_style = renderer.overlay_style("highlight")
        if highlight_style.get("visible", True):
            self._draw_index_overlay(
                renderer, renderer.resources.ebo_highlight, len(self.highlights),
                highlight_style.get("color", renderer.theme.color("highlight")),
                float(highlight_style.get("size", 7.0)),
            )


################################################################################
if __name__=="__main__":
    pass
