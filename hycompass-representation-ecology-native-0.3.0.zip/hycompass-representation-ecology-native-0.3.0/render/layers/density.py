################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

##### Internal Imports ####
from render.gl_utils import GL, make_program
from .base import RenderLayer


################################################################################
# CLASSES
################################################################################
class DensityLayer(RenderLayer):
    def __init__(self, index: int) -> None:
        self.index = int(index)

    def initialize(self, renderer) -> None:
        self.program = make_program("quad.vert", "density.frag")

    def draw(self, renderer) -> None:
        if not renderer.state.show_density or self.index >= len(renderer.resources.density_textures):
            return
        binding = renderer.dataset.densities[self.index]
        style = renderer.density_style(binding.spec.id)
        if style.get("visible", True) is False:
            return
        s, p = renderer.state, self.program
        GL.glUseProgram(p)
        renderer.set_view_uniforms(p)
        renderer.uniform1i(p, "uField", 0)
        renderer.uniform1f(p, "uOpacity", float(style.get("opacity", s.density_opacity)))
        renderer.uniform1f(p, "uThreshold", float(style.get("threshold", s.density_threshold)))
        renderer.uniform1f(p, "uContourLevels", float(style.get("contours", s.contour_levels)))
        mode = str(style.get("display_mode", "both"))
        renderer.uniform1i(p, "uShowFill", int(mode in {"both", "field", "fill", "heatmap"}))
        renderer.uniform1i(p, "uShowContours", int(mode in {"both", "contours"}))
        palette = renderer.theme.palette("density_palette")
        for i, color in enumerate(palette):
            renderer.uniform3f(p, f"uPalette{i}", color)
        renderer.uniform4f(p, "uContourColor", style.get("contour_color", [0.96, 0.96, 0.96, 0.38]))
        renderer.draw_quad(renderer.resources.density_textures[self.index], GL.GL_TEXTURE_2D)


################################################################################
if __name__=="__main__":
    pass
