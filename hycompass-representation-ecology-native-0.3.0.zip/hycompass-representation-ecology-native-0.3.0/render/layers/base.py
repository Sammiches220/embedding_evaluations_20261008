################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

##### Internal Imports #####
if TYPE_CHECKING:
    from render.renderer import Renderer


################################################################################
# ABSTRACT CLASSES
################################################################################
class RenderLayer(ABC):
    @abstractmethod
    def initialize(self, renderer: "Renderer") -> None: ...

    @abstractmethod
    def draw(self, renderer: "Renderer") -> None: ...


################################################################################
if __name__=="__main__":
    pass
