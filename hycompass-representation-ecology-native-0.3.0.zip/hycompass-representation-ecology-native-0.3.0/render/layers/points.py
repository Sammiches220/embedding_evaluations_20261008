################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

##### Internal Imports #####
from render.gl_utils import GL, make_program
from .base import RenderLayer


################################################################################
# CLASSES
################################################################################
class PointsLayer(RenderLayer):
    def initialize(self, renderer) -> None:
        self.program = make_program("points.vert", "points.frag")

    def draw(self, renderer) -> None:
        s, ds, p = renderer.state, renderer.dataset, self.program
        renderer.resources.ensure_visibility_uploaded()
        GL.glUseProgram(p)
        renderer.set_view_uniforms(p)
        renderer.uniform1f(p, "uTimeline", s.timeline)
        renderer.uniform1f(p, "uPointSize", s.point_size * renderer.device_pixel_ratio)
        renderer.uniform1i(p, "uHasTimeline", int(ds.has_timeline))
        renderer.uniform1i(p, "uHasSelection", int(ds.has_selection))
        renderer.uniform1i(p, "uHasCluster", int(ds.has_clusters))
        renderer.uniform1i(p, "uHasVisibility", int(renderer.resources.visibility_mask is not None))
        renderer.uniform1i(p, "uClusterColors", int(s.cluster_colors))
        renderer.uniform1i(p, "uShowActive", int(s.show_active))
        renderer.uniform1i(p, "uShowFuture", int(s.show_future))
        renderer.uniform1i(p, "uShowOutside", int(s.show_outside))
        renderer.uniform1i(p, "uCapBackground", int(s.cap_background))
        renderer.uniform1f(p, "uKeepFraction", renderer.keep_fraction())
        renderer.uniform4f(p, "uActiveColor", renderer.theme.color("points.active"))
        renderer.uniform4f(p, "uFutureColor", renderer.theme.color("points.future"))
        renderer.uniform4f(p, "uOutsideColor", renderer.theme.color("points.outside"))
        GL.glBindVertexArray(renderer.resources.vao)
        GL.glDrawArrays(GL.GL_POINTS, 0, ds.n)
        GL.glBindVertexArray(0)


################################################################################
if __name__=="__main__":
    pass
