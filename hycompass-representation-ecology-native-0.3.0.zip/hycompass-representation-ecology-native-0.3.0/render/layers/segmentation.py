################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

##### Internal Imports #####
from render.gl_utils import GL, make_program
from .base import RenderLayer


################################################################################
# CLASSES
################################################################################
class SegmentationLayer(RenderLayer):
    def __init__(self, index: int) -> None:
        self.index = int(index)

    def initialize(self, renderer) -> None:
        self.program = make_program("quad.vert", "landmarks.frag")

    def draw(self, renderer) -> None:
        if not renderer.state.show_segmentations or self.index >= len(renderer.resources.segmentation_textures):
            return
        binding = renderer.dataset.segmentations[self.index]
        style = renderer.segmentation_style(binding.spec.id)
        if style.get("visible", True) is False:
            return
        s, p = renderer.state, self.program
        GL.glUseProgram(p)
        renderer.set_view_uniforms(p)
        renderer.uniform1i(p, "uLabels", 0)
        renderer.uniform1f(p, "uFillOpacity", float(style.get("fill_opacity", s.segmentation_fill_opacity)) / max(1, len(renderer.dataset.segmentations)))
        renderer.uniform1i(p, "uShowFill", int(style.get("fill", s.segmentation_fill)))
        renderer.uniform1i(p, "uShowBoundary", int(style.get("boundary", s.segmentation_boundary)))
        width = float(style.get("boundary_width", s.segmentation_boundary_width))
        if style.get("boundary_width_mode", "pixels") == "point-size":
            width *= max(float(s.point_size), 0.25)
        renderer.uniform1f(p, "uBoundaryWidthPx", width * max(renderer.device_pixel_ratio, 1.0))
        color = list(style.get("boundary_color", renderer.theme.color("segmentation.boundary")))
        if len(color) < 4: color.append(1.0)
        color[3] *= float(style.get("boundary_opacity", 1.0))
        renderer.uniform4f(p, "uBoundaryColor", color)
        renderer.draw_quad(renderer.resources.segmentation_textures[self.index], GL.GL_TEXTURE_2D)


################################################################################
if __name__=="__main__":
    pass
