################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import numpy as np
from PySide6.QtCore import QPointF

##### Internal Imports #####
from render.camera import Camera


################################################################################
# CLASSES
################################################################################
class LassoInteraction:
    def __init__(self, camera: Camera) -> None:
        self.camera = camera
        self.points: list[np.ndarray] = []

    def begin(self, point: QPointF, width: int, height: int) -> None:
        self.points = [self.camera.screen_to_world(point.x(), point.y(), width, height)]

    def move(self, point: QPointF, width: int, height: int) -> bool:
        world = self.camera.screen_to_world(point.x(), point.y(), width, height)
        half_w, half_h = self.camera.half_size(width, height)
        if not self.points or np.linalg.norm(world - self.points[-1]) > max(half_w, half_h) * 0.002:
            self.points.append(world)
            return True
        return False

    def finish(self) -> np.ndarray | None:
        result = (
            np.asarray(self.points, dtype=np.float64)
            if len(self.points) >= 3
            else None
        )
        self.points = []
        return result

    def cancel(self) -> None:
        self.points = []


################################################################################
if __name__=="__main__":
    pass
