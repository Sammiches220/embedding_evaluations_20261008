################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtCore import QPointF

##### Internal Imports #####
from model.workspace.session import ViewData
from render.camera import Camera


################################################################################
# CLASSES
################################################################################
class PickingService:
    def __init__(self, dataset: ViewData, camera: Camera) -> None:
        self.dataset = dataset
        self.camera = camera
        self.row_filter = None

    def set_row_filter(self, callback) -> None:
        self.row_filter = callback

    def point_at(self, point: QPointF, width: int, height: int, pixel_radius: float) -> int | None:
        if self.dataset.spatial_index is None:
            return None
        world = self.camera.screen_to_world(point.x(), point.y(), width, height)
        half_w, half_h = self.camera.half_size(width, height)
        dx, dy = self.dataset.pixel_radius_world(half_w, half_h, width, height, pixel_radius)
        return self.dataset.spatial_index.pick(world[0], world[1], dx, dy, row_filter=self.row_filter)

    def landmark_at(self, point: QPointF, width: int, height: int) -> int:
        if self.dataset.landmarks is None:
            return 0
        world = self.camera.screen_to_world(point.x(), point.y(), width, height)
        return self.dataset.landmarks.at(float(world[0]), float(world[1]))


################################################################################
if __name__=="__main__":
    pass
