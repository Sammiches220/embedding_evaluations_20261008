################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
from PySide6.QtCore import QPointF

##### Internal Imports #####
from model.workspace.session import ViewData
from render.camera import Camera

from .lasso import LassoInteraction
from .pan import PanInteraction
from .picking import PickingService


################################################################################
# CLASSES
################################################################################
@dataclass(frozen=True)
class ReleaseResult:
    polygon: np.ndarray | None = None
    point_row: int | None = None
    landmark_id: int = 0


class InteractionController:
    """State machine for pan/lasso/picking independent of QOpenGLWidget rendering."""

    def __init__(self, dataset: ViewData, camera: Camera) -> None:
        self.dataset = dataset
        self.camera = camera
        self.pan = PanInteraction(camera)
        self.lasso = LassoInteraction(camera)
        self.picking = PickingService(dataset, camera)
        self.mode = "pan"
        self.dragging = False
        self.press_mouse: QPointF | None = None
        self.hover_clock = 0.0

    @property
    def lasso_points(self) -> list[np.ndarray]:
        return self.lasso.points

    def set_pick_filter(self, callback) -> None:
        self.picking.set_row_filter(callback)

    def set_mode(self, mode: str) -> None:
        if mode not in {"pan", "lasso"}:
            raise ValueError(f"unsupported interaction mode: {mode}")
        self.mode = mode
        if mode != "lasso":
            self.lasso.cancel()

    def press(self, point: QPointF, width: int, height: int) -> None:
        self.press_mouse = point
        self.dragging = True
        if self.mode == "lasso":
            self.lasso.begin(point, width, height)
        else:
            self.pan.begin(point)

    def move_drag(self, point: QPointF, width: int, height: int) -> bool:
        if not self.dragging:
            return False
        if self.mode == "lasso":
            return self.lasso.move(point, width, height)
        return self.pan.move(point, width, height)

    def hover(self, point: QPointF, width: int, height: int) -> tuple[bool, int | None]:
        now = time.perf_counter()
        if now - self.hover_clock <= 0.09:
            return False, None
        self.hover_clock = now
        return True, self.picking.point_at(point, width, height, 6.0)

    def release(self, point: QPointF, width: int, height: int) -> ReleaseResult:
        was_dragging = self.dragging
        self.dragging = False

        if self.mode == "lasso":
            polygon = self.lasso.finish() if was_dragging else None
            self.press_mouse = None
            return ReleaseResult(polygon=polygon)

        self.pan.end()
        start = self.press_mouse
        self.press_mouse = None
        if start is None:
            return ReleaseResult()
        if abs(point.x() - start.x()) >= 3 or abs(point.y() - start.y()) >= 3:
            return ReleaseResult()

        row = self.picking.point_at(point, width, height, 7.0)
        if row is not None:
            return ReleaseResult(point_row=row)
        return ReleaseResult(landmark_id=self.picking.landmark_at(point, width, height))

    def cancel_lasso(self) -> None:
        self.lasso.cancel()


################################################################################
if __name__=="__main__":
    pass
