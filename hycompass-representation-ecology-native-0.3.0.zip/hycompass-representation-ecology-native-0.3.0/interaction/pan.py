################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtCore import QPointF

##### Internal Imports #####
from render.camera import Camera


################################################################################
# CLASSES
################################################################################
class PanInteraction:
    def __init__(self, camera: Camera) -> None:
        self.camera = camera
        self.last_mouse: QPointF | None = None

    def begin(self, point: QPointF) -> None:
        self.last_mouse = point

    def move(self, point: QPointF, width: int, height: int) -> bool:
        if self.last_mouse is None:
            return False
        dx = float(point.x() - self.last_mouse.x())
        dy = float(point.y() - self.last_mouse.y())
        self.camera.pan_pixels(dx, dy, width, height)
        self.last_mouse = point
        return True

    def end(self) -> None:
        self.last_mouse = None


################################################################################
if __name__=="__main__":
    pass
