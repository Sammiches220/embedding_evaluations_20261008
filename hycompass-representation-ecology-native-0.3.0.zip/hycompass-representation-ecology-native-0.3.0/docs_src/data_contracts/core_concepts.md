This document describes the canonical file formats, asset relationships, registration contracts, PointQuery language, feature schema, and REST API exposed by HyCompass.

The central design rule is:

> A **Domain** defines an immutable row space. Every domain-aligned asset uses the same row `i` for the same item. Built-in algorithms are optional producers; externally computed assets are valid as long as they satisfy the documented contracts.

Large numerical data is file-backed and normally stored as NumPy `.npy` arrays. The REST API passes paths and lightweight metadata rather than embedding large arrays inside JSON.

---

## Core concepts

---

### **Domain**

A Domain is the complete canonical population for one embedding type/version.

```text
Domain
├── embeddings.npy   [N,D]
└── item_ids.npy     [N]
```

Row alignment is the primary invariant:

```text
embeddings[i]
item_ids[i]
selection_mask[i]
timeline[i]
clustering[i]
projection[i]
```

all refer to the same domain item.

A Domain row space is treated as immutable once dependent assets exist. If the population/order changes, register a new Domain ID/version instead of replacing the existing one.

`embeddings.npy` must have a real numeric dtype.

`item_ids.npy` must:

- be one-dimensional;
- have exactly `N` rows;
- not use NumPy `object` dtype.

Each Domain row has exactly one canonical `item_id` from `item_ids.npy`. Latent Observer intentionally does not maintain arbitrary external ID columns. Companion services/databases should resolve `(domain_id, item_id)` to Hydrus records or any other external identities/metadata. Globally stable UUID item IDs may be resolved by `item_id` alone while retaining Domain as context.

External databases/applications should own relationships such as:

```text
Latent Observer item_id
    -> tracker UUID / database key
    -> Hydrus file/hash
    -> Danbooru post
    -> paths/tags/other metadata
```

The recommended integration key is the pair:

```text
(domain_id, item_id)
```

when item IDs are not guaranteed globally unique. If the chosen IDs are globally stable UUIDs, the Domain can be treated as context rather than part of the external primary key.

---

### **Selection**

A Selection is membership only. It has no temporal meaning.

```text
mask.npy [N]
```

An item is a member when its mask value is truthy/nonzero.

Registering a Domain automatically creates an all-items Selection named:

```text
<domain-id>-all
```

Accepted dtype families:

```text
bool
signed integer
unsigned integer
```

---

### **Timeline**

A Timeline is a domain-wide time series independent of Selections.

```text
timestamps.npy [N]
```

Canonical values are integer UNIX timestamps in seconds. Missing times normally use `-1`. The dtype must be integer.

The authoritative timestamps remain UNIX seconds. Any normalized `0..1` representation used by rendering is a runtime encoding only.

---

### **Projection**

A Projection maps Domain rows into a 2-D coordinate system.

```text
positions.npy [N,2]
```

For a global Projection every row is normally finite.

For a subset-local Projection:

```text
rows in the declared Selection       -> finite x,y
rows outside the declared Selection  -> NaN,NaN
```

The finite-row mask must exactly match the Projection's declared Selection.

#### Optional support files

```text
x_order.npy   integer [M]
x_sorted.npy  numeric [M]
```

where `M` is the number of finite projected rows.

Normally these should be omitted and generated automatically.

`x_order` must contain each finite projected Domain row exactly once.

`x_sorted` must equal:

```python
positions[x_order, 0]
```

in ascending order.

If only one of `x_order_path` / `x_sorted_path` is supplied, registration fails.

#### World bounds

Optional explicit bounds:

```text
[xmin, xmax, ymin, ymax]
```

If omitted they are inferred from finite positions.

---

### **Clustering**

A Clustering maps Domain rows to non-negative integer categories:

```text
labels.npy [N]
```

Clusterings may be domain-global or optionally tied to a specific Projection and/or Selection.

Important: external algorithms that use negative labels (for example `-1` for noise) must remap them to non-negative IDs before registration.

---

### **Density**

A Density asset is a scalar raster over one Projection:

```text
field.npy [H,W]
```

Both dimensions must be at least 2. The field must contain only finite real values.

The raster covers the Projection's `world_bounds`.

Normalized values in `[0,1]` are strongly recommended.

#### Value Range

Default:

```text
value_range = "unit"
```

which validates approximately:

```text
0 <= field <= 1
```

For intentionally raw finite values:

```text
value_range = "finite"
```

Normalized fields are strongly recommended because View thresholds, palettes, PointQuery comparisons, and percentile behavior become easier to interpret.

---

### **Segmentation**

A Segmentation is a categorical raster over one Projection:

```text
labels.npy [H,W]
```

Rules:

- integer dtype;
- non-negative labels;
- `0` is reserved for background. Positive integers identify segments.
- both dimensions at least 2.

Optional `stats.json` provides names and display metadata. If omitted, HyCompass derives basic statistics without recomputing the segmentation.

The raster extent is the Projection's `world_bounds`.

#### Optional density dependency

A Segmentation may reference a Density asset on the same Projection.

When a Density is declared, the Density raster and Segmentation raster must have the same `[H,W]` shape.

#### Optional statistics

An external producer may supply:

```text
stats.json
```

This must be a JSON list of objects containing at least:

```json
{"id": 1}
```

IDs must:

- be unique;
- be positive;
- exist in the segmentation raster.

Optional fields include:

```json
{
  "id": 1,
  "name": "Region name",
  "x": 0.42,
  "y": -1.31,
  "population": 24132,
  "peak_density": 0.83,
  "area_cells": 944,
  "basin_scale": 0.19
}
```

If statistics are omitted or incomplete, Latent Observer derives/merges:

- default names;
- projected anchor positions;
- Domain-point population;
- peak density when a Density is attached;
- raster area;
- basin display scale.

This does **not** recompute the segmentation itself.

---

### **Exploration**

An Exploration asset is a scalar field derived from a Selection and Projection.

Static:

```text
field/frames.npy [H,W]
```

Temporal:

```text
frames.npy [T,H,W]
```

Temporal Exploration additionally references a Timeline.

The field must be numeric and finite.

Both raster dimensions must be at least 2.

Normalized values in `[0,1]` are strongly recommended.

An Exploration always requires:

- one Projection;
- one Selection.

A multi-frame Exploration additionally requires one Timeline.

Density and Exploration are normally expected to be normalized to `0..1`, which gives consistent thresholds, palettes, boundaries, and PointQuery semantics. Registration validates this contract by default.

If an external field intentionally uses another finite scale, CLI/API registration can request `value_range=finite`. The app will preserve those values, but render thresholds and comparisons then use that raw scale; normalized fields are strongly recommended.


#### Timeline interval

For temporal Exploration, `timeline_start` / `timeline_end` are UNIX seconds.

If omitted, they are inferred from the valid timestamps of the registered Timeline.

---
