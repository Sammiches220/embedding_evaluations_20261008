# OpenAPI Context Generator

Build a compact JSON subset of the canonical OpenAPI contract for use in LLM prompts,
small-context tools, examples, or focused client work. The generator runs entirely in the
browser and never changes the source OpenAPI document.

!!! info "How selection works"
    Select API operations by tag or endpoint. The generator automatically follows local
    `$ref` dependencies and includes only the required component definitions. You can
    also seed additional schemas explicitly from the **Additional schemas** section.

<div
  id="openapi-context-builder"
  class="oacb"
  data-openapi-url="../assets/generated/openapi.json"
>
  <div class="oacb-loading">Loading OpenAPI schema…</div>
</div>

<noscript>
  This page requires JavaScript because the context subset is generated locally in your browser.
</noscript>
