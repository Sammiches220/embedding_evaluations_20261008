# Markdown Context Generator

Select documentation source files and combine them into prompt-ready Markdown context. Every physical
`.md` file beneath `docs_src/` is available, so the generator can cover guides, data contracts, examples,
research notes, resources, and archived prompts without duplicating those documents.

Markdown minimization is presentation-aware rather than code-aware. Options include removing front matter
and HTML comments, preserving visible link/image labels while dropping their targets, omitting fenced code,
stripping raw HTML or MkDocs admonition wrappers, compacting pipe tables, and collapsing excess whitespace.
Headings and normal prose are intentionally retained because their hierarchy is usually valuable context.

!!! note "Static source publication"
    The generated Markdown manifest contains the raw text of every physical `.md` file under `docs_src/`, including
    files that may not be linked from navigation. Only use this all-docs generator when those sources are suitable
    for the audience of the deployed documentation site.

!!! warning "Markdown parsing scope"
    The browser transformer handles the Markdown constructs used by this documentation suite, but it is not a
    full CommonMark parser. Fenced code blocks are protected from the other text transformations; unusually
    complex nested inline Markdown may be preserved rather than aggressively rewritten.

<div
  id="markdown-context-builder"
  class="oacb"
  data-context-url="../assets/generated/markdown_context.json"
>
  <div class="oacb-loading">Loading Markdown source manifest…</div>
</div>

<noscript>
  This page requires JavaScript because the context bundle is generated locally in your browser.
</noscript>
