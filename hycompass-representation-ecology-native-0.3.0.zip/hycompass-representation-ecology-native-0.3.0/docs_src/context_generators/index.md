# Context Generators

Build focused, copy-ready project context for constrained LLM prompts without maintaining a second documentation system.

Each generator consumes artifacts produced from the same project sources used by the normal documentation build:

- **OpenAPI** selects API operations and recursively includes only their referenced component contracts.
- **Python** selects the same importable package sources used by the Python Reference and can emit either implementation source or an AST-derived public/signature outline.
- **Markdown** selects any physical `.md` file under `docs_src/` and removes optional presentation-oriented syntax while preserving the selected documentation text.

All selection and minimization happens in the browser. The generated manifests are static documentation assets, so the tools work with `mkdocs serve` and with a normal GitHub Pages deployment.

!!! warning "Context transformation is not source rewriting"
    The compact outputs are intended for prompts and analysis. Aggressive options such as removing Python docstrings, replacing function bodies with ellipses, or stripping Markdown link targets intentionally produce a context representation rather than a file that should be written back into the project.
