# Python Context Generator

Select project Python modules and emit implementation-focused or API-surface context for LLM prompts.
The generated inventory follows the same public package/file discovery policy as the Python Reference.

The **Source** representation preserves implementation code and can independently remove tokenized comments,
docstrings, top-level `if __name__ == "__main__"` blocks, and excess whitespace. The **Signatures / outline**
representation is generated from Python's AST: function bodies become `...`, while signatures, decorators,
classes, annotations, compact module/class assignments, and optionally imports/docstrings remain.

!!! warning "Static hosting publishes the source manifest"
    The browser can only minimize source that the static site can fetch. A GitHub Pages deployment therefore
    publishes the Python files represented in `assets/generated/python_context.json`. This is appropriate when
    that source is already public; do not enable/deploy this asset unchanged for a private codebase on a public site.

!!! note "Why comments and docstrings are separate"
    Comments are lexical tokens; docstrings are executable string expressions attached to modules, classes,
    and functions. Treating them separately avoids the common mistake of deleting all string literals while
    attempting to remove documentation.

<div
  id="python-context-builder"
  class="oacb"
  data-context-url="../assets/generated/python_context.json"
>
  <div class="oacb-loading">Loading Python source manifest…</div>
</div>

<noscript>
  This page requires JavaScript because the context bundle is generated locally in your browser.
</noscript>
