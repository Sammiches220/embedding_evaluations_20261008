(() => {
  "use strict";

  const PRESETS = {
    balanced: {
      label: "Balanced documentation",
      help: "Keep prose, headings, code, tables, and useful labels while removing source-only metadata and destination-heavy markup.",
      options: {
        removeFrontMatter: true,
        removeHtmlComments: true,
        stripRawHtml: false,
        keepImageTargets: false,
        keepImageAltText: true,
        keepLinkTargets: false,
        keepCodeBlocks: true,
        keepAdmonitionSyntax: false,
        keepHeadingAttributes: false,
        keepHorizontalRules: false,
        compactTables: true,
        collapseBlankLines: true,
        trimTrailingWhitespace: true,
        fileBoundaries: true,
      },
    },
    prose: {
      label: "Prose focused",
      help: "Prioritize explanatory text: remove fenced code and presentation metadata while retaining headings, lists, tables, and image alt text.",
      options: {
        removeFrontMatter: true,
        removeHtmlComments: true,
        stripRawHtml: true,
        keepImageTargets: false,
        keepImageAltText: true,
        keepLinkTargets: false,
        keepCodeBlocks: false,
        keepAdmonitionSyntax: false,
        keepHeadingAttributes: false,
        keepHorizontalRules: false,
        compactTables: true,
        collapseBlankLines: true,
        trimTrailingWhitespace: true,
        fileBoundaries: true,
      },
    },
    minimal: {
      label: "Minimal text",
      help: "Aggressive prompt context: prose and structural headings remain, while code blocks, URLs, images, HTML chrome, and most presentation syntax are removed.",
      options: {
        removeFrontMatter: true,
        removeHtmlComments: true,
        stripRawHtml: true,
        keepImageTargets: false,
        keepImageAltText: false,
        keepLinkTargets: false,
        keepCodeBlocks: false,
        keepAdmonitionSyntax: false,
        keepHeadingAttributes: false,
        keepHorizontalRules: false,
        compactTables: true,
        collapseBlankLines: true,
        trimTrailingWhitespace: true,
        fileBoundaries: true,
      },
    },
    full: {
      label: "Full Markdown source",
      help: "Preserve the selected Markdown source with only file concatenation boundaries added.",
      options: {
        removeFrontMatter: false,
        removeHtmlComments: false,
        stripRawHtml: false,
        keepImageTargets: true,
        keepImageAltText: true,
        keepLinkTargets: true,
        keepCodeBlocks: true,
        keepAdmonitionSyntax: true,
        keepHeadingAttributes: true,
        keepHorizontalRules: true,
        compactTables: false,
        collapseBlankLines: false,
        trimTrailingWhitespace: false,
        fileBoundaries: true,
      },
    },
  };

  const OPTION_DEFS = [
    ["removeFrontMatter", "Remove front matter", "Drop leading YAML/TOML-style metadata blocks delimited by --- or +++."],
    ["removeHtmlComments", "Remove HTML comments", "Drop <!-- ... --> comments outside fenced code blocks."],
    ["stripRawHtml", "Strip raw HTML tags", "Remove HTML presentation tags while preserving surrounding text."],
    ["keepImageTargets", "Keep image targets", "Retain Markdown image URLs/paths."],
    ["keepImageAltText", "Keep image alt text", "When image targets are removed, retain their human-readable alt text."],
    ["keepLinkTargets", "Keep link targets", "When disabled, Markdown links become their visible labels and reference definitions are removed."],
    ["keepCodeBlocks", "Keep fenced code blocks", "Retain ``` / ~~~ blocks. Disable for prose-only context."],
    ["keepAdmonitionSyntax", "Keep admonition syntax", "Retain MkDocs !!! / ??? wrapper syntax. Content is preserved either way."],
    ["keepHeadingAttributes", "Keep heading attributes", "Retain trailing {#id .class} attribute lists."],
    ["keepHorizontalRules", "Keep horizontal rules", "Retain standalone ---, ***, and ___ separators."],
    ["compactTables", "Compact tables", "Trim padding around pipe-delimited table cells."],
    ["collapseBlankLines", "Collapse blank lines", "Reduce repeated blank lines to a single blank line."],
    ["trimTrailingWhitespace", "Trim trailing whitespace", "Remove spaces and tabs at line ends."],
    ["fileBoundaries", "File boundaries", "Add explicit FILE separators between selected Markdown sources."],
  ];

  const escapeHtml = (value) => String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MiB`;
  }

  function debounce(fn, delay = 75) {
    let timer = null;
    return (...args) => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => fn(...args), delay);
    };
  }

  async function copyText(text) {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return;
    }
    const area = document.createElement("textarea");
    area.value = text;
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }

  function downloadText(text, filename) {
    const blob = new Blob([text], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  function removeFrontMatter(source) {
    const lines = source.split("\n");
    if (!lines.length) return source;
    const opening = lines[0].trim();
    if (opening !== "---" && opening !== "+++") return source;
    for (let index = 1; index < lines.length; index += 1) {
      if (lines[index].trim() === opening) return lines.slice(index + 1).join("\n");
    }
    return source;
  }

  function stripHtmlCommentsLine(line, state) {
    let result = "";
    let cursor = 0;
    while (cursor < line.length) {
      if (state.inComment) {
        const end = line.indexOf("-->", cursor);
        if (end === -1) return result;
        state.inComment = false;
        cursor = end + 3;
        continue;
      }
      const start = line.indexOf("<!--", cursor);
      if (start === -1) {
        result += line.slice(cursor);
        break;
      }
      result += line.slice(cursor, start);
      state.inComment = true;
      cursor = start + 4;
    }
    return result;
  }

  function stripImageTargets(line, keepAltText) {
    let result = line;
    const replacement = keepAltText ? "$1" : "";
    result = result.replace(/!\[([^\]]*)\]\([^\n)]*\)/g, replacement);
    result = result.replace(/!\[([^\]]*)\]\[[^\]]*\]/g, replacement);
    result = result.replace(/<img\b[^>]*\balt=["']([^"']*)["'][^>]*>/gi, replacement);
    result = result.replace(/<img\b[^>]*>/gi, "");
    return result;
  }

  function stripLinkTargets(line) {
    let result = line;
    // Repeated passes handle a useful subset of nested labels without attempting
    // to become a full CommonMark parser.
    for (let pass = 0; pass < 3; pass += 1) {
      result = result.replace(/\[([^\]\n]+)\]\([^\n)]*\)/g, "$1");
    }
    result = result.replace(/\[([^\]\n]+)\]\[[^\]\n]*\]/g, "$1");
    return result;
  }

  function stripRawHtml(line) {
    return line.replace(/<\/?[A-Za-z][A-Za-z0-9-]*(?:\s[^<>]*?)?\s*\/?>/g, "");
  }

  function compactTableLine(line) {
    if ((line.match(/\|/g) || []).length < 2) return line;
    const leading = /^\s*\|/.test(line);
    const trailing = /\|\s*$/.test(line);
    const cells = line.split("|").map((cell) => cell.trim());
    if (leading) cells.shift();
    if (trailing) cells.pop();
    const core = cells.join("|");
    return `${leading ? "|" : ""}${core}${trailing ? "|" : ""}`;
  }

  function transformMarkdown(source, options) {
    let working = options.removeFrontMatter ? removeFrontMatter(source) : source;
    const input = working.split("\n");
    const output = [];
    const htmlState = { inComment: false };
    let fence = null;
    let skipFence = false;
    let admonitionBase = null;

    for (let rawLine of input) {
      const trimmed = rawLine.trimStart();
      const fenceMatch = trimmed.match(/^(`{3,}|~{3,})/);
      if (fenceMatch) {
        const marker = fenceMatch[1];
        if (fence === null) {
          fence = marker[0];
          skipFence = !options.keepCodeBlocks;
          if (!skipFence) output.push(rawLine);
        } else if (marker[0] === fence) {
          if (!skipFence) output.push(rawLine);
          fence = null;
          skipFence = false;
        } else if (!skipFence) {
          output.push(rawLine);
        }
        continue;
      }
      if (fence !== null) {
        if (!skipFence) output.push(rawLine);
        continue;
      }

      if (options.removeHtmlComments) rawLine = stripHtmlCommentsLine(rawLine, htmlState);
      if (htmlState.inComment && rawLine === "") continue;

      if (!options.keepAdmonitionSyntax) {
        const match = rawLine.match(/^(\s*)(?:!!!|\?\?\+?|\?\?\?)\s+\S+(?:\s+["']([^"']*)["'])?\s*$/);
        if (match) {
          admonitionBase = match[1].length;
          if (match[2]) output.push(`${match[1]}${match[2]}`);
          continue;
        }
        if (admonitionBase !== null) {
          const indentation = rawLine.match(/^\s*/)[0].length;
          if (rawLine.trim() && indentation <= admonitionBase) {
            admonitionBase = null;
          } else if (indentation >= admonitionBase + 4) {
            rawLine = rawLine.slice(Math.min(rawLine.length, admonitionBase + 4));
          }
        }
      }

      if (!options.keepImageTargets) rawLine = stripImageTargets(rawLine, options.keepImageAltText);
      if (!options.keepLinkTargets) {
        if (/^\s{0,3}\[[^\]]+\]:\s+\S+/.test(rawLine)) continue;
        rawLine = stripLinkTargets(rawLine);
      }
      if (!options.keepHeadingAttributes) {
        rawLine = rawLine.replace(/\s+\{(?:[#.][^}]*)\}\s*$/, "");
      }
      if (!options.keepHorizontalRules && /^\s{0,3}(?:(?:\*\s*){3,}|(?:-\s*){3,}|(?:_\s*){3,})$/.test(rawLine)) {
        continue;
      }
      if (options.stripRawHtml) rawLine = stripRawHtml(rawLine);
      if (options.compactTables) rawLine = compactTableLine(rawLine);
      if (options.trimTrailingWhitespace) rawLine = rawLine.replace(/[ \t]+$/g, "");
      output.push(rawLine);
    }

    working = output.join("\n");
    if (options.collapseBlankLines) working = working.replace(/\n[ \t]*\n(?:[ \t]*\n)+/g, "\n\n");
    return working.trimEnd();
  }

  function buildOutput(files, selectedPaths, options) {
    const selected = files.filter((file) => selectedPaths.has(file.path));
    const chunks = [];
    for (const file of selected) {
      const text = transformMarkdown(file.source, options);
      if (options.fileBoundaries) chunks.push(`===== FILE: ${file.path} =====\n${text}`.trimEnd());
      else chunks.push(text.trimEnd());
    }
    return chunks.filter(Boolean).join("\n\n");
  }

  function renderShell(root) {
    const presets = Object.entries(PRESETS)
      .map(([key, value]) => `<option value="${key}">${escapeHtml(value.label)}</option>`)
      .join("");
    const optionControls = OPTION_DEFS.map(([key, label, help]) => `
      <label class="oacb-option">
        <input type="checkbox" data-markdown-option="${key}">
        <span>${escapeHtml(label)}<small>${escapeHtml(help)}</small></span>
      </label>`).join("");

    root.innerHTML = `
      <div class="oacb-grid">
        <section class="oacb-panel">
          <h2>1. Select Markdown sources</h2>
          <p class="oacb-help">Every physical <code>.md</code> file under <code>docs_src/</code> is available, including guides, data contracts, examples, research notes, and old prompts.</p>
          <div class="oacb-toolbar">
            <input id="mdcb-search" type="search" placeholder="Filter titles or paths…" aria-label="Filter Markdown files">
            <button type="button" id="mdcb-select-all">Select all</button>
            <button type="button" id="mdcb-clear">Clear</button>
          </div>
          <div id="mdcb-file-list"></div>
        </section>

        <section class="oacb-panel">
          <h2>2. Minimize context</h2>
          <label><strong>Preset</strong>
            <select id="mdcb-preset">${presets}<option value="custom">Custom</option></select>
          </label>
          <p id="mdcb-preset-help" class="oacb-help"></p>
          <div class="oacb-options">${optionControls}</div>

          <h2>3. Copy context</h2>
          <div class="oacb-stats">
            <span class="oacb-stat"><span class="oacb-stat-label">Files</span> <strong id="mdcb-stat-files">0</strong></span>
            <span class="oacb-stat"><span class="oacb-stat-label">Size</span> <strong id="mdcb-stat-bytes">0 B</strong></span>
            <span class="oacb-stat"><span class="oacb-stat-label">Approx. tokens</span> <strong id="mdcb-stat-tokens">0</strong></span>
          </div>
          <textarea id="mdcb-output" class="oacb-output" spellcheck="false" aria-label="Generated Markdown context"></textarea>
          <div class="oacb-actions">
            <button type="button" id="mdcb-copy">Copy</button>
            <button type="button" id="mdcb-download">Download .md</button>
          </div>
          <p id="mdcb-status" class="oacb-status"></p>
        </section>
      </div>`;
  }

  function initBuilder(root, manifest) {
    renderShell(root);
    const files = manifest.files || [];
    const selected = new Set();
    const fileList = root.querySelector("#mdcb-file-list");
    const search = root.querySelector("#mdcb-search");
    const preset = root.querySelector("#mdcb-preset");
    const presetHelp = root.querySelector("#mdcb-preset-help");
    const output = root.querySelector("#mdcb-output");
    const status = root.querySelector("#mdcb-status");
    const optionsMap = new Map(
      [...root.querySelectorAll("[data-markdown-option]")].map((element) => [element.dataset.markdownOption, element]),
    );

    function options() {
      return Object.fromEntries([...optionsMap].map(([key, element]) => [key, element.checked]));
    }

    function applyPreset(name) {
      const config = PRESETS[name];
      if (!config) return;
      for (const [key, element] of optionsMap) element.checked = Boolean(config.options[key]);
      preset.value = name;
      presetHelp.textContent = config.help;
      updateOutput();
    }

    function markCustom() {
      preset.value = "custom";
      presetHelp.textContent = "Custom combination of Markdown context transformations.";
    }

    function renderFiles() {
      const query = search.value.trim().toLowerCase();
      const visible = files.filter((file) => !query || `${file.path} ${file.title} ${file.group}`.toLowerCase().includes(query));
      const groups = new Map();
      for (const file of visible) {
        if (!groups.has(file.group)) groups.set(file.group, []);
        groups.get(file.group).push(file);
      }
      if (!groups.size) {
        fileList.innerHTML = '<div class="oacb-empty">No matching Markdown files.</div>';
        return;
      }
      fileList.innerHTML = [...groups.entries()].map(([group, groupFiles]) => {
        const checkedCount = groupFiles.filter((file) => selected.has(file.path)).length;
        return `<div class="oacb-tag" data-markdown-group="${escapeHtml(group)}">
          <label class="oacb-tag-header">
            <input type="checkbox" class="mdcb-group-checkbox" ${checkedCount === groupFiles.length ? "checked" : ""} data-indeterminate="${checkedCount > 0 && checkedCount < groupFiles.length}">
            <span>${escapeHtml(group)} <small>(${groupFiles.length})</small></span>
          </label>
          ${groupFiles.map((file) => `<label class="oacb-operation">
            <input type="checkbox" class="mdcb-file-checkbox" data-path="${escapeHtml(file.path)}" ${selected.has(file.path) ? "checked" : ""}>
            <span><strong>${escapeHtml(file.title)}</strong><span class="oacb-summary">${escapeHtml(file.path)}</span></span>
          </label>`).join("")}
        </div>`;
      }).join("");
      for (const box of fileList.querySelectorAll(".mdcb-group-checkbox")) box.indeterminate = box.dataset.indeterminate === "true";
    }

    function updateOutput() {
      const text = buildOutput(files, selected, options());
      output.value = text;
      const bytes = new TextEncoder().encode(text).length;
      root.querySelector("#mdcb-stat-files").textContent = selected.size.toLocaleString();
      root.querySelector("#mdcb-stat-bytes").textContent = formatBytes(bytes);
      root.querySelector("#mdcb-stat-tokens").textContent = Math.ceil(text.length / 4).toLocaleString();
      status.textContent = `${files.length} Markdown files available from docs_src/.`;
    }

    const scheduleUpdate = debounce(updateOutput);
    fileList.addEventListener("change", (event) => {
      const target = event.target;
      if (target.classList.contains("mdcb-file-checkbox")) {
        target.checked ? selected.add(target.dataset.path) : selected.delete(target.dataset.path);
        renderFiles();
        scheduleUpdate();
      } else if (target.classList.contains("mdcb-group-checkbox")) {
        const group = target.closest("[data-markdown-group]").dataset.markdownGroup;
        for (const file of files.filter((item) => item.group === group)) {
          target.checked ? selected.add(file.path) : selected.delete(file.path);
        }
        renderFiles();
        scheduleUpdate();
      }
    });
    search.addEventListener("input", renderFiles);
    root.querySelector("#mdcb-select-all").addEventListener("click", () => {
      for (const file of files) selected.add(file.path);
      renderFiles();
      scheduleUpdate();
    });
    root.querySelector("#mdcb-clear").addEventListener("click", () => {
      selected.clear();
      renderFiles();
      scheduleUpdate();
    });
    preset.addEventListener("change", () => {
      if (preset.value === "custom") markCustom();
      else applyPreset(preset.value);
    });
    for (const element of optionsMap.values()) {
      element.addEventListener("change", () => {
        markCustom();
        scheduleUpdate();
      });
    }
    root.querySelector("#mdcb-copy").addEventListener("click", async () => {
      try {
        await copyText(output.value);
        status.textContent = "Copied Markdown context to clipboard.";
      } catch (error) {
        status.textContent = `Copy failed: ${error}`;
      }
    });
    root.querySelector("#mdcb-download").addEventListener("click", () => {
      downloadText(output.value, "hycompass-markdown-context.md");
      status.textContent = "Downloaded hycompass-markdown-context.md.";
    });

    renderFiles();
    applyPreset("balanced");
  }

  async function main() {
    const root = document.getElementById("markdown-context-builder");
    if (!root || root.dataset.initialized === "true") return;
    root.dataset.initialized = "true";
    const url = root.dataset.contextUrl;
    try {
      const response = await fetch(url, { cache: "no-store" });
      if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
      initBuilder(root, await response.json());
    } catch (error) {
      root.innerHTML = `<div class="oacb-warning">Unable to load <code>${escapeHtml(url)}</code>: ${escapeHtml(error)}. Run <code>scripts/docs/serve_docs.sh</code> or rebuild the static documentation so the generated Markdown context manifest exists.</div>`;
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", main, { once: true });
  else main();

  window.HyCompassMarkdownContextBuilder = { buildOutput, transformMarkdown, presets: PRESETS };
})();
