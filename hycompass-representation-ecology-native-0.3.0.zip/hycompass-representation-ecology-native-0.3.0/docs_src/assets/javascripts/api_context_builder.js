(() => {
  "use strict";

  const HTTP_METHODS = new Set([
    "get",
    "put",
    "post",
    "delete",
    "options",
    "head",
    "patch",
    "trace",
  ]);

  const OPTION_DEFS = [
    ["parameters", "Parameters", "Path, query, header, and cookie parameters."],
    ["requestBodies", "Request bodies", "Request body contracts and their dependencies."],
    ["responseBodies", "Response bodies / schemas", "Response content schemas; response status entries remain valid."],
    ["nonSuccessResponses", "Non-success responses", "Keep 4xx/5xx/default responses, including validation errors."],
    ["summaries", "Summaries", "Operation and path summaries."],
    ["descriptions", "Descriptions", "Human-oriented description text. Required response descriptions remain as empty strings when omitted."],
    ["examples", "Examples", "OpenAPI example/examples fields."],
    ["operationIds", "Operation IDs", "Generated or explicit operationId values."],
    ["titles", "Schema titles", "Schema title fields, which are often generated boilerplate."],
    ["deprecated", "Deprecated markers", "Deprecated flags on operations, parameters, and schemas."],
    ["security", "Security", "Operation/global security declarations and referenced security schemes."],
    ["metadata", "API metadata", "Full info, tags, servers, external docs, and related top-level metadata."],
    ["vendorExtensions", "Vendor extensions", "Keep x-* extension fields."],
  ];

  const PRESETS = {
    minimal: {
      label: "Minimal structure",
      help: "Compact API contract for constrained prompts: types, constraints, parameters, requests, success responses, and required dependency schemas.",
      options: {
        parameters: true,
        requestBodies: true,
        responseBodies: true,
        nonSuccessResponses: false,
        summaries: false,
        descriptions: false,
        examples: false,
        operationIds: false,
        titles: false,
        deprecated: false,
        security: false,
        metadata: false,
        vendorExtensions: false,
      },
    },
    coding: {
      label: "Coding assistant",
      help: "Balanced context for implementing clients or modifying API consumers, including explanatory prose, examples, errors, and operation IDs.",
      options: {
        parameters: true,
        requestBodies: true,
        responseBodies: true,
        nonSuccessResponses: true,
        summaries: true,
        descriptions: true,
        examples: true,
        operationIds: true,
        titles: false,
        deprecated: true,
        security: true,
        metadata: false,
        vendorExtensions: false,
      },
    },
    requests: {
      label: "Request generation",
      help: "Optimized for constructing calls: parameters, request bodies, descriptions, examples, operation IDs, and security, while omitting response body schemas and most errors.",
      options: {
        parameters: true,
        requestBodies: true,
        responseBodies: false,
        nonSuccessResponses: false,
        summaries: true,
        descriptions: true,
        examples: true,
        operationIds: true,
        titles: false,
        deprecated: false,
        security: true,
        metadata: false,
        vendorExtensions: false,
      },
    },
    full: {
      label: "Full documentation",
      help: "Keeps nearly all selected OpenAPI documentation while still pruning unselected operations and unreachable components.",
      options: {
        parameters: true,
        requestBodies: true,
        responseBodies: true,
        nonSuccessResponses: true,
        summaries: true,
        descriptions: true,
        examples: true,
        operationIds: true,
        titles: true,
        deprecated: true,
        security: true,
        metadata: true,
        vendorExtensions: true,
      },
    },
  };

  const deepClone = (value) =>
    value === undefined ? undefined : JSON.parse(JSON.stringify(value));

  const escapeHtml = (value) =>
    String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");

  const operationKey = (method, path) => `${method.toUpperCase()} ${path}`;

  function decodePointerSegment(segment) {
    return segment.replaceAll("~1", "/").replaceAll("~0", "~");
  }

  function parseLocalRef(ref) {
    if (typeof ref !== "string" || !ref.startsWith("#/")) return null;
    return ref.slice(2).split("/").map(decodePointerSegment);
  }

  function getByPointer(root, ref) {
    const parts = parseLocalRef(ref);
    if (!parts) return undefined;
    let current = root;
    for (const part of parts) {
      if (current === null || typeof current !== "object" || !(part in current)) {
        return undefined;
      }
      current = current[part];
    }
    return current;
  }

  function setByPointer(root, ref, value) {
    const parts = parseLocalRef(ref);
    if (!parts || parts.length === 0) return false;
    let current = root;
    for (const part of parts.slice(0, -1)) {
      if (!current[part] || typeof current[part] !== "object") current[part] = {};
      current = current[part];
    }
    current[parts.at(-1)] = value;
    return true;
  }

  function collectLocalComponentRefs(value, refs = new Set()) {
    if (typeof value === "string") {
      if (value.startsWith("#/components/")) refs.add(value);
      return refs;
    }
    if (Array.isArray(value)) {
      for (const item of value) collectLocalComponentRefs(item, refs);
      return refs;
    }
    if (value && typeof value === "object") {
      for (const child of Object.values(value)) collectLocalComponentRefs(child, refs);
    }
    return refs;
  }

  // OpenAPI/JSON Schema contain several maps whose keys are user-defined names
  // rather than vocabulary fields. A schema can legally have properties named
  // "title" or "description", so metadata pruning must never treat those map
  // keys as documentation keywords.
  const NAMED_MAP_KEYS = new Set([
    "properties",
    "patternProperties",
    "$defs",
    "definitions",
    "dependentSchemas",
    "paths",
    "schemas",
    "responses",
    "parameters",
    "requestBodies",
    "headers",
    "links",
    "callbacks",
    "content",
    "encoding",
    "securitySchemes",
    "pathItems",
    "mapping",
    "scopes",
    "variables",
  ]);

  function stripOptionalFields(value, options, context = { namedMap: false }) {
    if (Array.isArray(value)) {
      return value.map((item) => stripOptionalFields(item, options, context));
    }
    if (!value || typeof value !== "object") return value;

    const result = {};
    for (const [key, child] of Object.entries(value)) {
      if (!context.namedMap) {
        if (!options.vendorExtensions && key.startsWith("x-")) continue;
        if (!options.summaries && key === "summary") continue;
        if (!options.examples && (key === "example" || key === "examples")) continue;
        if (!options.operationIds && key === "operationId") continue;
        if (!options.titles && key === "title") continue;
        if (!options.deprecated && key === "deprecated") continue;
        if (!options.security && key === "security") continue;
        if (!options.metadata && (key === "externalDocs" || key === "servers")) continue;
        if (!options.descriptions && key === "description") continue;
      }

      result[key] = stripOptionalFields(child, options, {
        namedMap: !context.namedMap && NAMED_MAP_KEYS.has(key),
      });
    }
    return result;
  }

  function normalizeResponseObject(response, options) {
    if (!response || typeof response !== "object" || Array.isArray(response)) {
      return response;
    }
    const result = stripOptionalFields(response, options);
    if (!("$ref" in result) && !("description" in result)) result.description = "";
    if (!options.responseBodies) delete result.content;
    return result;
  }

  function keepResponseCode(code) {
    return /^2\d\d$/.test(code) || /^2XX$/i.test(code);
  }

  function pruneResponses(responses, options) {
    if (!responses || typeof responses !== "object") return responses;
    const result = {};
    const entries = Object.entries(responses);

    for (const [code, response] of entries) {
      if (!options.nonSuccessResponses && !keepResponseCode(code)) continue;
      result[code] = normalizeResponseObject(response, options);
    }

    if (Object.keys(result).length === 0 && entries.length > 0) {
      const [code, response] = entries[0];
      result[code] = normalizeResponseObject(response, options);
    }
    return result;
  }

  function pruneOperation(operation, options) {
    const result = stripOptionalFields(deepClone(operation), options);
    if (!options.parameters) delete result.parameters;
    if (!options.requestBodies) delete result.requestBody;
    if (result.responses) result.responses = pruneResponses(result.responses, options);
    return result;
  }

  function collectSecurityNames(value, names = new Set()) {
    if (Array.isArray(value)) {
      for (const item of value) collectSecurityNames(item, names);
      return names;
    }
    if (!value || typeof value !== "object") return names;
    if (Array.isArray(value.security)) {
      for (const requirement of value.security) {
        if (!requirement || typeof requirement !== "object") continue;
        for (const name of Object.keys(requirement)) names.add(name);
      }
    }
    for (const child of Object.values(value)) collectSecurityNames(child, names);
    return names;
  }

  function addReferencedComponents(source, output, options, warnings) {
    const queued = [...collectLocalComponentRefs(output)];
    const seen = new Set();

    while (queued.length > 0) {
      const ref = queued.pop();
      if (seen.has(ref)) continue;
      seen.add(ref);

      const parts = parseLocalRef(ref);
      if (!parts || parts[0] !== "components") continue;

      const target = getByPointer(source, ref);
      if (target === undefined) {
        warnings.push(`Unresolved local reference: ${ref}`);
        continue;
      }

      const pruned = parts[1] === "responses"
        ? normalizeResponseObject(deepClone(target), options)
        : stripOptionalFields(deepClone(target), options);
      setByPointer(output, ref, pruned);
      for (const dependency of collectLocalComponentRefs(pruned)) {
        if (!seen.has(dependency)) queued.push(dependency);
      }
    }
  }

  function addSecuritySchemes(source, output, options, warnings) {
    if (!options.security) return;
    const names = collectSecurityNames(output);
    for (const name of names) {
      const scheme = source.components?.securitySchemes?.[name];
      if (!scheme) {
        warnings.push(`Security scheme '${name}' is referenced but not defined.`);
        continue;
      }
      output.components ??= {};
      output.components.securitySchemes ??= {};
      output.components.securitySchemes[name] = stripOptionalFields(
        deepClone(scheme),
        options,
      );
    }
  }

  function removeEmptyComponents(output) {
    if (!output.components) return;
    for (const [group, values] of Object.entries(output.components)) {
      if (values && typeof values === "object" && Object.keys(values).length === 0) {
        delete output.components[group];
      }
    }
    if (Object.keys(output.components).length === 0) delete output.components;
  }

  function minimalInfo(source) {
    return {
      title: source.info?.title || "OpenAPI subset",
      version: source.info?.version || "0",
    };
  }

  function buildSubset(source, selectedOperations, selectedSchemas, options) {
    const warnings = [];
    const output = {
      openapi: source.openapi || "3.1.0",
      info: options.metadata ? deepClone(source.info || minimalInfo(source)) : minimalInfo(source),
      paths: {},
    };

    if (options.metadata) {
      for (const key of [
        "jsonSchemaDialect",
        "servers",
        "tags",
        "externalDocs",
      ]) {
        if (source[key] !== undefined) output[key] = deepClone(source[key]);
      }
    }
    if (options.security && source.security !== undefined) {
      output.security = deepClone(source.security);
    }

    for (const path of Object.keys(source.paths || {}).sort()) {
      const pathItem = source.paths[path] || {};
      const selectedMethods = [...HTTP_METHODS]
        .filter((method) => pathItem[method] && selectedOperations.has(operationKey(method, path)))
        .sort();
      if (selectedMethods.length === 0) continue;

      const pathOut = {};
      if (pathItem.$ref) pathOut.$ref = pathItem.$ref;
      if (options.parameters && pathItem.parameters) {
        pathOut.parameters = stripOptionalFields(deepClone(pathItem.parameters), options);
      }
      if (options.summaries && pathItem.summary !== undefined) pathOut.summary = pathItem.summary;
      if (options.descriptions && pathItem.description !== undefined) pathOut.description = pathItem.description;
      if (options.metadata && pathItem.servers !== undefined) pathOut.servers = deepClone(pathItem.servers);

      for (const method of selectedMethods) {
        pathOut[method] = pruneOperation(pathItem[method], options);
      }
      output.paths[path] = pathOut;
    }

    for (const schemaName of [...selectedSchemas].sort((a, b) => a.localeCompare(b))) {
      const schema = source.components?.schemas?.[schemaName];
      if (!schema) {
        warnings.push(`Selected schema '${schemaName}' no longer exists.`);
        continue;
      }
      output.components ??= {};
      output.components.schemas ??= {};
      output.components.schemas[schemaName] = stripOptionalFields(deepClone(schema), options);
    }

    addReferencedComponents(source, output, options, warnings);
    addSecuritySchemes(source, output, options, warnings);
    addReferencedComponents(source, output, options, warnings);
    removeEmptyComponents(output);

    return { output, warnings };
  }

  function getOperations(schema) {
    const operations = [];
    for (const [path, pathItem] of Object.entries(schema.paths || {})) {
      for (const method of HTTP_METHODS) {
        const operation = pathItem?.[method];
        if (!operation) continue;
        const tags = operation.tags?.length ? operation.tags : ["Untagged"];
        operations.push({
          method,
          path,
          key: operationKey(method, path),
          operation,
          tags,
          primaryTag: tags[0],
          summary: operation.summary || operation.description || "",
        });
      }
    }
    return operations.sort((a, b) =>
      a.primaryTag.localeCompare(b.primaryTag) ||
      a.path.localeCompare(b.path) ||
      a.method.localeCompare(b.method),
    );
  }

  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MiB`;
  }

  function debounce(fn, delay = 75) {
    let timer = null;
    return (...args) => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => fn(...args), delay);
    };
  }

  async function copyText(text) {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return;
    }
    const area = document.createElement("textarea");
    area.value = text;
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }

  function downloadText(text, filename) {
    const blob = new Blob([text], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  function renderShell(root) {
    const presetOptions = Object.entries(PRESETS)
      .map(([value, preset]) => `<option value="${value}">${escapeHtml(preset.label)}</option>`)
      .join("");

    const optionControls = OPTION_DEFS.map(
      ([key, label, help]) => `
        <label class="oacb-option">
          <input type="checkbox" data-option="${key}">
          <span>${escapeHtml(label)}<small>${escapeHtml(help)}</small></span>
        </label>`,
    ).join("");

    root.innerHTML = `
      <div class="oacb-grid">
        <section class="oacb-panel">
          <h2>1. Select API surface</h2>
          <div class="oacb-toolbar">
            <input id="oacb-operation-search" type="search" placeholder="Filter endpoints…" aria-label="Filter endpoints">
            <button type="button" id="oacb-select-all">Select all</button>
            <button type="button" id="oacb-clear-all">Clear</button>
          </div>
          <div id="oacb-operation-list"></div>

          <details class="oacb-subsection">
            <summary>Additional schemas</summary>
            <p class="oacb-help">Optional schema seeds. Dependencies of selected endpoints are included automatically.</p>
            <div class="oacb-toolbar">
              <input id="oacb-schema-search" type="search" placeholder="Filter schemas…" aria-label="Filter schemas">
              <button type="button" id="oacb-clear-schemas">Clear schemas</button>
            </div>
            <div id="oacb-schema-list" class="oacb-schema-list"></div>
          </details>
        </section>

        <section class="oacb-panel">
          <h2>2. Choose context profile</h2>
          <div class="oacb-toolbar">
            <select id="oacb-preset" aria-label="Context preset">
              ${presetOptions}
              <option value="custom">Custom</option>
            </select>
          </div>
          <p id="oacb-preset-help" class="oacb-help"></p>
          <div class="oacb-options">${optionControls}</div>

          <div class="oacb-subsection">
            <h3>Output formatting</h3>
            <label><input type="radio" name="oacb-format" value="compact" checked> Compact JSON</label>
            &nbsp;
            <label><input type="radio" name="oacb-format" value="pretty"> Pretty JSON</label>
          </div>

          <div class="oacb-subsection">
            <h3>Context size</h3>
            <div class="oacb-stats">
              <span class="oacb-stat"><span class="oacb-stat-label">Operations</span> <strong id="oacb-stat-operations">0</strong></span>
              <span class="oacb-stat"><span class="oacb-stat-label">Schemas</span> <strong id="oacb-stat-schemas">0</strong></span>
              <span class="oacb-stat"><span class="oacb-stat-label">Size</span> <strong id="oacb-stat-bytes">0 B</strong></span>
              <span class="oacb-stat"><span class="oacb-stat-label">Approx. tokens</span> <strong id="oacb-stat-tokens">0</strong></span>
            </div>
            <p class="oacb-help">Token count uses a rough 4-characters-per-token estimate and is intended only for planning.</p>
          </div>
        </section>
      </div>

      <section class="oacb-panel oacb-subsection">
        <h2>3. Copy context JSON</h2>
        <div class="oacb-actions">
          <button type="button" id="oacb-copy">Copy JSON</button>
          <button type="button" id="oacb-download">Download JSON</button>
          <span id="oacb-status" class="oacb-status" role="status"></span>
        </div>
        <div id="oacb-warning" class="oacb-warning" hidden></div>
        <textarea id="oacb-output" class="oacb-output" spellcheck="false" aria-label="Generated OpenAPI context JSON"></textarea>
      </section>
    `;
  }

  function initBuilder(root, schema) {
    renderShell(root);

    const operations = getOperations(schema);
    const selectedOperations = new Set();
    const selectedSchemas = new Set();
    const schemaNames = Object.keys(schema.components?.schemas || {}).sort((a, b) => a.localeCompare(b));

    const operationList = root.querySelector("#oacb-operation-list");
    const operationSearch = root.querySelector("#oacb-operation-search");
    const schemaList = root.querySelector("#oacb-schema-list");
    const schemaSearch = root.querySelector("#oacb-schema-search");
    const presetSelect = root.querySelector("#oacb-preset");
    const presetHelp = root.querySelector("#oacb-preset-help");
    const outputArea = root.querySelector("#oacb-output");
    const status = root.querySelector("#oacb-status");
    const warningBox = root.querySelector("#oacb-warning");

    const optionElements = new Map(
      [...root.querySelectorAll("[data-option]")].map((element) => [element.dataset.option, element]),
    );

    function currentOptions() {
      return Object.fromEntries(
        [...optionElements].map(([key, element]) => [key, element.checked]),
      );
    }

    function applyPreset(name) {
      const preset = PRESETS[name];
      if (!preset) return;
      for (const [key, value] of Object.entries(preset.options)) {
        const element = optionElements.get(key);
        if (element) element.checked = value;
      }
      presetHelp.textContent = preset.help;
      scheduleUpdate();
    }

    function markCustom() {
      presetSelect.value = "custom";
      presetHelp.textContent = "Custom combination of context fields.";
    }

    function renderOperations() {
      const query = operationSearch.value.trim().toLowerCase();
      const groups = new Map();
      for (const item of operations) {
        const haystack = [
          item.method,
          item.path,
          item.summary,
          item.operation.operationId || "",
          ...item.tags,
        ].join(" ").toLowerCase();
        if (query && !haystack.includes(query)) continue;
        if (!groups.has(item.primaryTag)) groups.set(item.primaryTag, []);
        groups.get(item.primaryTag).push(item);
      }

      if (groups.size === 0) {
        operationList.innerHTML = '<div class="oacb-empty">No matching operations.</div>';
        return;
      }

      operationList.innerHTML = [...groups.entries()]
        .map(([tag, items]) => {
          const checkedCount = items.filter((item) => selectedOperations.has(item.key)).length;
          const tagId = `oacb-tag-${Math.random().toString(36).slice(2)}`;
          return `
            <div class="oacb-tag" data-tag="${escapeHtml(tag)}">
              <label class="oacb-tag-header">
                <input type="checkbox" class="oacb-tag-checkbox" id="${tagId}" ${checkedCount === items.length ? "checked" : ""} data-indeterminate="${checkedCount > 0 && checkedCount < items.length}">
                <span>${escapeHtml(tag)} <small>(${items.length})</small></span>
              </label>
              ${items.map((item) => `
                <label class="oacb-operation">
                  <input type="checkbox" class="oacb-operation-checkbox" data-key="${escapeHtml(item.key)}" ${selectedOperations.has(item.key) ? "checked" : ""}>
                  <span>
                    <code><span class="oacb-method">${escapeHtml(item.method)}</span>${escapeHtml(item.path)}</code>
                    ${item.summary ? `<span class="oacb-summary">${escapeHtml(item.summary)}</span>` : ""}
                  </span>
                </label>
              `).join("")}
            </div>
          `;
        })
        .join("");

      for (const checkbox of operationList.querySelectorAll(".oacb-tag-checkbox")) {
        checkbox.indeterminate = checkbox.dataset.indeterminate === "true";
      }
    }

    function renderSchemas() {
      const query = schemaSearch.value.trim().toLowerCase();
      const visible = schemaNames.filter((name) => !query || name.toLowerCase().includes(query));
      schemaList.innerHTML = visible.length
        ? visible.map((name) => `
            <label class="oacb-schema-row">
              <input type="checkbox" class="oacb-schema-checkbox" data-schema="${escapeHtml(name)}" ${selectedSchemas.has(name) ? "checked" : ""}>
              <code>${escapeHtml(name)}</code>
            </label>
          `).join("")
        : '<div class="oacb-empty">No matching schemas.</div>';
    }

    function countOutputSchemas(output) {
      return Object.keys(output.components?.schemas || {}).length;
    }

    function updateOutput() {
      const options = currentOptions();
      const { output, warnings } = buildSubset(
        schema,
        selectedOperations,
        selectedSchemas,
        options,
      );
      const format = root.querySelector('input[name="oacb-format"]:checked').value;
      const text = format === "pretty"
        ? JSON.stringify(output, null, 2)
        : JSON.stringify(output);
      outputArea.value = text;

      const bytes = new TextEncoder().encode(text).length;
      root.querySelector("#oacb-stat-operations").textContent = selectedOperations.size.toLocaleString();
      root.querySelector("#oacb-stat-schemas").textContent = countOutputSchemas(output).toLocaleString();
      root.querySelector("#oacb-stat-bytes").textContent = formatBytes(bytes);
      root.querySelector("#oacb-stat-tokens").textContent = Math.ceil(text.length / 4).toLocaleString();

      warningBox.hidden = warnings.length === 0;
      warningBox.textContent = warnings.join(" ");
      status.textContent = `${schema.openapi || "OpenAPI"} source loaded; ${operations.length} operations available.`;
    }

    const scheduleUpdate = debounce(updateOutput);

    operationList.addEventListener("change", (event) => {
      const target = event.target;
      if (target.classList.contains("oacb-operation-checkbox")) {
        target.checked ? selectedOperations.add(target.dataset.key) : selectedOperations.delete(target.dataset.key);
        renderOperations();
        scheduleUpdate();
        return;
      }
      if (target.classList.contains("oacb-tag-checkbox")) {
        const tag = target.closest(".oacb-tag").dataset.tag;
        for (const item of operations.filter((operation) => operation.primaryTag === tag)) {
          target.checked ? selectedOperations.add(item.key) : selectedOperations.delete(item.key);
        }
        renderOperations();
        scheduleUpdate();
      }
    });

    schemaList.addEventListener("change", (event) => {
      const target = event.target;
      if (!target.classList.contains("oacb-schema-checkbox")) return;
      target.checked ? selectedSchemas.add(target.dataset.schema) : selectedSchemas.delete(target.dataset.schema);
      scheduleUpdate();
    });

    operationSearch.addEventListener("input", renderOperations);
    schemaSearch.addEventListener("input", renderSchemas);

    root.querySelector("#oacb-select-all").addEventListener("click", () => {
      for (const item of operations) selectedOperations.add(item.key);
      renderOperations();
      scheduleUpdate();
    });

    root.querySelector("#oacb-clear-all").addEventListener("click", () => {
      selectedOperations.clear();
      renderOperations();
      scheduleUpdate();
    });

    root.querySelector("#oacb-clear-schemas").addEventListener("click", () => {
      selectedSchemas.clear();
      renderSchemas();
      scheduleUpdate();
    });

    presetSelect.addEventListener("change", () => {
      if (presetSelect.value === "custom") {
        presetHelp.textContent = "Custom combination of context fields.";
        return;
      }
      applyPreset(presetSelect.value);
    });

    for (const element of optionElements.values()) {
      element.addEventListener("change", () => {
        markCustom();
        scheduleUpdate();
      });
    }

    for (const radio of root.querySelectorAll('input[name="oacb-format"]')) {
      radio.addEventListener("change", scheduleUpdate);
    }

    root.querySelector("#oacb-copy").addEventListener("click", async () => {
      try {
        await copyText(outputArea.value);
        status.textContent = "Copied JSON to clipboard.";
      } catch (error) {
        status.textContent = `Copy failed: ${error}`;
      }
    });

    root.querySelector("#oacb-download").addEventListener("click", () => {
      downloadText(outputArea.value, "hycompass-openapi-context.json");
      status.textContent = "Downloaded hycompass-openapi-context.json.";
    });

    renderOperations();
    renderSchemas();
    presetSelect.value = "coding";
    applyPreset("coding");
    updateOutput();
  }

  async function main() {
    const root = document.getElementById("openapi-context-builder");
    if (!root || root.dataset.initialized === "true") return;
    root.dataset.initialized = "true";

    const url = root.dataset.openapiUrl;
    try {
      const response = await fetch(url, { cache: "no-store" });
      if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
      const schema = await response.json();
      initBuilder(root, schema);
    } catch (error) {
      root.innerHTML = `
        <div class="oacb-warning">
          Unable to load <code>${escapeHtml(url)}</code>: ${escapeHtml(error)}.
          The published schema asset could not be fetched. Run <code>scripts/docs/serve_docs.sh</code> for local development or rebuild the static documentation so <code>assets/generated/openapi.json</code> is present.
        </div>`;
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main, { once: true });
  } else {
    main();
  }

  // Small public surface for console-level inspection/testing without coupling the
  // documentation page to a framework.
  window.HyCompassOpenApiContextBuilder = {
    buildSubset,
    getOperations,
    presets: PRESETS,
  };
})();
