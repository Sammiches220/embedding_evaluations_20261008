(() => {
  "use strict";

  const PRESETS = {
    balanced: {
      label: "Balanced implementation",
      help: "Full implementation with comments removed, docstrings retained, and whitespace compacted.",
      options: {
        mode: "source",
        removeComments: true,
        removeDocstrings: false,
        removeMainGuards: false,
        collapseBlankLines: true,
        trimTrailingWhitespace: true,
        includePrivate: true,
        includeImports: true,
        fileBoundaries: true,
      },
    },
    compact: {
      label: "Compact implementation",
      help: "Implementation-focused context with comments and docstrings removed and blank space collapsed.",
      options: {
        mode: "source",
        removeComments: true,
        removeDocstrings: true,
        removeMainGuards: false,
        collapseBlankLines: true,
        trimTrailingWhitespace: true,
        includePrivate: true,
        includeImports: true,
        fileBoundaries: true,
      },
    },
    surface: {
      label: "Public API surface",
      help: "AST-derived signatures, decorators, public classes/functions, compact constants, imports, and docstrings; implementation bodies are replaced with ellipses.",
      options: {
        mode: "outline",
        removeComments: true,
        removeDocstrings: false,
        removeMainGuards: true,
        collapseBlankLines: true,
        trimTrailingWhitespace: true,
        includePrivate: false,
        includeImports: true,
        fileBoundaries: true,
      },
    },
    full: {
      label: "Full source",
      help: "Preserve the selected Python files as closely as possible, including comments and docstrings.",
      options: {
        mode: "source",
        removeComments: false,
        removeDocstrings: false,
        removeMainGuards: false,
        collapseBlankLines: false,
        trimTrailingWhitespace: false,
        includePrivate: true,
        includeImports: true,
        fileBoundaries: true,
      },
    },
  };

  const CHECKBOX_OPTIONS = [
    ["removeComments", "Remove comments", "Tokenized Python comments, including type/noqa comments. Source mode only."],
    ["removeDocstrings", "Remove docstrings", "Module, class, function, and async-function docstrings."],
    ["removeMainGuards", "Remove __main__ guards", "Drop top-level if __name__ == '__main__' blocks. Source mode only."],
    ["collapseBlankLines", "Collapse blank lines", "Reduce repeated blank lines to a single blank line."],
    ["trimTrailingWhitespace", "Trim trailing whitespace", "Remove spaces and tabs at line ends."],
    ["includePrivate", "Include private definitions", "In outline mode, include names beginning with a single underscore."],
    ["includeImports", "Include imports", "In outline mode, retain import/from statements for type and dependency context."],
    ["fileBoundaries", "File boundaries", "Add explicit FILE separators when combining multiple sources."],
  ];

  const escapeHtml = (value) => String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MiB`;
  }

  function debounce(fn, delay = 75) {
    let timer = null;
    return (...args) => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => fn(...args), delay);
    };
  }

  async function copyText(text) {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return;
    }
    const area = document.createElement("textarea");
    area.value = text;
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }

  function downloadText(text, filename) {
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  function positionCompare(a, b) {
    return a[0] - b[0] || a[1] - b[1];
  }

  function spanContains(outer, inner) {
    return positionCompare([outer[0], outer[1]], [inner[0], inner[1]]) <= 0
      && positionCompare([outer[2], outer[3]], [inner[2], inner[3]]) >= 0;
  }

  function removeSpans(source, spans) {
    if (!spans.length) return source;
    const lines = source.split("\n").map((line) => Array.from(line));
    const sorted = [...spans].sort((a, b) =>
      b[0] - a[0] || b[1] - a[1] || b[2] - a[2] || b[3] - a[3]);

    for (const [startLine, startCol, endLine, endCol] of sorted) {
      const startIndex = startLine - 1;
      const endIndex = endLine - 1;
      if (startIndex < 0 || endIndex >= lines.length || startIndex > endIndex) continue;
      if (startIndex === endIndex) {
        lines[startIndex].splice(startCol, Math.max(0, endCol - startCol));
        continue;
      }
      lines[startIndex].splice(startCol);
      for (let index = startIndex + 1; index < endIndex; index += 1) lines[index] = [];
      lines[endIndex].splice(0, endCol);
    }
    return lines.map((line) => line.join("")).join("\n");
  }

  function compactWhitespace(source, options) {
    let result = source;
    if (options.trimTrailingWhitespace) {
      result = result.split("\n").map((line) => line.replace(/[ \t]+$/g, "")).join("\n");
    }
    if (options.collapseBlankLines) {
      result = result.replace(/\n[ \t]*\n(?:[ \t]*\n)+/g, "\n\n");
    }
    return result.trimEnd();
  }

  function sourceText(file, options) {
    let spans = [];
    const mainGuards = options.removeMainGuards ? (file.mainGuards || []) : [];
    spans.push(...mainGuards);

    const addOutsideMainGuards = (items) => {
      for (const span of items || []) {
        if (!mainGuards.some((guard) => spanContains(guard, span))) spans.push(span);
      }
    };
    if (options.removeComments) addOutsideMainGuards(file.comments);
    if (options.removeDocstrings) addOutsideMainGuards(file.docstrings);

    return compactWhitespace(removeSpans(file.source, spans), options);
  }

  function outlineText(file, options) {
    if (file.parseError || !file.outlines) return sourceText(file, options);
    const visibility = options.includePrivate ? "all" : "public";
    const docs = options.removeDocstrings ? "nodocs" : "docs";
    const imports = options.includeImports ? "imports" : "noimports";
    return compactWhitespace(file.outlines[`${visibility}_${docs}_${imports}`] || "", options);
  }

  function transformFile(file, options) {
    return options.mode === "outline" ? outlineText(file, options) : sourceText(file, options);
  }

  function buildOutput(files, selectedPaths, options) {
    const selected = files.filter((file) => selectedPaths.has(file.path));
    const chunks = [];
    const warnings = [];
    for (const file of selected) {
      if (options.mode === "outline" && file.parseError) {
        warnings.push(`${file.path}: AST outline unavailable (${file.parseError}); source fallback used.`);
      }
      const text = transformFile(file, options);
      if (options.fileBoundaries) chunks.push(`===== FILE: ${file.path} =====\n${text}`.trimEnd());
      else chunks.push(text.trimEnd());
    }
    return { text: chunks.filter(Boolean).join("\n\n"), warnings };
  }

  function renderShell(root) {
    const presetOptions = Object.entries(PRESETS)
      .map(([key, preset]) => `<option value="${key}">${escapeHtml(preset.label)}</option>`)
      .join("");
    const optionsHtml = CHECKBOX_OPTIONS.map(([key, label, help]) => `
      <label class="oacb-option" data-python-option-row="${key}">
        <input type="checkbox" data-python-option="${key}">
        <span>${escapeHtml(label)}<small>${escapeHtml(help)}</small></span>
      </label>`).join("");

    root.innerHTML = `
      <div class="oacb-grid">
        <section class="oacb-panel">
          <h2>1. Select Python sources</h2>
          <p class="oacb-help">The inventory follows the same public top-level package discovery rules as the generated Python Reference.</p>
          <div class="oacb-toolbar">
            <input id="pycb-search" type="search" placeholder="Filter modules or paths…" aria-label="Filter Python files">
            <button type="button" id="pycb-select-all">Select all</button>
            <button type="button" id="pycb-clear">Clear</button>
          </div>
          <div id="pycb-file-list"></div>
        </section>

        <section class="oacb-panel">
          <h2>2. Minimize context</h2>
          <label><strong>Preset</strong>
            <select id="pycb-preset">${presetOptions}<option value="custom">Custom</option></select>
          </label>
          <p id="pycb-preset-help" class="oacb-help"></p>

          <div class="oacb-mode-row">
            <strong>Representation</strong>
            <label><input type="radio" name="pycb-mode" value="source"> Source</label>
            <label><input type="radio" name="pycb-mode" value="outline"> Signatures / outline</label>
          </div>
          <div class="oacb-options">${optionsHtml}</div>

          <h2>3. Copy context</h2>
          <div class="oacb-stats">
            <span class="oacb-stat"><span class="oacb-stat-label">Files</span> <strong id="pycb-stat-files">0</strong></span>
            <span class="oacb-stat"><span class="oacb-stat-label">Size</span> <strong id="pycb-stat-bytes">0 B</strong></span>
            <span class="oacb-stat"><span class="oacb-stat-label">Approx. tokens</span> <strong id="pycb-stat-tokens">0</strong></span>
          </div>
          <textarea id="pycb-output" class="oacb-output" spellcheck="false" aria-label="Generated Python context"></textarea>
          <div class="oacb-actions">
            <button type="button" id="pycb-copy">Copy</button>
            <button type="button" id="pycb-download">Download .txt</button>
          </div>
          <div id="pycb-warning" class="oacb-warning" hidden></div>
          <p id="pycb-status" class="oacb-status"></p>
        </section>
      </div>`;
  }

  function initBuilder(root, manifest) {
    renderShell(root);
    const files = manifest.files || [];
    const selected = new Set();
    const fileList = root.querySelector("#pycb-file-list");
    const search = root.querySelector("#pycb-search");
    const preset = root.querySelector("#pycb-preset");
    const presetHelp = root.querySelector("#pycb-preset-help");
    const output = root.querySelector("#pycb-output");
    const warning = root.querySelector("#pycb-warning");
    const status = root.querySelector("#pycb-status");

    const optionElements = new Map(
      [...root.querySelectorAll("[data-python-option]")].map((element) => [element.dataset.pythonOption, element]),
    );

    function options() {
      const mode = root.querySelector('input[name="pycb-mode"]:checked')?.value || "source";
      return {
        mode,
        ...Object.fromEntries([...optionElements].map(([key, element]) => [key, element.checked])),
      };
    }

    function setModeState() {
      const mode = root.querySelector('input[name="pycb-mode"]:checked')?.value || "source";
      for (const key of ["removeComments", "removeMainGuards"]) {
        optionElements.get(key).disabled = mode === "outline";
        root.querySelector(`[data-python-option-row="${key}"]`).classList.toggle("oacb-disabled", mode === "outline");
      }
      for (const key of ["includePrivate", "includeImports"]) {
        optionElements.get(key).disabled = mode !== "outline";
        root.querySelector(`[data-python-option-row="${key}"]`).classList.toggle("oacb-disabled", mode !== "outline");
      }
    }

    function applyPreset(name) {
      const config = PRESETS[name];
      if (!config) return;
      for (const radio of root.querySelectorAll('input[name="pycb-mode"]')) {
        radio.checked = radio.value === config.options.mode;
      }
      for (const [key, element] of optionElements) element.checked = Boolean(config.options[key]);
      preset.value = name;
      presetHelp.textContent = config.help;
      setModeState();
      updateOutput();
    }

    function markCustom() {
      preset.value = "custom";
      presetHelp.textContent = "Custom combination of Python context transformations.";
      setModeState();
    }

    function renderFiles() {
      const query = search.value.trim().toLowerCase();
      const visible = files.filter((file) => !query || `${file.path} ${file.module} ${file.package}`.toLowerCase().includes(query));
      const groups = new Map();
      for (const file of visible) {
        if (!groups.has(file.package)) groups.set(file.package, []);
        groups.get(file.package).push(file);
      }
      if (!groups.size) {
        fileList.innerHTML = '<div class="oacb-empty">No matching Python files.</div>';
        return;
      }
      fileList.innerHTML = [...groups.entries()].map(([group, groupFiles]) => {
        const checkedCount = groupFiles.filter((file) => selected.has(file.path)).length;
        return `<div class="oacb-tag" data-python-group="${escapeHtml(group)}">
          <label class="oacb-tag-header">
            <input type="checkbox" class="pycb-group-checkbox" ${checkedCount === groupFiles.length ? "checked" : ""} data-indeterminate="${checkedCount > 0 && checkedCount < groupFiles.length}">
            <span>${escapeHtml(group)} <small>(${groupFiles.length})</small></span>
          </label>
          ${groupFiles.map((file) => `<label class="oacb-operation">
            <input type="checkbox" class="pycb-file-checkbox" data-path="${escapeHtml(file.path)}" ${selected.has(file.path) ? "checked" : ""}>
            <span><code>${escapeHtml(file.module || file.path)}</code><span class="oacb-summary">${escapeHtml(file.path)}</span></span>
          </label>`).join("")}
        </div>`;
      }).join("");
      for (const box of fileList.querySelectorAll(".pycb-group-checkbox")) box.indeterminate = box.dataset.indeterminate === "true";
    }

    function updateOutput() {
      const { text, warnings } = buildOutput(files, selected, options());
      output.value = text;
      const bytes = new TextEncoder().encode(text).length;
      root.querySelector("#pycb-stat-files").textContent = selected.size.toLocaleString();
      root.querySelector("#pycb-stat-bytes").textContent = formatBytes(bytes);
      root.querySelector("#pycb-stat-tokens").textContent = Math.ceil(text.length / 4).toLocaleString();
      warning.hidden = warnings.length === 0;
      warning.textContent = warnings.join(" ");
      status.textContent = `${files.length} Python files available from generated reference sources.`;
    }

    const scheduleUpdate = debounce(updateOutput);
    fileList.addEventListener("change", (event) => {
      const target = event.target;
      if (target.classList.contains("pycb-file-checkbox")) {
        target.checked ? selected.add(target.dataset.path) : selected.delete(target.dataset.path);
        renderFiles();
        scheduleUpdate();
      } else if (target.classList.contains("pycb-group-checkbox")) {
        const group = target.closest("[data-python-group]").dataset.pythonGroup;
        for (const file of files.filter((item) => item.package === group)) {
          target.checked ? selected.add(file.path) : selected.delete(file.path);
        }
        renderFiles();
        scheduleUpdate();
      }
    });
    search.addEventListener("input", renderFiles);
    root.querySelector("#pycb-select-all").addEventListener("click", () => {
      for (const file of files) selected.add(file.path);
      renderFiles();
      scheduleUpdate();
    });
    root.querySelector("#pycb-clear").addEventListener("click", () => {
      selected.clear();
      renderFiles();
      scheduleUpdate();
    });
    preset.addEventListener("change", () => {
      if (preset.value === "custom") markCustom();
      else applyPreset(preset.value);
    });
    for (const element of optionElements.values()) {
      element.addEventListener("change", () => {
        markCustom();
        scheduleUpdate();
      });
    }
    for (const radio of root.querySelectorAll('input[name="pycb-mode"]')) {
      radio.addEventListener("change", () => {
        markCustom();
        scheduleUpdate();
      });
    }
    root.querySelector("#pycb-copy").addEventListener("click", async () => {
      try {
        await copyText(output.value);
        status.textContent = "Copied Python context to clipboard.";
      } catch (error) {
        status.textContent = `Copy failed: ${error}`;
      }
    });
    root.querySelector("#pycb-download").addEventListener("click", () => {
      downloadText(output.value, "hycompass-python-context.txt");
      status.textContent = "Downloaded hycompass-python-context.txt.";
    });

    renderFiles();
    applyPreset("balanced");
  }

  async function main() {
    const root = document.getElementById("python-context-builder");
    if (!root || root.dataset.initialized === "true") return;
    root.dataset.initialized = "true";
    const url = root.dataset.contextUrl;
    try {
      const response = await fetch(url, { cache: "no-store" });
      if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
      initBuilder(root, await response.json());
    } catch (error) {
      root.innerHTML = `<div class="oacb-warning">Unable to load <code>${escapeHtml(url)}</code>: ${escapeHtml(error)}. Run <code>scripts/docs/serve_docs.sh</code> or rebuild the static documentation so the generated Python context manifest exists.</div>`;
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", main, { once: true });
  else main();

  window.HyCompassPythonContextBuilder = { buildOutput, presets: PRESETS, removeSpans };
})();
