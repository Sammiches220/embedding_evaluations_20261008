I want you to create a new modular Python project called HyCompass Hydrus Viewer that works with two other REST APIs. The goal of this new project is to work directly with a Hydrus Network instance to load files that are selected in the main HyCompass instance.

To do this, it needs to interact with two other applications: HyCompass (latent observer) + a Hydrus Embedding Tracker.

HyCompass has views which allow for selecting specific data points, which also must be within some specified domain. Upon selection changes, HyCompass can respond with SSE events for some watchers, which includes point selections including deltas as well. 

This new application must see events, resolve item IDs, and then check those item IDs against the Hydrus Embedding Tracker app.

SSE event
   │
   ├── tiny delta available
   │       ↓
   │   added_rows / removed_rows
   │       ↓
   │   /items/features
   │       ↓
   │   canonical item_ids
   │
   └── snapshot required
           ↓
       /working-selection
           ↓
       rows + item_ids together


To check item IDs against the Hydrus Embedding Tracker, this application needs to first relate HyCompass domain item Ids to UUIDs on the Hydrus Embedding Tracker. Once a user defines a HyCompass domain which should be able to relate to UUIDs, then it is necessary to have a mapping table. Ideally, the item IDs from the HyCompass domain are identical to the UUIDs from the tracker. However, this is not guaranteed. As such, there needs to be an option to provide some mapping of IDs. By default this mapping does still exist, but is just automatically populated upon definition since the mappings are identical. 

Note that there is a potential for a LOT of mappings, so please use some performane mechanisms to improve lookup if necessary.

Then, once it has related the item IDs, it can query the Embedding Tracker:

For Hydrus Embedding Tracker:
```
there is a direct REST endpoint for a tracker-owned item ID:

GET /items/{item_id}

For example:

curl http://127.0.0.1:8765/items/550e8400-e29b-41d4-a716-446655440000

If the item exists, the response looks roughly like:

{
  "item": {
    "item_id": "550e8400-e29b-41d4-a716-446655440000",
    "item_hash": "...",
    "hydrus_file_id": 12345,
    "hydrus_hash": "...",
    "last_seen_at": "..."
  },
  "embeddings": [
    {
      "embedding_record_id": "...",
      "embedding_type_id": "swinv2-v3",
      "name": "SwinV2 v3",
      "version": "3",
      "source_hash": "...",
      "embedding_dimension": 1024,
      "updated_at": "..."
    }
  ]
}

If the item does not exist, the current implementation does not return a 404. It returns:

{
  "item": null,
  "embeddings": []
}

So programmatically, the existence check is simply:

import requests

item_id = "550e8400-e29b-41d4-a716-446655440000"

r = requests.get(
    f"http://127.0.0.1:8765/items/{item_id}",
    timeout=30,
)
r.raise_for_status()

data = r.json()

if data["item"] is not None:
    print("Item exists")
else:
    print("Item is not in the tracker")

The endpoint also conveniently tells you which embedding types that item already has, so you can distinguish:

item exists in tracker
        vs.
item exists and already has SwinV2
        vs.
item exists but does not have SwinV2

For example:

has_swin = any(
    e["embedding_type_id"] == "swinv2-v3"
    for e in data["embeddings"]
)

One important distinction: this endpoint expects the tracker's UUID-style item_id, not a Hydrus numeric file_id. The tracker item ID is its own stable identity. If all you have is a Hydrus file_id, v0.4.1 does not currently expose an equally direct GET /items/by-hydrus-file-id/{id} REST lookup, even though the repository internally supports that lookup.
```

This lets the app get the Hydrus information directly.

Then, once it has the Hydrus information, it should be able to query the Hydrus API to let the user view information about the item. Try to keep the information relatively simply displayed. There's no need to try to emulate what Hydrus does, just keep it simple and ultra fast.

Additionally, there importantly should be an option to export Hydrus item IDs and also send them to a new page in Hydrus. Keep this implementation simple as well.

Note that HyCompass allows one or multiple selections. This watcher project should be able to display individual selection thumbnails very quickly, and then have a button to fetch the full item if desired. Similar with multiple files, but these should be paginated with thumbnails and then update with full items from Hydrus if desired (click on thumbnail). Similar to any typical Hydrus gallery viewer.

Please provide your implementation as a modular Python QT project.

Attached should be all the different forms of documentation you may need.