Hello, I am interested in creating an application that is able to interface with Hydrus Network and track what items have records of registered types of embeddings. This application will expose an interface to register types of embeddings, manage records of embeddings per item per type, then perform tracking and synchronization of these embeddings.

The application will not keep track of how the embeddings are created or provide anything to actually create embeddings, but rather solely acts as an application that interfaces with Hydrus Network's client API to provide a means to track and watch items and what embedding types they have.

You should provide a downloadable set of Python files that make up a modularized project. Please include argparse for the cli, type hints, proper logging, and use pathlib for any filepaths.

Please have a .env with only the Hydrus access key + URL/port, with a config.py for anything else that needs configurations.

**Please also provide a basic QT gui in addition to the cli.**


Sample embedding type record is below. These reocrds serve as both record keeping AND the necessary information to perform a Hydrus Client API search for the "universe" of the items to keep track of.

{
    "embedding_type_id": "uuid",
    "name": "name",
    "description": "description",
    "version": "1.0",
    "selection_criteria": {  # See hydrus search files API documentation
        ...
    },
    "created_at": "...",
    "updated_at": "...",
    "active": true,
}

The selection criteria will be specified exactly as it goes into the Hydrus Network for searching files:

GET /get_files/search_files¶

Search for the client's files.

Restricted access:
    YES. Search for Files permission needed. Additional search permission limits may apply.

Required Headers: n/a

Arguments (in percent-encoded JSON):

        tags: (a list of tags you wish to search for)
        file domain (optional, defaults to combined local file domains)
        tag_service_key: (optional, hexadecimal, the tag domain on which to search, defaults to combined local file domains)
        include_current_tags: (optional, bool, whether to search 'current' tags, defaults to true)
        include_pending_tags: (optional, bool, whether to search 'pending' tags, defaults to true)
        file_sort_type: (optional, integer, the results sort method, defaults to 2 for import time)
        file_sort_asc: true or false (optional, default true, the results sort order)
        return_file_ids: true or false (optional, default true, returns file id results)
        return_hashes: true or false (optional, default false, returns hex hash results)

Example request for 16 files (system:limit=16) in the inbox with tags "blue eyes", "blonde hair", and "кино"

/get_files/search_files?tags=%5B%22blue%20eyes%22%2C%20%22blonde%20hair%22%2C%20%22%5Cu043a%5Cu0438%5Cu043d%5Cu043e%22%2C%20%22system%3Ainbox%22%2C%20%22system%3Alimit%3D16%22%5D

If the access key's permissions only permit search for certain tags, at least one positive whitelisted/non-blacklisted tag must be in the "tags" list or this will 403. Tags can be prepended with a hyphen to make a negated tag (e.g. "-green eyes"), but these will not be checked against the permissions whitelist.

Wildcards and namespace searches are supported, so if you search for 'character:sam*' or 'series:*', this will be handled correctly clientside.

Many system predicates are also supported using a text parser! The parser was designed by a clever user for human input and allows for a certain amount of error (e.g. ~= instead of ≈, or "isn't" instead of "is not") or requires more information (e.g. the specific hashes for a hash lookup). Here's a big list of supported examples:
System Predicates

Please test out the system predicates you want to send. If you are in help->advanced mode, you can test this parser in the advanced text input dialog when you click the OR* button on a tag autocomplete dropdown. More system predicate types and input formats will be available in future. Reverse engineering system predicate data from text is obviously tricky. If a system predicate does not parse, you'll get 400.

Also, OR predicates are now supported! Just nest within the tag list, and it'll be treated like an OR. For instance:

    [ "skirt", [ "space bounty hunter", "jane raider" ], "system:height > 1000" ]

Makes:

    skirt
    space bounty hunter OR jane raider
    system:height > 1000

The file and tag services are for search domain selection, just like clicking the buttons in the client. They are optional--default is 'combined local file domains' and 'all known tags'.

include_current_tags and include_pending_tags do the same as the buttons on the normal search interface. They alter the search of normal tags and tag-related system predicates like 'system:number of tags', including or discluding that type of tag from whatever the search is doing. If you set both of these to false, you'll often get no results.

File searches occur in the display tag_display_type. If you want to pair autocomplete tag lookup from /search_tags to this file search (e.g. for making a standard booru search interface), then make sure you are searching display tags there.

file_sort_asc is 'true' for ascending, and 'false' for descending. The default is descending.

file_sort_type is by default import time. It is an integer according to the following enum, and I have written the semantic (asc/desc) meaning for each type after:

    0 - file size (smallest first/largest first)
    1 - duration (shortest first/longest first)
    2 - import time (oldest first/newest first)
    3 - filetype (N/A)
    4 - random (N/A)
    5 - width (slimmest first/widest first)
    6 - height (shortest first/tallest first)
    7 - ratio (tallest first/widest first)
    8 - number of pixels (ascending/descending)
    9 - number of tags (on the current tag domain) (ascending/descending)
    10 - number of media views (ascending/descending)
    11 - total media viewtime (ascending/descending)
    12 - approximate bitrate (smallest first/largest first)
    13 - has audio (audio first/silent first)
    14 - modified time (oldest first/newest first)
    15 - framerate (slowest first/fastest first)
    16 - number of frames (smallest first/largest first)
    18 - last viewed time (oldest first/newest first)
    19 - archive timestamp (oldest first/newest first)
    20 - hash hex (lexicographic/reverse lexicographic)
    21 - pixel hash hex (lexicographic/reverse lexicographic)
    22 - blurhash (lexicographic/reverse lexicographic)
    23 - average colour - lightness (darkest first/lightest first)
    24 - average colour - chromatic magnitude (greys first/colours first)
    25 - average colour - green/red axis (greens first/reds first)
    26 - average colour - blue/yellow axis (blues first/yellows first)
    27 - average colour - hue (rainbow - red first/rainbow - purple first)

The pixel, blurhash, and average colour sorts will put files without one of these (e.g. an mp3) at the end, regardless of asc/desc.

Response:

    The full list of numerical file ids that match the search.
    Example response

    {
        "file_ids" : [125462, 4852415, 123, 591415]
    }

    Example response with return_hashes=true

    {
      "hashes" : [
        "1b04c4df7accd5a61c5d02b36658295686b0abfebdc863110e7d7249bba3f9ad",
        "fe416723c731d679aa4d20e9fd36727f4a38cd0ac6d035431f0f452fad54563f",
        "b53505929c502848375fbc4dab2f40ad4ae649d34ef72802319a348f81b52bad"
      ],
      "file_ids" : [125462, 4852415, 123]
    }

    You can of course also specify return_hashes=true&return_file_ids=false just to get the hashes. The order of both lists is the same.

    File ids are internal and specific to an individual client. For a client, a file with hash H always has the same file id N, but two clients will have different ideas about which N goes with which H. IDs are a bit faster to retrieve than hashes and search with en masse, which is why they are exposed here.

    This search does not apply the implicit limit that most clients set to all searches (usually 10,000), so if you do system:everything on a client with millions of files, expect to get boshed. Even with a system:limit included, complicated queries with large result sets may take several seconds to respond. Just like the client itself.



Sample item record:

{
    "item_id": "12345",  # Primary key from API
    "item_hash": "abc123",
    "last_seen_at": "...",
    "api_metadata": {  # Optional
        ...
    }
}

Sample embedding record:

{
    "embedding_record_id": "uuid",
    "embedding_type_id": "uuid",
    "item_id": "12345",
    "source_hash": "abc123",
    "embedding_dimension: 768,
    "embedding_vector": [...],
    "embedding_metadata": ...,
    "run_id": "run_id",
    "created_at": "...",
    "updated_at": "...",
}

Sample embedding run:

{
    "run_id": "run_42",
    "embedding_type_id": "uuid",
    "description": "...",
    "started_at": "...",
    "completed_at": "...",
    "status": "completed",
    "records_attempted": 1000,
    "record_succeeded": 200,
    "records_failed": 800,
    "metadata": {},
}


Below is an initial sample exposed API schema. This shouldn't be anything hosted on any network yet, but instead should be exposed functions that a cli interacts with, but please do plan around having alternative means of communication such as a proper REST API.

1. Embedding Type Management

register_embedding_type
update_embedding_type
remove_embedding_type

get_embedding_type
list_embedding_types

2. Embedding Record Management

insert_embedding
verify_embedding
update_embedding
delete_embedding

3. Tracking / Synchronization

get_pending_items  # This queries the Hydrus Network API and sees what is NOT already embedded from the search criteria + embedding type. The app does NOT maintain a queue or run embedding processes.
get_embedded_items
get_item_status  # Includes what embedding types have this record
get_embedding_statistics

4. Run Tracking 
Run tracking is primarily a means for record keeping. It's not necessary for every embedding to have a registered run, but it's nice to have.

register_embedding_run
get_embedding_runs

5. Exporting Data and fetching item metadata

There should be 2 functions here. One to export an npy of embeddings + the item_ids, then another to export an npy first_seen.npy which corresponds to the `time_archived` for each of the records from fetching Hydrus Network item metadata. This is a large call since it will make a call to Hydrus per every item. Importantly this should have an option to save the JSON output of every item into a table. There will also be two more to work with item metadata. These are not a main focus since Hydrus is always the source of truth, but it's a performance feature to decrease calls when working with other applications. The JSON metadata should be saved to a completely separate sqlite database and have an option to be toggled on/off (default: off) to avoid bloating issues.

export_embeddings
export_first_seen
update_item_metadata
export_item_metadata  # These will be JSON ofc


The exported first seen and embeddings should be in the format of an npy format that matches the following exported formats:

## `embeddings.npy`

- Shape: `[N, D]`
- Typical dtype: `float32`
- Meaning: one embedding vector per item.
- Purpose: defines similarity/geometry before projection into the 2D map.

Example:

```python
embeddings.shape == (100000, 64)
```

`embeddings[i]` is the embedding for the item identified by `item_ids[i]`.

## `item_ids.npy`

- Shape: `[N]`
- Typical dtype: Unicode strings, integer IDs, or another non-object NumPy dtype.
- Meaning: stable identity for each item.
- Purpose: lets external systems refer back to the correct representation row.

Example:

```python
item_ids[i] == "item_00001234"
```

Real projects might use SHA-256 hashes, Hydrus hashes, post IDs, UUIDs, or database keys.

## `first_seen.npy`

This will be a dataframe of UNIX timestamps (as those are what are in Hydrus) that can go into the following script:

```
#!/usr/bin/env python3
"""
Convert Unix first-observation timestamps stored in a 1D .npy array into the
normalized first_seen.npy format expected by the Latent Observer representation.

Input
-----
A numeric NumPy array shaped [N], for example:

    [1641044542, 1641227345, -1, 1641510081, ...]

Values >= 0 are treated as Unix timestamps in seconds.
Negative values and NaN are treated as "never observed".

Output
------
A float32 NumPy array shaped [N]:

    0.0 .. 1.0  = normalized position in observation history
    2.0         = never observed

Normalization uses the earliest and latest observed timestamps:

    normalized = (timestamp - earliest) / (latest - earliest)

Example
-------
    python unix_timestamps_to_first_seen.py observed_at.npy first_seen.npy
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np


UNOBSERVED_VALUE = np.float32(2.0)


def convert_timestamps(values: np.ndarray) -> tuple[np.ndarray, dict]:
    values = np.asarray(values)

    if values.ndim != 1:
        raise ValueError(
            f"Expected a 1D array shaped [N], got shape {values.shape}."
        )

    if not np.issubdtype(values.dtype, np.number):
        raise TypeError(
            f"Expected a numeric dtype containing Unix timestamps, got {values.dtype}."
        )

    timestamps = values.astype(np.float64, copy=False)

    observed_mask = np.isfinite(timestamps) & (timestamps >= 0.0)
    observed = timestamps[observed_mask]

    result = np.full(values.shape, UNOBSERVED_VALUE, dtype=np.float32)

    if observed.size == 0:
        return result, {
            "items": int(values.size),
            "observed": 0,
            "unobserved": int(values.size),
            "earliest": None,
            "latest": None,
        }

    earliest = float(observed.min())
    latest = float(observed.max())

    if latest > earliest:
        normalized = (timestamps[observed_mask] - earliest) / (latest - earliest)
        result[observed_mask] = normalized.astype(np.float32)
    else:
        result[observed_mask] = np.float32(0.0)

    return result, {
        "items": int(values.size),
        "observed": int(observed.size),
        "unobserved": int(values.size - observed.size),
        "earliest": int(earliest) if earliest.is_integer() else earliest,
        "latest": int(latest) if latest.is_integer() else latest,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Convert a [N] NumPy array of Unix timestamps in seconds into "
            "normalized first_seen.npy values."
        )
    )
    parser.add_argument("input", type=Path, help="Input Unix timestamp .npy file")
    parser.add_argument("output", type=Path, help="Output first_seen.npy file")
    args = parser.parse_args()

    values = np.load(args.input, allow_pickle=False)
    first_seen, stats = convert_timestamps(values)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.save(args.output, first_seen)

    print(f"Input:      {args.input}")
    print(f"Output:     {args.output}")
    print(f"Items:      {stats['items']:,}")
    print(f"Observed:   {stats['observed']:,}")
    print(f"Unobserved: {stats['unobserved']:,}")

    if stats["earliest"] is not None:
        print(f"Earliest Unix timestamp: {stats['earliest']}")
        print(f"Latest Unix timestamp:   {stats['latest']}")

    print()
    print("Output convention:")
    print("  0.0 .. 1.0 = normalized first-observation time")
    print("  2.0        = never observed")


if __name__ == "__main__":
    main()
```


# Relevant Hydrus API Client Documentation

API¶

In general, the API deals with standard UTF-8 JSON. POST requests and 200 OK responses are generally going to be a JSON 'Object' with variable names as keys and values obviously as values. There are examples throughout this document. For GET requests, everything is in standard GET parameters, but some variables are complicated and will need to be JSON-encoded and then URL-encoded. An example would be the 'tags' parameter on GET /get_files/search_files, which is a list of strings. Since GET http URLs have limits on what characters are allowed, but hydrus tags can have all sorts of characters, you'll be doing this:

    Your list of tags:

    [ 'character:space bounty hunter', 'creator:青い桜', 'system:height > 2000' ]

    JSON-encoded:

    ["character:space bounty hunter", "creator:\\u9752\\u3044\\u685c", "system:height > 2000"]

    Then URL-encoded:

    %5B%22character%3Aspace%20bounty%20hunter%22%2C%20%22creator%3A%5Cu9752%5Cu3044%5Cu685c%22%2C%20%22system%3Aheight%20%3E%202000%22%5D

    In python, converting your tag list to the URL-encoded string would be:

    urllib.parse.quote( json.dumps( tag_list ), safe = '' )

    Full URL path example:

    /get_files/search_files?file_sort_type=6&file_sort_asc=false&tags=%5B%22character%3Aspace%20bounty%20hunter%22%2C%20%22creator%3A%5Cu9752%5Cu3044%5Cu685c%22%2C%20%22system%3Aheight%20%3E%202000%22%5D

The API returns JSON for everything except actual file/thumbnail requests. Every JSON response includes the version of the Client API and hydrus_version of the Client hosting it (for brevity, these values are not included in the example responses in this help). For errors, you'll typically get 400 for a missing/invalid parameter, 401/403/419 for missing/insufficient/expired access, and 500 for a real deal serverside error.

Note

For any request sent to the API, the total size of the initial request line (this includes the URL and any parameters) and the headers must not be larger than 2 megabytes. Exceeding this limit will cause the request to fail. Make sure to use pagination if you are passing very large JSON arrays as parameters in a GET request.
CBOR¶

The API now tentatively supports CBOR, which is basically 'byte JSON'. If you are in a lower level language or need to do a lot of heavy work quickly, try it out!

To send CBOR, for POST put Content-Type application/cbor in your request header instead of application/json, and for GET just add a cbor=1 parameter to the URL string. Use CBOR to encode any parameters that you would previously put in JSON:

For POST requests, just print the pure bytes in the body, like this:

cbor2.dumps( arg_dict )

For GET, encode the parameter value in base64, like this:

base64.urlsafe_b64encode( cbor2.dumps( argument ) )

-or-

str( base64.urlsafe_b64encode( cbor2.dumps( argument ) ), 'ascii' )

If you send CBOR, the client will return CBOR. If you want to send CBOR and get JSON back, or vice versa (or you are uploading a file and can't set CBOR Content-Type), send the Accept request header, like so:

Accept: application/cbor
Accept: application/json

If the client does not support CBOR, you'll get 406.
Access and permissions¶

The client gives access to its API through different 'access keys', which are the typical random 64-character hex used in many other places across hydrus. Each guarantees different permissions such as handling files or tags. Most of the time, a user will provide full access, but do not assume this. If a access key header or parameter is not provided, you will get 401, and all insufficient permission problems will return 403 with appropriate error text.

Access is required for every request. You can provide this as an http header, like so:

Hydrus-Client-API-Access-Key : 0150d9c4f6a6d2082534a997f4588dcf0c56dffe1d03ffbf98472236112236ae

Or you can include it in the normal parameters of any request (except POST /add_files/add_file, which uses the entire POST body for the file's bytes).

For GET, this means including it into the URL parameters:

/get_files/thumbnail?file_id=452158&Hydrus-Client-API-Access-Key=0150d9c4f6a6d2082534a997f4588dcf0c56dffe1d03ffbf98472236112236ae

For POST, this means in the JSON body parameters, like so:

{
    "hash_id" : 123456,
    "Hydrus-Client-API-Access-Key" : "0150d9c4f6a6d2082534a997f4588dcf0c56dffe1d03ffbf98472236112236ae"
}

There is also a simple 'session' system, where you can get a temporary key that gives the same access without having to include the permanent access key in every request. You can fetch a session key with the /session_key command and thereafter use it just as you would an access key, just with Hydrus-Client-API-Session-Key instead.

Session keys will expire if they are not used within 24 hours, or if the client is restarted, or if the underlying access key is deleted. An invalid/expired session key will give a 419 result with an appropriate error text.

Bear in mind the Client API is still under construction. Setting up the Client API to be accessible across the internet requires technical experience to be convenient. HTTPS is available for encrypted comms, but the default certificate is self-signed (which basically means an eavesdropper can't see through it, but your ISP/government could if they decided to target you). If you have your own domain to host from and an SSL cert, you can replace them and it'll use them instead (check the db directory for client.crt and client.key). Otherwise, be careful about transmitting sensitive content outside of your localhost/network.
Common Complex Parameters¶
files¶

If you need to refer to some files, you can use any of the following:

Arguments:

        file_id: (selective, a numerical file id)
        file_ids: (selective, a list of numerical file ids)
        hash: (selective, a hexadecimal SHA256 hash)
        hashes: (selective, a list of hexadecimal SHA256 hashes)

In GET requests, make sure any list is percent-encoded JSON. Your [1,2,3] becomes urllib.parse.quote( json.dumps( [1,2,3] ), safe = '' ), and thus file_ids=%5B1%2C%202%2C%203%5D.
file domain¶

When you are searching, you may want to specify a particular file domain. Most of the time, you'll want to just set file_service_key, but this can get complex:

Arguments:

        file_service_key: (optional, selective A, hexadecimal, the file domain on which to search)
        file_service_keys: (optional, selective A, list of hexadecimals, the union of file domains on which to search)
        deleted_file_service_key: (optional, selective B, hexadecimal, the 'deleted from this file domain' on which to search)
        deleted_file_service_keys: (optional, selective B, list of hexadecimals, the union of 'deleted from this file domain' on which to search)

The service keys are as in /get_services.

Hydrus supports two concepts here:

    Searching over a UNION of subdomains. If the user has several local file domains, e.g. 'favourites', 'personal', 'sfw', and 'nsfw', they might like to search two of them at once.
    Searching deleted files of subdomains. You can specifically, and quickly, search the files that have been deleted from somewhere.

You can play around with this yourself by clicking 'multiple locations' in the client with help->advanced mode on.

In extreme edge cases, these two can be mixed by populating both A and B selective, making a larger union of both current and deleted file records.

Please note that unions can be very very computationally expensive. If you can achieve what you want with a single file_service_key, two queries in a row with different service keys, or an umbrella like combined local file domains or hydrus local file storage, please do. Otherwise, let me know what is running slow and I'll have a look at it.

'deleted from hydrus local file storage' is all files that have been physically deleted (i.e. deleted from the trash) and not available any more for fetch file/thumbnail requests. 'deleted from combined local file domains' includes all of those physically deleted files and the trash. If a file is deleted with the special 'do not leave a deletion record' command, then it won't show up in a 'deleted from file domain' search!

'all known files' is a tricky domain. It converts much of the search tech to ignore where files actually are and look at the accompanying tag domain (e.g. all the files that have been tagged), and can sometimes be very expensive.

Also, if you have the option to set both file and tag domains, you cannot enter 'all known files'/'all known tags'. It is too complicated to support, sorry!

The Services Object¶

Hydrus manages its different available domains and actions with what it calls services. If you are a regular user of the program, you will know about review services and manage services. The Client API needs to refer to services, either to accept commands from you or to tell you what metadata files have and where.

When the client tells you about the available services, it gives you the following structure, typically under a services_v2 key right off the root node.
Services Object (actually a List)

[
  {
    "name" : "my tags",
    "service_key" : "c6f63616c2074616773",
    "type": 5,
    "type_pretty" : "local tag domain"
  },
  {
    "name" : "example tag repo",
    "service_key" : "5674450950748cfb28778b511024cfbf0f9f67355cf833de632244078b5a6f8d",
    "type" : 0,
    "type_pretty" : "hydrus tag repository"
  },
  {
    "name" : "my files",
    "service_key" : "6c6f63616c2066696c6573",
    "type" : 2,
    "type_pretty" : "local file domain"
  },
  {
    "name" : "repository updates",
    "service_key" : "7265706f7369746f72792075706461746573",
    "type" : 20,
    "type_pretty" : "local update file domain"
  },
  {
    "name": "example file repo",
    "service_key" : "ae7d9a603008919612894fc360130ae3d9925b8577d075cd0473090ac38b12b6",
    "type" : 1,
    "type_pretty" : "hydrus file repository"
  },
  {
    "name" : "hydrus local file storage",
    "service_key" : "616c6c206c6f63616c2066696c6573",
    "type": 15,
    "type_pretty" : "virtual combined local file domain"
  },
  {
    "name" : "combined local file domains",
    "service_key" : "616c6c206c6f63616c206d65646961",
    "type" : 21,
    "type_pretty" : "virtual combined local media domain"
  },
  {
    "name" : "all known files",
    "service_key" : "616c6c206b6e6f776e2066696c6573",
    "type" : 11,
    "type_pretty" : "virtual combined file domain"
  },
  {
    "name" : "all known tags",
    "service_key" : "616c6c206b6e6f776e2074616773",
    "type": 10,
    "type_pretty" : "virtual combined tag domain"
  },
  {
    "name" : "example local rating like service",
    "service_key" : "74d52c6238d25f846d579174c11856b1aaccdb04a185cb2c79f0d0e499284f2c",
    "type" : 7,
    "type_pretty" : "local like/dislike rating service",
    "star_shape" : "svg",
    "show_in_thumbnail" : true,
    "show_in_thumbnail_even_when_null" : true,
    "colours": {
      "dislike": {
        "brush": "#FFFFFF",
        "pen": "#000000"
      },
      "like": {
        "brush": "#50C878",
        "pen": "#000000"
      },
      "mixed": {
        "brush": "#5F5F5F",
        "pen": "#000000"
      },
      "null": {
        "brush": "#BFBFBF",
        "pen": "#000000"
      }
    }
  },
  {
    "name": "example local rating numerical service",
    "service_key" : "90769255dae5c205c975fc4ce2efff796b8be8a421f786c1737f87f98187ffaf",
    "type": 6,
    "type_pretty": "local numerical rating service",
    "star_shape": "fat star",
    "allows_zero": false,
    "min_stars": 1,
    "max_stars": 5,
    "show_in_thumbnail": true,
    "show_in_thumbnail_even_when_null": false,
    "colours": {
      "dislike": {
        "brush": "#FFFFFF",
        "pen": "#000000"
      },
      "like": {
        "brush": "#50C878",
        "pen": "#000000"
      },
      "mixed": {
        "brush": "#5F5F5F",
        "pen": "#000000"
      },
      "null": {
        "brush": "#BFBFBF",
        "pen": "#000000"
      }
    }
  },
  {
    "name": "example local rating inc/dec service",
    "service_key" : "b474e0cbbab02ca1479c12ad985f1c680ea909a54eb028e3ad06750ea40d4106",
    "type": 22,
    "type_pretty": "local inc/dec rating service",
    "show_in_thumbnail": false,
    "show_in_thumbnail_even_when_null": false,
    "colours": {
      "like": {
        "brush": "#50C878",
        "pen": "#000000"
      },
      "mixed": {
        "brush": "#5F5F5F",
        "pen": "#000000"
      }
    }
  },
  {
    "name" : "trash",
    "service_key" : "7472617368",
    "type" : 14,
    "type_pretty" : "local trash file domain"
  }
]

You will likely see an older, uglier format, under a services key--you can ignore this.

All services have these properties:

    name - A mutable human-friendly name like 'my tags'. You can use this to present the service to the user--they should recognise it.
    type - An integer enum saying whether the service is a local tag domain or like/dislike rating or whatever. This cannot change.
    service_key - The true 'id' of the service. It is a string of hex, sometimes just twenty or so characters but in many cases sixty-four characters. This cannot change, and it is how we will refer to different services.

This service_key is important. A user can rename their services, so name is not an excellent identifier, and definitely not something you should save to any permanent config file.

If we want to search some files on a particular file and tag domain, we should expect to be saying something like file_service_key=6c6f63616c2066696c6573 and tag_service_key=f032e94a38bb9867521a05dc7b189941a9c65c25048911f936fc639be2064a4b somewhere in the request.

You won't see all of these, but the service type enum is:

    0 - tag repository
    1 - file repository
    2 - a local file domain like 'my files'
    5 - a local tag domain like 'my tags'
    6 - a 'numerical' rating service with several stars
    7 - a 'like/dislike' rating service with on/off status
    10 - all known tags -- a union of all the tag services
    11 - all known files -- a union of all the file services and files that appear in tag services
    12 - the local booru -- you can ignore this
    13 - IPFS
    14 - trash
    15 - hydrus local file storage -- all files on hard disk ('combined local file domains' + updates + trash)
    17 - file notes
    18 - Client API
    19 - deleted from anywhere -- you can ignore this
    20 - local updates -- a file domain to store repository update files in
    21 - combined local file domains -- union of combined local file domains
    22 - a 'inc/dec' rating service with positive integer rating
    99 - server administration

type_pretty is something you can show users. Hydrus uses the same labels in manage services and so on.

Rating services have some extra data:

    They all have some colours for differing rating states, the same as you'd see in manage services. Pen and brush are the line and the fill of the rating star shape, respectively. like generally means set/left-click, dislike means off/right-click, null means not set, and mixed is what I show in the edit rating dialog for multiple files when the files have differing values. Feel free to use them however you like.
    They all have show_in_thumbnail and show_in_thumbnail_even_when_null, which you can obey in your display context if convenient.
    Like/dislike and numerical services have star_shape, which is one of circle | square | fat star | pentagram star | six point star | eight point star | x shape | square cross | triangle up | triangle down | triangle right | triangle left | diamond | rhombus right | rhombus left | hourglass | pentagon | hexagon | small hexagon | heart | teardrop | crescent moon -or- svg, which means a custom user svg that can be fetched with /get_service_rating_svg.
    Numerical services have min_stars (0 or 1) and max_stars (1 to 20). allows_zero lines up with min_stars and is for your convenience.

If you are displaying ratings, don't feel crazy obligated to obey the shape! Show a ⅘, select from a dropdown list, do whatever you like!

If you want to know the services in a client, hit up /get_services, which simply gives the above. The same structure appears in a few other calls for convenience, like /get_files/file_metadata, since that refers to many different services when it is talking about file locations and ratings and so on.

Note: If you need to do some quick testing, you should be able to copy the service_key of any service by hitting the 'copy service key' button in review services.
Current Deleted Pending Petitioned¶

The content storage and update pipeline systems in hydrus consider content (e.g. 'on file service x, file y exists', 'on tag service x, file y has tag z', or 'on rating service x, file y has rating z') as existing within a blend of four states:

    Current - The content exists on the service.
    Deleted - The content has been removed from on the service.
    Pending - The content is queued to be added to the service.
    Petitioned - The content is queued to be removed from the service.

Where content that has never touched the service has a default 'null status' of no state at all.

Content may be in two categories at once--for instance, any Petitioned data is always also Current--but some states are mutually exclusive: Current data cannot also be Deleted.

Let's examine this more carefully specifically. Current, Deleted, and Pending may exist on their own, and Deleted and Pending may exist simultaneously. Read this horizontally to vertically, such that 'Content that is Current may also be Petitioned' while 'Content that is Petitioned must also be Current':
	Current 	Deleted 	Pending 	Petitioned
Current 	- 	Never 	Never 	May
Deleted 	Never 	- 	May 	Never
Pending 	Never 	May 	- 	Never
Petitioned 	Must 	Never 	Never 	-

Local services have no concept of pending or petitioned, so they generally just have 'add x'/'delete x' verbs to convert content between current and deleted. Remote services like the PTR have a queue of pending changes waiting to be committed by the user to the server, so in these cases I will expose to you the full suite of 'pend x'/'petition x'/'rescind pend x'/'rescind petition x'. Although you might somewhere be able to 'pend'/'petition' content to a local service, these 'pending' changes will be committed instantly so they are synonymous with add/delete.

    When an 'add' is committed, the data is removed from the deleted record and added to the current record.
    When a 'delete' is committed, the data is removed from the current record and added to the deleted record.
    When a 'pend' is committed, the data is removed from the deleted record and added to the current record. (It is also deleted from the pending record!)
    When a 'petition' is committed, the data is removed from the current record and added to the deleted record. (It is also deleted from the petitioned record!)
    When a 'rescind pend' is committed, the data is removed from the pending record.
    When a 'rescind petition' is committed, the data is removed from the petitioned record.

Let's look at where the verbs make sense. Again, horizontal, so 'Content that is Current can receive a Petition command':
	Add/Pend 	Delete/Petition 	Rescind Pend 	Rescind Petition
No state 	May 	May 	- 	-
Current 	- 	May 	- 	-
Deleted 	May 	- 	- 	-
Pending 	May overwrite an existing reason 	- 	May 	-
Petitioned 	- 	May overwrite an existing reason 	- 	May

In hydrus, anything in the content update pipeline that doesn't make sense, here a '-', tends to result in an errorless no-op, so you might not care to do too much filtering on your end of things if you don't need to--don't worry about deleting something twice.

Note that content that does not yet exist can be pre-emptively petitioned/deleted. A couple of advanced cases enjoy this capability, for instance when you are syncing delete records from one client to another.

Also, it is often the case that content that is recorded as deleted is more difficult to re-add/re-pend. You might need to be a janitor to re-pend something, or, for this API, set some override_previously_deleted_mappings parameter. This is by design and helps you to stop automatically re-adding something that the user spent slow human time deciding to delete.
Access Management¶
GET /api_version¶

Gets the current API version. This increments every time I alter the API.

Restricted access:
    NO.

Required Headers: n/a

Arguments: n/a

Response:
    Some simple JSON describing the current api version (and hydrus client version, if you are interested).
    Note that this is not very useful any more, for two reasons:

        The 'Server' header of every response (and a duplicated 'Hydrus-Server' one, if you have a complicated proxy situation that overwrites 'Server') are now in the form "client api/{client_api_version} ({software_version})", e.g. "client api/32 (497)".

        Every JSON response explicitly includes this now.

Example response

{
  "version" : 17,
  "hydrus_version" : 441
}

GET /session_key¶

Get a new session key.

Restricted access:
    YES. No permissions required.

Required Headers: n/a

Arguments: n/a

Response:
    Some JSON with a new session key in hex.
    Example response

    {
      "session_key" : "f6e651e7467255ade6f7c66050f3d595ff06d6f3d3693a3a6fb1a9c2b278f800"
    }

Note

Note that the access you provide to get a new session key can be a session key, if that happens to be useful. As long as you have some kind of access, you can generate a new session key.

A session key expires after 24 hours of inactivity, whenever the client restarts, or if the underlying access key is deleted. A request on an expired session key returns 419.
GET /verify_access_key¶

Check your access key is valid.

Restricted access:
    YES. No permissions required.

Required Headers: n/a

Arguments: n/a

Response:
    401/403/419 and some error text if the provided access/session key is invalid, otherwise some JSON with basic permission info. 

Example response

{
  "name" : "autotagger",
  "permits_everything" : false,
  "basic_permissions" : [0, 1, 3],
  "human_description" : "API Permissions (autotagger): add tags to files, import files, search for files: Can search: only autotag this"
}

GET /client_info¶

Ask the client about its current boot and status.

Restricted access:
    YES. No permissions required.

Required Headers: n/a

Arguments: n/a

Response:
    Some JSON about the current state of the client.
    Example response

    {
        "boot_id": "df59ca0100536e89afbbc8d66ac382464a3119013f0b96c90848a48de545117f",
        "boot_time": 1779118174.24,
        "currently_idle": false
    }

The boot_id is a random string of hex generated on every program start, and boot_time is a timestamp float from when the main program controller started, which is typically a few seconds after the program process starts. Use one or both if you need to track client restarts.

currently_idle is a bool for whether the Client API is currently 'idle' as per options->maintenance and processing. If you want to add some heavy CPU work and don't want to interrupt the user, check this.

Searching and Fetching Files¶

File search in hydrus is not paginated like a booru--all searches return all results in one go. In order to keep this fast, search is split into two steps--fetching file identifiers with a search, and then fetching file metadata in batches. You may have noticed that the client itself performs searches like this--thinking a bit about a search and then bundling results in batches of 256 files before eventually throwing all the thumbnails on screen.
GET /get_files/search_files¶

Search for the client's files.

Restricted access:
    YES. Search for Files permission needed. Additional search permission limits may apply.

Required Headers: n/a

Arguments (in percent-encoded JSON):

        tags: (a list of tags you wish to search for)
        file domain (optional, defaults to combined local file domains)
        tag_service_key: (optional, hexadecimal, the tag domain on which to search, defaults to combined local file domains)
        include_current_tags: (optional, bool, whether to search 'current' tags, defaults to true)
        include_pending_tags: (optional, bool, whether to search 'pending' tags, defaults to true)
        file_sort_type: (optional, integer, the results sort method, defaults to 2 for import time)
        file_sort_asc: true or false (optional, default true, the results sort order)
        return_file_ids: true or false (optional, default true, returns file id results)
        return_hashes: true or false (optional, default false, returns hex hash results)

Example request for 16 files (system:limit=16) in the inbox with tags "blue eyes", "blonde hair", and "кино"

/get_files/search_files?tags=%5B%22blue%20eyes%22%2C%20%22blonde%20hair%22%2C%20%22%5Cu043a%5Cu0438%5Cu043d%5Cu043e%22%2C%20%22system%3Ainbox%22%2C%20%22system%3Alimit%3D16%22%5D

If the access key's permissions only permit search for certain tags, at least one positive whitelisted/non-blacklisted tag must be in the "tags" list or this will 403. Tags can be prepended with a hyphen to make a negated tag (e.g. "-green eyes"), but these will not be checked against the permissions whitelist.

Wildcards and namespace searches are supported, so if you search for 'character:sam*' or 'series:*', this will be handled correctly clientside.

Many system predicates are also supported using a text parser! The parser was designed by a clever user for human input and allows for a certain amount of error (e.g. ~= instead of ≈, or "isn't" instead of "is not") or requires more information (e.g. the specific hashes for a hash lookup). Here's a big list of supported examples:
System Predicates

Please test out the system predicates you want to send. If you are in help->advanced mode, you can test this parser in the advanced text input dialog when you click the OR* button on a tag autocomplete dropdown. More system predicate types and input formats will be available in future. Reverse engineering system predicate data from text is obviously tricky. If a system predicate does not parse, you'll get 400.

Also, OR predicates are now supported! Just nest within the tag list, and it'll be treated like an OR. For instance:

    [ "skirt", [ "space bounty hunter", "jane raider" ], "system:height > 1000" ]

Makes:

    skirt
    space bounty hunter OR jane raider
    system:height > 1000

The file and tag services are for search domain selection, just like clicking the buttons in the client. They are optional--default is 'combined local file domains' and 'all known tags'.

include_current_tags and include_pending_tags do the same as the buttons on the normal search interface. They alter the search of normal tags and tag-related system predicates like 'system:number of tags', including or discluding that type of tag from whatever the search is doing. If you set both of these to false, you'll often get no results.

File searches occur in the display tag_display_type. If you want to pair autocomplete tag lookup from /search_tags to this file search (e.g. for making a standard booru search interface), then make sure you are searching display tags there.

file_sort_asc is 'true' for ascending, and 'false' for descending. The default is descending.

file_sort_type is by default import time. It is an integer according to the following enum, and I have written the semantic (asc/desc) meaning for each type after:

    0 - file size (smallest first/largest first)
    1 - duration (shortest first/longest first)
    2 - import time (oldest first/newest first)
    3 - filetype (N/A)
    4 - random (N/A)
    5 - width (slimmest first/widest first)
    6 - height (shortest first/tallest first)
    7 - ratio (tallest first/widest first)
    8 - number of pixels (ascending/descending)
    9 - number of tags (on the current tag domain) (ascending/descending)
    10 - number of media views (ascending/descending)
    11 - total media viewtime (ascending/descending)
    12 - approximate bitrate (smallest first/largest first)
    13 - has audio (audio first/silent first)
    14 - modified time (oldest first/newest first)
    15 - framerate (slowest first/fastest first)
    16 - number of frames (smallest first/largest first)
    18 - last viewed time (oldest first/newest first)
    19 - archive timestamp (oldest first/newest first)
    20 - hash hex (lexicographic/reverse lexicographic)
    21 - pixel hash hex (lexicographic/reverse lexicographic)
    22 - blurhash (lexicographic/reverse lexicographic)
    23 - average colour - lightness (darkest first/lightest first)
    24 - average colour - chromatic magnitude (greys first/colours first)
    25 - average colour - green/red axis (greens first/reds first)
    26 - average colour - blue/yellow axis (blues first/yellows first)
    27 - average colour - hue (rainbow - red first/rainbow - purple first)

The pixel, blurhash, and average colour sorts will put files without one of these (e.g. an mp3) at the end, regardless of asc/desc.

Response:

    The full list of numerical file ids that match the search.
    Example response

    {
        "file_ids" : [125462, 4852415, 123, 591415]
    }

    Example response with return_hashes=true

    {
      "hashes" : [
        "1b04c4df7accd5a61c5d02b36658295686b0abfebdc863110e7d7249bba3f9ad",
        "fe416723c731d679aa4d20e9fd36727f4a38cd0ac6d035431f0f452fad54563f",
        "b53505929c502848375fbc4dab2f40ad4ae649d34ef72802319a348f81b52bad"
      ],
      "file_ids" : [125462, 4852415, 123]
    }

    You can of course also specify return_hashes=true&return_file_ids=false just to get the hashes. The order of both lists is the same.

    File ids are internal and specific to an individual client. For a client, a file with hash H always has the same file id N, but two clients will have different ideas about which N goes with which H. IDs are a bit faster to retrieve than hashes and search with en masse, which is why they are exposed here.

    This search does not apply the implicit limit that most clients set to all searches (usually 10,000), so if you do system:everything on a client with millions of files, expect to get boshed. Even with a system:limit included, complicated queries with large result sets may take several seconds to respond. Just like the client itself.

GET /get_files/file_hashes¶

Lookup file hashes from other hashes.

Restricted access:
    YES. Search for Files permission needed.

Required Headers: n/a

Arguments (in percent-encoded JSON):

        hash: (selective, a hexadecimal hash)
        hashes: (selective, a list of hexadecimal hashes)
        source_hash_type: [sha256|md5|sha1|sha512] (optional, defaulting to sha256)
        desired_hash_type: [sha256|md5|sha1|sha512]

If you have some MD5 hashes and want to see what their SHA256 are, or vice versa, this is the place. Hydrus records the non-SHA256 hashes for every file it has ever imported. This data is not removed on file deletion.
Example request

/get_files/file_hashes?hash=ec5c5a4d7da4be154597e283f0b6663c&source_hash_type=md5&desired_hash_type=sha256

Response:
    A mapping Object of the successful lookups. Where no matching hash is found, no entry will be made (therefore, if none of your source hashes have matches on the client, this will return an empty hashes Object).
    Example response

    {
      "hashes" : {
        "ec5c5a4d7da4be154597e283f0b6663c" : "2a0174970defa6f147f2eabba829c5b05aba1f1aea8b978611a07b7bb9cf9399"
      }
    }

GET /get_files/file_metadata¶

Get metadata about files in the client.

Restricted access:
    YES. Search for Files permission needed. Additional search permission limits may apply.

Required Headers: n/a

Arguments (in percent-encoded JSON):

        files
        create_new_file_ids: true or false (optional if asking with hash(es), defaulting to false)
        only_return_identifiers: true or false (optional, defaulting to false)
        only_return_basic_information: true or false (optional, defaulting to false)
        detailed_url_information: true or false (optional, defaulting to false)
        include_blurhash: true or false (optional, defaulting to false. Only applies when only_return_basic_information is true)
        include_milliseconds: true or false (optional, defaulting to false)
        include_notes: true or false (optional, defaulting to false)
        include_services_object: true or false (optional, defaulting to true)
        hide_service_keys_tags: Deprecated, will be deleted soon! true or false (optional, defaulting to true)

If your access key is restricted by tag, the files you search for must have been in the most recent search result.
Example request for two files with ids 123 and 4567

/get_files/file_metadata?file_ids=%5B123%2C%204567%5D

The same, but only wants hashes back

/get_files/file_metadata?file_ids=%5B123%2C%204567%5D&only_return_identifiers=true

And one that fetches two hashes

/get_files/file_metadata?hashes=%5B%224c77267f93415de0bc33b7725b8c331a809a924084bee03ab2f5fae1c6019eb2%22%2C%20%223e7cb9044fe81bda0d7a84b5cb781cba4e255e4871cba6ae8ecd8207850d5b82%22%5D

This request string can obviously get pretty ridiculously long. It also takes a bit of time to fetch metadata from the database. In its normal searches, the client usually fetches file metadata in batches of 256.

Response:
    A list of JSON Objects that store a variety of file metadata. Also The Services Object for service reference.

Example response

{
  "services" : "The Services Object",
  "metadata" : [
    {
      "file_id" : 123,
      "hash" : "4c77267f93415de0bc33b7725b8c331a809a924084bee03ab2f5fae1c6019eb2",
      "size" : 63405,
      "mime" : "image/jpeg",
      "filetype_forced" : false,
      "filetype_human" : "jpeg",
      "filetype_enum" : 1,
      "ext" : ".jpg",
      "width" : 640,
      "height" : 480,
      "thumbnail_width" : 200,
      "thumbnail_height" : 150,
      "duration" : null,
      "time_modified" : null,
      "time_modified_details" : {},
      "file_services" : {
        "current" : {},
        "deleted" : {}
      },
      "ipfs_multihashes" : {},
      "has_audio" : false,
      "blurhash" : "U6PZfSi_.AyE_3t7t7R**0o#DgR4_3R*D%xt",
      "pixel_hash" : "2519e40f8105599fcb26187d39656b1b46f651786d0e32fff2dc5a9bc277b5bb",
      "num_frames" : null,
      "num_words" : null,
      "is_inbox" : false,
      "is_local" : false,
      "is_trashed" : false,
      "is_deleted" : false,
      "has_exif" : true,
      "has_xmp" : false,
      "has_iptc" : false,
      "has_human_readable_embedded_metadata" : true,
      "has_software_source" : true,
      "has_icc_profile" : true,
      "has_transparency" : false,
      "known_urls" : [],
      "ratings" : {
        "74d52c6238d25f846d579174c11856b1aaccdb04a185cb2c79f0d0e499284f2c" : null,
        "90769255dae5c205c975fc4ce2efff796b8be8a421f786c1737f87f98187ffaf" : null,
        "b474e0cbbab02ca1479c12ad985f1c680ea909a54eb028e3ad06750ea40d4106" : 0
      },
      "tags" : {
        "6c6f63616c2074616773" : {
          "storage_tags" : {},
          "display_tags" : {}
        },
        "37e3849bda234f53b0e9792a036d14d4f3a9a136d1cb939705dbcd5287941db4" : {
          "storage_tags" : {},
          "display_tags" : {}
        },
        "616c6c206b6e6f776e2074616773" : {
          "storage_tags" : {},
          "display_tags" : {}
        }
      },
      "file_viewing_statistics" : [
        {
          "canvas_type" : 0,
          "canvas_type_pretty" : "media viewer",
          "views" : 0,
          "viewtime" : 0,
          "last_viewed_timestamp" : null
        },
        {
          "canvas_type" : 1,
          "canvas_type_pretty" : "preview viewer",
          "views" : 0,
          "viewtime" : 0,
          "last_viewed_timestamp" : null
        },
        {
          "canvas_type" : 4,
          "canvas_type_pretty" : "client api viewer",
          "views" : 0,
          "viewtime" : 0,
          "last_viewed_timestamp" : null
        }
      ]
    },
    {
      "file_id" : 4567,
      "hash" : "3e7cb9044fe81bda0d7a84b5cb781cba4e255e4871cba6ae8ecd8207850d5b82",
      "size" : 199713,
      "mime" : "video/webm",
      "filetype_forced" : false,
      "filetype_human" : "webm",
      "filetype_enum" : 21,
      "ext" : ".webm",
      "width" : 1920,
      "height" : 1080,
      "thumbnail_width" : 200,
      "thumbnail_height" : 113,
      "duration" : 4040,
      "time_modified" : 1604055647,
      "time_modified_details" : {
        "local" : 1641044491,
        "somebooru.org" : 1604055647
      },
      "file_services" : {
        "current" : {
          "616c6c206c6f63616c2066696c6573" : {
            "time_imported" : 1641044491
          },
          "616c6c206c6f63616c206d65646961" : {
            "time_imported" : 1641044491
          },
          "cb072cffbd0340b67aec39e1953c074e7430c2ac831f8e78fb5dfbda6ec8dcbd" : {
            "time_imported" : 1641204220
          }
        },
        "deleted" : {
          "6c6f63616c2066696c6573" : {
            "time_deleted" : 1641204274,
            "time_imported" : 1641044491
          }
        }
      },
      "ipfs_multihashes" : {
        "55af93e0deabd08ce15ffb2b164b06d1254daab5a18d145e56fa98f71ddb6f11" : "QmReHtaET3dsgh7ho5NVyHb5U13UgJoGipSWbZsnuuM8tb"
      },
      "has_audio" : true,
      "blurhash" : "UHF5?xYk^6#M@-5b,1J5@[or[k6.};FxngOZ",
      "pixel_hash" : "1dd9625ce589eee05c22798a9a201602288a1667c59e5cd1fb2251a6261fbd68",
      "num_frames" : 102,
      "num_words" : null,
      "is_inbox" : false,
      "time_archived" : 1641044542,
      "is_local" : true,
      "is_trashed" : false,
      "is_deleted" : false,
      "has_exif" : false,
      "has_human_readable_embedded_metadata" : false,
      "has_icc_profile" : false,
      "has_transparency" : false,
      "known_urls" : [
        "https://somebooru.org/index.php?page=post&s=view&id=12345",
        "https://cdn.somebooru.org/images/4d/7f/4d7f62bb8675cef84760d6263e4c254c5129ef56.jpg",
        "http://somegallerysite.com/post/123456/space bounty hunter_is_cool.jpg"
      ],
      "ratings" : {
        "74d52c6238d25f846d579174c11856b1aaccdb04a185cb2c79f0d0e499284f2c" : true,
        "90769255dae5c205c975fc4ce2efff796b8be8a421f786c1737f87f98187ffaf" : 3,
        "b474e0cbbab02ca1479c12ad985f1c680ea909a54eb028e3ad06750ea40d4106" : 11
      },
      "tags" : {
        "6c6f63616c2074616773" : {
          "storage_tags" : {
            "0" : ["space bounty hunter favourites"],
            "2" : ["process this later"]
          },
          "display_tags" : {
            "0" : ["space bounty hunter favourites", "favourites"],
            "2" : ["process this later"]
          }
        },
        "37e3849bda234f53b0e9792a036d14d4f3a9a136d1cb939705dbcd5287941db4" : {
          "storage_tags" : {
            "0" : ["blonde_hair", "blue_eyes", "looking_at_viewer"],
            "1" : ["bodysuit"]
          },
          "display_tags" : {
            "0" : ["blonde hair", "blue_eyes", "looking at viewer"],
            "1" : ["bodysuit", "clothing"]
          }
        },
        "616c6c206b6e6f776e2074616773" : {
          "storage_tags" : {
            "0" : ["space bounty hunter favourites", "blonde_hair", "blue_eyes", "looking_at_viewer"],
            "1" : ["bodysuit"]
          },
          "display_tags" : {
            "0" : ["space bounty hunter favourites", "favourites", "blonde hair", "blue_eyes", "looking at viewer"],
            "1" : ["bodysuit", "clothing"]
          }
        }
      },
      "file_viewing_statistics" : [
        {
          "canvas_type" : 0,
          "canvas_type_pretty" : "media viewer",
          "views" : 5,
          "viewtime" : 21.657,
          "last_viewed_timestamp" : 1738010610.073
        },
        {
          "canvas_type" : 1,
          "canvas_type_pretty" : "preview viewer",
          "views" : 8,
          "viewtime" : 48.657,
          "last_viewed_timestamp" : 1738010001.895
        },
        {
          "canvas_type" : 4,
          "canvas_type_pretty" : "client api viewer",
          "views" : 0,
          "viewtime" : 0,
          "last_viewed_timestamp" : null
        }
      ]
    }
  ]
}

And one where only_return_identifiers is true

{
  "services" : "The Services Object",
  "metadata" : [
    {
      "file_id" : 123,
      "hash" : "4c77267f93415de0bc33b7725b8c331a809a924084bee03ab2f5fae1c6019eb2"
    },
    {
      "file_id" : 4567,
      "hash" : "3e7cb9044fe81bda0d7a84b5cb781cba4e255e4871cba6ae8ecd8207850d5b82"
    }
  ]
}

And where only_return_basic_information is true

{
  "services" : "The Services Object",
  "metadata" : [
    {
      "file_id" : 123,
      "hash" : "4c77267f93415de0bc33b7725b8c331a809a924084bee03ab2f5fae1c6019eb2",
      "size" : 63405,
      "mime" : "image/jpeg",
      "filetype_forced" : false,
      "filetype_human" : "jpeg",
      "filetype_enum" : 1,
      "ext" : ".jpg",
      "width" : 640,
      "height" : 480,
      "duration" : null,
      "has_audio" : false,
      "num_frames" : null,
      "num_words" : null
    },
    {
      "file_id" : 4567,
      "hash" : "3e7cb9044fe81bda0d7a84b5cb781cba4e255e4871cba6ae8ecd8207850d5b82",
      "size" : 199713,
      "mime" : "video/webm",
      "filetype_forced" : false,
      "filetype_human" : "webm",
      "filetype_enum" : 21,
      "ext" : ".webm",
      "width" : 1920,
      "height" : 1080,
      "duration" : 4040,
      "has_audio" : true,
      "num_frames" : 102,
      "num_words" : null
    }
  ]
}

basics¶

Size is in bytes. Duration is in milliseconds, and may be an int or a float.

is_trashed means if the file is currently in the trash but available on the hard disk. is_deleted means currently either in the trash or completely deleted from disk.

file_services stores which file services the file is currently in and deleted from. The entries are by the service key, same as for tags later on. In rare cases, the timestamps may be null, if they are unknown (e.g. a time_deleted for the file deleted before this information was tracked). The time_modified can also be null. Time modified is just the filesystem modified time for now, but it will evolve into more complicated storage in future with multiple locations (website post times) that'll be aggregated to a sensible value in UI.

ipfs_multihashes stores the ipfs service key to any known multihash for the file.

The thumbnail_width and thumbnail_height are a generally reliable prediction but aren't a promise. The actual thumbnail you get from /get_files/thumbnail will be different if the user hasn't looked at it since changing their thumbnail options. You only get these rows for files that hydrus actually generates an actual thumbnail for. Things like pdf won't have it. You can use your own thumb, or ask the api and it'll give you a fixed fallback; those are mostly 200x200, but you can and should size them to whatever you want.

include_notes will decide whether to show a file's notes, in a simple names->texts Object.

include_milliseconds will determine if timestamps are integers (1641044491), which is the default, or floats with three significant figures (1641044491.485). As of v559, all file timestamps across the program are internally tracked with milliseconds.

If the file has a thumbnail, blurhash gives a base 83 encoded string of its blurhash. pixel_hash is an SHA256 of the image's pixel data and should exactly match for pixel-identical files (it is used in the duplicate system for 'must be pixel duplicates').

If the file's filetype is forced by the user, filetype_forced becomes true and a second mime string, original_mime is added.
tags¶

The tags structure is similar to the /add_tags/add_tags scheme, excepting that the status numbers are:

    0 - current
    1 - pending
    2 - deleted
    3 - petitioned

Note

Since JSON Object keys must be strings, these status numbers are strings, not ints.

Read about Current Deleted Pending Petitioned for more info on these states.

While the 'storage_tags' represent the actual tags stored on the database for a file, 'display_tags' reflect how tags appear in the UI, after siblings are collapsed and parents are added. If you want to edit a file's tags, refer to the storage tags. If you want to render to the user, use the display tags. The display tag calculation logic is very complicated; if the storage tags change, do not try to guess the new display tags yourself--just ask the API again.
ratings¶

The ratings structure is simple, but it holds different data types. For each service:

    For a like/dislike service, 'no rating' is null. 'like' is true, 'dislike' is false.
    For a numerical service, 'no rating' is null. Otherwise it will be an integer, for the number of stars.
    For an inc/dec service, it is always an integer. The default value is 0 for all files.

Check The Services Object to see the shape of a rating star, and min/max number of stars in a numerical service.
services¶

The tags, ratings, and file_services structures use the hexadecimal service_key extensively. If you need to look up the respective service name or type, check The Services Object under the top level services key.

Note

If you look, those file structures actually include the service name and type already, but this bloated data is deprecated and will be deleted in 2024, so please transition over.

If you don't want the services object (it is generally superfluous on the 'simple' responses), then add include_services_object=false.
parameters¶

The metadata list should come back in the same sort order you asked, whether that is in file_ids or hashes!

If you ask with hashes rather than file_ids, hydrus will, by default, only return results when it has seen those hashes before. This is to stop the client making thousands of new file_id records in its database if you perform a scanning operation. If you ask about a hash the client has never encountered before--for which there is no file_id--you will get this style of result:
Missing file_id example

{
    "metadata" : [
        {
            "file_id" : null,
            "hash" : "766da61f81323629f982bc1b71b5c1f9bba3f3ed61caf99906f7f26881c3ae93"
        }
    ]
}

You can change this behaviour with create_new_file_ids=true, but bear in mind you will get a fairly 'empty' metadata result with lots of 'null' lines, so this is only useful for gathering the numerical ids for later Client API work.

If you ask about file_ids that do not exist, you'll get 404.

If you set only_return_basic_information=true, this will be much faster for first-time requests than the full metadata result, but it will be slower for repeat requests. The full metadata object is cached after first fetch, the limited file info object is not. You can optionally set include_blurhash when using this option to fetch blurhash strings for the files.

If you add detailed_url_information=true, a new entry, detailed_known_urls, will be added for each file, with a list of the same structure as /add_urls/get_url_info. This may be an expensive request if you are querying thousands of files at once.
For example

{
  "detailed_known_urls": [
    {
      "normalised_url": "https://somebooru.org/index.php?id=123456&page=post&s=view",
      "url_type": 0,
      "url_type_string": "post url",
      "match_name": "somebooru file page",
      "can_parse": true
    },
    {
      "normalised_url": "https://cdn.somebooru.org/images/4d/7f/4d7f62bb8675cef84760d6263e4c254c5129ef56.jpg",
      "url_type": 5,
      "url_type_string": "unknown url",
      "match_name": "unknown url",
      "can_parse": false
    }
  ]
}

GET /get_files/file¶

Get a file.

Restricted access:
    YES. Search for Files permission needed. Additional search permission limits may apply.

Required Headers: n/a

Arguments :

        file_id: (selective, numerical file id for the file)
        hash: (selective, a hexadecimal SHA256 hash for the file)
        download: (optional, boolean, default false)

Only use one of file_id or hash. As with metadata fetching, you may only use the hash argument if you have access to all files. If you are tag-restricted, you will have to use a file_id in the last search you ran.

Example request

/get_files/file?file_id=452158

Example request

/get_files/file?hash=7f30c113810985b69014957c93bc25e8eb4cf3355dae36d8b9d011d8b0cf623a&download=true

Response:
    The file itself. You should get the correct mime type as the Content-Type header.

By default, this will set the Content-Disposition header to inline, which causes a web browser to show the file. If you set download=true, it will set it to attachment, which triggers the browser to automatically download it (or open the 'save as' dialog) instead.

This stuff supports Range requests, so if you want to build a video player, go nuts.
GET /get_files/thumbnail¶

Get a file's thumbnail.

Restricted access:
    YES. Search for Files permission needed. Additional search permission limits may apply.

Required Headers: n/a

Arguments:

        file_id: (selective, numerical file id for the file)
        hash: (selective, a hexadecimal SHA256 hash for the file)

Only use one. As with metadata fetching, you may only use the hash argument if you have access to all files. If you are tag-restricted, you will have to use a file_id in the last search you ran.

Example request

/get_files/thumbnail?file_id=452158

Example request

/get_files/thumbnail?hash=7f30c113810985b69014957c93bc25e8eb4cf3355dae36d8b9d011d8b0cf623a

Response:

    The thumbnail for the file. Some hydrus thumbs are jpegs, some are pngs. It should give you the correct image/jpeg or image/png Content-Type.

    If hydrus keeps no thumbnail for the filetype, for instance with pdfs, then you will get the same default 'pdf' icon you see in the client. If the file does not exist in the client, or the thumbnail was expected but is missing from storage, you will get the fallback 'hydrus' icon, again just as you would in the client itself. This request should never give a 404.

Size of Normal Thumbs

Thumbnails are not guaranteed to be the correct size! If a thumbnail has not been loaded in the client in years, it could well have been fitted for older thumbnail settings. Also, even 'clean' thumbnails will not always fit inside the settings' bounding box; they may be boosted due to a high-DPI setting or spill over due to a 'fill' vs 'fit' preference. You cannot easily predict what resolution a thumbnail will or should have!

In general, thumbnails are the correct ratio. If you are drawing thumbs, you should embed them to fit or fill, but don't fix them at 100% true size: make sure they can scale to the size you want!

Size of Defaults

If you get a 'default' filetype thumbnail like the pdf or hydrus one, you will be pulling the pngs straight from the hydrus/static folder. They will most likely be 200x200 pixels.
GET /get_files/file_path¶

Get a local file path.

Restricted access:
    YES. Search for Files permission and See Local Paths permission needed. Additional search permission limits may apply.

Required Headers: n/a

Arguments :

        file_id: (selective, numerical file id for the file)
        hash: (selective, a hexadecimal SHA256 hash for the file)

Only use one. As with metadata fetching, you may only use the hash argument if you have access to all files. If you are tag-restricted, you will have to use a file_id in the last search you ran.

Example request

/get_files/file_path?file_id=452158

Example request

/get_files/file_path?hash=7f30c113810985b69014957c93bc25e8eb4cf3355dae36d8b9d011d8b0cf623a

Response:
    The actual path to the file on the host system. Filetype and size are included for convenience.

Example response

{
    "path" : "D:\hydrus_files\f7f\7f30c113810985b69014957c93bc25e8eb4cf3355dae36d8b9d011d8b0cf623a.jpg",
    "filetype" : "image/jpeg",
    "size" : 95237
}

This will give 404 if the file is not stored locally (which includes if it should exist but is actually missing from the file store).
GET /get_files/thumbnail_path¶

Get a local thumbnail path.

Restricted access:
    YES. Search for Files permission and See Local Paths permission needed. Additional search permission limits may apply.

Required Headers: n/a

Arguments:

        file_id: (selective, numerical file id for the file)
        hash: (selective, a hexadecimal SHA256 hash for the file)
        include_thumbnail_filetype: (optional, boolean, defaults to false)

Only use one of file_id or hash. As with metadata fetching, you may only use the hash argument if you have access to all files. If you are tag-restricted, you will have to use a file_id in the last search you ran.

Example request

/get_files/thumbnail_path?file_id=452158

Example request

/get_files/thumbnail_path?hash=7f30c113810985b69014957c93bc25e8eb4cf3355dae36d8b9d011d8b0cf623a&include_thumbnail_filetype=true

Response:
    The actual path to the thumbnail on the host system.

Example response

{
    "path" : "D:\hydrus_files\f7f\7f30c113810985b69014957c93bc25e8eb4cf3355dae36d8b9d011d8b0cf623a.thumbnail"
}

Example response with include_thumbnail_filetype=true

{
    "path" : "C:\hydrus_thumbs\f85\85daaefdaa662761d7cb1b026d7b101e74301be08e50bf09a235794ec8656f79.thumbnail",
    "filetype" : "image/png"
}

All thumbnails in hydrus have the .thumbnail file extension and in content are either jpeg (almost always) or png (to handle transparency).

This will 400 if the given file type does not have a thumbnail in hydrus, and it will 404 if there should be a thumbnail but one does not exist and cannot be generated from the source file (which probably would mean that the source file was itself Not Found).
GET /get_files/local_file_storage_locations¶

Get the local file storage locations, as you see under database->migrate files.

Restricted access:
    YES. Search for Files permission and See Local Paths permission needed.

Required Headers: n/a

Arguments: n/a

Response:
    A list of the different file storage locations and what they store.

Example response

{
    "locations" : [
        {
            "path" : "C:\my_thumbs",
            "ideal_weight" : 1,
            "max_num_bytes": null,
            "prefixes" : [
                "t00", "t01", "t02", "t03", "t04", "t05", "t06", "t07", "t08", "t09", "t0a", "t0b", "t0c", "t0d", "t0e", "t0f",
                "t10", "t11", "t12", "t13", "t14", "t15", "t16", "t17", "t18", "t19", "t1a", "t1b", "t1c", "t1d", "t1e", "t1f",
                "t20", "t21", "t22", "t23", "t24", "t25", "t26", "t27", "t28", "t29", "t2a", "t2b", "t2c", "t2d", "t2e", "t2f",
                "t30", "t31", "t32", "t33", "t34", "t35", "t36", "t37", "t38", "t39", "t3a", "t3b", "t3c", "t3d", "t3e", "t3f",
                "t40", "t41", "t42", "t43", "t44", "t45", "t46", "t47", "t48", "t49", "t4a", "t4b", "t4c", "t4d", "t4e", "t4f",
                "t50", "t51", "t52", "t53", "t54", "t55", "t56", "t57", "t58", "t59", "t5a", "t5b", "t5c", "t5d", "t5e", "t5f",
                "t60", "t61", "t62", "t63", "t64", "t65", "t66", "t67", "t68", "t69", "t6a", "t6b", "t6c", "t6d", "t6e", "t6f",
                "t70", "t71", "t72", "t73", "t74", "t75", "t76", "t77", "t78", "t79", "t7a", "t7b", "t7c", "t7d", "t7e", "t7f",
                "t80", "t81", "t82", "t83", "t84", "t85", "t86", "t87", "t88", "t89", "t8a", "t8b", "t8c", "t8d", "t8e", "t8f",
                "t90", "t91", "t92", "t93", "t94", "t95", "t96", "t97", "t98", "t99", "t9a", "t9b", "t9c", "t9d", "t9e", "t9f",
                "ta0", "ta1", "ta2", "ta3", "ta4", "ta5", "ta6", "ta7", "ta8", "ta9", "taa", "tab", "tac", "tad", "tae", "taf",
                "tb0", "tb1", "tb2", "tb3", "tb4", "tb5", "tb6", "tb7", "tb8", "tb9", "tba", "tbb", "tbc", "tbd", "tbe", "tbf",
                "tc0", "tc1", "tc2", "tc3", "tc4", "tc5", "tc6", "tc7", "tc8", "tc9", "tca", "tcb", "tcc", "tcd", "tce", "tcf",
                "td0", "td1", "td2", "td3", "td4", "td5", "td6", "td7", "td8", "td9", "tda", "tdb", "tdc", "tdd", "tde", "tdf",
                "te0", "te1", "te2", "te3", "te4", "te5", "te6", "te7", "te8", "te9", "tea", "teb", "tec", "ted", "tee", "tef",
                "tf0", "tf1", "tf2", "tf3", "tf4", "tf5", "tf6", "tf7", "tf8", "tf9", "tfa", "tfb", "tfc", "tfd", "tfe", "tff"
            ]
        },
        {
            "path" : "D:\hydrus_files_1",
            "ideal_weight" : 5,
            "max_num_bytes": null,
            "prefixes" : [
                "f00", "f02", "f04", "f05", "f08", "f0c", "f11", "f12", "f13", "f15", "f17", "f18", "f1a", "f1b", "f20", "f23",
                "f25", "f26", "f27", "f2b", "f2e", "f2f", "f31", "f35", "f36", "f37", "f38", "f3a", "f40", "f42", "f43", "f44",
                "f49", "f4b", "f4d", "f4e", "f50", "f51", "f55", "f59", "f60", "f63", "f64", "f65", "f66", "f68", "f69", "f6e",
                "f71", "f73", "f78", "f79", "f7a", "f7d", "f7f", "f82", "f83", "f84", "f86", "f87", "f88", "f89", "f8f", "f90",
                "f91", "f96", "f9e", "fa1", "fa4", "fa5", "fa7", "faa", "fad", "faf", "fb1", "fb9", "fba", "fbb", "fbf", "fc1",
                "fc4", "fc7", "fc8", "fcf", "fd2", "fd6", "fd7", "fd8", "fd9", "fdf", "fe2", "fe8", "fe9", "fea", "feb", "fec",
                "ff4", "ff7", "ffd", "ffe"
            ]
        },
        {
            "path" : "E:\hydrus\hydrus_files_2",
            "ideal_weight" : 2,
            "max_num_bytes": 805306368000,
            "prefixes" : [
                "f01", "f03", "f06", "f07", "f09", "f0a", "f0b", "f0d", "f0e", "f0f", "f10", "f14", "f16", "f19", "f1c", "f1d",
                "f1e", "f1f", "f21", "f22", "f24", "f28", "f29", "f2a", "f2c", "f2d", "f30", "f32", "f33", "f34", "f39", "f3b",
                "f3c", "f3d", "f3e", "f3f", "f41", "f45", "f46", "f47", "f48", "f4a", "f4c", "f4f", "f52", "f53", "f54", "f56",
                "f57", "f58", "f5a", "f5b", "f5c", "f5d", "f5e", "f5f", "f61", "f62", "f67", "f6a", "f6b", "f6c", "f6d", "f6f",
                "f70", "f72", "f74", "f75", "f76", "f77", "f7b", "f7c", "f7e", "f80", "f81", "f85", "f8a", "f8b", "f8c", "f8d",
                "f8e", "f92", "f93", "f94", "f95", "f97", "f98", "f99", "f9a", "f9b", "f9c", "f9d", "f9f", "fa0", "fa2", "fa3",
                "fa6", "fa8", "fa9", "fab", "fac", "fae", "fb0", "fb2", "fb3", "fb4", "fb5", "fb6", "fb7", "fb8", "fbc", "fbd",
                "fbe", "fc0", "fc2", "fc3", "fc5", "fc6", "fc9", "fca", "fcb", "fcc", "fcd", "fce", "fd0", "fd1", "fd3", "fd4",
                "fd5", "fda", "fdb", "fdc", "fdd", "fde", "fe0", "fe1", "fe3", "fe4", "fe5", "fe6", "fe7", "fed", "fee", "fef",
                "ff0", "ff1", "ff2", "ff3", "ff5", "ff6", "ff8", "ff9", "ffa", "ffb", "ffc", "fff"
            ]
        }
    ]
}

Note that ideal_weight and max_num_bytes are provided for courtesy and mean nothing fixed. Each storage location might store anything, thumbnails or files or nothing, regardless of the ideal situation. Whenever a folder is non-ideal, the 'move media files' dialog shows "files need to be moved now", but it will still keep doing its thing.

For now, a prefix only occurs in one location, so there will always be 512 total prefixes in this response, all unique. However, please note that this will not always be true! In a future expansion, the client will be, on user command, slowly migrating files from one place to another in the background, and during that time there will be multiple valid locations for a file to actually be. When this happens, you will have to hit all the possible locations and test.

Also, it won't be long before the client supports moving to some form of three- and four-character prefix. I am still thinking how this will happen other than it will be an atomic change--no slow migration where we try to support both at once--but it will certainly complicate something in here (e.g. while the prefix may be 'f012', maybe the subfolder will be '\f01\2'), so we'll see.
GET /get_files/render¶

Get an image or ugoira file as rendered by Hydrus.

Restricted access:
    YES. Search for Files permission needed. Additional search permission limits may apply.

Required Headers: n/a

Arguments :

        file_id: (selective, numerical file id for the file)
        hash: (selective, a hexadecimal SHA256 hash for the file)
        download: (optional, boolean, default false)
        render_format: (optional, integer, the filetype enum value to render the file to, for still images it defaults 2 for PNG, for Ugoiras it defaults to 23 for APNG)
        render_quality: (optional, integer, the quality or PNG compression level to use for encoding the image, default 1 for PNG and 80 for JPEG and WEBP, has no effect for Ugoiras using APNG)
        width and height: (optional but must provide both if used, integer, the width and height to scale the image to. Doesn't apply to Ugoiras)

    Only use one of file_id or hash. As with metadata fetching, you may only use the hash argument if you have access to all files. If you are tag-restricted, you will have to use a file_id in the last search you ran.

    Currently the accepted values for render_format for image files are:

        1 for JPEG (quality sets JPEG quality 0 to 100, always progressive 4:2:0 encoding)
        2 for PNG (quality sets the compression level from 0 to 9. A higher value means a smaller size and longer compression time)
        33 for WEBP (quality sets WEBP quality 1 to 100, for values over 100 lossless compression is used)

    The accepted values for Ugoiras are:

        23 for APNG (quality does nothing for this format)
        83 for animated WEBP (quality sets WEBP quality 1 to 100, for values over 100 lossless compression is used)

The file you request must be a still image file that Hydrus can render (this includes PSD files) or a Ugoira file. This request uses the client image cache for images.

Example request

/get_files/render?file_id=452158

Example request

/get_files/render?hash=7f30c113810985b69014957c93bc25e8eb4cf3355dae36d8b9d011d8b0cf623a&download=true

Response:
    A PNG (or APNG), JPEG, or WEBP file of the image as would be rendered in the client, optionally resized as specified in the query parameters. It will be converted to sRGB color if the file had a color profile but the rendered file will not have any color profile.

By default, this will set the Content-Disposition header to inline, which causes a web browser to show the file. If you set download=true, it will set it to attachment, which triggers the browser to automatically download it (or open the 'save as' dialog) instead.