Please do significant research and search for existing methods to create embeddings using posts from Danbooru. 

I've already got the metadata + actual posts from the 2026 dataset from HuggingFace.

Here are the metadata fields I am considering adding:

```bash
Index([
'id',  # ✅
'created_at',  # ✅
'score',  # ✅
'md5',  # ✅
'rating',  # ✅
'image_width',  # ✅
'image_height',  # ✅
'fav_count',  # ✅
'file_ext',   # ✅
'tag_count_general',  # ✅ 
'tag_count_artist', # ✅
'tag_count_character',  # ✅
'tag_count_copyright',  # ✅
'file_size',  # ✅
'up_score', # ✅
'down_score',  # ✅
'is_pending', # ✅
'is_flagged',  # ✅
'is_deleted',  # ✅  Note that deleted files are never truly deleted
'tag_count',  # ✅
'updated_at',  # ✅
'tag_count_meta',  # ✅
'tag_string_general',  # ✅
'tag_string_character',  # ✅
'tag_string_copyright',  # ✅
'tag_string_artist',  # ✅
'tag_string_meta',   # ✅


'has_large',  # ✅❔  Rationale: I don't know what this does??
'bit_flags',  # ❔  Rationale: I don't know what this does??
'media_asset',   # ❔  Rationale: I don't know what this does??
'tag_string',  # ❌❔  Rationale: Duplicated with tag_* columns


'uploader_id',  # ❌  Rationale: not meaningful for content
'source',  # ❌  Rationale: although meaningful, inconsistent.
'last_comment_bumped_at',  # ❌  Rationale: Irrelevant to content
'last_noted_at',  # ❌  Rationale: Irrelevant to content
'parent_id',  # ❌  Rationale: Irrelevant to content
'has_children', # ❌  Rationale: Existence of children / variations has inconsistent reasoning
'approver_id',  # ❌  Rationale: Irrelevant to content
'is_banned',  # ❌  Creator ban status, although meaningful, is inconsistent with individual content
'pixiv_id',   # ❌  Rationale: Irrelevant to content
'last_commented_at',  # ❌  Rationale: Irrelevant to content
'has_active_children',  # ❌  Rationale: Irrelevant to content
'has_visible_children',   # ❌  Rationale: Irrelevant to content
'file_url',  # ❌  Rationale: Irrelevant to content
'large_file_url',  # ❌  Rationale: Irrelevant to content
'preview_file_url'  # ❌  Rationale: Irrelevant to content
],
      dtype='str')
```

I think I may try using Qwen3 embeddings from the above tags?

Please consider these and search for previous notable work as well as what else can be used for additional meaning.

I am considering adding the following items, please discuss these and research them as well:

1. Automatically generated tags. There are plenty of pretrained models to generate tags specifically for Danbooru posts. 

2. LLM description of a description from some LLM text-image model then a representation via Qwen3 Embeddings from that description.

3. PyIQA metrics. I've already got a workflow with these. I need to experiment more with these but to start out I'll probably start with: brisque, laion_aes, unique, qualiclip+, arniqa, tres, niqe, paq2piq, piqe, liqe_mix, misiq. These are just the ones that I've had little issues with and are feasible to use without notable VRAM issues.



I am also interested in potentially some self-attention layers for some of the most notable features. Discuss this.

Do note that there are about 11.6 million images, so something absurdly expensive in time or compute is infeasible. Consider these for each option.