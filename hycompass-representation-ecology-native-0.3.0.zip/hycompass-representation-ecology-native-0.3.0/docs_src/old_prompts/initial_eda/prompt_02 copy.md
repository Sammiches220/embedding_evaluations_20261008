I am interested in building an interactive visualization of an observer progressively exploring and developing "understanding" of a latent vector space.

Conceptually, this should be a **layered visualization** consisting of two related components:

1. **Latent space**

   * A collection of vectors/embeddings occupying a high-dimensional latent space.
   * These should be projected into 2D or 3D for visualization using an appropriate dimensionality-reduction technique such as UMAP, PCA, or another suitable method.
   * The visualization should make a conceptual distinction between distances in the original latent space and distances in the projected visualization.

2. **Observer state**

   * An observer has encountered only a subset of the vectors in the latent space.
   * Each observation has a timestamp, allowing the observer's state to evolve over time.
   * I want to visualize not merely which individual points have been observed, but the observer's estimated familiarity or "understanding" of different regions of the latent space.

The observer visualization should ideally distinguish between:

* **Observed points:** individual vectors that the observer has actually encountered.
* **Explored territory:** regions of latent space sufficiently represented by previous observations.
* **Understanding/familiarity:** potentially a continuous field representing how well explored a region is. This could depend on factors such as observation density, proximity, recency, diversity, or another reasonable estimator.
* **Current attention/position:** the region represented by the observer's most recent observations. Rather than necessarily being a single point, this could be represented as a heatmap/density field generated from observations within a recent time window.

### Explored-region visualization

I want some form of enclosing shape or continuous region representing the observer's total explored territory, including regions explored previously rather than only recently observed points.

Please consider what representation is appropriate for this. For example, possibilities might include alpha shapes, KDE contours, k-nearest-neighbor-derived regions, unions of local neighborhoods, or another technique. A simple convex hull should probably be avoided if it would incorrectly classify large unexplored gaps as explored.

Ideally, different levels of familiarity could be represented continuously rather than through a binary explored/unexplored classification.

### Fog of war

Include a toggleable "fog of war" layer.

The fog should obscure regions that the observer has not sufficiently explored while revealing explored regions. If practical, make this continuous:

* well-understood regions → mostly/fully visible
* weakly explored regions → partially obscured
* unexplored regions → heavily/fully obscured

The fog should be derived from the observer's exploration/understanding model rather than simply whether individual datapoints have been observed.

### Temporal visualization

Because observations have timestamps, include an interactive time component.

Ideally this should include:

* a timeline slider;
* ability to view observer state at an arbitrary point in time;
* playback showing exploration accumulating through time;
* visualization of recent/current observations separately from historical observations.

This should make it possible to watch the observer's explored territory and familiarity field evolve.

### Orientation / compass

Consider whether some kind of "compass" or orientation system would be useful.

However, latent-space orientation may be arbitrary, so do not imply that directions have semantic meaning unless such meaning can actually be established. If a meaningful compass could instead be constructed using semantic anchors, cluster centroids, known reference vectors, or interpretable directions through the latent space, explain and demonstrate an appropriate approach.

### Interaction

The visualization should be interactive and preferably support:

* pan and zoom;
* hover information for individual vectors;
* selection/inspection of points;
* toggling observed/unobserved points;
* toggling explored-region boundaries;
* toggling familiarity/understanding heatmaps;
* toggling fog of war;
* adjusting the definition of "recent" observations;
* timeline scrubbing/playback;
* optionally displaying clusters or semantic anchors.

### Implementation

Please provide a Python implementation using an interactive visualization framework suitable for running entirely locally. Choose an appropriate package/framework (for example Plotly/Dash, Bokeh, Panel/HoloViews, PyVista, or another suitable option) and explain why you chose it.

The implementation should be structured so that the mock dataset can later be replaced with real high-dimensional embeddings without substantially rewriting the visualization system.

Please provide:

1. A Python script implementing the interactive visualization/application.
2. A separate Python script that generates mock latent-space data and timestamped observer observations.
3. Instructions for installing dependencies and running the application locally.

### Mock data

The mock dataset should be designed to meaningfully demonstrate the visualization rather than simply consist of uniformly random points.

Please include features such as:

* multiple latent clusters;
* dense and sparse regions;
* gaps between regions;
* some nearby but unobserved regions;
* observer movement/exploration through different regions over time;
* revisiting previously explored regions;
* recently explored regions;
* timestamps for every observation.

If useful, generate the data initially in a higher-dimensional latent space and then project it into 2D/3D for visualization.

### Design goal

The main conceptual goal is to make the visualization feel like a **map of an observer's evolving knowledge of a larger latent space**.

At any moment, I should ideally be able to visually distinguish:

* what exists in the overall latent space;
* what the observer has directly encountered;
* where the observer has historically explored;
* how strongly different regions are understood/familiar;
* where the observer is currently focused;
* what remains effectively unknown.

Please make reasonable design decisions where the specification is ambiguous, explain those decisions, and prioritize a useful working prototype over unnecessary implementation complexity.
