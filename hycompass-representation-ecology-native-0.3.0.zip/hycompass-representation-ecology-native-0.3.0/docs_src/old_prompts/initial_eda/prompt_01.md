I am interested in creating an overlapping pair of visualizations:
1. A visualization of a latent space with vectors within it
2. An "observer" status regarding how much "understanding" has been learned from the observer's perspective. This should be represented as primarily a subset of the vectors within the latent space above.

The observer component should also include:
- Some sort of enclosing shape to demonstrate the total explored space instead of just color coded datapoints. This would include previously explored regions.
- Current "position", represented as a visualization of the recently added datapoints. Probably mostly just like a heatmap of the enclosing space overlapped with it.
- Toggleable fog of war component which just hides most of the unexplored regions


- Compass? Orientation?


I want you to provide a Python script that uses some sort of visualization package that can be used interactively in some sort of local application. Please also provide a script that produces a set of mock data (with timestamps for the observed datapoints) to demonstrate the visualizations.