Excellent thank you. I like the SSE + normal REST option.

These important events would include: selections, predicates changing, switching tabs (since visible selection may update automatically depending on external application implementation), as well as please include any other super cheap and small update information that relates to what external applications could use with the REST API. I don't want it to be something that is expensive to poll extremely frequently. + revision numbers. I really like the snapshot/delta ideas, view+domain+type methodology as well.


GET /events                         SSE
GET /views/{view}/working-selection/state 


I want you to please provide a modified full implementation (v0.5.4) that implements your suggestions, along with updated documentation + an addition that I can append onto the LATENT_OBSERVER_DATA_AND_REST_API.md file you provided since it is separate from the actual project repo.
