Excellent thank you. Now, I am interested in creating some separate application to hook up to this application to automatically detect when points are selected, then update some view based off of either a separate database that relates item IDs to Hydrus records.

However, before I prompt for this, I need to know more about the possible options.

First, how can this application best "hook up" to this application to automatically detect when new items are selected? It will also need to know when many points are selected. Would it poll the API? Is there a separate means for this application to send out hook-based updates to some arbitrary endpoint? Thoughts?

Also, how would items be related to some external database or smthn? To maintain scope, I figured that only one possible item ID per point makes sense for this application. Since I don't want to maintain any N number of databases. However, is this already supported in the modular workspace? Is it best to have external applications handle this?