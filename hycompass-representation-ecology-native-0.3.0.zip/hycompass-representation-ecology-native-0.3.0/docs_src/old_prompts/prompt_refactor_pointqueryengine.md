Thank you.

I want you to please refactor the module of PointQueryEngine similar to how it was done for the REST API package.

IMPORTANT: I want you to make it so there is NO external behavior change. It should purely be a refactoring to improve documentation / organization / readability. Also do the same for the Feature Provider

I also want you to please modify the documentation I provided you with to address the new refactored design. Ideally I will be able to point to it where ever there is the "where" field for the point engine and whatever else for the feature provider.

Additionally, ensure that any query would be able to effectively parse and evaluate expressions, since these may be tens of thousands or maybe even tens of thousands of expressions. If there needs to be some serious improvements, then please discuss. Again, no external behavior should be changed.

Please provide a downloadable zip file of the refactored files, and add a downloadable markdown file documenting the languages here (what I will point to for the OpenAPI generated documentation)

