Excellent thank you.

I will explicitely clarify one change though, specifically that we should completely separate selection and timing of "seen" data like you said. I initially restricted it to just timing based off of "archive" from Hydrus to register them as being "seen". However, as you noted, this is restrictive to other selection criteria to demonstrate "exploration". 

A user should be able to select a selection criteria and see the exploration data just the same even if there are no times registered.

As such, I am interested in separating the timing data that corresponds directly to the complete domain instead of any selection criteria. This doesn't have to be "Hydrus" related, and can simply be a set of timestamps similar to how the first seen is currently implemented.

The timelines can retain the actual timestamps as UNIX timestamps, but should still be normalized IFF it improves performance at all. 

Regarding timelines per view, I'm not sure it makes much sense to have more than one selected normalzied timeline per view. The purpose is to demonstrate the evolution of exploration. You can only have one reference of a timeline at a timeline. You could argue that you could select some domain of time to progress upon, but I'd argue that is a selection criteria and should be separated.

Thoughts?