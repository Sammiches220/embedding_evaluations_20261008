Excellent thank you. It works really well. 

Now, some new questions and thoughts. Do not implement anything yet, please just discuss.

Does this support different means of computing and showing exploration fields? I can see you can select multiple but I'm not sure if these are all the same implementations of computing a field just different selections. Depending on how visualization works, the app doesn't necessarily need to support different means of displaying fields since that can be determined by the selection instead. But I'm curious if it would be possible to support fundamentally different means of displaying a field determined by points in some selection. What about the density field related options?

What about segmentation methods? Do they permit fundamentally different means of segementation computation as long as they can be visualized in the same way? How are they visualized in the same way? The example you provided does not clearly show what this part in the sidebar entails.

I'm also interested in some configurations with how the lines are presented when visualizing the segments. I am curious if it'd be feasible to add some settings for how the lines are visualized, since right now the lights are massive and obscure a significant portion of the chart and don't have means for the user to adjust and scale with point size and such


Also, the means to select points needs a rework:
- I can't deselect a lasso selection. There should be a button to deselect some lasso selection.
- Point selections should be able to be for specific selection criteria instead of always being for the main domain. The user should also be able to select points in a specific cluster or segmentation (and with a specific selection as well), plus, within / outside the exploration boundary if possible. 
- The user should have an optional layer for segmentations to show the name / label of the segmentation overlayed on the layer if possible. This is less of an important feature, but is a quality of life addition.
- Being able to hide/show points based off of the different categories as described above (not selection, actually showing / hiding them)

- there is a bug whenever I select points with the lasso, please discuss how to fix:

```
Error calling Python override of QOpenGLWidget::paintGL(): Traceback (most recent call last):
  File "/home/main/Desktop/files/projects/hycompass/ui/map_widget.py", line 44, in paintGL
    self.renderer.draw(self.width(), self.height(), self.devicePixelRatioF())
  File "/home/main/Desktop/files/projects/hycompass/render/renderer.py", line 114, in draw
    layer.draw(self)
  File "/home/main/Desktop/files/projects/hycompass/render/layers/lasso.py", line 30, in draw
    GL.glLineWidth(2.0)
  File "/home/main/Desktop/files/projects/hycompass/.venv/lib/python3.12/site-packages/OpenGL/error.py", line 230, in glCheckError
    raise self._errorClass(
OpenGL.error.GLError: GLError(
        err = 1281,
        description = b'invalid value',
        baseOperation = glLineWidth,
        cArguments = (2.0,)
)
```


--

Then, I want to check up on the means of sorting and rating points. I want to ensure that it is still modular and users can still implement new techniques for sorting a selection?

This requires a check-in because I am interested in potentially providing some sort of avenue to integrate external data for items into the sorting. This is a tricky topic because it introduces the issue of providing an interface for a user to obtain the necessary information from the application to perform external postprocessing to sort items on their own. 

I want to avoid maintaining support for techniques that utilize any arbitrary external data in the application itself.

For example, say I select some points in a segment. I want to utilize the exploration-related / density / general information from this application AND some external data such as relating the items to their Hydrus metadata then creating an arbitrary technique to interface with everything. I'm curious what that might entail.
- This is also of interest since I am particularly interested in providing an interface to let users get app-specific data for data and potentially add external data to be represented in a completely separate standalone tool. Particularly I'm interested in the external https://github.com/apple/embedding-atlas tool. Since one aspect that I am interested in is point-data analysis + visualization, but I importantly do not want to include this in the scope of this project. Having some sort of interface or adapter would permit users to use external matured tools while still letting this application focus on what its primary focus is (to act as a compass). 
  - An important aspect of this sort of implementation would not just be exporting all of a selection, but potentially being able to have an API for specifically selected points / selections to export to an adapter or some other service. For example, if I select a point in the current app, I can see the app-specific information, but I cannot see what the item data actually is. If I were specifically tailoring it to Hydrus, I could request a feature where you could "load" a point in a new page of Hydrus if it exists so you could directly see it. However, I'm particularly interested in allowing external applications to be used as well such as that embedding-atlas tool. For example, I should also be able to request some selected point(s) from this app with some adapter / external app, then the adapter fetches additional data from elsewhere (e.g. Hydrus), and THEN formats and sends that data to the embedding-atlas tool. As such, some API seems like the best approach here. Please discuss. This is already implemented somewhat when going the other way with the Hydrus Embedding Tracker project where there is an acceptable interface for this application to accept as long as the items are in the correct format, though, a REST API to refresh or register searches and so on would be nice. 

I'm also interested in the following features:
- Saving some "saved searches" for the views to easily reload them without having to actually remember each setting. They can be specifically tied to domains + projections if that works best
- A major feature being a REST API as mentioned earlier for some crucial features. Another notable example would be a way to identify items based off of some sorting technique with in-app information then retrieving the items and related information. This would help users automate procedures to identify points without needing the manual visualization interface. Please discuss what this could entail and what it may include. 
- Color themes (with user definable configs) for the main components of the program. Please discuss how feasible this is and how it might be implemented.