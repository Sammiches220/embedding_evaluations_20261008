Excellent! Thank you.

However, there are several bugs, issues, and minor corrections to your implementation. These are detailed below. Please provide a reimplementation of the project (v0.5.1) with these adjustments.


Density opacity doesn't seem to respect a scale and instead only changes if it's either 0 or >0. Fix this if possible.
The innermost density contour seems to be filled in which makes everything really difficult to see. Make it an unfilled border like the rest of the contours.

-- 

The layer styles section should have its sub sections separated. Together it's one large block that is hard to digest

I do not like how the Point predicates section is laid out. First, similar to the layer styles section there needs to be some sort of sub section separation to make it more digestible. Second, There needs to be some checklist of available cluster IDs and Segmentations so that you can select any combination and also users understand what options exist to select. Third, there should be a clear ability to not apply some set of predicates. For example, if you don't want density to factor in at all, then it should gray out and not have the selections to make it more digestible.

These selections also get highlighted bright blue and there seems to be no real way to get this bright blue highlight to go away aside from the Clear selection button from the Interaction section. 

We should also be able to modify the style of the highlight in some basic manner.

Similarly, reorder the sections by order of importance for the user. It should be something like: View composition, Rendering, Interaction, point predicates, Inspection / State (with separate subsections),  Layer styles, Timeline, then Performance (point size should go with interaction or rendering NOT performance)

Separate the Save PNG function from the lasso section. It makes no sense for it to be there.

Additionally, please try to make each section collapsible in some way if possible. Having to scroll around is really obnoxious.

--

I like the lasso implementations. Yet, I'm not sure what Clear highlights does? It doesn't seem to do anything. Remove it.

--

Saved queries seems to only appear once you create a new view. Plus, there should be a better organized set of buttons for modifications including a delete button for saved queries. 

This is the same for views. The implementation works but is really clunky and unintuitive. There should be some ability to organize and save views in a hierarchical structure like subdirs and files. Additionally, it shouldn't go in the weird place it currently is in, but should mimic what Hydrus Network does for saved searches where clicking save opens a new dialogue to organize in a hierarchical structure but you open up a new tab with the view either by clicking a load button or double clicking in the empty tab space.

--

Clicking and lasso selections need to have an option to have the possible selections be dictated by the active point predicate query if possible. If I can only see some points then clicking shouldn't select some other invisible points.

Additionally, I wanted a way to be able to export the selections with their features (in addition to it ofc being exposed in the API). Provide this.

--

Additionally, I want you to provide some sample implementations of the other modular features of the project such as theme and projection method. Pair this ofc with an updated example generation and prepare script as needed.