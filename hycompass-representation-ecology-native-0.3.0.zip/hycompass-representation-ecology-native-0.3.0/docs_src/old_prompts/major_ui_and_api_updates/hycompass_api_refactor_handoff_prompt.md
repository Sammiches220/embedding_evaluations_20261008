# Refactor HyCompass REST API while preserving the current documentation architecture

## Your role

You are being given the **current working API implementation files** for a Python project called **HyCompass**. Your task is to refactor the REST API into a cleaner, well-typed, code-first API project **without changing its externally observable behavior unless a change is clearly necessary and explicitly justified**.

The current working files I provide are authoritative. Do not reconstruct missing behavior from guesses or from older snippets. In particular, if older discussion or partial code suggested that helpers such as `EventHub` or `_query_hash` were missing, ignore that: use the working files I provide as the source of truth.

Do not merely propose an architecture. Inspect the supplied files, preserve their behavior, and produce a working refactor.

---

# 1. Main goals

I want the refactor to accomplish all of the following:

1. Preserve the existing REST API behavior.
2. Preserve the existing SSE/event behavior.
3. Improve the FastAPI/OpenAPI schema quality substantially.
4. Keep the API **code-first**.
5. Avoid duplicated request/response schemas wherever practical.
6. Keep Python developer documentation generated from Google-style docstrings.
7. Integrate REST API documentation into the **same MkDocs Material site** as the Python/developer documentation.
8. Keep documentation generation independent of a loaded dataset or active GUI/runtime session whenever possible.
9. Keep the implementation understandable and reasonably simple. Do not over-engineer it.

---

# 2. Current conceptual architecture

The project currently has a FastAPI application factory conceptually like:

```python
def create_app(session, runtime):
    app = FastAPI(...)
    ...
    return app
```

The API uses a session/workspace layer plus a shared runtime state.

Important existing concepts include:

- runtime views
- active view state
- working selections
- working-selection revisions and deltas
- predicates
- visibility
- highlights
- focus
- result sets
- timelines
- saved queries
- saved views
- workspace reload
- asset catalog
- asset registration
- query execution
- feature retrieval
- Server-Sent Events (SSE)
- event replay / resync behavior
- runtime event revisions
- NumPy-backed asset contracts

The supplied files define the exact current behavior. Preserve those semantics.

---

# 3. Current API style and the main problem to improve

A major portion of the current API accepts bodies like:

```python
@app.post("/query")
def query_points(payload: dict = Body(...)):
    ...
```

and reads values procedurally:

```python
payload.get("domain")
payload.get("projection")
payload.get("where")
payload.get("limit")
```

Likewise, many responses are anonymous dictionaries.

This works, but it produces weak OpenAPI schemas because FastAPI only knows that the request is an arbitrary object.

The refactor should replace these untyped HTTP-boundary dictionaries with typed request/response models **where doing so accurately represents the existing wire contract**.

The goal is not "Pydantic everywhere." The goal is:

```text
typed HTTP boundary
    -> better runtime validation
    -> better generated JSON Schema
    -> better OpenAPI
    -> better generated API documentation
```

---

# 4. Desired source-of-truth model

I want three distinct code-first documentation sources.

## A. HTTP/API structure

Use Python types, FastAPI metadata, and preferably Pydantic models for:

- request bodies
- response bodies
- path parameters
- query parameters
- headers
- enums
- validation constraints
- pagination constraints
- nullability
- discriminated unions where useful
- reusable HTTP schemas
- error response schemas where appropriate

These types should generate the OpenAPI contract automatically.

Do **not** maintain a manually duplicated OpenAPI YAML schema for the same API.

---

## B. Python/developer documentation

Use **Google-style docstrings** for:

- class purpose
- method/function behavior
- invariants
- side effects
- algorithmic explanations
- relationships between components
- exceptions
- implementation-level semantics that are useful to Python developers

These are rendered by MkDocs + mkdocstrings.

Do not duplicate every field definition in prose if it is already represented clearly by Python/Pydantic types.

---

## C. Non-HTTP data contracts

Some important HyCompass contracts are not ordinary JSON schemas.

Examples include:

- `.npy` dtype expectations
- `[N, D]`, `[N, 2]`, `[H, W]`, `[T, H, W]` shape rules
- cross-file row alignment
- `NaN` meaning "out of scope"
- raster/world-bounds alignment
- storage mode semantics (`copy` vs `reference`)
- timeline missing-value semantics

These should remain code-backed documentation, but they do not need to be forced awkwardly into OpenAPI.

A suitable approach is to define them in a small Python contract module using constants, dataclasses, or typed structures, then reuse that same source for:

- `/assets/contracts`
- project documentation
- validation/help text where useful

Avoid copying the same contract prose into several places.

---

# 5. Schema reuse rules

Avoid duplicate schemas, but do not couple unrelated layers merely to achieve "one class."

Use this rule:

```text
internal/domain type == desired public wire representation
    -> reuse the existing type when practical

internal/domain type != desired public wire representation
    -> create a dedicated API DTO/schema
```

Examples:

- If an existing dataclass already represents exactly what the API should expose, reuse it if FastAPI/Pydantic can handle it cleanly.
- If an internal object contains NumPy arrays, caches, indexes, private state, or implementation-specific fields, create an API response model instead.
- Do not create an API copy of a domain dataclass merely because all API types "should be Pydantic."
- Do not expose internal implementation state merely to avoid a conversion step.

A little conversion code is acceptable. Duplicating semantic definitions is what should be avoided.

---

# 6. Important shared schemas to look for

When reviewing the supplied files, identify repeated API concepts and model them once where that improves clarity.

Likely examples include:

- API/view context
- pagination
- rows/item IDs
- feature selections
- revision information
- count/revision responses
- standard `ok` responses
- asset registration base fields
- metadata
- storage mode
- working-selection mutation mode
- query expressions
- result-set inputs
- focus inputs
- saved query payloads
- event envelope data

Do not create dozens of tiny one-use classes just for appearance. Reuse models when the semantics really are the same.

---

# 7. Query language

The project has a `PointQueryEngine` and a structured `where` query object.

Inspect the actual query grammar in the files I provide.

If the query language has a finite, meaningful set of operations, prefer modeling it as a typed/discriminated schema rather than leaving it as:

```python
where: dict
```

For example, if the real grammar supports operations conceptually like:

```json
{"op": "all"}
```

or:

```json
{
  "op": "and",
  "items": [...]
}
```

or feature-specific predicates, consider a discriminated union keyed by `op`.

However:

- derive the actual grammar from the working implementation,
- do not invent unsupported operations,
- do not make the query engine less flexible than it currently is merely to satisfy OpenAPI.

If the grammar is intentionally extensible/dynamic, document the dynamic portion honestly instead of pretending it is statically closed.

---

# 8. Dynamic features

The feature APIs may return records whose available keys depend on requested features/assets.

Inspect the actual `FeatureProvider` behavior.

If the response shape is intentionally dynamic, represent that honestly.

For example, a stable envelope such as:

```json
{
  "row": 42,
  "item_id": "...",
  "features": {
    "position": [0.1, 0.2],
    "cluster.foo": 12
  }
}
```

would be easier to schema than arbitrary top-level dynamic keys, **but do not change the current public response format simply to make OpenAPI prettier unless you explicitly identify it as a versioned API change**.

Preserving compatibility takes priority.

---

# 9. Asset registration

The current API has registration endpoints for concepts such as:

- domains
- projections
- clusterings
- densities
- segmentations
- explorations
- selections
- timelines

The old style performs many conversions inline, such as:

```python
str(payload.get(...))
int(payload.get(...))
bool(payload.get(...))
max(...)
dict(payload.get(...) or {})
```

Move validation/defaults into typed request models when possible.

Benefits should include:

- OpenAPI knows the fields
- constraints are visible
- defaults are visible
- validation occurs before route logic
- route code becomes smaller
- no duplicate hand-validation when Pydantic can express it directly

Preserve the actual defaults and validation semantics of the working API unless there is a strong reason not to.

---

# 10. SSE/event system

The project has an SSE endpoint, conceptually:

```http
GET /events
Content-Type: text/event-stream
```

The runtime maintains event history and subscriptions and supports concepts such as:

- event IDs
- event types
- revisions
- view/domain/projection scope
- replay from a prior event ID
- `Last-Event-ID`
- resync-required events
- subscriber overflow/resync behavior
- heartbeats/keepalive
- filters by event type/view/domain

Preserve all current behavior.

Where useful, define typed Python event structures for:

- the common event envelope
- known event payloads
- stream-ready
- resync-required
- other stable event types

The event types can help both Python docs and API/event documentation.

Do not force SSE into an inaccurate ordinary JSON-response model.

OpenAPI may document the endpoint and `text/event-stream` response, while a companion MkDocs page can explain event semantics more fully.

AsyncAPI is optional and should **not** be introduced unless it clearly adds value without complicating the project.

---

# 11. Runtime and thread-safety

The current runtime is shared between Qt, REST, and SSE consumers.

It includes locking and revision/state tracking.

The working implementation may contain, among other things:

- `RuntimeState`
- `EventHub`
- event subscribers
- bounded history
- bounded subscriber queues
- selection-delta history
- locks
- runtime action queues

Do not casually rewrite concurrency behavior.

Refactoring file/module structure is fine, but preserve:

- lock boundaries
- non-blocking producer behavior
- event ordering assumptions
- revision behavior
- snapshot/delta semantics
- queue overflow/resync behavior

If you change concurrency logic, explain exactly why and prove equivalent behavior with tests.

---

# 12. Error behavior

Preserve the existing status codes and error meanings.

The current API uses errors such as:

- `400` for malformed/invalid API requests
- `404` for missing views/result sets/etc.
- `409` for revision conflicts or existing resources where appropriate
- FastAPI validation errors for typed input

When converting from manual parsing to Pydantic validation, be careful:

a request that previously produced a hand-written `400` may automatically become a FastAPI `422`.

Do not silently change error behavior across the entire API.

Either:

1. preserve the existing status behavior where compatibility matters, or
2. clearly identify and justify deliberate API changes.

This deserves explicit attention during the refactor.

---

# 13. Suggested project organization

Use judgment based on the actual repository, but a reasonable target is something like:

```text
api/
├── app.py or server.py
├── runtime.py
├── dependencies.py
├── routes/
│   ├── system.py
│   ├── events.py
│   ├── query.py
│   ├── views.py
│   ├── assets.py
│   └── saved.py
├── schemas/
│   ├── common.py
│   ├── context.py
│   ├── query.py
│   ├── features.py
│   ├── views.py
│   ├── assets.py
│   ├── events.py
│   └── errors.py
└── contracts/
    └── assets.py
```

This is a guideline, not a requirement.

The current API may be in one large `create_app()` function. Splitting routes is desirable if it substantially improves readability and documentation, but do not create unnecessary abstraction layers.

The final API should still be easy to trace.

---

# 14. Dependency injection / application factory

The current factory accepts:

```python
create_app(session, runtime)
```

A useful refactor may be to expose session/runtime through:

- `app.state`
- small FastAPI dependencies
- router dependencies

For example:

```python
def get_runtime(request: Request):
    return request.app.state.runtime
```

This can make route modules independent of nested closures.

However, preserve behavior and keep the pattern simple.

---

# 15. OpenAPI generation must not require a live workspace

A previous documentation problem occurred because an OpenAPI exporter constructed live runtime state unnecessarily.

The desired OpenAPI export process should inspect route/schema definitions without requiring:

- a loaded dataset
- a running GUI
- a populated workspace
- active views
- a live SSE consumer

The exporter should effectively be able to do something like:

```python
app = create_app(...)
schema = app.openapi()
```

using documentation-safe dependencies/state.

If the refactor can cleanly support:

```python
create_app(session=None, runtime=None)
```

for schema generation, that is acceptable.

An even cleaner design is fine as long as OpenAPI generation remains independent from real application data.

Do not create fake application behavior merely to satisfy the exporter.

---

# 16. Current documentation system

The project uses a combined **MkDocs Material** documentation site.

The desired documentation feel is similar to Hydrus Network's documentation:

- technical-manual feel
- readable prose-first pages
- restrained styling
- hierarchical navigation
- Material for MkDocs
- light/dark support
- generated reference content embedded where useful
- no giant symbol-dump pages by default

The documentation source/output should remain clearly separated.

A representative layout is:

```text
mkdocs.yml
requirements-docs.txt
build_docs.sh
serve_docs.sh
export_openapi.py

docs_src/
├── index.md
├── general/
│   ├── architecture.md
│   ├── querying.md
│   ├── workspace.md
│   └── ...
├── reference/
│   └── ...
└── openapi/
    └── openapi.json        # generated

docs_generated/
└── site/
    └── ...                 # generated combined MkDocs site
```

If the real repository uses slightly different names/paths, preserve the real project conventions rather than blindly applying this tree.

The build/documentation scripts are currently intended to live at the **project root**, because earlier nested script paths caused path-resolution problems.

---

# 17. Python documentation flow

Python/developer reference pages use:

- MkDocs
- Material for MkDocs
- mkdocstrings
- the Python handler
- Google-style docstrings

Preferred page style:

```markdown
# Query system

Human-written explanation of the subsystem.

## PointQueryEngine

More context about how this class is used.

::: model.query.PointQueryEngine
    options:
      show_root_heading: true
      members:
        - query
        - resolve_rows
```

Avoid broad dumps such as:

```markdown
::: model.query
    options:
      members: true
```

unless there is a specific reason.

Those full-module dumps were harder to read and previously caused Griffe/mkdocstrings issues involving imported aliases such as:

```python
from __future__ import annotations
```

The documentation should be prose-first, with generated symbols inserted selectively.

---

# 18. REST API documentation flow

The API documentation should be integrated into the **same MkDocs Material site**.

The desired pipeline is:

```text
FastAPI source
    ↓
app.openapi()
    ↓
generated OpenAPI JSON
    ↓
MkDocs OpenAPI renderer/plugin
    ↓
same MkDocs Material site
```

Do not build a separate standalone ReDoc site unless there is a compelling reason.

The goal is for REST documentation to feel like another native section of the project manual, with the same:

- navigation
- search
- typography
- light/dark theme
- table of contents
- overall visual language

The OpenAPI renderer may be `mkdocs-openapi` or another native MkDocs approach that achieves this cleanly.

Prefer native MkDocs rendering over an iframe.

---

# 19. API documentation quality target

The generated OpenAPI contract should document more than routes.

For important endpoints it should express:

- summary
- description
- tags
- stable operation ID where useful
- path parameters
- query parameters
- headers
- request media type
- request schema
- required fields
- defaults
- constraints
- response status codes
- response schemas
- error schemas where practical
- representative examples when they add real value

The API should ideally be sufficiently well-defined that an OpenAPI client generator can understand the wire format without manual explanation.

That is a useful quality test, not a requirement to actually generate SDKs.

---

# 20. FastAPI tags

Organize endpoints with meaningful tags so generated API pages are not grouped under `Untagged`.

Likely tag groups include:

- System
- Events
- Workspace
- Views
- Query
- Features
- Assets
- Saved Queries
- Saved Views

Use the actual API structure to decide final names.

---

# 21. Build flow

The combined build should be conceptually:

```bash
python export_openapi.py
python -m mkdocs build --clean -f mkdocs.yml
```

The build should produce one combined site.

For example:

```text
docs_generated/site/index.html
```

The OpenAPI JSON is a generated artifact and should not be manually edited.

A live-development command should similarly refresh/export OpenAPI and then run MkDocs serve.

---

# 22. Documentation/build reliability requirements

The final documentation flow should:

- build from the project root
- use robust path resolution
- not depend on the caller's current working directory where avoidable
- not instantiate real runtime state just to export OpenAPI
- not require loading a dataset
- not execute dangerous/import-time application startup behavior
- not rely on a separate Node/ReDoc build unless truly necessary
- avoid stale Markdown pages that MkDocs will still process even when omitted from `nav`

Remember that MkDocs processes Markdown files in `docs_dir` even if they are not listed in navigation.

---

# 23. Testing and validation expectations

Before declaring the refactor complete, verify at least the following.

## Python/import sanity

- modules import successfully
- no undefined names
- no circular-import regressions
- FastAPI app can be constructed
- `RuntimeState()` can be constructed if that is a valid normal operation

## OpenAPI

- `app.openapi()` succeeds without a loaded project
- generated schema is valid
- request bodies are typed for the important endpoints
- response schemas appear where expected
- endpoints are properly tagged
- SSE endpoint is represented honestly
- the OpenAPI export script works from project root

## Documentation

- `mkdocs build --clean` succeeds
- combined site includes normal project docs
- combined site includes Python reference docs
- combined site includes generated REST API docs
- no broken stale reference pages
- no separate ReDoc site is required for normal browsing
- navigation is readable and not overloaded

## API compatibility

Compare the refactored application against the original supplied implementation:

- same route paths
- same HTTP methods
- same important defaults
- same pagination limits
- same selection modes
- same registration semantics
- same query behavior
- same SSE semantics
- same revision/conflict behavior
- same event filters
- same saved-query/saved-view behavior
- same workspace reload behavior

If anything intentionally changes, list it explicitly.

---

# 24. Refactor strategy

Please work incrementally.

A good order is:

1. Read and map the supplied working API/runtime/domain files.
2. Inventory every route and its current request/response behavior.
3. Inventory shared payload concepts.
4. Define the minimal reusable HTTP schema layer.
5. Refactor one route group at a time.
6. Preserve existing service/runtime functions rather than rewriting business logic unnecessarily.
7. Add/retain Google-style docstrings while touching public functions/classes.
8. Add OpenAPI metadata/tags.
9. Make OpenAPI export independent of live application state.
10. Integrate the generated contract into the combined MkDocs site.
11. Run compatibility and build checks.
12. Only then clean up/decompose remaining large modules.

Do not begin by rewriting the entire runtime.

---

# 25. Things I explicitly do NOT want

Do not:

- manually duplicate the OpenAPI schema in YAML
- duplicate every domain dataclass into a Pydantic class without reason
- rewrite correct runtime logic merely for style
- replace working SSE behavior with a simpler incompatible event system
- make OpenAPI generation depend on a real dataset
- generate a separate documentation website for every subsystem
- turn the Python docs into massive automatic module dumps
- introduce a large framework or architecture pattern without a concrete benefit
- silently change error/status semantics
- silently rename routes or JSON fields
- silently change defaults
- remove dynamic behavior simply because static schemas are easier
- invent API operations not present in the supplied code
- assume an older broken/incomplete code snippet is authoritative over the current working files

---

# 26. What I want you to return

Please provide:

1. A short assessment of the supplied current API structure.
2. A route inventory grouped by subsystem.
3. A concise refactor plan.
4. The actual refactored files/code.
5. Any new schema/model modules.
6. Any updated MkDocs/OpenAPI configuration.
7. Updated root-level build/export/serve scripts if needed.
8. A clear project tree showing changed/new files.
9. Commands to:
   - install documentation dependencies
   - export OpenAPI
   - build the combined docs
   - serve the docs locally
   - run any tests/checks
10. A compatibility summary:
    - preserved behavior
    - intentional changes, if any
11. Any remaining limitations or places where the API is intentionally dynamic.

Where practical, prefer complete downloadable files or a coherent patch rather than isolated fragments.

---

# 27. Most important principle

The target is not simply "more classes."

The target is:

```text
working application behavior
        +
clean typed HTTP boundary
        +
one code-first OpenAPI contract
        +
Google-docstring Python reference
        +
native combined MkDocs Material documentation
```

The working code I provide is the behavioral source of truth.

Refactor around it rather than re-inventing it.
