Very excellent. It almost has everything I need to be a working first version.

However, there are some additional relatively small changes I want you to implement in a new v0.5.2 project.

--

I am unable to close tabs. There were x marks previously, but not anymore. Please make it so users can close the tabs from an x and also middle clicking.

Similarily, users can no longer move around tabs. It was a nice ability to have. Please reintroduce this.

--

All sections should start folded always. This includes loading a saved view. 

--

The use controls button is incredibly vague. It should be more obvious whether the user is actively using a saved query or using the controls for point predicates.

-- 

For point predicates, I want to check whether users have the option to select multiple clusters / segments across different categories. For any item where you can have multiple overlayed onto the same view, then they should have a corresponding ability to select multiple in multiple.

Note that this follows even more heavily for the REST API function. When users select points from some predicates, they have no restriction on view. I want you to look at how users can interact with the API to get point features with predicates and determine if they properly have all options.

--

The segmentation labels are near invisible. Try to make them more obvious and larger with a couple visual options

--

You didn't provide a good example means to generate and prepare a representation with multiple implementations for projections / domains / clustering / watershed / density fields. You may have implemented some additional options, but I want an explicit example generation + prepare script that by default utilizes multiple options to give the user a good sense of the extensive modularity. This would ofc be paired with a steps to prepare this example representation. Include an actual additional projection method like t-sne