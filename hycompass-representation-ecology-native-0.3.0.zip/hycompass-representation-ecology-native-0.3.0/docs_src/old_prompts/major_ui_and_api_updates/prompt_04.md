Excellent, I like your suggestions.

Now, I want you to try to implement everything discussed as a new project version. 

Thank you. Now some additional thoughts to discuss:

I think it's probably best to not have a sorting method in the sidebar of the application or support maintaining them in the application at all, as I don't really like the idea of having sorting that is based solely on the in-app data being in the main UI. Instead, the app should expose the in-app features of selected points that can be exported or retrieved via the API. 
- However, one aspect that does need to be kept is the interactive functionality of being able to select some points based off of some rating / sorting algorithm in the UI. This can be done by exposing the same functionality in the REST API for external applications to interact with. Like when you selected a row in the sorted table, it moved the camera to that point. I want to be able to do the same thing but for example by interacting with the API to highlight some point(s)

Also, for selecting points, I am also interested in having the density or related implementations be selectable as a predicate. I forgot to mention this and maybe something else, but the general idea is that the user should be able to interact with the features of the app to select.