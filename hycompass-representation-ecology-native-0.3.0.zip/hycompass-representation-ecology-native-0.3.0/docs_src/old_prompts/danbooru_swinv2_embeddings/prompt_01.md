I have a set of npz files like:

```py
import numpy as np

data = np.load("./embeddings_tools/danbooru_swinv2_embeddings/0000.npz")

print(data)

# NpzFile './embeddings_tools/danbooru_swinv2_embeddings/0000.npz' with keys: ids, embs

print(data.files)

# ['ids', 'embs']

embs = data['embs']
print(embs)
print(embs.shape)

# [[-0.02820996  0.10225514 -0.46542522 ...  0.9688175  -0.19070879
#    0.7239044 ]
#  [ 0.07374078 -0.2982009   0.16025674 ... -0.33409756  0.0097236
#   -0.11380163]
#  [ 0.5453806   0.03494937  0.5501416  ...  0.28232148 -0.5347594
#    0.2204199 ]
#  ...
#  [-0.02687617  0.22324269 -0.28196713 ... -0.07482785 -0.447331
#   -0.05702502]
#  [-0.10916688  0.14378254 -0.09279391 ... -0.3336028   0.51123804
#    1.0186585 ]
#  [-0.5053736   0.14688735 -0.3996466  ... -0.1881761   0.13248658
#    0.06833076]]
# (8010, 1024)

ids = data['ids']
print(ids)
print(ids.shape)

# [8360000 8359000 8357000 ...    3000    2000    1000]
# (8010,)
```

How do these IDs probably relate to the embeddings?