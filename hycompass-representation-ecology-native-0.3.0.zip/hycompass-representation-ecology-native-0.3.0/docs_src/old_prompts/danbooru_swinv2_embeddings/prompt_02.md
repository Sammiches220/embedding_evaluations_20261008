I have a set of npz files like:

```py
import numpy as np

data = np.load("./embeddings_tools/danbooru_swinv2_embeddings/0000.npz")

print(data)

# NpzFile './embeddings_tools/danbooru_swinv2_embeddings/0000.npz' with keys: ids, embs

print(data.files)

# ['ids', 'embs']

embs = data['embs']
print(embs)
print(embs.shape)

# [[-0.02820996  0.10225514 -0.46542522 ...  0.9688175  -0.19070879
#    0.7239044 ]
#  [ 0.07374078 -0.2982009   0.16025674 ... -0.33409756  0.0097236
#   -0.11380163]
#  [ 0.5453806   0.03494937  0.5501416  ...  0.28232148 -0.5347594
#    0.2204199 ]
#  ...
#  [-0.02687617  0.22324269 -0.28196713 ... -0.07482785 -0.447331
#   -0.05702502]
#  [-0.10916688  0.14378254 -0.09279391 ... -0.3336028   0.51123804
#    1.0186585 ]
#  [-0.5053736   0.14688735 -0.3996466  ... -0.1881761   0.13248658
#    0.06833076]]
# (8010, 1024)

ids = data['ids']
print(ids)
print(ids.shape)

# [8360000 8359000 8357000 ...    3000    2000    1000]
# (8010,)
```

I want you to please provide a Python adaptor for a Hydrus Embedding project. Please provide this script as something that can be used with argparse with --dry-run and some argument detailed a max number of imports to the project. 

You are interested in particularly danbooru class file pages: "system:has url with class danbooru file page"
With Danbooru having post IDs present in URLs like: "https://danbooru.donmai.us/posts/9125989"

Below is ample documentation to detail this:

# Hydrus Embedding Tracker — Adapter Guide for Existing Embeddings

This guide describes how to build an **adapter for an existing embedding
collection** and reconcile those records against a Hydrus Network client before
inserting/upserting them into Hydrus Embedding Tracker v0.2.0.

The core pattern is:

```text
existing embedding records
        │
        ├── external identity (Danbooru post ID, URL, database ID, etc.)
        ├── optional content hash
        └── embedding vector
        │
        ▼
adapter-specific identity reconciliation
        │
        ├── matched to Hydrus
        │      ├── Hydrus file_id
        │      └── Hydrus SHA-256
        │
        └── not matched to Hydrus
               └── standalone tracker item
        │
        ▼
hydrus-embedding-tracker embedding upsert
```

The tracker intentionally does **not** know how a Danbooru post ID, Pixiv ID,
URL, filename, or another external identifier maps to a Hydrus file. That
mapping is adapter logic.

A reconciliation adapter should also preserve Hydrus's **archive timestamp**
(`time_archived`) whenever it fetches full file metadata. This timestamp is the
source used to construct the tracker's `first_seen.npy` / observation timeline.
Do not confuse it with the tracker's `last_seen_at`, which only records when the
tracker most recently encountered an item during synchronization.

For repeatable downstream timestamp exports, the recommended workflow is:

```text
fetch Hydrus metadata
    -> retain time_archived in the adapter mapping
    -> upsert matched embeddings
    -> populate the optional tracker metadata cache
    -> export first_seen.npy using the cache
```

Hydrus remains the source of truth. The cache is a performance/persistence aid
for metadata already fetched from Hydrus, especially useful when large archive
timestamp scans would otherwise be repeated.

---

## 1. Important identity rules

Hydrus Embedding Tracker has its own UUID `item_id`.

Do **not** use a Danbooru post ID or a Hydrus numerical `file_id` as the tracker
`item_id`.

A tracked item can instead have:

```text
tracker item_id       UUID owned by Hydrus Embedding Tracker
item_hash             stable source/content identity
hydrus_file_id        optional Hydrus numerical file_id
hydrus_hash           optional Hydrus SHA-256
```

For an embedding that is found in Hydrus, the safest CLI input is:

```text
--hydrus-file-id <Hydrus numerical ID>
--hydrus-hash <Hydrus SHA-256>
--source-hash <same Hydrus SHA-256>
```

For an embedding that is **not** in Hydrus, omit the Hydrus identity:

```text
--source-hash <stable external/content identity>
```

If the external collection has a real SHA-256 of the original media, prefer
that for unmatched items. It gives the adapter a content-stable identity.

If no content hash exists, a namespaced stable external key is acceptable, for
example:

```text
external:danbooru-post:1234567
```

The current tracker accepts arbitrary non-empty `source_hash` strings; the name
reflects the normal case where this is a content hash.

### Reconciliation caveat for unmatched items

If you create a standalone tracker item with:

```text
external:danbooru-post:1234567
```

and the exact media later appears in Hydrus with a SHA-256 that the adapter did
not previously know, the tracker cannot infer from the Danbooru post ID alone
that the two identities are the same.

Therefore:

1. Prefer a real content SHA-256 when the existing dataset has one.
2. Treat post-ID/URL matching as adapter-owned reconciliation.
3. Do not blindly create a second record when a previously-unmatched external
   item later becomes matchable; first reconcile the identities deliberately.

---

# 2. Danbooru example

A useful Danbooru adapter can correlate records by the Danbooru post ID embedded
in the file's known source URL.

The workflow is:

```text
Hydrus
  │
  ├── search for files that have a Danbooru Post URL Class
  │
  ├── fetch file metadata, including detailed known URL information
  │
  └── parse Danbooru post IDs from those URLs
  │
  ▼
{ danbooru_post_id -> Hydrus file_id + Hydrus SHA-256 }
  │
  ▼
cross-check existing embedding records
  │
  ├── matched
  └── unmatched
```

Hydrus URL Class names are configured in the Hydrus client and can differ
between clients/imported downloader definitions. The notebook therefore keeps
the class name in one editable constant.

A current Hydrus search predicate supports the form:

```text
system:has a url with class <URL CLASS NAME>
```

For file metadata, `detailed_url_information=true` adds
`detailed_known_urls`, including fields such as:

```text
normalised_url
url_type
url_type_string
match_name
can_parse
```

---

# 3. Sample Jupyter notebook

The following cells are designed to be pasted into a Jupyter notebook.

The notebook communicates:

- **directly with Hydrus** for adapter-specific URL discovery; and
- **through the Hydrus Embedding Tracker CLI** for tracker operations.

It does not import the tracker's repository or service implementation.

## Prerequisites

Run the notebook in the same Python environment where the project is installed:

```bash
pip install -e .
pip install pandas jupyter
```

The project `.env` should contain:

```dotenv
HYDRUS_API_URL=http://127.0.0.1:45869
HYDRUS_ACCESS_KEY=...
```

The Hydrus access key needs permission to search files.

---

## Cell 1 — imports and configuration

```python
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from urllib.parse import urlparse

import numpy as np
import pandas as pd
import requests
from dotenv import load_dotenv


# Run the notebook from the project directory, or change this explicitly.
PROJECT_ROOT = Path.cwd()
DATA_DIR = PROJECT_ROOT / "data"

load_dotenv(PROJECT_ROOT / ".env")

HYDRUS_API_URL = os.environ["HYDRUS_API_URL"].rstrip("/")
HYDRUS_ACCESS_KEY = os.environ["HYDRUS_ACCESS_KEY"]

HYDRUS_HEADERS = {
    "Hydrus-Client-API-Access-Key": HYDRUS_ACCESS_KEY,
    "Accept": "application/json",
}

# IMPORTANT:
# Replace this with the exact Danbooru *Post URL* class name in your Hydrus
# client: network -> downloader components -> manage url classes.
#
# The exact name is client configuration, not a universal API constant.
DANBOORU_URL_CLASS = "danbooru post"

# Use the installed package through its CLI module. This avoids depending on
# whether the console-script entry point is on Jupyter's PATH.
TRACKER_CLI = [sys.executable, "-m", "hydrus_embedding_tracker"]

# Demo embedding type for the five sample vectors below.
EMBEDDING_TYPE_NAME = "legacy_danbooru_adapter_demo"
EMBEDDING_TYPE_VERSION = "1.0"
```

---

## Cell 2 — small Hydrus GET helper

Hydrus GET parameters that contain arrays are JSON-encoded. `requests` performs
the URL percent-encoding.

```python
def hydrus_get(path: str, **params):
    encoded = {}

    for key, value in params.items():
        if value is None:
            continue

        if isinstance(value, (list, dict, tuple)):
            encoded[key] = json.dumps(
                value,
                ensure_ascii=False,
                separators=(",", ":"),
            )
        elif isinstance(value, bool):
            encoded[key] = "true" if value else "false"
        else:
            encoded[key] = value

    response = requests.get(
        f"{HYDRUS_API_URL}{path}",
        params=encoded,
        headers=HYDRUS_HEADERS,
        timeout=60,
    )

    response.raise_for_status()
    return response.json()
```

Optional connection check:

```python
print(hydrus_get("/api_version"))
print(hydrus_get("/verify_access_key"))
```

---

## Cell 3 — search for files with the Danbooru Post URL Class

The search asks Hydrus for both `file_ids` and SHA-256 hashes. Their result
positions correspond.

```python
danbooru_url_predicate = (
    f"system:has a url with class {DANBOORU_URL_CLASS}"
)

search_response = hydrus_get(
    "/get_files/search_files",
    tags=[danbooru_url_predicate],
    file_sort_type=20,      # hash order: deterministic
    file_sort_asc=True,
    return_file_ids=True,
    return_hashes=True,
)

hydrus_file_ids = [int(x) for x in search_response["file_ids"]]
hydrus_hashes = [str(x) for x in search_response["hashes"]]

assert len(hydrus_file_ids) == len(hydrus_hashes)

print(f"Hydrus files with {DANBOORU_URL_CLASS!r}: {len(hydrus_file_ids):,}")
print("First Hydrus file IDs:", hydrus_file_ids[:10])
```

If this returns HTTP 400, first verify the exact URL Class name inside Hydrus.
You can also test the system predicate in Hydrus's advanced search UI.

---

## Cell 4 — fetch detailed known URLs **and archive timestamps** in batches

Hydrus metadata lookup supports multiple file IDs in one request. A batch size
of 256 is a conservative/default-style choice.

This is also the point where the adapter obtains `time_archived`. Preserve that
field. It is the Hydrus timestamp needed later for the tracker's first-seen /
observation timeline.

`last_seen_at` in the tracker is **not** a substitute for `time_archived`.

```python
def batched(values, size=256):
    for start in range(0, len(values), size):
        yield values[start : start + size]


metadata_rows = []

for batch in batched(hydrus_file_ids, 256):
    response = hydrus_get(
        "/get_files/file_metadata",
        file_ids=batch,
        detailed_url_information=True,
        include_services_object=False,
    )
    metadata_rows.extend(response["metadata"])

print(f"Fetched metadata rows: {len(metadata_rows):,}")
```

---

## Cell 5 — parse Danbooru post IDs

This parser handles the normal modern form:

```text
https://danbooru.donmai.us/posts/1234567
```

and the corresponding `.json` API form. It also accepts the older
`/post/show/<id>` path form if one is present in historical known URLs.

```python
DANBOORU_HOSTS = {
    "danbooru.donmai.us",
    "www.danbooru.donmai.us",
    "betabooru.donmai.us",
}

DANBOORU_POST_PATHS = [
    re.compile(r"^/posts/(\d+)(?:\.json)?/?$"),
    re.compile(r"^/post/show/(\d+)/?$"),
]


def danbooru_post_id_from_url(url: str) -> int | None:
    parsed = urlparse(url)

    if parsed.hostname not in DANBOORU_HOSTS:
        return None

    for pattern in DANBOORU_POST_PATHS:
        match = pattern.match(parsed.path)
        if match:
            return int(match.group(1))

    return None


danbooru_hydrus_rows = []

for metadata in metadata_rows:
    file_id = int(metadata["file_id"])
    file_hash = str(metadata["hash"])
    time_archived = metadata.get("time_archived")

    # Prefer detailed URL information because it exposes the Hydrus URL Class
    # match name. Fall back to known_urls if needed.
    detailed_urls = metadata.get("detailed_known_urls", [])

    found_for_file = set()

    for url_info in detailed_urls:
        normalised_url = url_info.get("normalised_url")
        if not normalised_url:
            continue

        post_id = danbooru_post_id_from_url(normalised_url)
        if post_id is None:
            continue

        # Since the initial search already constrained the file by URL Class,
        # domain/path parsing is sufficient. Keeping match_name is still useful
        # for auditing the adapter.
        found_for_file.add(post_id)

        danbooru_hydrus_rows.append(
            {
                "danbooru_post_id": post_id,
                "hydrus_file_id": file_id,
                "hydrus_hash": file_hash,
                "time_archived": time_archived,
                "post_url": normalised_url,
                "url_class": url_info.get("match_name"),
            }
        )

    # Defensive fallback for older/limited metadata output.
    if not found_for_file:
        for known_url in metadata.get("known_urls", []):
            post_id = danbooru_post_id_from_url(known_url)
            if post_id is None:
                continue

            danbooru_hydrus_rows.append(
                {
                    "danbooru_post_id": post_id,
                    "hydrus_file_id": file_id,
                    "hydrus_hash": file_hash,
                    "time_archived": time_archived,
                    "post_url": known_url,
                    "url_class": None,
                }
            )


danbooru_hydrus_df = (
    pd.DataFrame(danbooru_hydrus_rows)
    .drop_duplicates(
        subset=["danbooru_post_id", "hydrus_file_id", "hydrus_hash"]
    )
    .sort_values(["danbooru_post_id", "hydrus_file_id"])
    .reset_index(drop=True)
)

print(f"Resolved Danbooru post/file relationships: {len(danbooru_hydrus_df):,}")
danbooru_hydrus_df.head(10)
```

The last expression renders approximately the first ten discovered post IDs in
Jupyter. The resulting mapping also carries each matched file's
`time_archived`, when Hydrus has one.

A quick timestamp audit is useful before continuing:

```python
display(
    danbooru_hydrus_df[
        [
            "danbooru_post_id",
            "hydrus_file_id",
            "hydrus_hash",
            "time_archived",
        ]
    ].head(10)
)

print(
    "Rows with archive timestamps:",
    danbooru_hydrus_df["time_archived"].notna().sum(),
)
print(
    "Rows without archive timestamps:",
    danbooru_hydrus_df["time_archived"].isna().sum(),
)
```

A missing archive timestamp is valid: it means the file has no usable Hydrus
archive time and should ultimately map to the tracker's unobserved/missing
first-seen value.

You can also construct a simple set:

```python
hydrus_danbooru_post_ids = set(
    danbooru_hydrus_df["danbooru_post_id"].astype(int)
)

print(f"Unique Danbooru post IDs: {len(hydrus_danbooru_post_ids):,}")
print(sorted(hydrus_danbooru_post_ids)[:10])
```

---

## Cell 6 — check for unexpected one-to-many mappings

Normally a Danbooru post identifies one media item, but adapter code should
check instead of silently assuming that.

```python
post_id_counts = (
    danbooru_hydrus_df
    .groupby("danbooru_post_id")["hydrus_file_id"]
    .nunique()
)

ambiguous_post_ids = post_id_counts[post_id_counts > 1]

print(f"Post IDs mapping to multiple Hydrus files: {len(ambiguous_post_ids):,}")

if not ambiguous_post_ids.empty:
    display(
        danbooru_hydrus_df[
            danbooru_hydrus_df["danbooru_post_id"].isin(
                ambiguous_post_ids.index
            )
        ].sort_values("danbooru_post_id")
    )
```

For a production adapter, decide explicitly how an ambiguous external identity
should be handled rather than choosing a row silently.

The rest of this example rejects ambiguous matches.

---

## Cell 7 — sample existing embedding table

This is intentionally a tiny hard-coded five-record representation of an
existing embedding dataset.

Replace the example Danbooru IDs with IDs relevant to your collection.

All vectors use the same dimensionality because one registered embedding type
must have one dimension.

```python
existing_embeddings = pd.DataFrame(
    [
        {
            "external_embedding_id": "legacy-0001",
            "danbooru_post_id": 100001,
            "content_sha256": None,
            "embedding": [0.10, 0.20, 0.30, 0.40],
        },
        {
            "external_embedding_id": "legacy-0002",
            "danbooru_post_id": 100002,
            "content_sha256": None,
            "embedding": [0.20, 0.10, 0.40, 0.30],
        },
        {
            "external_embedding_id": "legacy-0003",
            "danbooru_post_id": 100003,
            "content_sha256": None,
            "embedding": [0.90, 0.10, 0.00, 0.20],
        },
        {
            "external_embedding_id": "legacy-0004",
            "danbooru_post_id": 999999991,
            "content_sha256": None,
            "embedding": [0.50, 0.50, 0.10, 0.10],
        },
        {
            "external_embedding_id": "legacy-0005",
            "danbooru_post_id": 999999992,
            "content_sha256": None,
            "embedding": [0.60, 0.40, 0.20, 0.00],
        },
    ]
)

existing_embeddings
```

If the source dataset provides SHA-256 values, populate `content_sha256`.
That is especially useful for rows that do not currently match Hydrus.

---

## Cell 8 — cross-check existing embeddings against Hydrus

First reduce the Hydrus mapping to unambiguous Danbooru IDs.

```python
unambiguous_ids = set(
    post_id_counts[post_id_counts == 1].index.astype(int)
)

hydrus_lookup = (
    danbooru_hydrus_df[
        danbooru_hydrus_df["danbooru_post_id"].isin(unambiguous_ids)
    ]
    .drop_duplicates(subset=["danbooru_post_id"])
    .set_index("danbooru_post_id")
)


cross_checked = existing_embeddings.copy()

cross_checked["found_in_hydrus"] = (
    cross_checked["danbooru_post_id"]
    .astype(int)
    .isin(hydrus_lookup.index)
)

cross_checked["hydrus_file_id"] = cross_checked["danbooru_post_id"].map(
    hydrus_lookup["hydrus_file_id"]
)

cross_checked["hydrus_hash"] = cross_checked["danbooru_post_id"].map(
    hydrus_lookup["hydrus_hash"]
)

cross_checked["time_archived"] = cross_checked["danbooru_post_id"].map(
    hydrus_lookup["time_archived"]
)

cross_checked["hydrus_post_url"] = cross_checked["danbooru_post_id"].map(
    hydrus_lookup["post_url"]
)

cross_checked[
    [
        "external_embedding_id",
        "danbooru_post_id",
        "found_in_hydrus",
        "hydrus_file_id",
        "hydrus_hash",
        "time_archived",
    ]
]
```

Quick summary:

```python
print(
    cross_checked["found_in_hydrus"]
    .value_counts(dropna=False)
    .rename(index={True: "matched", False: "unmatched"})
)
```

---

## Cell 9 — CLI JSON helper

All tracker writes below go through the CLI.

```python
def tracker_cli_json(*args: str):
    command = [
        *TRACKER_CLI,
        "--data-dir",
        str(DATA_DIR),
        *map(str, args),
    ]

    completed = subprocess.run(
        command,
        cwd=PROJECT_ROOT,
        text=True,
        capture_output=True,
        check=False,
    )

    if completed.returncode != 0:
        raise RuntimeError(
            "Tracker CLI failed.\n"
            f"Command: {command}\n"
            f"stdout:\n{completed.stdout}\n"
            f"stderr:\n{completed.stderr}"
        )

    stdout = completed.stdout.strip()
    return json.loads(stdout) if stdout else None
```

Check the tracker/Hydrus connection through the CLI:

```python
tracker_cli_json("hydrus", "check")
```

---

## Cell 10 — register or reuse an embedding type

The selection criteria describe the Hydrus universe for this embedding type.

The adapter is still permitted to upsert standalone items that are outside that
universe.

```python
selection_criteria = {
    "tags": [
        f"system:has a url with class {DANBOORU_URL_CLASS}",
    ],
    "file_sort_type": 20,
    "file_sort_asc": True,
}


embedding_types = tracker_cli_json("type", "list")

matching_type = next(
    (
        row
        for row in embedding_types
        if row["name"] == EMBEDDING_TYPE_NAME
        and row["version"] == EMBEDDING_TYPE_VERSION
    ),
    None,
)

if matching_type is None:
    matching_type = tracker_cli_json(
        "type",
        "register",
        "--name",
        EMBEDDING_TYPE_NAME,
        "--version",
        EMBEDDING_TYPE_VERSION,
        "--description",
        "Example adapter import of an existing Danbooru-keyed embedding set.",
        "--selection-json",
        json.dumps(selection_criteria, separators=(",", ":")),
    )

EMBEDDING_TYPE_ID = matching_type["embedding_type_id"]

print("Embedding type:", EMBEDDING_TYPE_ID)
```

---

## Cell 11 — choose the source identity for unmatched rows

For matched records, use the Hydrus SHA-256.

For unmatched records:

1. prefer an existing content SHA-256, otherwise
2. use a stable namespaced adapter identity.

```python
def standalone_source_hash(row) -> str:
    value = row.get("content_sha256")

    if isinstance(value, str) and value.strip():
        return value.strip().lower()

    # Stable fallback identity. This is not pretending to be a media SHA-256.
    return f"external:danbooru-post:{int(row['danbooru_post_id'])}"
```

---

## Cell 12 — upsert all five embeddings through the CLI

`embedding upsert` is preferable for an adapter because rerunning the notebook
replaces the current vector for an already-resolved item/type instead of
creating duplicate current records.

```python
upsert_results = []

with tempfile.TemporaryDirectory(prefix="hydrus_embedding_adapter_") as tmp:
    tmp_dir = Path(tmp)

    for row_index, row in cross_checked.iterrows():
        vector = np.asarray(row["embedding"], dtype=np.float32)

        if vector.ndim != 1:
            raise ValueError(
                f"Row {row_index}: expected 1D embedding, got {vector.shape}"
            )

        vector_path = tmp_dir / f"embedding_{row_index:04d}.npy"
        np.save(vector_path, vector, allow_pickle=False)

        metadata = {
            "adapter": "danbooru_post_id_example",
            "external_embedding_id": row["external_embedding_id"],
            "danbooru_post_id": int(row["danbooru_post_id"]),
            "matched_to_hydrus": bool(row["found_in_hydrus"]),
            # Audit/provenance copy only. The tracker's first_seen export does
            # NOT read archive time from embedding metadata; it reads Hydrus
            # metadata live or from the optional metadata cache.
            "hydrus_time_archived": (
                None
                if pd.isna(row.get("time_archived"))
                else int(row["time_archived"])
            ),
        }

        args = [
            "embedding",
            "upsert",
            "--type",
            EMBEDDING_TYPE_ID,
            "--vector",
            str(vector_path),
            "--metadata-json",
            json.dumps(metadata, separators=(",", ":")),
        ]

        if row["found_in_hydrus"]:
            hydrus_file_id = int(row["hydrus_file_id"])
            hydrus_hash = str(row["hydrus_hash"])

            args.extend(
                [
                    "--hydrus-file-id",
                    str(hydrus_file_id),
                    "--hydrus-hash",
                    hydrus_hash,
                    # For an existing Hydrus-associated item, source_hash should
                    # agree with the tracker's content identity.
                    "--source-hash",
                    hydrus_hash,
                ]
            )
        else:
            args.extend(
                [
                    "--source-hash",
                    standalone_source_hash(row),
                ]
            )

        result = tracker_cli_json(*args)

        upsert_results.append(
            {
                "external_embedding_id": row["external_embedding_id"],
                "danbooru_post_id": int(row["danbooru_post_id"]),
                "found_in_hydrus": bool(row["found_in_hydrus"]),
                "tracker_item_id": result["item_id"],
                "embedding_record_id": result["embedding_record_id"],
            }
        )


upsert_results_df = pd.DataFrame(upsert_results)
upsert_results_df
```

Matched rows become tracker items with Hydrus associations.

Unmatched rows become valid standalone tracker items with:

```text
hydrus_file_id = NULL
hydrus_hash = NULL
```

They still export normally in `embeddings.npy` / `item_ids.npy`.

For first-seen export, standalone rows receive the missing/unobserved value.

---

## Cell 13 — persist Hydrus metadata/archive times in the tracker metadata cache

The notebook already fetched `time_archived`, but Hydrus Embedding Tracker's
`first_seen.npy` exporter intentionally does **not** treat
`embedding_metadata["hydrus_time_archived"]` as authoritative.

It reads archive timestamps either:

1. live from Hydrus; or
2. from the optional separate metadata cache.

For a large adapter import, populate that cache after the matched tracker items
have been created. This records Hydrus `time_archived` values for later
timestamp export.

```python
def tracker_cli_json_with_metadata_cache(*args: str):
    command = [
        *TRACKER_CLI,
        "--data-dir",
        str(DATA_DIR),
        "--metadata-cache",
        *map(str, args),
    ]

    completed = subprocess.run(
        command,
        cwd=PROJECT_ROOT,
        text=True,
        capture_output=True,
        check=False,
    )

    if completed.returncode != 0:
        raise RuntimeError(
            "Tracker CLI failed.\n"
            f"Command: {command}\n"
            f"stdout:\n{completed.stdout}\n"
            f"stderr:\n{completed.stderr}"
        )

    stdout = completed.stdout.strip()
    return json.loads(stdout) if stdout else None


metadata_update_result = tracker_cli_json_with_metadata_cache(
    "metadata",
    "update",
    "--type",
    EMBEDDING_TYPE_ID,
)

metadata_update_result
```

`metadata update --type` resolves all tracker items for the embedding type,
skips standalone items with no Hydrus file ID, fetches current Hydrus metadata
for the remaining items, and stores `time_archived` plus the raw metadata JSON
in the separate metadata SQLite database.

This does perform a Hydrus metadata fetch again. The current public CLI does not
have a command for directly importing the notebook's already-fetched metadata
rows into the cache. Keeping this second fetch is preferable to coupling an
adapter directly to the internal SQLite schema.

### Why this step matters

Without a populated cache, `export first-seen` can still query Hydrus live, so
the archive timestamps are not lost conceptually. However, caching is strongly
recommended when:

- the adapter has just performed a large reconciliation;
- the downstream visualization will repeatedly regenerate timestamps;
- some Hydrus records may later become unavailable;
- you want a stable local snapshot of the Hydrus metadata used for the import.

The cache remains optional and Hydrus remains the source of truth.

---

## Cell 14 — export the raw archive-time / first-seen array

Use the cache so the first-seen export corresponds to the metadata snapshot
recorded above:

```python
FIRST_SEEN_OUTPUT = PROJECT_ROOT / "export" / "first_seen.npy"

first_seen_result = tracker_cli_json_with_metadata_cache(
    "export",
    "first-seen",
    EMBEDDING_TYPE_ID,
    str(FIRST_SEEN_OUTPUT),
    "--use-cache",
)

first_seen_result
```

Inspect the exported timestamps:

```python
first_seen_raw = np.load(FIRST_SEEN_OUTPUT, allow_pickle=False)

print("shape:", first_seen_raw.shape)
print("dtype:", first_seen_raw.dtype)
print("first values:", first_seen_raw[:10])
print("missing/unobserved:", int((first_seen_raw < 0).sum()))
```

Raw convention:

```text
Hydrus time_archived present    -> Unix timestamp
no time_archived                -> -1
standalone/no Hydrus item       -> -1
stale/unresolvable Hydrus item  -> -1
```

If the downstream project expects the normalized Latent Observer convention,
add `--normalized`; then observed timestamps become `0.0 .. 1.0` and missing
values become `2.0`.

---

## Cell 15 — verify tracker statistics

```python
stats = tracker_cli_json(
    "tracking",
    "stats",
    EMBEDDING_TYPE_ID,
)

stats
```

Useful fields include:

```text
universe_items
embedded_in_universe
pending_items
embedded_total
outside_current_universe
embedded_without_hydrus
embedded_with_hydrus_outside_universe
coverage_percent
```

The unmatched sample records should contribute to
`embedded_without_hydrus`.

---

## Cell 16 — inspect individual imported records

```python
for tracker_item_id in upsert_results_df["tracker_item_id"].head(5):
    status = tracker_cli_json(
        "tracking",
        "status",
        tracker_item_id,
    )

    print(json.dumps(status, indent=2))
```

---

# 4. Using external URLs instead of pre-extracted post IDs

An existing embedding collection may contain source URLs instead of a
`danbooru_post_id` column.

Normalize them through the same parser before cross-checking:

```python
existing_embeddings["danbooru_post_id"] = (
    existing_embeddings["source_url"]
    .map(danbooru_post_id_from_url)
)
```

Reject or separately handle rows where the parser returns `None`.

Do not compare raw URL strings if you can instead compare the stable post ID.
URLs can vary by:

- scheme;
- hostname/subdomain;
- API vs human page;
- optional trailing slash;
- historical URL form.

The post ID is the adapter's useful common key.

---

# 5. Scaling the adapter

For a real archive with millions of embeddings, keep the same conceptual
pipeline but avoid row-by-row heavyweight work.

Recommended changes:

1. **Hydrus discovery once per adapter run**
   - search the Danbooru URL Class once;
   - fetch metadata in batches;
   - build a compact `post_id -> (file_id, hash)` mapping.

2. **Vector loading**
   - memory-map large `.npy` arrays where practical;
   - do not materialize an entire `[N,D]` collection as Python lists.

3. **CLI writes**
   - the current CLI is intentionally simple and one record per invocation;
   - for a large one-time migration, this subprocess overhead can dominate.
   - Keep the adapter/reconciliation logic independent so it can later target a
     batch CLI or REST adapter without changing the identity logic.

4. **Checkpointing**
   - the tracker itself is the persistent record of completed embeddings;
   - an adapter can be rerun and use `embedding upsert`;
   - for huge migrations, a separate adapter progress checkpoint can still be
     useful, but it is not part of the tracker contract.

5. **Ambiguous keys**
   - log duplicate Danbooru post mappings;
   - do not silently pick one.

---

# 6. General adapter recipe

Danbooru is only one example. For another source:

```text
1. Pick a stable external key.
2. Discover corresponding Hydrus files.
3. Fetch Hydrus metadata and retain:
       Hydrus file_id
       Hydrus SHA-256
       time_archived
       source-specific reconciliation fields (URLs, etc.)
4. Build:
       external_key -> Hydrus file_id + Hydrus SHA-256 + time_archived
5. Cross-check the existing embedding collection.
6. For matches:
       embedding upsert
       + hydrus_file_id
       + hydrus_hash
       + source_hash = Hydrus hash
7. For non-matches:
       embedding upsert
       + stable source_hash only
8. Preserve external identifiers in embedding_metadata.
9. Populate/refresh the optional tracker metadata cache for matched Hydrus
   items if reproducible first-seen timestamps are needed.
10. Export `first_seen.npy` from Hydrus or, preferably after a large adapter
    import, with `--use-cache`.
```

Good adapter keys include:

- source-site post IDs;
- canonical source URLs;
- cryptographic content hashes;
- stable database record IDs.

Avoid:

- list indices;
- row numbers;
- temporary filenames;
- randomized identifiers that cannot be reconstructed.

---

# 7. Why the adapter should use the CLI

The notebook could technically import internal repository classes, but an
adapter should normally target the public CLI/service contract instead.

This keeps it independent of:

- SQLite schema migrations;
- vector BLOB representation;
- tracker UUID generation;
- item/Hydrus reconciliation implementation;
- future replacement of SQLite internals.

The adapter's job is to answer:

```text
"What external record is this, and does it correspond to a Hydrus item?"
```

The tracker's job is to answer:

```text
"What tracker item owns this embedding, and what is its current state?"
```
