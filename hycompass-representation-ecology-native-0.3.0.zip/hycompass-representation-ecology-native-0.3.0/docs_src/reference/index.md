# Python reference

This section is generated automatically from the Python source tree during each MkDocs build.

The generator discovers importable project packages, mirrors their package/module hierarchy in the navigation, and renders documented public symbols with **mkdocstrings**. Google-style docstrings are parsed according to the global `mkdocstrings` configuration, and symbols within each module remain in source order.

Undocumented modules and undocumented public top-level symbols are omitted from the generated reference. Imported aliases are not treated as module members merely because they appear in a module namespace.

Normal conceptual and architectural documentation should remain in the hand-written **Guide** section. This reference is intended for Python-level API details such as classes, functions, methods, signatures, parameters, return values, exceptions, and implementation-facing contracts.
