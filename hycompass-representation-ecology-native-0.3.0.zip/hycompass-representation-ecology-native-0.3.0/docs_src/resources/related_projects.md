# Related Projects

Many concepts of this project are implemented in other projects. I encourage researching 

[embedding-atlas](https://github.com/apple/embedding-atlas), [tensorflow projector](https://projector.tensorflow.org/): Interactive visualizations & data relationships

[map-of-reddit](https://anvaka.github.io/map-of-reddit/): Uses shared-user-participation (e.g. membership / comments)

[map-of-github](https://anvaka.org/map-of-github/#3/1.63/5.14): Overlapping repository “stars” (GitHub’s version of “likes”)

[TwitchMap](https://twitchmap.com/): Active chatters on mapped (tracked) streamers

[CSET Map of Science](https://cset.georgetown.edu/?p=7697), [connectedpapers](connectedpapers), [researchrabbit](https://www.researchrabbit.ai/solutions/for-researchers): Paper relationships and textual similarity

[Open Knowledge Maps](https://openknowledgemaps.org/index): Search for a subject → generates maps for research documents

[internet-map](https://internet-map.net/): Traffic magnitude & traffic between sites

[Steam Map](https://www.game-oracle.com/blog/v61): High-dimensional embeddings of Steam’s game catalog

Others: [Economic Complexity Map](https://atlas.hks.harvard.edu/explore/productspace/), [Every Noise at Once](https://everynoise.com/)
