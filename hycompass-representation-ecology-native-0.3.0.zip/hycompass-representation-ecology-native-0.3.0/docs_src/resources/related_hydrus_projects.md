# Related Hydrus Projects

[tools_created_by_hydrus_users](https://hydrusnetwork.github.io/hydrus/client_api.html#tools_created_by_hydrus_users) -- Hydrus API docs

LLM Integration:

- [Hydrus MCP](https://github.com/TheElo/HydrusMCPServer/tree/main): [Model Context Protocol (MCP)](https://modelcontextprotocol.io/docs/2026-07-28/getting-started/intro) Standardized interface for LLMs to connect to data
- [HyCLIP](https://github.com/therandomlance/HyCLIP): Generates CLIP-style embeddings, records them, preps items for searching with LLMs

Auto-taggers: [hydrus-dd](https://gitgud.io/koto/hydrus-dd), [wd-e621-hydrus-tagger](https://github.com/Garbevoir/wd-e621-hydrus-tagger), [Pydrus-Tagger](https://github.com/shephipster/Pydrus-Tagger), [hatate-iqdb-tagger](https://github.com/nostrenz/hatate-iqdb-tagger)

Useful supplemental tools: [HydrusTools](https://github.com/GiovanH/HydrusTools), [hydrus-stats](https://github.com/hallongrotta/hydrus-stats) (PMI / TF-IDF tag scores)

---

Note: LLM integration for navigation is currently out of scope for this project

Why? → The goal of HyCompass is to provide overarching explorable maps. LLMs can be extremely powerful for understanding high dimensional representations, but the user still has to understand what there is to understand in the first place. Plus, incorporating many differing model implementations is messy and often require conflicting packages. The field is still far too immature to easily support one “API” interface.

HyCompass still provides relevant tooling for interacting with LLMs and relevant projects (e.g. HyCLIP) notably through its REST API.