# Precomputed Danbooru Semantic Representation Options

| Resource | Representation | Best use |
|---|---|---|
| **DeepGHS WD-SwinV2 v3** | ~8.0M × 1024-D | Good general semantic image representation |
| **Danbooru ConvNeXt / DINOv3** | ~5.6M × 1536-D | General visual structure, appearance, perceptual/visual similarity |
| **LRimuru WD-EVA** | Millions of Danbooru images | Alternative Danbooru-trained semantic image space |
| **DeepGHS wd14_tagger_inversion** | Image embeddings + predicted tags | Studying mappings between tag representations and image representations |
| **Anima tag artifacts / BGE-M3** | ~273k tags × 1024-D | Semantic representation of Danbooru tags and ontology |
| **Danbooru Wiki / Qwen3-Embedding-8B** | ~137k wiki entries × 4096-D | Rich textual meaning of tags/wiki concepts |
| **JackBinary danbooru-db** | ~9.3k popular tags × 640-D | Lightweight tag/wiki semantic database |

## Suggested progression

1. **Start with WD-SwinV2 v3** as the post's baseline semantic vector.
2. Add **DINOv3** as an independent visual/perceptual representation.
3. Add tag/wiki-derived **Qwen3 or BGE-M3 semantics** for explicit ontology-level meaning.
4. Compare or fuse these representations only after evaluating what neighborhoods each one produces.

A useful conceptual split is:

- **WD-SwinV2:** “What Danbooru concepts are represented here?”
- **DINOv3:** “What does this visually resemble?”
- **Tag/wiki embeddings:** “What do the concepts associated with this post mean?”

For a general-purpose Danbooru semantic map, WD-SwinV2 is therefore the strongest existing precomputed foundation.
