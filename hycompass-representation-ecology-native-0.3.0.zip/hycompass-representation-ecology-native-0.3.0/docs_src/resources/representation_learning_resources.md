# Representation Learning Resources

This project utilizes many concepts from the relatively immature field of "Representation Learning" alongside several other complex fields including "Applied Computational Topology", "Dimensionality Reduction", and "Machine Learning". Many of which are not addressed in this project's documentation. Any reader is encouraged to 

*Recommended Representation Learning Resources (for already-capable developers):*

- FREE: ["Essence of linear algebra" YouTube Course](https://www.youtube.com/playlist?list=PLZHQObOWTQDPD3MizzM2xVFitgF8hE_ab) by 3Blue1Brown (Linear Algebra is **Necessary**)
- FREE: ["Computer Graphics (CMU 15-462/662)" YouTube Course](https://www.youtube.com/playlist?list=PL9_jI1bdZmz2emSh0UQ5iOdT2xRHFHL7E) by Prof. Keenan Crane
- PAID: ["Elements of Dimensionality Reduction and Manifold Learning" Textbook](https://link.springer.com/book/10.1007/978-3-031-10602-6) by Ghojogh, Crowley, Karray, Ghodsi
- FREE: ["GEOMETRIC DEEP LEARNING" Textbook](https://geometricdeeplearning.com/) by Bronstein, Bruna, Cohen, Veličković
- FREE: ["Foundations of Topological Data Analysis" YouTube Course](https://www.youtube.com/playlist?list=PL8erL0pXF3JaR4no7ivppQ5zwhq2QnzzQ) by Prof. Ghrist Math
- PARTLY FREE: ["Basic Topology \[dark\]" YouTube Course](https://www.youtube.com/playlist?list=PLBh2i93oe2quhpWjMQpb15JOUzG2Q1fJ9) by The Bright Side of Mathematics
- FREE: ["Computational Topology for Data Analysis" Textbook](https://www.cs.purdue.edu/homes/tamaldey/book/CTDAbook/CTDAbook.pdf) by Dey, Wang
- FREE: ["ELEMENTARY APPLIED TOPOLOGY" Textbook](https://www2.math.upenn.edu/~ghrist/notes.html) by Dr. Robert W. Ghrist
- FREE: ["2023 Spring Math 3385 - Point Set Topology" YouTube Course](https://www.youtube.com/playlist?list=PLqObMWX4M-Id2bgMBX_cVDKAVebL_pqMu) by Prof. Staecker
- FREE: ["Discrete Differential Geometry - CMU 15-458/858" YouTube Course](https://www.youtube.com/playlist?list=PL9_jI1bdZmz0hIrNCMQW1YmZysAiIYSSS) by Prof. Keenan Crane


If you are interested in developing your own maps, it is important to properly understand what constitutes a useful map for some set of purposes. 

It is possible to skip straight to shoving existing embedding datasets into HyCompass, but I'd argue that at least understanding how to perform effective **"extrinsic and intrinsic evaluations of representations"** is necessary to even understand what anything means.

Similarily, LLMs are a powerful tool for understanding higher-dimensional embeddings. However, a core problem emerges when you don't even know what there is to know. Even if an LLM "understands" something, it will be difficult to use it if you don't even know what to prompt it to get some particular vibes. It is still recommended to experiment with LLM-incorporated workflows for navigating maps, but until some more effective interface with LLMs is developed and the industry settles down a little, it remains tricky to incorporate these technologies.
