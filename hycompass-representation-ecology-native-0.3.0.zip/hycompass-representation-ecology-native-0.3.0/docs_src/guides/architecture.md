# Architecture

HyCompass separates persistent workspace descriptions from runtime UI state.

```text
workspace manifest
      |
      v
session / resolved views
      |
      +---- query + feature providers
      |
      +---- runtime state + events
      |
      +---- GUI
      |
      +---- REST API
```

## Workspace model

The workspace describes domains and compatible assets. A view composes a domain and projection with optional selection and timeline state.

## Runtime state

Runtime state tracks ephemeral information such as the active view, working selection, highlights, focus, and revisions. This information is exposed to both the GUI and REST API.

## API boundary

The REST layer adapts typed request/response models to the model and runtime operations. OpenAPI documents the HTTP contract; these pages explain the implementation behind it.
