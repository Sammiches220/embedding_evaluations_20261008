# Cartography Project: Observer Traversal, Representation Geometry, and Human-Defined Observation

## Core Goal

The project is fundamentally a **cartography system for media spaces**.

Rather than treating embeddings and projections merely as visualization tools, the goal is to construct a map-like system in which:

- media objects occupy a representational terrain,
- multiple embeddings and transformations provide different candidate geometries,
- human observation generates traversal through that terrain,
- timestamped traversal provides observer-relative position and direction,
- human-readable metadata and system predicates help interpret otherwise opaque latent structures.

A central design principle is that the human should **not explicitly supervise the map** by saying things like "these two items should be closer."

Instead, the human interacts with media normally. The cartography system observes only which items cross a human-defined **observed boundary**, and when.

---

# 1. Media Objects as Stable Shared Entities

Each media object is the stable underlying object.

Different models produce different measurements or representations of the same media:

```text
image
├── SigLIP 2
├── DreamSim
├── WD / JoyTag features
├── WD / JoyTag → Qwen embeddings
├── RAM++ / RAM++ → Qwen
├── pose representations
├── NSFW representations
├── IQA metrics
├── perceptual hashes
├── metadata
└── other future representations
```

Conceptually, the system contains multiple matrices sharing the same rows:

\[
X_{\text{SigLIP}},
X_{\text{DreamSim}},
X_{\text{WD}},
X_{\text{Pose}},
\dots
\]

where the same row always refers to the same media item.

That row correspondence allows otherwise incompatible representation spaces to be compared, aligned, fused, and evaluated.

---

# 2. Embeddings Are Candidate Coordinate Systems

An embedding should be thought of as a **coordinate system describing the media**, not as the object itself.

For media object \(x\):

\[
x \xrightarrow{E_1} z_1,\qquad
x \xrightarrow{E_2} z_2,\qquad
x \xrightarrow{E_3} z_3
\]

Different embeddings capture different notions of similarity.

Examples:

- SigLIP: semantic / visual-semantic similarity
- DreamSim: perceptual similarity
- pose representations: bodily or structural similarity
- Danbooru-derived representations: explicit concept/tag structure
- Qwen-derived representations: semantic compression of structured or textual descriptions

The goal is not necessarily to find one universally correct embedding.

Instead, the system can treat these as **candidate geometries** from which useful maps may be constructed.

---

# 3. Projection Is a Chart, Not the Underlying Terrain

A projection such as UMAP maps a representation to 2-D:

\[
z_i \xrightarrow{P_j} y_{ij} \in \mathbb{R}^2
\]

But the absolute coordinates of separate UMAP runs are not intrinsically comparable.

UMAP outputs may differ by:

- rotation,
- reflection,
- translation,
- scale,
- nonlinear deformation,
- parameter choice.

Therefore, the 2-D map should be understood as a **rendered chart** of an underlying geometry, not the geometry itself.

When comparing multiple projections, alignment is necessary.

---

# 4. A Space of Geometries

Different complete pipelines can be treated as different candidate maps:

```text
SigLIP → cosine → UMAP
DreamSim → cosine → UMAP
Pose → cosine → UMAP
WD/Qwen → cosine → UMAP
SigLIP + DreamSim → fused metric → UMAP
SigLIP + Pose → fused metric → UMAP
```

A useful abstraction is a parameterized metric:

\[
D_\theta(a,b)
=
\sum_i w_i d_i(a,b)
\]

where each \(d_i\) is a distance under one representation.

Then:

\[
\theta=(w_1,w_2,\ldots,w_n)
\]

defines a location in a **space of possible geometries**.

The cartography system can therefore reason not only about where media lies, but also about how the chosen coordinate system changes.

---

# 5. Critical Observer Distinction

The observer should **not provide direct map feedback**.

No explicit:

```text
"these are similar"
"move this closer"
"this cluster is wrong"
```

The user instead interacts with the media itself.

The system receives only timestamped records of what became **observed**.

The fundamental cartographic input can therefore be extremely small:

```text
object_id | observed_at | observer_context
```

The observer trajectory is generated from these timestamped observations.

---

# 6. Why "Observed Only" Is Not Necessarily Too Limiting

The observed state is not intended to encode all human behavior directly.

Instead, it acts as a **human-controlled interface boundary**.

Conceptually:

\[
O(x,t)=P_{\text{human}}(x,M(x),S(t))
\]

where:

- \(x\) is the media item,
- \(M(x)\) is available metadata,
- \(S(t)\) is relevant system state,
- \(P_{\text{human}}\) is the human-defined rule determining whether something counts as observed.

The cartography system only needs the resulting observation event.

The meaning of "observed" remains under human control.

---

# 7. Hydrus Network / HyDownloader as the Observation Substrate

In practice, the project may use Hydrus Network or HyDownloader.

A natural operational interpretation is:

```text
inbox = unobserved
archive = observed
```

However, the human controls the meaning of this transition through their workflow.

Examples:

```text
inbox
↓
looked at once
↓
archive
```

or:

```text
inbox
↓
viewtime > 1 hour
AND
tagged with project:X
↓
archive
```

or:

```text
inbox
↓
manually evaluated
AND
assigned a meaningful tag
↓
archive
```

The cartography layer does not need to understand the full upstream semantics.

It only observes that a media object crossed the boundary at a given time.

This is better understood as **encapsulation** than as simple information loss.

---

# 8. Human Meaning Remains Upstream and Extensible

Hydrus provides a flexible system of:

- tags,
- system predicates,
- file metadata,
- source metadata,
- viewtime,
- ratings,
- namespaces,
- custom workflows,
- inbox/archive state,
- multiple Hydrus instances if necessary.

Therefore, if the human develops a new concept or goal, they can encode it upstream.

For example:

```text
composition_reference:useful
```

or establish a workflow in which archival means completion of some particular evaluation.

The cartography system does not need a hardcoded behavioral feature for every possible human meaning.

Instead:

\[
\text{human meaning}
\rightarrow
\text{Hydrus state / predicates}
\]

and the map receives observation events.

---

# 9. Multiple Observer Contexts Are Possible

Different Hydrus instances or workflow contexts may define different notions of observation:

\[
O^{(A)}(x,t),
O^{(B)}(x,t),
O^{(C)}(x,t)
\]

Example:

```text
Context A:
"media I have consumed"

Context B:
"media I have evaluated for composition"

Context C:
"media I have incorporated into project X"
```

The same media universe can therefore produce multiple traversal fields:

\[
V_A(x,y),\quad
V_B(x,y),\quad
V_C(x,y)
\]

This allows different human-defined observer coordinate systems to be compared on the same media substrate.

---

# 10. Attention Map as a Scalar Field

The original attention-map idea remains useful.

Given timestamped observed items, define an accumulated observation density:

\[
A(x,y)
\]

This answers:

> Where has observation accumulated?

It can be rendered as:

- heatmap,
- topographic surface,
- density field,
- explored-region mask,
- fog-of-war support.

However, attention alone lacks meaningful direction.

That motivates an additional vector-field layer.

---

# 11. Traversal as a Vector Field

If observations occur in timestamp order:

\[
x_1,x_2,\ldots,x_n
\]

and each media object has 2-D map coordinates:

\[
p_i=(x_i,y_i)
\]

then each consecutive observation creates a displacement:

\[
\Delta p_i=p_{i+1}-p_i
\]

and elapsed time:

\[
\Delta t_i=t_{i+1}-t_i
\]

A local velocity estimate is:

\[
v_i=\frac{\Delta p_i}{\Delta t_i}
\]

Raw transitions would be noisy, so they should be spatially smoothed into a vector field:

\[
V(x,y)
\]

This answers:

> In what direction has observation tended to move through this region?

---

# 12. Attention + Flow

The map can therefore contain two complementary layers:

## Scalar field

\[
A(x,y)
\]

Historical observation density.

## Vector field

\[
V(x,y)
\]

Observed traversal direction.

Conceptually:

```text
attention / occupancy        directional flow

     ░░▓▓▓░                    ↗ ↗ ↑
   ░▓████▓░                  → ↗ ↑ ↑
  ░▓██████▓░                 → → ↗ ↑
    ░▓██▓░                     → →
```

The first shows **where the observer has been**.

The second shows **how the observer moves through the terrain**.

---

# 13. Recency as Current Position

Timestamping permits a recency field:

\[
R_t(x,y)
=
\sum_i
K_\sigma((x,y)-p_i)
e^{-(t-t_i)/\tau}
\]

This provides an estimate of the observer's **current local position** without requiring any additional behavioral statistics.

A useful three-layer interpretation is:

```text
historical density  = attention / explored terrain
recency density     = current position
flow field          = heading / local movement
```

This is closely analogous to physical cartography.

---

# 14. Gradient of Attention

The attention field also has a gradient:

\[
\nabla A(x,y)
\]

This points toward increasing historical attention.

However:

\[
\nabla A(x,y) \neq V(x,y)
\]

in general.

The gradient means:

> Which direction leads toward historically denser observed territory?

The traversal field means:

> Which direction did observation actually move?

Both are useful.

---

# 15. Comparing Flow with Attention Gradient

A local alignment score can compare the two:

\[
c(x,y)
=
\frac{
V\cdot\nabla A
}{
\|V\|\|\nabla A\|
}
\]

Interpretation:

- \(c\approx +1\): movement toward established observed territory
- \(c\approx -1\): movement away from established observed territory
- \(c\approx 0\): lateral movement across or around the attention landscape

This can reveal whether traversal is:

- returning,
- departing,
- circling,
- crossing,
- following boundaries.

No explicit psychological interpretation is required.

---

# 16. Streamlines as the Main Directional Visualization

A dense arrow/quiver plot may become visually noisy.

For the main interface, **streamlines** may better fit the cartographic metaphor.

Example:

```text
        ╭──────────→
     ╭──╯
 ───→╯

              ╭────→
         ────→╯
```

Potential rendering:

- heat / terrain = historical observation density
- bright local region = recency/current position
- streamlines = traversal field
- arrowheads = direction
- line strength = transition density or confidence

This resembles a weather or fluid-flow map.

---

# 17. Divergence and Curl

Once a vector field exists, additional physical-map-style quantities become available.

## Divergence

\[
\nabla\cdot V
\]

Positive divergence:

```text
 ↖ ↑ ↗
 ← ● →
 ↙ ↓ ↘
```

suggests a **source**, **branching point**, or area from which traversal disperses.

Negative divergence:

```text
 ↘ ↓ ↙
 → ● ←
 ↗ ↑ ↖
```

suggests a **destination**, **basin**, or convergence region.

## Curl

\[
\nabla\times V
\]

can identify areas where traversal tends to circulate around a structure.

These provide functional cartographic interpretation without requiring semantic labels.

---

# 18. Traversal as Interpretability for Embeddings

Embedding spaces are generally difficult for humans to interpret.

Human-readable data produced during representation generation helps mitigate this:

- tags,
- captions,
- detected poses,
- NSFW ratings,
- quality metrics,
- source metadata,
- other explicit features.

Traversal adds a different kind of interpretation.

There are therefore two complementary channels:

\[
\text{semantic interpretation}
\]

from metadata and human-readable representations,

and

\[
\text{functional interpretation}
\]

from traversal.

---

# 19. Physical Map Analogy: Rivers

A physical map may contain a river geometrically, but human traversal helps reveal what the river **means functionally**.

For example:

- paths bending around it → barrier
- repeated crossings → permeable boundary / bridge locations
- movement along it → corridor
- convergence near it → destination or resource
- persistent avoidance → friction

The same principle applies to latent media terrain.

An embedding cluster boundary, ridge, gap, or manifold structure may be mathematically visible, but traversal can reveal whether it behaves like:

- a barrier,
- corridor,
- junction,
- attractor,
- source,
- bridge,
- boundary,
- irrelevant artifact.

---

# 20. Geometric Structure vs Experienced Structure

A major conceptual distinction is:

\[
\boxed{\text{geometric structure} \neq \text{experienced structure}}
\]

Two regions may appear separate geometrically but be frequently crossed in traversal.

That suggests the separation may not be important to the observer.

Conversely, two regions may appear adjacent in 2-D but rarely be crossed between.

That suggests a possible **latent barrier** or projection artifact.

Traversal therefore reveals whether geometric features are functionally meaningful.

---

# 21. Functional Cartographic Features

Local traversal structure can be classified operationally.

## Corridor

Trajectories align strongly along one direction.

## Junction

Multiple directional flows intersect.

## Basin

Trajectories converge.

## Source

Trajectories disperse.

## Boundary

Trajectories tend to run parallel to a region edge rather than cross it.

## Bridge

A narrow area consistently connects otherwise separated regions.

These labels describe **how the terrain functions**, not necessarily what the underlying media means semantically.

---

# 22. Translating Emergent Structure Against Metadata

The map should not necessarily be built directly from all behavioral or metadata variables.

Instead, structure can emerge first from observation traversal.

Then discovered structures can be translated against available metadata or predicates.

For example, suppose a strong convergence basin is discovered.

The system could test associations such as:

```text
                         association
                         with basin

viewtime > 1 hour          +0.73
tag:character_focus        +0.51
tag:solo                   +0.39
rating:safe                -0.03
source:twitter             +0.02
resolution > 4MP           +0.01
```

This gives:

\[
\text{Traversal structure}
\leftrightarrow
\text{Metadata predicates}
\]

without defining the map using those predicates in advance.

That preserves emergent structure while still permitting human interpretation.

---

# 23. Why Rich Telemetry Should Not Automatically Become Observer Dimensions

Feeding variables like:

- clicks,
- scrolling,
- zoom,
- saves,
- viewtime,
- mouse movement,

directly into an observer model risks silently imposing assumptions such as:

\[
\text{long viewtime}\Rightarrow\text{high interest}
\]

which may be false.

If the human explicitly decides that:

\[
\text{viewtime}>1h
\]

has operational meaning in their workflow, then it becomes meaningful by **human definition**, not by developer assumption.

This preserves user control over imposed meaning.

---

# 24. Observation as an API Contract

The dimensional reduction:

\[
\text{large human behavioral state}
\rightarrow
\{\text{unobserved},\text{observed}\}
\]

appears severe mathematically.

But conceptually it is better understood as an API contract:

> The cartographer does not need to know why the human declared this territory traversed.

The richer upstream data remains available for later interpretation.

Therefore, the system gains simplicity without necessarily losing the ability to explain discovered structure.

---

# 25. Multiple Representations Can Explain the Same Traversal

For a real observed trajectory:

\[
P=(x_1,x_2,\ldots,x_n)
\]

each candidate geometry \(G\) can be evaluated by its path length:

\[
L_G(P)=
\sum_{t=1}^{n-1}
d_G(x_t,x_{t+1})
\]

A geometry under which the real traversal is unusually short and locally coherent may better explain that traversal.

This creates a cartographic evaluation criterion:

> What map makes the route the observer actually took look locally sensible?

No explicit similarity feedback is necessary.

---

# 26. Observer Position in Geometry Space

The observer may have two simultaneous positions:

\[
p_{\text{content}}(t)
\]

and:

\[
p_{\text{geometry}}(t)
\]

## Content position

Where in the media terrain the observer is currently traversing.

## Geometry position

Which combination of representations or metrics best makes that traversal locally coherent.

This means two observers can traverse the same content while using different effective orientations.

Likewise, one observer can move through the same content under different inferred geometries over time.

---

# 27. Direction in Geometry Space

If the observer trajectory becomes more coherent when increasing certain representation weights, their inferred coordinate frame can move in that direction.

For example:

```text
DreamSim   +0.21
Pose       +0.17
SigLIP     -0.25
WD/Qwen    -0.08
```

This can act like a **representation-space compass**.

The system does not need to semantically name the direction.

It only needs to describe the transformation in terms of the underlying representations.

---

# 28. Projection Disagreement

A transition can be examined across multiple aligned projections:

```text
SigLIP UMAP       ↗
DreamSim UMAP     →
Pose UMAP         ↑
WD/Qwen UMAP      ↘
```

If the projections agree on direction, the transition has stronger cartographic stability.

If they strongly disagree, the direction is not stable under representation choice.

A resultant vector can be computed:

\[
\bar V=
\sum_k w_kV_k
\]

with a directional certainty:

\[
C=
\frac{
\left\|\sum_k w_kV_k\right\|
}{
\sum_k w_k\|V_k\|
}
\]

This allows the representative coordinate system to express both:

- direction,
- confidence / consensus.

---

# 29. A Representative Coordinate System

A shared 1×1 2-D chart is still useful, but should be treated as a **representative aligned map**, not an absolute universal coordinate system.

The useful goal is to map:

- media position,
- historical density,
- current recency,
- traversal direction,
- representation disagreement,
- local topology,
- emergent functional structures,

into one interpretable cartographic interface.

The underlying computations should remain grounded in the higher-dimensional geometries.

---

# 30. Overall Architecture

```text
                    HUMAN
                      │
                      ↓
          defines operational meaning
                      │
                      ↓
           HYDRUS / HYDOWNLOADER
        ┌──────────────────────────┐
        │ tags                     │
        │ predicates               │
        │ metadata                 │
        │ inbox / archive state    │
        │ optional workflow logic  │
        └────────────┬─────────────┘
                     │
                     │ timestamped observations
                     ↓
                CARTOGRAPHY
        ┌──────────────────────────┐
        │ attention field A(x,y)   │
        │ recency field R(x,y,t)   │
        │ trajectories             │
        │ flow field V(x,y,t)      │
        │ gradients                │
        │ divergence / curl        │
        │ explored territory       │
        │ landmarks                │
        └────────────┬─────────────┘
                     │
                     ↓
           REPRESENTATION ANALYSIS
        ┌──────────────────────────┐
        │ SigLIP                   │
        │ DreamSim                 │
        │ WD / JoyTag              │
        │ Qwen-derived spaces      │
        │ Pose                     │
        │ NSFW                     │
        │ other geometries         │
        └────────────┬─────────────┘
                     │
                     ↓
                TRANSLATION
        ┌──────────────────────────┐
        │ metadata predicates      │
        │ human-readable tags      │
        │ system predicates        │
        │ representation changes   │
        │ traversal structures     │
        └──────────────────────────┘
```

---

# 31. Core Methodological Principle

The cartography system should not decide what observation means.

That is upstream and human-controlled.

The cartography system should not automatically decide what discovered structures mean either.

That can be interpreted downstream through translation against metadata, predicates, and human-readable representations.

Its core responsibility is narrower:

\[
\boxed{
\text{Given timestamped observation events, what spatial and directional structure does traversal exhibit?}
}
\]

---

# 32. Compact Conceptual Summary

The project can be summarized as:

\[
\boxed{
\text{human-defined observation}
+
\text{timestamped traversal}
+
\text{representational terrain}
\rightarrow
\text{observer-relative cartography}
}
\]

The human controls what counts as observation.

The embeddings provide candidate terrains.

The timestamps provide motion.

The attention field provides historical occupancy.

The recency field provides approximate current position.

The vector field provides direction.

Gradients, divergence, curl, and streamlines provide cartographic structure.

Human-readable metadata and system predicates provide translation and interpretation.

Traversal adds functional meaning to otherwise opaque embedding spaces.

The resulting system is therefore not merely a visualization of latent space.

It is a **map of media terrain whose meaning is partially revealed by how a human-defined observer traverses it**.
