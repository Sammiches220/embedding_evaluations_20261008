# Semantic Cartography of Embedding Spaces

## Core Question
Can human-meaningful maps be constructed over arbitrary embedding spaces, similar to how physical maps highlight what humans care about rather than preserving all underlying detail?

## Key Findings

### 1. Engineered Features as Human Landmarks
- Engineered features often act as shortcuts to patterns humans already know matter.
- They function as semantic landmarks rather than new information.
- Their value is often improved sample efficiency, interpretability, and alignment with human goals.

### 2. PCA vs. Semantic Descriptions
**PCA:**
- Preserves variance.
- Finds geometric structure.
- Produces mathematically useful axes.

**LLM Descriptions:**
- Preserve human-relevant distinctions.
- Approximate axes of attention rather than axes of variance.
- Act similarly to large-scale, language-derived feature engineering.

### 3. Physical Map Are Not PCA of Reality
Maps do not preserve maximum physical variance.
They preserve what humans generall find useful:
- Roads
- Cities
- Borders
- Landmarks

Thus maps are best viewed as recommendation systems for attention.

### 4. The Anchor Problem
A major challenge emerges:
- Meaningful landmarks are needed to interpret a space.
- Yet landmarks appear to require prior interpretation.

This creates a bootstrap problem similar to asking where the first meanings originated.

### 5. Evolutionary Perspective
Meaning may arise through:
1. Constraints
2. Repeated usefulness
3. Stabilized distinctions
4. Semantic concepts

Under this view, meaning is not discovered directly.
It accumulates through successful interaction

### 6. Why Image Models Work
Vision-language models do not interpret arbitrary embeddings.
Their embedding spaces were explicitely aligned with language during training.

Image understanding works semantic anchors were learned beforehand.

### 7. Semantic Atlases for Arbitrary Embeddings
A possible approach:

```text
Embedding Space
 ...
Cluster Discovery
 ...
Representative Examples
 ...
LLM Summaries
 ...
Semantic Landmarks
```

The LLM interprets examples, not raw vectors.

### 8. Recommendation as Cartography
A useful map depends on the observer.

```text
Embedding Space
+ User
+ Goal
...
Recommended Projection
```

This suggests there may be no single optimal semantic map.
Different users require different landmark systems.

### 9. Hierarchy of Maps
Level 0: Raw geometry

Level 1: General human attention
- Trust
- Risk
- Novelty
- Complexity

Level 2: Domain-specific attention
- Clinical
- Financial
- Manufacturing
- Scientific

Level 3: User-specific attention
- Personal goals
- Historical interactions
- Current tasks

### Central Hypothesis
Language may function as a semantic atlas over latent spaces.

PCA discovers geometric structure.
LLMs approximate human attention structure.

A future semantic cartography system may combine:
- Embedding geometry
- Human-derived semantic landmarks
- Recommendation systems
- Interactive refinement through user behavior

The resulting maps would not merely show what exists.
They would suggest what is likely worth noticing.

