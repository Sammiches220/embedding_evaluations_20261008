# Methodology: General-Purpose Multimodal Embedding for Danbooru Images

## Objective

The objective is to generate **one fixed-dimensional embedding per piece of content**, suitable for similarity search, clustering, dimensionality reduction, and navigation through a projected latent space.

The representation should primarily describe **general human-perceived meaning and similarity**, while remaining usable for images outside Danbooru and outside the anime/illustration domain.

Accordingly:

* pixels form the universal foundation;
* automatically derived features may be generated for any image;
* Danbooru-specific human metadata acts as supplemental information;
* all semantic modalities are fused into **one final embedding**;
* hashes, fingerprints, and file-level metadata are maintained separately as retrieval/deduplication infrastructure.

A reasonable initial output size is:

$$
z_{\text{final}}\in\mathbb{R}^{512}
$$

with L2 normalization before similarity search.

---

# 1. Universal visual-semantic representation

Every image should receive a strong embedding derived directly from its pixels.

### Primary v1 backbone: SigLIP 2

Use **SigLIP 2** as the initial universal visual-semantic representation.

Its role is to establish the basic location of every image regardless of source:

$$
I\rightarrow
\operatorname{SigLIP2}(I)
\rightarrow
z_{\text{visual}}
$$

This should be the required modality and therefore provide meaningful embeddings even when every supplemental source is absent.

### Perception Encoder

**PE-Core-B** should be evaluated as an alternative rather than immediately run alongside SigLIP 2 across the full corpus.

Methodology:

1. Compute SigLIP 2 and PE embeddings on a representative subset.
2. Compare nearest-neighbor behavior.
3. Measure how much unique neighborhood information PE contributes after SigLIP 2.
4. Select one as the universal backbone unless their combination produces a clear improvement.

For v1, prefer **SigLIP 2** because it provides a straightforward language-aligned semantic representation.

---

# 2. Human-perceptual image representation

Evaluate **DreamSim** as a second universal visual modality.

DreamSim independently maps each image to an embedding; a reference image is required only when the stored representations are later compared. Its implementation explicitly supports precomputing image embeddings. It therefore satisfies the requirement that feature extraction itself be reference-free.

Use:

$$
I\rightarrow
\operatorname{DreamSim}(I)
\rightarrow
z_{\text{perceptual}}
$$

Its purpose is complementary to SigLIP:

* SigLIP 2: semantic/conceptual similarity;
* DreamSim: human-perceived visual similarity, including gestalt, layout, appearance, and semantics.

DreamSim should first be evaluated on a subset. If it adds little beyond SigLIP 2, omit it from the 11.6M-image production pipeline.

---

# 3. Generic automatic semantic tagging

Run an image tagger whose vocabulary is not specific to Danbooru.

Initial candidate:

**RAM++**

The output should not simply be preserved as arbitrary strings. Convert predicted concepts into a semantic text representation:

$$
I
\rightarrow RAM++
\rightarrow
\{(t_i,p_i)\}
\rightarrow
\text{text/tag encoder}
\rightarrow
z_{\text{generic-tags}}
$$

Probabilities should be retained so predictions can be weighted by confidence.

This provides a source-independent explicit semantic interpretation of each image.

---

# 4. Danbooru-trained automatic tagging

In parallel, use a **Danbooru-trained image tagger**, even for images that did not originate from Danbooru.

Candidate models should include:

* WD/SmilingWolf taggers;
* DanbooruTagQuery;
* potentially newer Danbooru taggers after benchmarking.

Its purpose is different from RAM++:

$$
I\rightarrow\text{generic vocabulary}
$$

versus:

$$
I\rightarrow\text{Danbooru visual vocabulary}.
$$

The Danbooru tagger should particularly emphasize **general tags** when applied to out-of-domain imagery. Character/copyright predictions should receive lower trust outside the illustration/anime domain.

This provides a useful semantic bridge between photographs and illustrations: a photograph may still produce concepts such as `long_hair`, `smile`, `sitting`, `tree`, `blue_sky`, or `looking_at_viewer`.

---

# 5. Wiki-aware Danbooru tag semantics

Human Danbooru tags should be treated as high-quality supplemental semantic information.

Rather than embedding only raw tag names, construct a reusable representation for each Danbooru tag using available ontology/text information:

$$
t\rightarrow
\{
\text{name},
\text{category},
\text{wiki definition},
\text{aliases},
\text{implications}
\}
\rightarrow Qwen3
\rightarrow e_t.
$$

This dictionary only needs to be constructed once.

For each image, aggregate its tag embeddings:

$$
z_{\text{human-tags}}
=
\frac{
\sum_t w_t e_t
}{
\sum_t w_t
}
$$

where \(w_t\) can incorporate:

* tag category;
* inverse document frequency;
* optional confidence/reliability.

The same dictionary should be reused for automatically predicted Danbooru tags:

$$
z_{\text{db-auto}}
=
\frac{
\sum_t p(t|I)w_te_t
}{
\sum_t p(t|I)w_t
}.
$$

Human and automatically generated Danbooru tags therefore occupy the same semantic vocabulary while remaining separate modalities.

DanbooruTagQuery itself should not be assumed to provide wiki semantics; the wiki-derived representation should remain a separate component.

---

# 6. Natural-language semantic information

Where available, additional human text should be embedded with Qwen3.

### Artist commentary

Combine appropriate fields such as:

* title;
* translated title;
* artist description;
* translated description.

Then:

$$
\text{commentary}
\rightarrow Qwen3
\rightarrow
z_{\text{commentary}}.
$$

### Danbooru notes

Combine active note contents into structured text:

$$
\text{notes}
\rightarrow Qwen3
\rightarrow
z_{\text{notes}}.
$$

Spatial note coordinates can initially remain outside the model.

Notes are particularly useful for comics, dialogue, signs, translated text, and memes.

### VLM-generated description

A later universal modality can be:

$$
I
\rightarrow \text{VLM description}
\rightarrow Qwen3
\rightarrow
z_{\text{caption}}.
$$

Because inference over 11.6M images may be expensive, initially generate descriptions only for a representative subset and determine whether they provide useful semantic information beyond SigLIP, automatic tags, and Danbooru metadata.

---

# 7. Image quality representation

Use the existing no-reference PyIQA pipeline.

Initial metrics may include:

* BRISQUE;
* LAION-AES;
* UNIQUE;
* QualiCLIP+;
* ARNIQA;
* TReS;
* NIQE;
* PaQ-2-PiQ;
* PIQE;
* LIQE;
* MUSIQ.

Normalize each metric across the corpus and project the resulting scalar vector through a small MLP:

$$
q\in\mathbb R^{N}
\rightarrow
\operatorname{MLP}_{IQA}
\rightarrow
z_{\text{IQA}}.
$$

The learned projection can handle correlations between metrics.

IQA should remain a relatively weak modality so that technical/aesthetic quality does not dominate semantic position.

---

# 8. Minimal image metadata

Only metadata with a plausible relationship to the visual content should be considered.

Potential weak inputs:

$$
\log(W/H)
$$

for aspect ratio, and possibly rating if desired.

Do not include absolute file size or timestamps in semantic fusion.

### Exclude from semantic fusion

* `file_size`
* `created_at`
* `updated_at`
* `id`
* `md5`
* uploader/approver IDs
* URLs
* moderation state
* pending/deleted/flagged state
* `has_large`
* `bit_flags`
* comment timestamps
* other database lifecycle information

These may remain available for filtering and analysis.

---

# 9. Separate hashing and fingerprint pipeline

Hashing should be treated as a **parallel similarity/indexing subsystem**, not as input to the semantic embedding.

The layers should be approximately:

## Exact-byte identity

Existing:

$$
\text{MD5}(F)
$$

Use for exact duplicate detection.

Since MD5 already exists in the Danbooru metadata, there is little reason to recompute another persistent exact-content hash solely for the existing corpus.

---

## Fast ingestion fingerprint

Use:

**XXH3 / xxHash**

for extremely cheap initial file fingerprinting or hash-table operations.

xxHash is explicitly designed as a very fast non-cryptographic hash, with XXH3 optimized especially for modern 64-bit/SIMD systems.

Its role is:

$$
\boxed{\text{speed}}
$$

not fuzzy similarity or semantic similarity.

Possible ingestion sequence:

$$
\text{file size + MIME}
\rightarrow
xxHash
\rightarrow
stronger comparison if necessary.
$$

- Exact identity → SHA-256 or BLAKE3 - BLAKE3 is attractive for speed; SHA-256 is useful for ecosystem compatibility.
- Probabilistic “seen before?” checks → Bloom filters

---

## Cheap metadata narrowing

Use:

* file size;
* MIME type / detected media type;
* dimensions where appropriate.

These are useful for narrowing candidate comparisons.

Thus `file_size` is:

$$
\boxed{\text{useful for retrieval infrastructure}}
$$

but:

$$
\boxed{\text{not useful as a semantic embedding feature}}.
$$

Those are not contradictory.

---

## Binary/text fuzzy similarity

Use **TLSH** as the initial default fuzzy-content digest.

$$
F\rightarrow TLSH(F)
$$

TLSH provides a similarity/distance relationship between byte streams rather than merely exact equality and is specifically designed as a locality-sensitive/fuzzy hash.

It is appropriate for identifying files that contain related underlying byte structures despite modifications.

**ssdeep** can optionally be retained for compatibility/interoperability. It implements context-triggered piecewise hashing and compares common byte-sequence structure between files.

The ssdeep project itself notes that stronger fuzzy hashes exist while emphasizing ssdeep's speed and status as a widely supported standard.

Therefore:

$$
\boxed{\text{TLSH first}}
$$

with:

$$
\boxed{\text{ssdeep optional}}
$$

is a reasonable default methodology.

These hashes are primarily useful for:

* modified text;
* metadata files;
* related binaries;
* altered archives;
* other byte-level relationships.

They should not be interpreted as visual semantics.

---

## Perceptual image hashing

Calculate at least:

* **pHash**
* **dHash**

and potentially evaluate:

* wHash;
* crop-resistant hashes;
* color hashes.

Perceptual hashes intentionally map nearly visually identical images to nearby binary fingerprints, unlike exact cryptographic hashes where a tiny file change radically changes the digest.

Use Hamming distance:

$$
d_H(h_i,h_j)
$$

for near-duplicate detection.

Their role is:

* resize/recompression detection;
* modified-copy discovery;
* duplicate clustering;
* high-confidence positive pairs for representation training.

Do **not** concatenate the hash bits into the semantic embedding.

Two different images of the same meaningful subject can have completely unrelated pHashes, while a resized copy should have nearly the same pHash. That is a different similarity definition from the semantic latent space.

---

# 10. Similarity hierarchy

The complete infrastructure should therefore distinguish several levels:

| Question                                                        | Method                     |
| --------------------------------------------------------------- | -------------------------- |
| Are these byte-identical?                                       | MD5 / exact digest         |
| Can I cheaply eliminate impossible matches?                     | file size + MIME           |
| Do I need an extremely fast fingerprint?                        | xxHash / XXH3              |
| Are these binaries/text files structurally related?             | TLSH, optionally ssdeep    |
| Are these effectively the same visual media?                    | pHash / dHash              |
| Do humans perceive these images similarly?                      | DreamSim                   |
| Do these images contain similar concepts/meaning?               | SigLIP 2 + semantic models |
| Where should this content live in the navigable semantic space? | **final fused embedding**  |

This hierarchy should remain explicit in the implementation.

---

# 11. Self-attention fusion

Every semantic modality is converted to a common token dimension, for example 512:

$$
x_m=P_m(z_m)\in\mathbb R^{512}.
$$

Potential tokens:

$$
[
\text{FUSE},
\text{SigLIP},
\text{DreamSim},
\text{RAM++},
\text{DB-auto},
\text{DB-human},
\text{commentary},
\text{notes},
\text{IQA}
].
$$

Feed the available tokens through a small Transformer encoder:

* approximately 2 layers;
* 4–8 attention heads;
* hidden width 512;
* learned modality/type embeddings.

The output of the `[FUSE]` token becomes the single representation:

$$
z_{\text{attention}}
=
h_{\text{FUSE}}.
$$

Missing modalities are masked or omitted.

---

# 12. Simple residual fusion for v1

Maintain SigLIP as the universal anchor.

Project its output:

$$
z_0=P_{\text{SigLIP}}(z_{\text{SigLIP}}).
$$

Have the attention fusion network predict a semantic correction:

$$
\Delta z=
F_{\theta}
(
x_{\text{available modalities}}
).
$$

Then:

$$
\boxed{
z_{\text{final}}
=
\operatorname{L2Norm}
(
z_0+\alpha\Delta z
)
}
$$

where \(\alpha\) may initially be a single learned bounded scalar.

This provides a useful invariant:

$$
\text{no supplemental data}
\Rightarrow
z_{\text{final}}\approx z_{\text{SigLIP}}.
$$

Danbooru metadata therefore **refines** the universal visual representation rather than defining it.

---

# 13. Modality dropout

During training, randomly remove optional modalities.

SigLIP remains available 100% of the time.

Example training availability:

| Modality            | Approximate availability |
| ------------------- | -----------------------: |
| SigLIP 2            |                     100% |
| DreamSim            |                   50–80% |
| RAM++               |                   50–80% |
| Danbooru auto-tags  |                   50–80% |
| Human Danbooru tags |                   40–70% |
| IQA                 |                   50–80% |
| commentary          |                   20–40% |
| notes               |                   20–40% |
| VLM caption         |   potentially much lower |

The exact rates should be tuned experimentally.

This prevents the final space from becoming dependent on Danbooru-only information.

---

# 14. Training objective

The fusion network should learn to preserve the consensus neighborhood structure implied by the component representations.

Construct normalized teacher similarities such as:

$$
S_{ij}
=
w_sS^{\text{SigLIP}}_{ij}
+
w_dS^{\text{DreamSim}}_{ij}
+
w_gS^{\text{generic tags}}_{ij}
+
w_aS^{\text{DB auto}}_{ij}
+
w_hS^{\text{human tags}}_{ij}
+
w_qS^{\text{IQA}}_{ij}.
$$

Convert these to neighborhood distributions:

$$
P_T(j|i)
=
\operatorname{softmax}
(S_{ij}/\tau_T).
$$

The fused embeddings generate:

$$
P_Z(j|i)
=
\operatorname{softmax}
(z_i^\top z_j/\tau_Z).
$$

Train the final embedding to reproduce those neighborhoods.

Additional high-confidence constraints can come from:

* exact duplicates;
* pHash/dHash near-duplicates;
* parent/child relationships;
* replacements;
* image augmentations.

Hashes therefore contribute to **training supervision and search**, even though their values never enter the semantic fusion network.

---

# 15. Experimental procedure

### Phase 1 — representative subset

Select approximately 100k–500k images spanning:

* years;
* artists;
* copyrights;
* common and rare tags;
* popularity;
* aspect ratios;
* illustration types;
* quality levels.

Calculate all candidate modalities.

Also calculate:

* pHash;
* dHash;
* TLSH where appropriate;
* xxHash if useful operationally.

---

### Phase 2 — modality evaluation

Evaluate:

* SigLIP 2 versus PE;
* SigLIP alone versus SigLIP + DreamSim;
* RAM++ contribution;
* Danbooru auto-tagger contribution;
* wiki-aware human tags;
* IQA;
* commentary;
* notes;
* VLM descriptions on a smaller sample.

Measure both quantitative neighborhood agreement and subjective quality in the latent-space viewer.

---

### Phase 3 — baseline fusion

Before self-attention, create a simple baseline:

$$
[
\hat z_1;
\hat z_2;
...;
\hat z_n
]
\rightarrow
\text{linear projection / MLP}
\rightarrow
512D.
$$

The Transformer must outperform this baseline enough to justify its complexity.

---

### Phase 4 — self-attention fusion

Train the small attention model with:

* modality embeddings;
* modality dropout;
* neighborhood preservation;
* residual SigLIP anchor.

Output exactly:

$$
\boxed{512\text{-dimensional normalized vector per image}}.
$$

---

### Phase 5 — full corpus

Only after choosing the useful modalities should the expensive image models be run across all ~11.6 million images.

Cache every intermediate representation.

Fusion experiments can then be performed entirely on cached features without repeatedly decoding or processing the images.

---

# Final system architecture

The overall pipeline becomes:

```text
                                 CONTENT
                                    │
                    ┌───────────────┴────────────────┐
                    │                                │
               HASH/FINGERPRINT                 SEMANTICS
                    │                                │
       ┌────────────┼─────────────┐        ┌────────┼───────────┐
       │            │             │        │        │           │
     xxHash       TLSH      pHash/dHash  SigLIP  DreamSim   Auto-tags
       │            │             │        │        │           │
 file/MIME      binary        visual       │        │       RAM++ + DB
 prefilter      similarity     duplicate    │        │           │
                                  │         │        │           │
                                  │      human tags/wiki         │
                                  │      commentary/notes        │
                                  │          IQA                 │
                                  │           │                  │
                                  │           └────────┬─────────┘
                                  │                    │
                                  │            self-attention
                                  │                    │
                                  │             residual fusion
                                  │                    │
                                  │                    ▼
                                  │              ONE 512D VECTOR
                                  │                    │
                                  └──── training /    │
                                        evaluation    ▼
                                                latent-space map
```

The fundamental separation is:

$$
\boxed{\text{hashing identifies sameness and modification}}
$$

while:

$$
\boxed{\text{embeddings represent meaning and similarity}}.
$$

The hash/fingerprint subsystem can dramatically reduce search and ingestion costs at 11.6M+ items, while the self-attention fusion model remains responsible for the single semantic coordinate used by the navigable latent space.
