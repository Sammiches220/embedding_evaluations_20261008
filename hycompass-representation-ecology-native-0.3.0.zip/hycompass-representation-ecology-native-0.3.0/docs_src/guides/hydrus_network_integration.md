# Hydrus Network Integration

!!! warning "Important — Large Dataset Usage"

    **It is NOT recommended to send large amounts of data to Hydrus.**

    **It is NOT recommended to scrape large amounts of full-sized data.**

    When viewing data not already in Hydrus, it is best to use simple, lower-level viewers for mass-viewing
    *optimized* data.

    For example, the
    [deepghs/danbooru2024-webp-4Mpixel](https://huggingface.co/datasets/deepghs/danbooru2024-webp-4Mpixel)
    dataset contains approximately **8 million compressed images in ~1.77 TB**.

    **Recommended approach:**

    1. Create an optimized indexing application that maps file paths to unique
       HyCompass IDs. LLMs can do this in a couple prompts.
    2. Integrate whatever logic you need to relate items to source info (e.g. Danbooru post IDs)
    3. Use the HyCompass REST API to retrieve selections.
    4. Resolve those selections against the external index rather than importing
       the entire dataset into Hydrus.

    !!! tip

        It is strongly recommended to **sample unknown data** rather than attempting
        to view or process everything. 
        
        You can even incorporate recommendation logic like basing samples off of features like `score` for Danbooru

## Overview

The "Hy" in "HyCompass" represents its direct support to  [Hydrus Network](https://hydrusnetwork.github.io/hydrus/index.html) ([GitHub](https://github.com/hydrusnetwork/hydrus))

By itself, HyCompass can be used with any arbitrary embeddings and is not attached to Hydrus. Despite being separated, HyCompass directly supports two separate packages to integrate directly with Hydrus Network:

1. [Hydrus Embedding Tracker](https://github.com/SBroaddus220/hydrus_embedding_tracker)
2. HyCompass Hydrus Viewer

The relationships work as follows:

<div style="text-align: center;">
  <img
    src="../img/hydrus_integration_relationship_diagram.png"
    alt="Hydrus Integration Relationship Diagram."
    style="
      width: 100%;
      max-width: 1200px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>


## Sample Hydrus Selection Viewer

Using HyCompass' REST API, you can effectively query selections and update any supplemental application via using the *Server-Sent Events (SEE)* to optimize with deltas instead of reprocessing every selection again.

Below shows what to expect from the viewer when all three applications are set up successfully:

<div style="text-align: center;">
  <img
    src="../img/sample_hydrus_selection_viewer.png"
    alt="Embedding card for Danbooru Swinv2 dataset."
    style="
      width: 100%;
      max-width: 1200px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>


## Why The Support is Separated 

Although I initially wanted it to be more attached, I realized that this is infeasible. This is mostly because of how:

-  HyCompass cannot host any arbitrary means of embedding. Thus, it must directly support importing embeddings.
      -  Methodologies can have conflicting dependencies
      -  Supporting arbitrary code is an absurd requirement
      -  Performance requirements can differ dramatically (e.g. supercomputers or GPU clusters for expensive datasets)
-  Existing datasets (e.g. on [Hugging Face](https://huggingface.co/)) should be importable 
-  Users should not have to recompute embeddings (Similar idea to the [PTR](https://hydrusnetwork.github.io/hydrus/PTR.html))
-  HyCompass does not need to know any Hydrus data
-  Embedding datasets can be *large*. The Hydrus viewer does not need to see the entire dataset. It only needs to know what you want it to load.

Due to these reasons, HyCompass chooses to separate its support.
The API intentionally has no schema for Hydrus tags, arbitrary scores, model metadata, ratings, or other external columns.

## Relating Item IDs to External Items

It is an unreasonable requirement to support any arbitrary logic to relate any given embedding record to any external item. As such, HyCompass keeps its own managed UIDs for items, and pushes the scope of relating them onto other external applications. 

For example, for the Hydrus Network integration, the embedding tracker records the Hydrus file ID, the Hydrus SHA256 hash, and the actual SHA256 hash of the item. 

Exactly matching deterministic hashes or item IDs are a great method to reliably relate items, but there are many issues with this approach. There are many times this is not. Some examples include: slightly modified images (cropped / lower res / etc.), differently encoded videos, 

