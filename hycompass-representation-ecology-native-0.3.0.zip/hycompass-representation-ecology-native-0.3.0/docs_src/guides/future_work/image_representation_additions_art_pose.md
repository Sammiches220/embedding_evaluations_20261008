# Project Context Update: Additional Image Representations
## Art-Specific, NSFW / Safety, and Human Pose Coordinate Systems

This document summarizes the findings from the recent discussion about expanding the modular image-representation pipeline with additional independent coordinate systems.

The project goal is **not** to produce one universal embedding as early as possible.

Instead:

```text
image
 ↓
multiple independent representations
 ↓
preserve native information
 ↓
derive normalized / interpretable coordinate systems
 ↓
compare empirically
 ↓
fuse only later
```

The broader objective is to represent different notions of human-perceived meaning separately so that a large media archive can be navigated according to different semantic, perceptual, artistic, safety-related, and geometric criteria.

---

# Existing Representation Philosophy

Current major branches already include concepts such as:

```text
SigLIP 2
    general visual-semantic similarity

DreamSim
    perceptual / human similarity judgments

RAM++
    explicit generic tags
        ↓
    Qwen3
        ↓
    generic semantic embedding

WD EVA02-Large v3
    visual representation
    full Danbooru ontology vector
    general-tag Qwen representation
    character-tag Qwen representation

JoyTag
    visual representation
    full tag ontology vector
    Qwen semantic representation
```

Important methodology:

```text
Do not immediately concatenate or fuse representations.

Preserve:
- model-native outputs
- exact vocabularies
- probabilities / logits
- normalized similarity embeddings
- explicit semantic intermediates
- preprocessing identity
- model/checkpoint provenance
- downstream transformation parameters
```

Expensive inference should be cached richly.

Cheap transformations should remain regenerable.

---

# New Representation Categories Identified

The recent discussion identified several particularly valuable additional coordinate systems:

```text
1. artistic style / content disentanglement
2. artistic aesthetics
3. affect / emotional response
4. sexual / NSFW severity
5. anatomical exposure
6. general safety / disturbing content
7. human body pose
8. hand / facial geometry
9. multi-person spatial configuration
10. formal artwork analysis through language
```

These are useful specifically because they represent notions of similarity that are not cleanly captured by generic image-semantic embeddings.

---

# Art-Datasets Repository

Reviewed:

```text
https://github.com/georgeblck/art-datasets
```

The repository is primarily valuable as a directory of:

- art datasets
- pretrained models associated with art datasets
- style/content representation research
- aesthetic datasets
- emotional-response datasets
- formal artwork-analysis datasets
- evaluation datasets

Most entries should not automatically become embedding branches.

The strongest candidates are those that add a **new coordinate system** rather than merely providing another generic art classifier.

---

# SCFlow / CAtFM
## Style and Content Disentanglement

One of the most relevant findings was **SCFlow**, along with its newer **CAtFM** follow-up.

The important conceptual feature is explicit separation of:

```text
artistic style

vs.

semantic content
```

inside a CLIP-related latent representation.

Conceptually:

```text
image
 ↓
CLIP-like image representation
 ↓
SCFlow / CAtFM inverse mapping
 │
 ├── content representation
 │
 └── style representation
```

Potential canonical representations:

```text
z_catfm_content
z_catfm_style
```

or, if using SCFlow directly:

```text
z_scflow_content
z_scflow_style
```

This is especially valuable because generic visual-semantic encoders tend to entangle:

- subject
- composition
- style
- medium
- visual appearance

A dedicated style representation would permit queries such as:

```text
find images with a similar artistic style
while ignoring depicted subject matter
```

while a content representation could attempt the inverse.

This is a high-priority research direction.

---

# fruit-SALAD
## Evaluation Rather Than a Production Embedding

`fruit-SALAD` is useful primarily as an **evaluation benchmark**.

Its structure deliberately varies:

```text
semantic content
×
artistic style
```

making it useful for measuring whether a representation is biased toward:

- content similarity
- style similarity

Possible evaluation table:

```text
representation          content sensitivity    style sensitivity

SigLIP                          ...
DreamSim                        ...
WD visual                       ...
JoyTag visual                   ...
CAtFM content                   ...
CAtFM style                     ...
```

This would allow empirical characterization rather than relying only on qualitative impressions.

---

# APDDv2 / ArtCLIP
## Artistic Aesthetic Attributes

APDDv2 and ArtCLIP provide another useful art-specific direction.

The important distinction is that this is not merely generic technical image quality.

Possible representation:

```text
r_artclip_aesthetics
```

containing:

```text
overall aesthetic score
+
individual aesthetic attributes
```

Potentially also preserve a useful pre-classifier visual representation if the model exposes one:

```text
z_artclip_visual
```

This could represent an explicitly art-oriented notion of aesthetic quality and artistic properties.

It should remain separate from:

```text
NR-IQA
generic aesthetic predictors
SigLIP semantics
DreamSim perceptual similarity
```

---

# ArtEmis
## Affective / Emotional Representation

ArtEmis associates artworks with emotional responses and explanations.

A pretrained artwork-to-emotion model can therefore provide a new coordinate system.

Potential architecture:

```text
image
 ↓
ArtEmis emotion model
 │
 ├── emotion probability vector
 │     ↓
 │   r_artemis_emotion
 │
 └── penultimate visual representation
       ↓
     z_artemis_affective
```

Interpretation:

```text
z_siglip
    what does the image mean?

z_dreamsim
    what does the image look like?

z_artemis_affective
    what emotional response does the image tend to evoke?
```

This is meaningfully different from generic semantics.

---

# Formal Artwork Analysis
## VLM → Structured Text → Qwen

Another possible representation is to ask a multimodal model to perform formal artwork analysis.

Instead of one generic description:

```text
image
 ↓
VLM
 ↓
structured analysis
```

Possible sections:

```text
subject
composition
color
lighting
technique
medium
perspective
mood
symbolism
style
```

Each could then be embedded independently using Qwen3.

For example:

```text
z_art_subject_text
z_art_composition_text
z_art_color_text
z_art_technique_text
z_art_mood_text
z_art_style_text
```

This retains interpretability and prevents unrelated semantic axes from being immediately collapsed.

---

# NSFW as Its Own Representation Family

The discussion strongly favored treating NSFW / sexual content as **several related but separate coordinate systems**, rather than only:

```text
p_nsfw
```

A better decomposition is:

```text
sexual-content representation
│
├── rating / severity
│
├── anatomical exposure
│
├── semantic type of sexual content
│
└── broader safety / disturbing content
```

This matters because these are not equivalent.

Examples:

```text
classical nude
    high exposure
    possibly low pornographic character

suggestive clothed image
    low exposure
    elevated erotic/suggestive rating

explicit sexual image
    high exposure
    high explicitness

gore
    potentially unsafe
    not sexual
```

---

# WD Rating Representation
## Promote Existing Information to First-Class Status

WD EVA02 already contains Danbooru rating outputs.

Instead of treating them only as metadata, preserve them as a dedicated representation.

Potential canonical representation:

```text
r_wd_rating
    [
        p_general,
        p_sensitive,
        p_questionable,
        p_explicit
    ]
```

This should generally remain **unnormalized**, because the dimensions have classifier/probability meaning rather than ordinary cosine-embedding meaning.

A derived convenience scalar can also be generated:

```text
s_wd_explicitness
```

For example, after renormalizing rating scores:

```text
general        → 0.00
sensitive      → 0.33
questionable   → 0.67
explicit       → 1.00
```

However:

```text
r_wd_rating
```

should remain canonical.

The scalar should be treated as a derived downstream view.

---

# Marqo NSFW Image Detection
## Dedicated NSFW Visual Geometry

A particularly interesting dedicated model is:

```text
Marqo/nsfw-image-detection-384
```

It uses a small ViT trained specifically for SFW/NSFW discrimination across diverse imagery.

Of particular interest is preserving the model's **pre-classifier representation**, not just its final binary probability.

Potential architecture:

```text
image
 ↓
Marqo NSFW ViT
 │
 ├── pre-classifier representation
 │     ↓
 │   normalize
 │     ↓
 │   z_marqo_nsfw_visual
 │
 └── classifier
       ↓
     r_marqo_nsfw
```

Potential outputs:

```text
z_marqo_nsfw_visual
    ~192-D

r_marqo_nsfw
    [
        p_sfw,
        p_nsfw
    ]
```

Interpretation:

```text
z_marqo_nsfw_visual
    image similarity according to visual features
    learned specifically for NSFW discrimination
```

This may produce a useful geometry that differs substantially from SigLIP, DreamSim, and WD.

---

# NudeNet
## Anatomical Exposure Representation

NudeNet provides something fundamentally different from a binary NSFW classifier.

It detects exposed or covered body regions using bounding boxes.

Examples include concepts such as:

```text
breast exposed
genitalia exposed
buttocks exposed
anus exposed
male genitalia exposed

and corresponding covered categories
```

Native outputs should be cached:

```text
class
confidence
bounding box
```

Derived per-class features might include:

```text
maximum confidence
number of detections
total image-area fraction
largest detection-area fraction
```

Potential representation:

```text
r_nudenet_exposure
```

This answers:

```text
how physically exposed are human anatomical regions?
```

rather than:

```text
is this image pornographic / NSFW?
```

That distinction is highly useful.

---

# Stable Diffusion Safety Checker
## Safety Prototype Similarity

The Stable Diffusion safety checker is more interesting internally than its final yes/no result suggests.

It uses a CLIP image representation and compares it to learned safety-concept embeddings.

Potential outputs:

```text
z_sd_safety_visual
r_sd_safety_concepts
```

where:

```text
r_sd_safety_concepts
```

is a vector of similarities to learned safety concepts.

This creates an additional safety-related geometry.

The downside is reduced interpretability because the learned concept vectors are not exposed as a clean human-readable ontology.

Therefore this is best treated as an experimental branch.

---

# LAION CLIP-Based NSFW Detector

The LAION NSFW detector is conceptually interesting because it applies a lightweight NSFW classifier over a CLIP image embedding.

Conceptually:

```text
image
 ↓
CLIP ViT-L/14
 ↓
CLIP embedding
 │
 ├── z_clip_l14
 │
 └── NSFW head
       ↓
     p_unsafe
```

This creates an interesting opportunity to analyze:

```text
NSFW direction
within general CLIP semantic geometry
```

The downside is additional model cost when SigLIP is already present.

Therefore it is scientifically interesting but lower priority than WD rating + Marqo + NudeNet.

---

# Broader Safety / NSFL

Sexual content should remain separate from:

```text
gore
graphic violence
disturbing imagery
```

A separate classifier with:

```text
SFW
NSFW
NSFL
```

can provide:

```text
r_content_safety
```

For example:

```text
r_content_safety =
[
    p_sfw,
    p_nsfw,
    p_nsfl
]
```

This avoids treating all unsafe content as sexual content.

---

# Recommended NSFW Architecture

A useful initial system would be:

```text
image
│
├── WD EVA02
│     └── rating outputs
│           ├── r_wd_rating
│           └── s_wd_explicitness
│
├── Marqo NSFW ViT
│     ├── z_marqo_nsfw_visual
│     └── r_marqo_nsfw
│
├── NudeNet
│     ├── raw detections
│     └── r_nudenet_exposure
│
├── optional SD safety checker
│     ├── z_sd_safety_visual
│     └── r_sd_safety_concepts
│
└── optional general safety model
      └── r_content_safety
```

The most important distinction is:

```text
rating severity
≠
anatomical exposure
≠
sexual-content geometry
≠
general safety
```

---

# Human Pose as a Separate Coordinate System

Human pose was identified as another particularly strong missing representation.

Pose is attractive because it can represent body configuration largely independently of:

```text
identity
character
clothing
art style
medium
background
semantic subject
```

For example:

```text
photograph of a T-pose
anime T-pose
painting of a T-pose
3D render of a T-pose
```

may be very distant under general visual similarity but should be very close under a dedicated pose representation.

---

# DWPose
## Recommended Initial Pose Extractor

DWPose is a strong practical candidate for whole-body pose extraction.

Using COCO-WholeBody conventions, a detected person may contain:

```text
133 keypoints

17 body
6 feet
68 face
21 left hand
21 right hand
```

Native expensive output should be preserved per person:

```text
person_i:
    bounding box
    person confidence

    keypoints:
        x
        y
        confidence
```

Conceptually:

```text
image
 ↓
person detection
 ↓
DWPose
 ↓
people[]
    └── 133 keypoints each
```

The raw detector output should remain canonical.

---

# Normalized 2D Pose Geometry

For body-pose similarity, all 133 landmarks should not necessarily be collapsed together immediately.

A useful first representation might use:

```text
17 body keypoints
+
6 foot keypoints
```

Then normalize:

```text
raw coordinates
 ↓
translate relative to pelvis / hip midpoint
 ↓
normalize body scale
 ↓
optional rotation normalization
 ↓
normalized skeleton
```

Potential representation:

```text
r_pose2d_body
```

For 23 `(x,y)` keypoints:

```text
23 × 2 = 46-D
```

Confidence should preferably be preserved separately:

```text
r_pose2d_confidence
```

rather than directly allowing uncertain joints to distort geometry.

Interpretation:

```text
r_pose2d_body
    "does the person's pose look geometrically similar
     in the image plane?"
```

This is intentionally view-sensitive.

---

# View-Sensitive vs View-Invariant Pose

There are at least two useful notions of pose similarity.

## View-sensitive

```text
same apparent projected body geometry
```

Use:

```text
r_pose2d_body
```

This is useful for:

- silhouettes
- composition
- apparent gesture
- visible articulation

## View-invariant

```text
same underlying 3D body configuration
despite different camera viewpoints
```

This requires a different representation.

Both should be preserved.

---

# Pr-VIPE / L2-VIPE
## Learned View-Invariant Pose Embedding

Pr-VIPE is especially relevant because it explicitly maps 2D body keypoints into a compact pose embedding designed to recognize similar underlying 3D human poses across camera viewpoints.

Conceptually:

```text
DWPose
 ↓
2D body joints
 ↓
Pr-VIPE
 ↓
z_pose_view_invariant
```

Possible native outputs:

```text
r_prvipe_mean
r_prvipe_variance
```

because Pr-VIPE represents pose probabilistically.

A convenient normalized retrieval vector might be:

```text
z_prvipe
    = normalize(mean)
```

but the uncertainty should remain preserved.

Interpretation:

```text
mean:
    estimated pose location in latent space

variance:
    ambiguity / uncertainty of the 3D pose interpretation
```

The probabilistic component is particularly useful because monocular 2D pose is inherently ambiguous.

---

# Important Pr-VIPE Caveat

The released Pr-VIPE checkpoints were trained using specific upstream keypoint distributions.

Using DWPose keypoints may therefore create domain shift.

Accordingly:

```text
DWPose → Pr-VIPE
```

should initially be treated as an **experimental derived representation** and evaluated empirically.

It should not be assumed to be perfectly calibrated.

---

# 3D Pose / SMPL Reconstruction

A more ambitious branch can reconstruct an articulated 3D human body.

Potential models include:

```text
HMR 2.0 / 4DHumans
TokenHMR
```

These can estimate SMPL-like parameters.

Useful decomposition:

```text
KEEP for pose:
    body joint rotations

KEEP separately:
    global orientation

SEPARATE from pose:
    body shape

SEPARATE from pose:
    camera parameters
```

Potential representation:

```text
r_smpl_pose
```

This answers something closer to:

```text
what 3D articulated human configuration
most likely produced this image?
```

rather than only describing projected 2D geometry.

---

# TokenHMR
## Learned Discrete Pose Vocabulary

TokenHMR is particularly interesting conceptually because it learns a tokenized latent representation of human pose.

Its architecture contains a learned pose codebook and represents poses through learned discrete/latent tokens.

Potential information to preserve:

```text
r_tokenhmr_pose_logits
r_tokenhmr_pose_latents
r_tokenhmr_smpl
```

Possible experimental derived representation:

```text
z_tokenhmr_pose
```

obtained by pooling pose-token latents.

However, the pooled latent should not immediately be treated as a canonical similarity embedding because TokenHMR was not primarily trained for nearest-neighbor pose retrieval.

The native token representation is still highly interesting to preserve.

---

# Hands and Face Should Be Separate

Whole-body detection provides:

```text
body
feet
hands
face
```

These should not necessarily be collapsed into one large pose vector.

Potential representation family:

```text
r_body_pose
r_left_hand_pose
r_right_hand_pose
r_face_geometry
```

Hand pose is particularly interesting because it can represent gestures such as:

```text
peace sign
pointing
fist
open palm
hand on hip
hands behind head
```

These may be semantically important even when overall body pose is similar.

Facial landmark geometry could also become a separate expression-related coordinate system later.

---

# Multi-Person Images

Multi-person images require special treatment.

Do **not** average all detected humans during expensive inference.

Instead preserve each person independently:

```text
image_sha256
person_index
bbox
bbox_area
detection_confidence

raw_pose
normalized_pose
pose_embedding
...
```

Then derive image-level representations later.

---

# Primary-Person Pose

For images dominated by one character/person:

```text
z_pose_primary
```

could select the largest or most confidently detected person.

This is useful for many illustration datasets where one subject dominates the image.

---

# Pose-Set Similarity

For general multi-person comparison, retain a set:

```text
{
    z_person_1,
    z_person_2,
    ...
}
```

and compare two images using:

```text
optimal assignment
Chamfer-like distance
Earth Mover / matching approaches
```

rather than averaging.

This preserves differences between:

```text
two people embracing
```

and:

```text
one standing person
```

which mean pooling could destroy.

---

# Inter-Person Geometry

A future representation could describe the arrangement of people relative to each other.

Possible representation:

```text
r_human_layout
```

Potential features:

```text
relative body centers
relative scales
relative orientations
pairwise distances
facing direction
body overlap
pose relationships
```

This could eventually capture concepts such as:

```text
facing each other
embracing
standing side by side
one person carrying another
one person above/below another
```

This is distinct from individual pose.

---

# Recommended Pose Architecture

A strong first implementation:

```text
image
 ↓
DWPose
 ↓
people[]

for each person:

    raw:
        bbox
        133 keypoints
        133 confidences

    ↓

    normalized body + feet skeleton
        ↓
    r_pose2d_body

    ↓

    body-joint conversion
        ↓
    Pr-VIPE / L2-VIPE
        ↓
    z_pose_view_invariant
    uncertainty_pose
```

Potential first-class outputs:

```text
NATIVE
------

pose_people[]
    bbox
    133 × (x, y, confidence)


DERIVED
-------

r_pose2d_body
    apparent image-plane pose geometry

z_pose_view_invariant
    estimated similarity of underlying 3D pose

uncertainty_pose
    ambiguity of pose interpretation
```

Then later:

```text
TokenHMR / HMR2
    ↓
3D pose and learned pose-token representations
```

---

# Revised Representation Taxonomy

The system could eventually be organized conceptually as:

```text
GENERAL VISUAL SEMANTICS
    z_siglip


PERCEPTUAL SIMILARITY
    z_dreamsim


GENERIC EXPLICIT SEMANTICS
    z_ram_semantic


DANBOORU / ILLUSTRATION SEMANTICS
    z_wd_visual
    z_wd_ontology
    z_wd_general_qwen3
    z_wd_character_qwen3

    z_joytag_visual
    z_joytag_ontology
    z_joytag_qwen3


STYLE / CONTENT
    z_catfm_style
    z_catfm_content


ARTISTIC AESTHETICS
    r_artclip_aesthetics
    possibly z_artclip_visual


AFFECT / EMOTION
    r_artemis_emotion
    possibly z_artemis_affective


SEXUAL / NSFW
    r_wd_rating
    s_wd_explicitness

    z_marqo_nsfw_visual
    r_marqo_nsfw

    r_nudenet_exposure

    optionally:
        z_sd_safety_visual
        r_sd_safety_concepts


GENERAL SAFETY
    r_content_safety
        [SFW, NSFW, NSFL]


HUMAN BODY POSE
    raw whole-body keypoints

    r_pose2d_body
    z_pose_view_invariant
    uncertainty_pose

    future:
        r_smpl_pose
        TokenHMR representations


HAND / FACE GEOMETRY
    r_left_hand_pose
    r_right_hand_pose
    r_face_geometry


MULTI-PERSON STRUCTURE
    pose sets
    r_human_layout


FORMAL ART INTERPRETATION
    structured VLM analysis
        ↓
    Qwen3
        ↓
    separate semantic embeddings
```

---

# Suggested Implementation Priority

A practical ordering based on cost, complementarity, and conceptual novelty:

## Very High Priority

```text
1. WD rating branch
    r_wd_rating
    s_wd_explicitness

2. DWPose
    raw whole-body landmarks
    normalized body-pose representation

3. Pr-VIPE / L2-VIPE
    view-invariant pose embedding

4. Marqo NSFW ViT
    NSFW probability
    NSFW-specialized visual latent
```

## High Priority

```text
5. NudeNet
    anatomical-exposure representation

6. CAtFM / SCFlow
    style/content disentanglement

7. ArtCLIP / APDDv2
    art-oriented aesthetic attributes

8. ArtEmis
    affective / emotional coordinate system
```

## Experimental / Later

```text
9. TokenHMR / HMR2
    explicit 3D articulation
    learned pose tokens

10. Stable Diffusion safety prototypes

11. LAION CLIP NSFW geometry

12. structured VLM formal-art analysis

13. multi-person relationship / layout embedding
```

---

# Evaluation Strategy

Each representation should be evaluated according to the specific notion of similarity it is intended to capture.

Avoid asking:

```text
which embedding is best?
```

Instead ask:

```text
which embedding best represents THIS semantic axis?
```

Examples:

```text
SigLIP
    semantic-neighbor quality

DreamSim
    perceptual-neighbor quality

CAtFM style
    style matching under content changes

CAtFM content
    content matching under style changes

ArtEmis
    emotional-response agreement

WD rating
    illustration-oriented sexual severity

Marqo
    general NSFW discrimination

NudeNet
    anatomical exposure

r_pose2d
    apparent projected pose

Pr-VIPE
    underlying pose under viewpoint changes
```

Useful evaluation methods:

```text
nearest-neighbor inspection

pairwise retrieval benchmarks

cross-model neighbor agreement

cross-model disagreement analysis

domain-specific subsets:
    anime
    photography
    paintings
    3D renders

occlusion tests

style-transfer tests

viewpoint-change tests

single-person vs multi-person tests

NSFW disagreement matrices
```

Disagreement should be preserved as potentially useful information rather than automatically treated as error.

---

# Core Architectural Principle Going Forward

The expanded project should continue following:

```text
extract first

preserve native information

cache expensive inference

derive representations cheaply

normalize only where geometrically appropriate

keep semantically different outputs separate

compare empirically

measure disagreement

fuse later
```

The objective is increasingly not just to collect embedding models.

It is to construct a **collection of complementary coordinate systems** through which media can be interpreted and navigated.

For an image, these coordinate systems may independently describe:

```text
what it depicts
what it looks like
what concepts occur in it
what artistic style it uses
what emotional response it evokes
how aesthetically it is judged
how sexually explicit it is
which anatomy is exposed
whether it contains disturbing material
how depicted humans are posed
how multiple humans relate spatially
```

These different notions of similarity should remain independently controllable until there is strong empirical evidence for a particular fusion strategy.

---

# Reference Projects / Models Mentioned

```text
Art datasets directory
https://github.com/georgeblck/art-datasets

SCFlow / CAtFM
https://github.com/CompVis/SCFlow

fruit-SALAD
https://github.com/Style-Aligned-Artwork-Datasets/fruit-SALAD

APDDv2 / ArtCLIP
https://github.com/BestiVictory/APDDv2

ArtEmis
https://github.com/optas/artemis

Marqo NSFW detector
https://huggingface.co/Marqo/nsfw-image-detection-384

NudeNet
https://github.com/notAI-tech/NudeNet

LAION CLIP-based NSFW detector
https://github.com/LAION-AI/CLIP-based-NSFW-Detector

Stable Diffusion Safety Checker
https://huggingface.co/CompVis/stable-diffusion-safety-checker

DWPose
https://github.com/IDEA-Research/DWPose

COCO-WholeBody
https://github.com/jin-s13/COCO-WholeBody

ViTPose
https://github.com/ViTAE-Transformer/ViTPose

Pr-VIPE
https://research.google/pubs/view-invariant-probabilistic-embedding-for-human-pose/

4DHumans / HMR 2.0
https://github.com/shubham-goel/4D-Humans

TokenHMR
https://tokenhmr.is.tue.mpg.de/
```
