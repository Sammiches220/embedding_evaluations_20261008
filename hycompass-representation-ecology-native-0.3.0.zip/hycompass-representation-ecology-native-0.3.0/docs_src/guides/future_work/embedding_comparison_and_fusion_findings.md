# Comparing and Fusing Embedding Representations

## Goal

Given multiple embedding or representation spaces for the same set of items, compare the original spaces, construct several alternative fusions, and then evaluate those fused representations using the same framework.

Let each representation be:

\[
E_m \in \mathbb{R}^{N \times d_m}
\]

where:

- \(N\) is the number of items/images;
- \(m\) identifies a representation/model;
- \(d_m\) is that representation's dimensionality.

The representations do **not** need to have the same dimensionality unless a particular fusion operation requires it.

A useful overall methodology is:

1. Compare the original embedding spaces.
2. Measure both global and local agreement between them.
3. Construct multiple fusion candidates.
4. Treat every fusion as another representation.
5. Evaluate originals and fusions with the same metrics.
6. Perform ablations to determine the marginal contribution of each component.

---

## 1. Comparing Original Embedding Spaces

Raw coordinates generally should not be compared directly because different models have unrelated coordinate systems.

Instead, compare the **geometry induced by each representation**.

### Pairwise similarity matrices

For representation \(m\), compute:

\[
S_m(i,j) = \cos(E_m(i), E_m(j))
\]

The resulting \(N \times N\) matrix describes how the representation relates every item to every other item.

Two representations can then be compared even when their dimensionalities differ.

Useful comparison methods include:

- Pearson correlation between pairwise similarities;
- Spearman correlation between pairwise similarities/rankings;
- RSA (Representational Similarity Analysis);
- CKA (Centered Kernel Alignment);
- Mantel-style matrix correlation;
- nearest-neighbor overlap;
- rank-based neighborhood agreement.

CKA is especially useful because it is designed for comparing learned representations whose dimensionalities and coordinate systems may differ.

An illustrative comparison matrix might look like:

| | SigLIP | DreamSim | WD Tags | JoyTag |
|---|---:|---:|---:|---:|
| SigLIP | 1.00 | 0.51 | 0.43 | 0.46 |
| DreamSim | 0.51 | 1.00 | 0.21 | 0.24 |
| WD Tags | 0.43 | 0.21 | 1.00 | 0.81 |
| JoyTag | 0.46 | 0.24 | 0.81 | 1.00 |

Such a result would suggest that WD and JoyTag encode relatively redundant geometry, while DreamSim contributes a more independent notion of similarity.

---

## 2. Local Neighborhood Comparison

Global similarity correlation alone can hide important differences.

For each item \(x\), retrieve its \(k\) nearest neighbors under each representation:

\[
N_k^A(x), \quad N_k^B(x)
\]

Then compute neighborhood overlap:

\[
\text{overlap@k}(A,B,x)
=
\frac{|N_k^A(x)\cap N_k^B(x)|}{k}
\]

This can be aggregated over the dataset or examined per item/region.

This is particularly valuable for a navigable latent-space system because local neighborhoods are often what the human actually experiences during exploration.

For example, two representations might have moderate global agreement while strongly disagreeing around:

- illustrations;
- screenshots;
- photographs;
- particular characters;
- NSFW content;
- unusual poses;
- highly stylized images.

This disagreement can reveal complementary information that makes fusion worthwhile.

For projected representations, also consider metrics such as **trustworthiness** and **continuity** to measure how well a lower-dimensional projection preserves the original neighborhoods.

---

# Fusion Strategies

Rather than choosing one fusion immediately, construct several candidate representations and benchmark all of them.

Conceptually:

```text
A
B
C
│
├── fusion_1(A, B, C)
├── fusion_2(A, B, C)
├── fusion_3(A, B, C)
└── ...
```

Each fusion is simply another representation that can be passed through the same evaluation system.

---

## 3. Normalized Concatenation

A strong baseline is to normalize each embedding independently and concatenate them.

For example:

\[
\hat E_m = \frac{E_m}{\|E_m\|}
\]

followed by:

\[
F =
[
w_1\hat E_1
\;||\;
w_2\hat E_2
\;||\;
\cdots
\;||\;
w_M\hat E_M
]
\]

Advantages:

- extremely simple;
- preserves model-specific information;
- does not require equal source dimensionalities;
- allows explicit source weighting.

### Dimensional dominance

Care must be taken when representations have very different dimensionalities.

For example, blindly concatenating:

```text
SigLIP:     1152 dimensions
Model B:     128 dimensions
```

may implicitly give the larger block more influence.

Possible countermeasures include:

- independent L2 normalization;
- explicit block weights;
- PCA each source to a common dimension;
- whitening;
- variance normalization.

---

## 4. PCA / Whitened Concatenation

Each source can first be independently compressed or whitened:

```text
SigLIP    ── PCA/whiten → 256
DreamSim  ── PCA/whiten → 256
Tags      ── PCA/whiten → 256
                         │
                         ▼
                     concatenate
                         │
                         ▼
                       768-D
```

This can prevent one source from dominating because of:

- dimensionality;
- numerical scale;
- unusually high variance.

This is another strong baseline because it remains simple and interpretable while reducing some of the pathologies of raw concatenation.

---

## 5. Similarity / Distance-Level Fusion

Instead of combining vectors, combine the similarities produced by each representation:

\[
S_F(i,j)
=
\sum_m w_m S_m(i,j)
\]

For example:

\[
S_F =
0.35S_{\text{SigLIP}}
+
0.25S_{\text{DreamSim}}
+
0.20S_{\text{tags}}
+
0.10S_{\text{aesthetic}}
+
0.10S_{\text{NSFW}}
\]

This is especially attractive for a modular image-representation system.

### Advantages

- source embeddings can have completely different dimensionalities;
- representations can have very different internal structures;
- weights remain conceptually interpretable;
- components can easily be enabled/disabled;
- new representations can be added without retraining the others;
- similarity itself becomes the common interface.

The weights can have intuitive meanings such as:

```text
35% semantic similarity
25% perceptual similarity
20% tag/concept similarity
10% aesthetic similarity
10% NSFW/content similarity
```

This is particularly well suited to a system intended for interactive exploration where the desired definition of "similarity" may itself be adjustable.

---

## 6. Learned Fusion

If a target notion of similarity becomes available, the fusion can be learned:

\[
F =
f(
E_{\text{SigLIP}},
E_{\text{DreamSim}},
E_{\text{tags}},
...
)
\]

Possible models include:

- linear projections;
- MLPs;
- autoencoders;
- metric-learning networks;
- contrastive projections;
- attention-based fusion.

Training supervision could come from pairwise or triplet judgments such as:

```text
Image A is more similar to B than to C.
```

Triplet, contrastive, or ranking losses could then optimize the fused representation.

Learned fusion can be powerful, but it should probably come **after** simpler fusion experiments because learned models make it harder to understand exactly what each representation contributes.

---

# Shared vs. Representation-Specific Information

## 7. CCA and Common Latent Spaces

Another useful question is:

> What information is shared between two or more representations?

Canonical Correlation Analysis (CCA) and related techniques can identify correlated subspaces.

For two representations:

\[
E_A \rightarrow Z_A
\]

\[
E_B \rightarrow Z_B
\]

such that correlation between \(Z_A\) and \(Z_B\) is maximized.

For multiple representations, variants include:

- generalized CCA;
- multiset CCA;
- nonlinear/kernel CCA variants.

This allows a conceptual decomposition into:

```text
shared information
+
representation-specific residual information
```

For example:

```text
SigLIP
├── shared semantic structure ─────┐
└── SigLIP-specific residual       │
                                   ├── fused representation
DreamSim                           │
├── shared structure ──────────────┘
└── perceptual-specific residual
```

This may be particularly useful when multiple taggers or semantic models encode highly overlapping information.

---

# Evaluating the Fusions

A fusion should not simply be judged by whether its 2D UMAP visualization "looks good."

Instead, evaluate all representations systematically.

Suppose the candidate set is:

```text
Individual representations
--------------------------
SigLIP 2
DreamSim
WD-EVA02
JoyTag
RAM++ / Qwen
NSFW representation
Pose representation
...

Fusion representations
----------------------
normalized_concat
PCA_concat
whitened_concat
equal_similarity_mean
weighted_similarity
CCA
learned_projection
...
```

Each can be evaluated using several families of tests.

---

## 8. Representation-Level Metrics

Useful intrinsic comparisons include:

### Global geometry

- CKA;
- RSA;
- Pearson pairwise-similarity correlation;
- Spearman pairwise-similarity correlation.

### Local geometry

- kNN overlap;
- Jaccard@k;
- rank correlation of neighbors;
- neighborhood stability.

### Projection preservation

When projecting into 2D/3D:

- trustworthiness;
- continuity;
- neighborhood recall;
- distance distortion.

---

## 9. Task-Based Evaluation

There is no universally "best" representation without defining what information should be preserved.

Useful evaluation signals could include:

- human similarity judgments;
- known tags;
- character identity;
- artist/style identity;
- same-source retrieval;
- duplicate and near-duplicate retrieval;
- synthetic transformations of the same image;
- pose similarity;
- perceptual similarity;
- semantic similarity;
- NSFW/content similarity;
- retrieval diversity;
- cluster separability.

This produces a multi-objective benchmark rather than forcing all representation quality into one scalar.

For example:

| Representation | Semantic Retrieval | Perceptual Retrieval | Tag Agreement | Neighborhood Stability | Diversity | Redundancy |
|---|---:|---:|---:|---:|---:|---:|
| SigLIP | High | Medium | High | ... | ... | ... |
| DreamSim | Medium | High | Low | ... | ... | ... |
| WD | Medium | Low | Very High | ... | ... | ... |
| Normalized concat | ... | ... | ... | ... | ... | ... |
| Weighted similarity | ... | ... | ... | ... | ... | ... |

The goal is not necessarily to find a single universally dominant representation. Different fusions may be appropriate for different modes of exploration.

---

# Ablation Testing

Ablation is particularly important for determining whether adding another representation actually contributes useful information.

Given:

\[
F = A+B+C+D
\]

compare it against:

\[
B+C+D
\]

\[
A+C+D
\]

\[
A+B+D
\]

\[
A+B+C
\]

This answers:

> What marginal information does each representation contribute after the others are already present?

For example:

```text
SigLIP + DreamSim + WD
```

might perform almost identically to:

```text
SigLIP + DreamSim + WD + JoyTag
```

even if JoyTag is individually a very strong representation.

That would indicate that JoyTag contributes relatively little **conditional information** because WD already captures most of the same structure.

Conversely, a weaker standalone model may still be valuable if it contributes information absent from every other representation.

---

# Information-Theoretic Interpretation

The overall system can be thought of as several observers of the same underlying object:

\[
X
\rightarrow
\begin{cases}
Z_{\text{semantic}}\\
Z_{\text{perceptual}}\\
Z_{\text{tags}}\\
Z_{\text{aesthetic}}\\
Z_{\text{NSFW}}\\
Z_{\text{pose}}\\
\vdots
\end{cases}
\]

Fusion attempts to construct a representation \(F\) that retains useful information from the union of these observations without unnecessarily duplicating information.

Conceptually:

\[
\text{fusion quality}
\approx
\text{useful coverage}
-
\text{redundancy}
-
\text{noise}
\]

This framing emphasizes that adding more representations is not automatically beneficial.

A representation is most useful when it contributes a meaningful degree of freedom that is not already captured elsewhere.

---

# Proposed Experimental Architecture

A natural architecture for the project is:

```text
                           ┌─ SigLIP
                           ├─ DreamSim
images ── representations ─┼─ WD
                           ├─ JoyTag
                           ├─ RAM++ / Qwen
                           ├─ NSFW
                           ├─ Pose
                           └─ ...

                                │
                                ▼

                     Representation Analyzer
                    /          |           \
                global        local       task-based
                CKA           kNN         retrieval
                RSA           overlap     clustering
                correlation   rankings    known labels

                                │
                                ▼

                          Fusion Engine
                 ┌──────────────┼──────────────┐
                 │              │              │
          concatenation    similarity      learned/shared
          normalized       equal-weight    CCA
          PCA              weighted        metric learning
          whitened                         neural fusion

                 └──────────────┼──────────────┘
                                │
                                ▼

                     Representation Analyzer
                      (same evaluation suite)

                                │
                                ▼

                       Ablation Analysis

                                │
                                ▼

                    Fusion Comparison Report
```

A major architectural benefit is that the **Representation Analyzer does not need to know whether its input came from a single model or a fusion**.

Every representation implements the same conceptual interface.

---

# Recommended Initial Benchmark

Before attempting sophisticated learned fusion, establish four simple baselines:

1. **Normalized concatenation**
2. **PCA/whitened concatenation**
3. **Equal-weight similarity fusion**
4. **Weighted similarity fusion**

Evaluate these alongside every individual representation using:

- CKA / RSA;
- pairwise similarity correlation;
- kNN overlap;
- retrieval tests;
- projection trustworthiness/continuity where relevant;
- task-specific benchmarks;
- ablation testing.

Only after establishing these baselines should methods such as CCA, metric learning, or neural fusion be considered.

---

# Central Principle

The most useful question is not simply:

> Which fusion produces the best embedding?

Instead ask:

> Which notions of similarity survive the fusion, which disappear, which are redundant, and what genuinely new geometry does the fusion create?

This turns embedding fusion from an arbitrary vector-combination problem into a systematic study of how different representations encode complementary notions of meaning.
