# SwinV2 / Danbooru Specialized Preparation

`prepare_swinv2_danbooru.py` is a specialized companion to the large-file
`prepare.py` used by Latent Observer.

It is intended for WD/SmilingWolf-style SwinV2 embeddings of Danbooru posts,
especially very large `[N, 1024]` float arrays.

## Why this variant exists

The generic large-file preparer projects directly with 2-D Incremental PCA and
clusters the original high-dimensional vectors. That is scalable, but it is not
ideal for a multi-label image embedding space where cosine-like local geometry
is more important than raw vector magnitude.

This variant instead performs:

```text
embeddings.npy [N,D]
    -> row-wise L2 normalization
    -> out-of-core IncrementalPCA to 64D
    -> row-wise L2 normalization again
    -> MiniBatchKMeans in normalized 64D (optional/coarse regions)
    -> random sample from normalized 64D
    -> fit UMAP on the sample
    -> transform all N rows through UMAP in bounded batches
    -> positions.npy [N,2]
    -> ordinary Latent Observer density/index/familiarity/landmarks
```

KMeans labels should be interpreted as coarse Voronoi regions, not as proof
that the embedding population has that many natural disconnected clusters.

## Files required

Place these beside one another:

```text
prepare.py
prepare_swinv2_danbooru.py
```

Install the extra nonlinear-projection dependency:

```bash
pip install umap-learn
```

## Recommended starting command for a ~30 GB source

```bash
python prepare_swinv2_danbooru.py \
  --input-dir /path/to/input \
  --output /path/to/prepared \
  --memory-budget-mib 4096
```

Defaults particularly relevant to this workload:

```text
intermediate dimensions:       64
UMAP fit sample:               300,000 rows
UMAP neighbors:                30
UMAP min_dist:                 0.08
UMAP metric:                   cosine
UMAP transform batch:          25,000 rows
working-memory target:         4096 MiB
```

The memory budget is a batch-sizing target, not a hard process-RSS limit.

## Intermediate representation

The script keeps:

```text
intermediate_64d.npy
```

by default. For 8,000,000 rows this is approximately 1.91 GiB as float32.
Keeping it is strongly recommended because future UMAP experiments and
clustering experiments can operate on this much smaller representation instead
of rereading/reprojecting the original ~30 GB file.

Delete it automatically at the end with:

```bash
--discard-intermediate
```

## UMAP reproducibility vs parallelism

The default:

```text
--umap-random-state -1
--umap-jobs -1
```

allows nondeterministic parallel UMAP fitting. If repeatability matters more,
set a concrete seed, for example:

```bash
--umap-random-state 7
```

Some UMAP versions restrict parallelism when a deterministic random state is
used.

## Useful alternatives

Use a larger UMAP training sample when RAM permits:

```bash
--umap-sample-size 500000
```

Make local neighborhoods more visually separated:

```bash
--umap-neighbors 20 --umap-min-dist 0.04
```

Favor somewhat broader/global continuity:

```bash
--umap-neighbors 50 --umap-min-dist 0.10
```

If UMAP transform memory becomes uncomfortable:

```bash
--umap-transform-batch-rows 10000
```

Save a direct 2-D IPCA reference for comparison with the nonlinear map:

```bash
--save-pca2-reference
```

Save the fitted UMAP object for later transformations (potentially large):

```bash
--save-umap-model
```

## Important outputs

In addition to normal Latent Observer files, this preparer can produce:

```text
intermediate_64d.npy
intermediate_pca_model.npz
umap_fit_indices.npy
umap_fit_positions.npy
positions.npy
cluster.npy
cluster_stats.json
clustering_model.npz
prepare.log
```

`metadata.json` records the L2 normalization, IPCA dimensionality, retained
variance, UMAP settings/sample size, clustering space, batching choices, and
source scan policy.
