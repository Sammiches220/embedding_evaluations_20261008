## CLI registration

A completely external pipeline can bootstrap an empty workspace without running `prepare.py`:

```bash
python scripts/workspace_tool.py --workspace data/workspace init
```

Then register the completed Domain and derived assets. All commands validate compatibility and register the data directly:

```bash
python scripts/workspace_tool.py --workspace data/workspace add-domain \
  --id danbooru-swinv2 \
  --embeddings /analysis/embeddings.npy \
  --item-ids /analysis/item_ids.npy

python scripts/workspace_tool.py --workspace data/workspace add-projection \
  --id my-external-umap \
  --domain danbooru-swinv2 \
  --positions /analysis/umap_positions.npy \
  --method external-umap

python scripts/workspace_tool.py --workspace data/workspace add-clustering \
  --id my-hdbscan \
  --domain danbooru-swinv2 \
  --labels /analysis/hdbscan_labels.npy \
  --method hdbscan

python scripts/workspace_tool.py --workspace data/workspace add-density \
  --id custom-kde \
  --projection my-external-umap \
  --field /analysis/kde.npy \
  --method custom-kde

python scripts/workspace_tool.py --workspace data/workspace add-segmentation \
  --id custom-regions \
  --projection my-external-umap \
  --labels /analysis/regions.npy \
  --density custom-kde \
  --method external-segmentation

python scripts/workspace_tool.py --workspace data/workspace add-exploration \
  --id custom-coverage \
  --projection my-external-umap \
  --selection favorites \
  --frames /analysis/coverage.npy \
  --method custom-coverage
```

Temporal exploration additionally declares its Timeline:

```bash
python scripts/workspace_tool.py --workspace data/workspace add-exploration \
  --id custom-coverage-history \
  --projection my-external-umap \
  --selection favorites \
  --timeline archive-time \
  --frames /analysis/coverage_frames.npy
```

The timeline start/end are inferred from the Timeline unless explicitly supplied.

## Add or replace assets later

Use `scripts/workspace_tool.py` instead of rebuilding unrelated assets.

### Selection

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace add-selection \
  --id safe \
  --domain domain \
  --mask safe.npy
```

### Timeline

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace add-timeline \
  --id archive-time \
  --domain domain \
  --timestamps archive_time.npy
```

Canonical times remain exact UNIX seconds; no persistent normalized `first_seen.npy` is required.

### Projection

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace build-projection \
  --id safe-local \
  --domain domain \
  --selection safe \
  --method ipca
```

A subset-local projection remains `[N,2]` and uses `NaN` outside the selected scope so Domain row identity is preserved.

The bundled modular example can be built with:

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace build-projection \
  --id random-demo \
  --domain domain \
  --method random \
  --random-projection-seed 123
```

A real t-SNE implementation is also included for smaller/subset-local exploratory projections:

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace build-projection \
  --id local-tsne \
  --domain domain \
  --selection safe \
  --method tsne \
  --tsne-perplexity 30 \
  --tsne-max-iter 750
```

Standard t-SNE is in-memory; prefer IPCA for very large complete domains and use t-SNE where its local nonlinear view is computationally appropriate.

### Clustering

Supply a domain-aligned categorical array:

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace add-clustering \
  --id my-clusters \
  --domain domain \
  --labels clusters.npy
```

The v0.5.4 Point Predicate UI discovers actual IDs from every compatible clustering asset and can combine IDs across several clustering assets.

Or compute a clustering through a built-in implementation:

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace build-clustering \
  --id birch-demo \
  --domain domain \
  --method birch \
  --clusters 32
```

`minibatch-kmeans` is also available.

### Density

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace build-density \
  --id safe-density \
  --projection global \
  --selection safe \
  --method adaptive-gaussian
```

Density remains a scalar field asset; per-View opacity/contours/colors are display style, not recomputation parameters.

### Segmentation

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace build-segmentation \
  --id safe-watershed \
  --density safe-density \
  --method watershed
```

Different algorithms share the same integer `labels.npy [H,W]` + region stats visualization/query contract.

### Exploration

Static Selection-only field:

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace build-exploration \
  --id safe-distance \
  --projection global \
  --selection safe \
  --method distance
```

Temporal field over the same Selection:

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace build-exploration \
  --id safe-distance-history \
  --projection global \
  --selection safe \
  --timeline archive-time \
  --method distance
```

## Multiple Domains

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace add-domain \
  --id siglip-v2 \
  --version 1 \
  --embeddings /data/siglip/embeddings.npy \
  --item-ids /data/siglip/item_ids.npy
```

Views over the same Domain/Projection share file-backed and same-process GPU resources. A changed canonical row space should be registered as a new Domain/version rather than silently replacing an incompatible version.

## Themes

Three examples ship in `themes/` and are automatically registered during normal initial preparation. Register another theme manually with:

```bash
python scripts/workspace_tool.py --workspace /data/my_workspace add-theme \
  --id my-theme \
  --config /path/to/my-theme.json
```


## Preparing representations

### Generate the bundled example

```bash
python generate_example_inputs.py \
  --output data/example_input \
  --items 100000 \
  --dimensions 64
```

The generator writes:

```text
embeddings.npy
item_ids.npy
timestamps.npy
selection_a.npy
selection_b.npy
selection_c.npy
```

The three selections deliberately overlap and have no temporal semantics.

### Rich modular demonstration

The basic generator above explains the source contract. For a concrete demonstration of extensive modularity, use the dedicated pair:

```bash
python generate_modular_example_inputs.py \
  --output data/modular_example_inputs

python prepare_modular_example.py \
  --input-root data/modular_example_inputs \
  --output data/modular_example_workspace \
  --force

python main.py --workspace data/modular_example_workspace
```

By default this prepares:

- **2 Domains** (`alpha`, `beta`) with independent embeddings/item IDs/timelines/selections;
- **5 Projections** across Incremental PCA, real t-SNE, and Gaussian random projection;
- **5 Clusterings** across supplied labels, MiniBatchKMeans, and BIRCH;
- **6 Density assets** using Gaussian, adaptive-Gaussian, and histogram producers;
- **5 Segmentations** using watershed and connected-components producers;
- static and temporal Exploration fields using Gaussian, box-blur, and distance methods;
- 3 example Themes;
- hierarchical Saved Views demonstrating multiple Density/Segmentation layers in one View.

The script is executable documentation: inspect `prepare_modular_example.py` to see the exact `scripts/workspace_tool.py` commands used for every asset. t-SNE is intentionally demonstrated on modest generated populations because conventional t-SNE is not intended as the multi-million-item out-of-core default.

### Initial preparation

```bash
python prepare.py \
  --input-dir data/example_input \
  --timestamps data/example_input/timestamps.npy \
  --selection A=data/example_input/selection_a.npy \
  --selection B=data/example_input/selection_b.npy \
  --selection C=data/example_input/selection_c.npy \
  --output data/example_workspace
```

The default high-dimensional projection is incremental PCA. Two-dimensional embeddings pass through unchanged.

Initial method choices:

```text
--projection auto|passthrough|ipca|random|tsne|umap
--density-method gaussian|adaptive-gaussian|histogram
--segmentation-method watershed|connected-components
--exploration-method box-blur|gaussian|distance
```

The bundled `random` Projection is a compact sample modular implementation. `prepare.py` also registers the bundled example themes unless `--no-example-themes` is supplied.

Example fast preparation using it:

```bash
python prepare.py \
  --input-dir data/example_input \
  --timestamps data/example_input/timestamps.npy \
  --output data/example_random_workspace \
  --projection random \
  --random-projection-seed 7
```