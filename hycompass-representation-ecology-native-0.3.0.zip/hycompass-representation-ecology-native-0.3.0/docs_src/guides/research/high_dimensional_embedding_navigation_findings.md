# High-Dimensional Embedding Visualization and Human Navigation

## Summary

Reducing high-dimensional embeddings directly to 2D with UMAP is useful for visualization, but it is inherently lossy. A 2D projection should be treated as a **map of the embedding space**, not as the embedding space itself.

For a system intended for human exploration of latent or semantic structure, a stronger architecture is to keep the original high-dimensional embedding or its nearest-neighbor graph as the **analytical source of truth**, while exposing one or more human-facing projections and interactive controls for navigating otherwise invisible dimensions.

---

## 1. What 2D UMAP Retains

UMAP primarily attempts to preserve **local neighborhood structure**.

If several points are close neighbors in the original embedding space, UMAP tries to keep them nearby in the projected space. However:

- Nearby 2D points are often meaningfully related.
- Large 2D distances should not be interpreted literally.
- Relative placement between clusters can be distorted.
- Cluster size, shape, and density can be misleading.
- Different seeds and hyperparameters may produce visibly different layouts.
- Compressing hundreds or thousands of dimensions into two necessarily destroys many relationships.

This means that a 2D projection should not become the canonical latent space.

A better conceptual model is:

```text
Original embedding space
        │
        ├── source of truth
        ├── nearest-neighbor graph
        ├── clustering / density / landmarks
        ├── observer state / exploredness
        └── projection for human display
```

rather than:

```text
embedding
   ↓
2D UMAP
   ↓
"latent space"
```

---

## 2. Mature Alternatives to UMAP

Different dimensionality-reduction methods preserve different aspects of the original structure.

| Method | Main strength |
|---|---|
| PCA | Linear/global structure and a useful sanity-check baseline |
| t-SNE | Very strong local-neighborhood visualization |
| UMAP | Strong general-purpose local visualization |
| TriMap | Relative/global organization |
| PaCMAP | Explicit local/global compromise |
| PHATE | Continuous trajectories/manifold structure |
| MDS | Approximate pairwise-distance preservation |

### PaCMAP

PaCMAP is especially attractive for map-like latent-space visualization because it explicitly balances:

- nearby pairs,
- intermediate-distance pairs,
- far-away pairs.

This can preserve more global structure than methods focused almost entirely on local neighborhoods.

### TriMap

TriMap preserves relative relationships such as:

> A is closer to B than A is to C.

This can be useful for semantic geography, where relative organization may matter more than exact metric distances.

### PCA as an Intermediate Representation

Instead of reducing directly from a very large embedding to 2D:

```text
768D
 ↓
2D
```

a practical architecture can be:

```text
768D
 ↓
PCA to ~50D
 ↓
UMAP / PaCMAP / TriMap
 ↓
2D or 3D
```

The intermediate representation can remain useful for analysis while the 2D or 3D result is used only for rendering.

---

## 3. Separate Semantic Geometry from Display Geometry

A strong architecture separates two kinds of geometry.

### Semantic Geometry

Defined by the original embeddings or a derived nearest-neighbor graph.

Examples:

```text
cosine(A, B) = 0.93
cosine(A, C) = 0.81
cosine(A, D) = 0.22
```

This should be treated as authoritative.

### Display Geometry

Coordinates needed by the renderer:

```text
A = (0.32, 0.71)
B = (0.35, 0.74)
C = (0.28, 0.65)
D = (-0.72, 0.12)
```

These coordinates should be treated as cartographic coordinates, not ground truth.

A possible architecture is:

```text
embeddings
   ↓
FAISS / HNSW / other ANN graph
   ↓
high-dimensional relationships
   ├── density
   ├── clustering
   ├── representatives
   ├── observer coverage
   ├── unexploredness
   └── frontier analysis

embeddings
   ↓
projection engine
   ├── UMAP
   ├── PaCMAP
   ├── TriMap
   └── PCA
   ↓
2D / 3D renderer
```

---

## 4. Expose Projection Distortion to the Human

The visualization can show where a projection is misleading.

For a selected point, query its nearest neighbors in the original embedding space and draw edges to them in the projected map.

If a true semantic neighbor appears far away in the projection, the resulting long edge reveals that the projection has torn apart a real relationship.

Similarly, the system can detect **false neighbors**: points close in display space but not close in the original embedding.

A simple local fidelity measure is:

\[
Q_i = \frac{|N_k^H(i) \cap N_k^L(i)|}{k}
\]

where:

- \(N_k^H(i)\) is the set of high-dimensional nearest neighbors,
- \(N_k^L(i)\) is the projected-space nearest-neighbor set.

This can be rendered as a projection-confidence or fidelity heatmap.

Formal metrics such as **trustworthiness** and **continuity** can also be used.

---

## 5. Multiple Projections as Different Lenses

There may not be one "correct" projection.

A better interface could let the user switch between:

```text
Projection
────────────────
PaCMAP
UMAP
TriMap
PCA
PHATE
3D PaCMAP
```

The underlying observer state and semantic relationships remain unchanged.

This allows each projection to act as a different lens on the same latent topology.

A future extension could measure **projection consensus**, identifying relationships that remain stable across multiple projection methods.

---

# Human Exploration of Invisible Dimensions

## 6. The 4D-Game Analogy

A high-dimensional embedding can be explored in a way similar to 4D games.

In a four-dimensional space:

\[
(x, y, z, w)
\]

a human can view \(x,y,z\) while controlling \(w\) with a slider.

The same concept can be generalized to embeddings:

\[
\mathbf{x} \in \mathbb{R}^{768}
\]

The problem is that hundreds of raw sliders are not meaningful. Instead, the system should expose a smaller number of interpretable or useful **directions through the embedding space**.

---

## 7. Expose Directions, Not Raw Neural Dimensions

Choose basis directions:

\[
v_1, v_2, v_3
\]

and display:

\[
X = x \cdot v_1
\]

\[
Y = x \cdot v_2
\]

\[
Z = x \cdot v_3
\]

Then introduce another direction \(v_4\) as an invisible dimension.

The human can control position along \(v_4\) using a slider.

This is analogous to selecting a cross-section of a 4D world.

---

## 8. Rotate Visible Axes into Hidden Dimensions

Instead of only slicing along hidden dimensions, the user can rotate the visible coordinate system into them.

For example:

\[
v'_1 = \cos(\theta)v_1 + \sin(\theta)v_4
\]

and then:

\[
X' = x \cdot v'_1
\]

At:

\[
\theta = 0^\circ
\]

the display uses \(v_1\).

At:

\[
\theta = 90^\circ
\]

that visible dimension has fully rotated into \(v_4\).

This provides a mathematically literal form of high-dimensional navigation.

---

## 9. Useful Sources of Latent Axes

Raw embedding dimensions are usually not individually interpretable. Better axes can be derived.

### PCA Axes

The simplest prototype is to use principal components:

```text
PC1
PC2
PC3
PC4
PC5
...
```

The first two or three can be visible, while later PCs can be explored using sliders or axis rotation.

### Semantic Directions

A semantic axis can be built from two populations.

For example:

```text
photographic images
versus
illustrated images
```

Let their centroids be:

\[
\mu_{photo}
\]

and:

\[
\mu_{illustration}
\]

Then define:

\[
v_{style}
=
\frac{
\mu_{photo}-\mu_{illustration}
}{
\|\mu_{photo}-\mu_{illustration}\|
}
\]

The resulting axis can be presented as:

```text
photographic ◄────────────► illustration
```

Similar directions can represent:

- simple ↔ complex,
- SFW ↔ NSFW,
- familiar ↔ unfamiliar,
- low motion ↔ high motion,
- old ↔ new,
- one visual style ↔ another.

These axes can be derived from tags, classifiers, clusters, metadata, or labeled selections.

---

## 10. Human-Defined Latent Axes

The user can create a custom axis directly from selected populations.

Workflow:

1. Select population A.
2. Mark it as one pole.
3. Select population B.
4. Mark it as the opposite pole.
5. Compute:

\[
v =
\operatorname{normalize}(\mu_B - \mu_A)
\]

The interface can then expose:

```text
Selected A ◄──────────────► Selected B
```

The human does not even need to name the semantic property.

They can simply express:

> "Whatever distinguishes these things from those things, let me navigate along it."

This is particularly useful for exploratory analysis.

---

## 11. Observer-Derived Directions

The observer itself can define latent axes.

For example, compare:

```text
observed
versus
unobserved
```

A simple direction is:

\[
v_{observer}
=
\mu_{observed}
-
\mu_{unobserved}
\]

A stronger method would train a simple linear classifier separating the two populations and use its normal vector.

This produces a latent direction corresponding to:

> the feature-space direction that currently best separates familiar from unfamiliar regions.

As observation changes, this axis can change dynamically.

This can function as an **observer frontier**.

---

# 2D + Latent Depth

## 12. Latent Slicing / Tomography

A conventional 2D map can remain while an invisible dimension is controlled by a slider.

Suppose PC1 and PC2 are shown while PC3 is controlled interactively.

Instead of removing everything outside an exact slice, apply a Gaussian visibility window:

\[
\alpha_i =
\exp\left(
-\frac{(p_{i3}-t)^2}{2\sigma^2}
\right)
\]

where:

- \(t\) is the current position along the hidden dimension,
- \(\sigma\) controls slice thickness,
- \(lpha_i\) controls opacity.

The interface might expose:

```text
Latent position
──────────●──────────

Slice thickness
──────●──────────────
```

A narrow slice shows only a thin region of the hidden dimension.

A wide slice shows a larger neighborhood.

This behaves like **tomography of the embedding space**.

---

# Combined Navigation Model

## 13. Projection + Slicing + Rotation

A powerful interface can distinguish three navigation operations.

### Projection

> How do I flatten the space enough to see an overview?

Methods:

- UMAP
- PaCMAP
- TriMap
- PCA
- PHATE

### Slicing

> What exists around this position along an invisible dimension?

This is the direct analogue of the 4D-game slider.

### Rotation

> What happens if I rotate a visible axis toward an invisible direction?

This allows the viewport itself to move through the high-dimensional basis.

Together:

\[
\boxed{
\text{Projection}
+
\text{Slicing}
+
\text{Rotation}
}
\]

A fourth operation can be added:

### Semantic Axis Construction

> Which direction through the embedding should become navigable?

Sources can include:

- user-selected poles,
- tags,
- clusters,
- metadata,
- classifiers,
- observer state,
- PCA or other decomposition methods.

---

## 14. Example Latent-Navigation Interface

```text
                  LATENT NAVIGATOR

        ┌─────────────────────────┐
        │                         │
        │       2D / 3D          │
        │      OpenGL map        │
        │                         │
        └─────────────────────────┘

Visible axes
X   PC1
Y   PC2
Z   PC3

──────────────────────────────────

Hidden axis
PC4

-3σ ─────────●──────────── +3σ

Slice width
narrow ─────────●───────── wide

──────────────────────────────────

Rotate into visible space

PC1 ◄────────●────────► PC4
             37°

──────────────────────────────────

Semantic axes

photographic ◄────●────► illustration
simple       ◄──●──────► complex
familiar     ◄──────●──► unfamiliar

[ + Create axis from selections ]
```

---

# Recommended Architecture

A strong overall architecture is:

```text
                   EMBEDDINGS
                       │
        ┌──────────────┴──────────────┐
        │                             │
        ↓                             ↓
High-dimensional graph          Axis system
FAISS / HNSW                    PCA / semantic /
        │                       user-defined /
        │                       observer-derived
        │                             │
        ↓                             ↓
Semantic analysis            Projection / slicing /
        │                    rotation controls
        │                             │
        ├── density                   ↓
        ├── clustering           2D / 3D viewport
        ├── representatives
        ├── exploredness
        ├── frontier
        └── semantic distance
```

The high-dimensional representation remains the territory.

The visual projection is only the map.

The human can then explore not just one flattened map, but **different cross-sections, orientations, and semantic directions through the latent space**.

---

## Core Conclusion

The fundamental limitation is not simply that humans can only directly see two or three spatial dimensions.

The greater limitation is that hundreds of anonymous neural dimensions have no immediate cognitive meaning.

A useful latent-space interface should therefore transform those anonymous degrees of freedom into **human-manipulable directions**.

Instead of asking:

> "How do we perfectly compress 768 dimensions into 2D?"

the system can ask:

> "Which parts of the 768-dimensional structure should the human look through right now?"

That reframes dimensionality reduction from a one-time compression problem into an interactive navigation problem.
