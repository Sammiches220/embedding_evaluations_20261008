# Preparing Very Large Point and Embedding Collections

## Purpose

Ordinary data import establishes the domain, row alignment, identifiers, projections, and related assets. Very large data does not fundamentally change those contracts.

What changes is **how the preparation work is executed** when the source population or high-dimensional representation is too large to materialize comfortably in memory.

The guiding question is:

> **How should the normal preparation workflow change when the source data is larger than the available working memory or expensive enough that repeated full-population operations become impractical?**

The central idea is to treat the dataset as a **streamed population** and to distinguish expensive high-dimensional stages from much cheaper derived stages.

```text
large row-aligned source
        ↓
bounded sequential batches
        ↓
fit or derive compact models / representations
        ↓
incrementally materialize row-aligned outputs
        ↓
perform later low-dimensional work in larger chunks
```

---

## 1. Keep the source out of ordinary RAM

Large source arrays should remain in a form that supports bounded row-wise access rather than requiring a complete in-memory copy.

The preparation process then repeatedly works on slices:

```text
source rows
  0 ................. N
      ↓ batch
      process
      ↓ batch
      process
      ↓
```

The important invariant is not that the process uses *little* memory, but that working memory is governed primarily by **batch size and model state rather than total source size**.

---

## 2. Budget batches by bytes, not just rows

A row count has no stable memory meaning when dimensionality changes.

For a numeric matrix:

```text
raw batch bytes ≈ rows × dimensions × bytes_per_value
```

High-dimensional model fitting often requires additional temporary arrays, so the useful batch size should be derived from a memory target with room for model workspaces and library overhead.

Different stages should be allowed to use different batch sizes:

- high-dimensional fitting may require relatively small batches;
- high-dimensional transformation may allow somewhat larger batches;
- operations over 2-D positions or 1-D metadata can often use very large chunks.

A single global "chunk size" is therefore usually the wrong abstraction.

---

## 3. Organize expensive work into sequential passes

For large sources, a complete scan is itself a meaningful cost.

Preparation should therefore minimize unnecessary passes and combine compatible work when possible.

For example:

```text
PASS A
    fit incremental projection
    fit incremental clustering

PASS B
    transform all rows
    assign cluster labels
    write outputs
```

The exact operations may differ, but the architectural principle is stable:

> **Treat full-population I/O as a resource and design the pipeline around a small number of deliberate scans.**

This matters especially when the source is tens of gigabytes or stored on slower media.

---

## 4. Choose scalable model strategies

Some algorithms naturally support bounded-memory operation; others fundamentally expect the full population or large global structures.

Three broad strategies are useful.

### Incremental / mini-batch methods

When an algorithm has a meaningful incremental form, the model can be updated from successive batches.

Typical examples include linear dimensionality reduction and centroid-based clustering.

This is the cleanest large-data path because every source row can contribute to fitting while memory remains bounded.

### Reduced intermediate representation

A high-dimensional source can first be streamed into a compact intermediate representation.

Conceptually:

```text
high-dimensional source
        ↓
streamed reduction
        ↓
compact intermediate [N,d]
        ↓
later projection / clustering / experimentation
```

The intermediate representation can be valuable even when the final visualization is 2-D. It decouples later experiments from repeated scans of the original expensive feature space and can make nonlinear methods substantially more practical.

### Sample-fit, full-population transform

For algorithms whose fitting stage is expensive or not naturally out-of-core, a representative sample can be used to fit the model, followed by a bounded transform of the complete population.

```text
compact population
        ↓
representative sample
        ↓
fit nonlinear model
        ↓
transform all rows in batches
```

This does **not** make the original fitting algorithm fully out-of-core. It changes the approximation: global structure is learned from a sample, while every row still receives an output coordinate.

The sample should therefore be large and representative enough for the geometry the projection is expected to preserve.

---

## 5. Materialize outputs incrementally

Large row-aligned outputs should be written as they are produced rather than accumulated in Python memory.

Examples include:

- projected positions;
- intermediate representations;
- cluster labels;
- copied row metadata;
- generated temporal vectors.

A useful write pattern is:

```text
create temporary array on disk
        ↓
fill row ranges incrementally
        ↓
flush / validate
        ↓
atomically promote to final output
```

This reduces peak memory and makes it less likely that an interrupted stage leaves a normal output path pointing to an incomplete artifact.

---

## 6. Make the expensive representation reusable

If a costly transformation produces a substantially smaller representation, retaining it can change the economics of later work.

Instead of repeatedly performing:

```text
large embeddings
    → expensive reduction
    → experiment A

large embeddings
    → expensive reduction
    → experiment B
```

the workflow can become:

```text
large embeddings
    → compact reusable representation
        ├→ projection experiment A
        ├→ projection experiment B
        ├→ clustering
        └→ other analysis
```

Whether the intermediate should be retained depends on disk cost, reproducibility needs, and how likely future experiments are.

---

## 7. Exploit the dimensionality drop

Once the population has been reduced to positions or other compact row-aligned arrays, many downstream operations become much cheaper.

Examples include:

- raster accumulation;
- density and other spatial fields;
- segmentation;
- population statistics;
- metadata copies;
- simple spatial indexing.

These operations can usually use much larger chunks than high-dimensional model fitting.

Raster-derived assets are particularly favorable because their working memory is often governed by the **raster size**, not by the size of the original embedding matrix.

---

## 8. Recognize the remaining non-streaming costs

A bounded high-dimensional path does not imply that every later operation has constant memory.

Potential exceptions include:

- global sorting or indexing that requires an `O(N)` index array;
- model fitting methods that construct large neighborhood graphs;
- algorithms whose transform step itself requires global state;
- temporary library workspaces;
- operating-system page cache and numerical-library buffers.

Large-data preparation should therefore identify each stage by its scaling behavior:

```text
O(batch × D)       high-dimensional streamed work
O(N × d) on disk   compact row-aligned representation
O(N) memory        some global indexes / sorts
O(H × W)           static raster fields
O(T × H × W)       temporal raster fields
```

The goal is not to pretend every stage is perfectly out-of-core, but to keep the expensive scaling explicit.

---

## 9. Separate memory safety from computational cost

An operation can be memory-safe and still be prohibitively expensive.

For example, mini-batch clustering avoids storing all high-dimensional rows in RAM, but its total work still grows with:

- number of rows;
- feature dimensions;
- number of clusters;
- number of passes.

Likewise, transforming millions of rows through a nonlinear projection may be bounded in memory while still consuming substantial CPU time.

When a derived asset is optional, deferring it can be a legitimate large-data strategy.

---

## 10. Preserve row alignment throughout streaming

Large-data workflows increase the importance of a simple invariant:

> **Every row-aligned asset must continue to refer to the same canonical item row.**

Chunking, sampling, projection, and asynchronous output should never silently reorder the domain unless the resulting ordering is explicitly stored as a separate index.

Stable item identifiers remain the bridge between the prepared row space and external systems.

---

## 11. Design for long-running stages

Large preparation jobs benefit from being observable and restartable.

Useful practices include:

- explicit stage boundaries;
- periodic progress and throughput reporting;
- elapsed time and memory reporting;
- saved model state when it is useful for later transformation;
- temporary output paths followed by atomic promotion;
- avoiding unnecessary copying of huge immutable source files;
- enough free disk space for both final and temporary outputs.

The larger the source, the more valuable it becomes to know **which stage is expensive, which stages are complete, and which outputs can be reused**.

---

## 12. Choose the workflow from the bottleneck

A useful decision guide is:

```text
Source fits comfortably in memory
    → ordinary preparation is simplest

Source does not fit, but the desired model is incremental
    → stream all rows through bounded batches

Source is huge and nonlinear fitting is the bottleneck
    → reduce first, fit nonlinear geometry on a representative sample,
      then transform the full population in batches

Repeated experiments are expected
    → retain a compact reusable intermediate representation

Only downstream spatial assets are changing
    → reuse existing positions/intermediates;
      do not rescan the original high-dimensional source

A global O(N) step becomes the new bottleneck
    → treat that step separately rather than increasing the
      high-dimensional memory budget
```

The essential principle is:

> **Scale the workflow by changing execution strategy, not by changing the logical meaning of the data assets.**

Large-data preparation should preserve the same row space and asset semantics as ordinary preparation while replacing whole-population materialization with streaming, compact intermediates, sampling where appropriate, and incremental output.
