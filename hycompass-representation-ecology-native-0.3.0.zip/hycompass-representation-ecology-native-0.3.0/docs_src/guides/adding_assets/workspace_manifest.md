# Workspace and assets

The workspace manifest is the persistent description of domains, projections, selections, timelines, and derived assets.

The important distinction is between **asset metadata** and the underlying array/file contract. Python types describe the former; prose documentation can describe details such as NumPy shape, dtype, alignment, and missing-value conventions.

## Views

::: model.workspace.ViewSpec
    options:
      show_root_heading: true
      heading_level: 3
      members: false

## Registration

Registration functions validate an external asset and add its specification to the workspace manifest.

### Domain registration

::: model.workspace.register_domain
    options:
      show_root_heading: true
      heading_level: 4

### Projection registration

::: model.workspace.register_projection
    options:
      show_root_heading: true
      heading_level: 4

### Selection registration

::: model.workspace.register_selection
    options:
      show_root_heading: true
      heading_level: 4
