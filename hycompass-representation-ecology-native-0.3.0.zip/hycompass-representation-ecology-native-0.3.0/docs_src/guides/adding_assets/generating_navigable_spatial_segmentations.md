# Generating Navigable Spatial Segmentations

## Purpose

A positional segmentation divides a visible 2-D point distribution into **disjoint, contiguous regions that are useful for spatial navigation**.

The guiding question is:

> **How can the visible point distribution be divided into disjoint, contiguous, easily navigable regions?**

The segmentation is derived from the **geometry of the projected point distribution itself**. It is not intended to recover semantic classes, reproduce clusters from the original feature space, or assign meaning to regions.

Conceptually:

```text
projected point positions
        ↓
spatial raster representation
        ↓
local structural fields
        ↓
boundary / interior evidence
        ↓
structural partition
        ↓
connectivity and refinement
        ↓
disjoint navigable regions
```

The resulting regions should be interpreted as pieces of map geography rather than categories of items.

---

## 1. Establish the spatial analysis domain

Segmentation begins with an existing 2-D projection and a raster coordinate system aligned with that projection.

The first task is to determine which parts of the raster belong to the **navigable support** of the point cloud. The entire rectangular projection extent does not necessarily represent meaningful geography: large empty areas outside the visible distribution should normally remain background.

The support should therefore:

- include the visible point distribution;
- preserve sparse bridges, corridors, and narrow structures when they are spatially meaningful;
- exclude distant empty space and insignificant isolated fragments;
- remain aligned with the projection used by the viewer.

This support mask defines the area in which regions may exist.

To make that concrete, it helps to first think in terms of the visible projected geometry itself.

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/02_point_distribution.png"
    alt="Synthetic projected point distribution."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 1. A synthetic projected point distribution. The task is not to infer semantic categories, but to divide the visible geography into useful contiguous regions.*

Once the visible distribution has been rasterized and smoothed, a navigable support can be chosen that preserves the meaningful footprint of the map while excluding clearly irrelevant empty space.

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/04_navigable_support.png"
    alt="Navigable support over smoothed density."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 2. A navigable support mask over the smoothed positional density. The support defines where regions may exist.*

---

## 2. Convert the point distribution into a positional image

The projected points are rasterized into an occupancy field. This converts an irregular collection of points into an image-like representation on which local spatial structure can be measured.

Raw occupancy is generally too noisy and too uneven in dynamic range to use directly. A useful representation therefore smooths the distribution and compresses extreme density differences so that both dense and moderately sparse structures remain visible.

The resulting field represents the large-scale spatial mass of the projection without introducing any non-positional information.

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/03_rasterized_occupancy.png"
    alt="Rasterized occupancy (log-scaled)."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 3. Rasterized occupancy after log compression. This is the image-like starting point for later structural analysis.*

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/05_smoothed_density.png"
    alt="Smoothed positional density."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 4. Smoothed positional density, which captures the broad mass distribution of the projected geometry.*

---

## 3. Derive local structural evidence

No single field completely describes the shape of a projected point distribution. Several complementary positional measurements can be derived from the rasterized geometry.

Typical structural fields include:

- **Density** — where projected mass is concentrated.
- **Gradient** — where density changes rapidly, often indicating edges or transitions.
- **Curvature** — where the local shape of the density surface bends or changes slope.
- **Anisotropy** — whether local structure is strongly directional, such as along ridges or elongated bands.
- **Local support scale** — whether a location lies inside a broad interior, narrow corridor, or thin filament.

These measurements can be combined into a **boundary-strength field** representing how strongly the local geometry supports placing a region boundary at each location.

The same information can also be used to estimate **interior strength**: locations that lie well inside coherent structures, away from strong boundaries and the outer edge of the support.

### Gradient

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/06_gradient_magnitude.png"
    alt="Gradient magnitude."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 5. Gradient magnitude highlights where density changes quickly and where useful boundaries may exist.*

### Curvature

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/07_curvature_magnitude.png"
    alt="Curvature magnitude."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 6. Curvature magnitude emphasizes local bending and changes in slope or topographic shape.*

### Anisotropy

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/08_local_anisotropy.png"
    alt="Local anisotropy."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 7. Local anisotropy highlights directional structure such as elongated bands, ridges, and corridor-like regions.*

### Local support scale

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/09_local_support_scale.png"
    alt="Local support scale."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 8. Local support scale distinguishes broad interiors from narrow corridors and thin filaments.*

### Composite boundary evidence

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/10_boundary_strength.png"
    alt="Composite boundary strength."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 9. Composite boundary strength combines multiple positional cues into one image of likely region borders.*

---

## 4. Form regions from spatial structure

The segmentation stage should use the derived structural evidence to partition the navigable support.

Several general strategies are useful, depending on which aspect of the geometry should dominate.

### Local structural partitioning

Neighboring raster cells can be grouped when their local positional structure is sufficiently similar. Strong changes in density, shape, orientation, or scale resist grouping.

This directly asks:

> Where does the visible spatial structure itself change enough to justify a boundary?

It is useful as a general-purpose first partition because the number and shape of regions emerge from the observed geometry.

### Boundary-driven partitioning

Stable interior locations can be identified first and then expanded outward until competing regions meet at strong boundaries.

This asks:

> Given plausible region interiors, where should their borders settle according to the visible boundary evidence?

This is especially useful when strong ridges, gaps, transitions, or narrow separators are visually meaningful.

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/11_boundary_and_markers.png"
    alt="Boundary strength with interior markers."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 10. Boundary evidence together with interior markers. One common strategy is to place seeds in stable interiors and let boundaries settle where the positional image changes strongly.*

### Stable-mode partitioning

The density field can also be examined across changing density thresholds. Dense components appear, expand, and eventually merge through lower-density connections.

Components that persist across a substantial range of thresholds represent stable spatial modes. These modes can be used as region interiors before constructing a final disjoint partition.

This asks:

> Which spatial structures remain distinct across changes in observation level rather than appearing only because of local noise?

---

## 5. Refine regions through adjacency

An initial structural partition may contain more local pieces than are useful for navigation.

Because the segmentation is spatial, the resulting regions naturally form a **region-adjacency graph**: two regions are adjacent when they share a boundary.

Adjacent regions can then be considered for merging using evidence such as:

- similarity of their internal positional structure;
- strength of the boundary separating them;
- region size;
- whether a small region appears to be a residual fragment rather than useful geography.

Weak boundaries between structurally similar neighbors are good candidates for removal. Strong boundaries should resist merging.

This refinement converts a detailed local partition into a more navigable map without discarding the spatial evidence that created the boundaries.

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/12_structural_segmentation.png"
    alt="Structural segmentation."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 11. An example initial structural partition. It captures local distinctions, but may still contain more pieces than are convenient for navigation.*

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/13_refined_segmentation.png"
    alt="Refined navigable regions."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 12. A refined navigable partition after spatial cleanup or adjacency-based consolidation.*

---

## 6. Enforce the region contract

Regardless of how the initial partition is produced, the final segmentation should satisfy a simple spatial contract:

```text
background    → outside navigable support
region 1..K   → disjoint, contiguous spatial regions
```

Each positive region identifier should correspond to exactly one connected component. If the same provisional label occurs in disconnected locations, those locations should be separated into distinct final regions.

This guarantees that selecting or navigating to a region always refers to one coherent area of the map.

---

## 7. Treat scale as structural, not merely numerical

For navigation, the desired number of regions is usually less important than whether the boundaries correspond to visible structure.

The primary controls should therefore describe **observation scale, boundary sensitivity, interior stability, or merge strength**, rather than simply requesting an exact number of regions.

A useful segmentation should become coarser or finer by changing how much spatial structure is considered significant:

```text
fine observation
    → preserves weaker/local boundaries
    → more regions

coarse observation
    → preserves only stronger/stable boundaries
    → fewer regions
```

Multiple segmentation scales may coexist when both broad world-level navigation and finer local navigation are useful. These layers need not form a semantic hierarchy; they are simply different spatial resolutions of the same projected geography.

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/14_multiscale_coarse.png"
    alt="Coarse navigation layer."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 13. A coarser navigation layer emphasizing broader spatial regions.*

<div style="text-align: center;">
  <img
    src="../../img/segmentation_visual_examples/15_multiscale_fine.png"
    alt="Fine navigation layer."
    style="
      width: 100%;
      max-width: 600px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

*Figure 14. A finer navigation layer preserving more local structure.*

---

## 8. Validate the result as navigation geography

A good segmentation is not judged by whether it recovers known semantic labels. It should instead be evaluated according to the spatial navigation objective.

Useful checks include:

- **Disjointness** — every supported raster location belongs to at most one region.
- **Contiguity** — every region is one connected spatial area.
- **Coverage** — meaningful visible geography is represented without filling irrelevant empty space.
- **Boundary support** — borders tend to coincide with visible structural changes.
- **Region usability** — the map is not dominated by tiny fragments or excessively large undifferentiated areas.
- **Stability** — important regions remain recognizable under modest changes in scale or smoothing.
- **Inspectability** — the positional fields and refinement decisions can be examined when a boundary appears surprising.

The final segmentation should therefore answer a spatial question rather than a semantic one:

> **Which contiguous pieces of the visible projected geography provide a useful decomposition of the map for exploration and navigation?**

That interpretation keeps segmentation focused on the geometry of the projection while allowing semantic analysis, clustering, querying, and other higher-level systems to remain independent.
