# Registering External/Precomputed Assets

HyCompass has some built-in **optional producers** primarily to help populate the modular workspace, but these not required parts of the data model. It is generally expected that most computations are to be performed outside of the program.

An external program may compute a projection, clustering, density field, segmentation, or exploration field using any implementation and register the finished files with Latent Observer.

The important requirement is the **asset contract**, not the algorithm that produced it.

```text
external UMAP / MATLAB / research code
                    \
external clustering  \
external KDE           -> standardized file-backed assets -> Views / PointQuery / REST
external segmentation /
external exploration /
```

Use `GET /assets/contracts` for a machine-readable summary of these contracts and `GET /assets/catalog` for the assets currently registered in a workspace.

**REST API:** [Registering Assets](../../api/reference/assets/index.html)

**CLI:** [Registering Assets](../examples/cli_examples.md#cli-registration)

