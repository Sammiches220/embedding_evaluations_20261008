# Interaction and Point Queries

Latent Observer keeps persistent semantic assets separate from temporary interaction state:

- **SelectionAsset** — persistent membership attached to a Domain.
- **WorkingSelection** — temporary rows selected by click/lasso/query/API.
- **VisibilityFilter** — which points are drawn.
- **HighlightSet** — externally/API-emphasized rows; independent of WorkingSelection.
- **ExternalResultSet** — ordered externally supplied rows with optional opaque score/label metadata.

The same JSON-friendly PointQuery engine is used for UI predicates, lasso/click eligibility, whole-view selection, visibility filtering, and REST queries.

See [Data Concepts Core Concepts](../data_contracts/core_concepts.md) for more technical details

## UI predicate groups

Each predicate family has an explicit enable checkbox. If disabled, its controls are grayed out and the family contributes nothing to the query.

### Selection membership

Choose one or more compatible SelectionAssets. The UI can require membership in **any** or **all** checked selections.

### Clustering

Compatible clustering assets are shown as separate checkable trees. Enable **several clustering assets at once**, and within each asset check any combination of actual cluster IDs. IDs inside one asset are OR'd. Across enabled clustering assets choose **ANY** or **ALL**. Populations are displayed when available. Very high-cardinality label spaces may be capped in the GUI checklist; the REST query language remains unrestricted.

### Segmentation

Compatible segmentation assets are shown independently. Enable several segmentation assets simultaneously and choose any combination of region IDs inside each. IDs within one segmentation are OR'd; enabled segmentation assets may be combined with **ANY** or **ALL**. Region names/labels and populations from segmentation stats are shown when available.

### Density

Enable one or more compatible Density assets, choose **ANY/ALL** across them, then apply a literal comparison or percentile predicate such as:

```json
{"feature":"density","asset":"global-density","cmp":">=","percentile":90}
```

Percentiles are defined against the complete *projected population* of the View, not just the current lasso candidates. Therefore “top 10% density” has the same meaning globally and inside a lasso.

### Exploration

Enable one or more compatible Exploration assets and choose **ANY/ALL** across them. Each enabled field is tested using the chosen literal value or `inside` / `outside` boundary relationship.

### Timeline state

When a View has a Timeline, the predicate can restrict to items observed at/before the current View time or items that are future/missing.


## Visible controls versus a Saved Query

The panel has one active predicate source at a time. It explicitly shows either:

```text
Predicate source: Visible controls
```

or:

```text
Predicate source: Saved query — <name>
```

Loading a Saved Query intentionally overrides the visible controls. **Switch to visible predicate controls** clears that override. Editing any visible predicate control also returns to the visible-controls source.

## Compound example

```json
{
  "op": "and",
  "args": [
    {"feature":"projected","cmp":"finite"},
    {"feature":"selection","asset":"favorites","cmp":"member"},
    {"feature":"cluster","asset":"hdbscan-v3","cmp":"in","values":[17,19,23]},
    {"feature":"segmentation","asset":"macro-watershed","cmp":"in","values":[4,8]},
    {"feature":"density","asset":"global-density","cmp":">=","percentile":75},
    {"feature":"exploration","asset":"favorites-history","cmp":"outside","threshold":0.38},
    {"feature":"timeline","cmp":"observed"}
  ]
}
```

Nothing restricts a query to one asset per feature family. For example, an OR across two clusterings and an AND across two segmentations is simply nested composition:

```json
{
  "op":"and",
  "args":[
    {"op":"or","args":[
      {"feature":"cluster","asset":"kmeans","cmp":"in","values":[2,4]},
      {"feature":"cluster","asset":"birch","cmp":"in","values":[7,8]}
    ]},
    {"feature":"segmentation","asset":"watershed","cmp":"in","values":[3,5]},
    {"feature":"segmentation","asset":"components","cmp":"in","values":[1,2]}
  ]
}
```

## Click and lasso eligibility

Interaction has two independent constraints:

- **Respect active point predicates**;
- **Respect current visibility**.

When enabled, these constraints are applied before picking/selection. A hidden or predicate-ineligible point cannot steal the click simply because it is geometrically closer than an eligible visible point.

Lasso results can **Replace**, **Add**, **Subtract**, or **Intersect** the WorkingSelection. A normal point click uses the same combine mode.

`Clear selection` clears only the WorkingSelection.

## WorkingSelection versus external highlights

WorkingSelection and API/external highlights are intentionally independent. Both have separate per-View style controls (visibility, RGBA color, point size). The GUI no longer exposes a confusing “Clear highlights” button because external highlights are chiefly an external/API interaction channel.

## Visibility actions

The active PointQuery can:

- **Select matches** — update WorkingSelection;
- **Show only matches** — create a VisibilityFilter from matches;
- **Hide matches** — hide matches while leaving other rows visible;
- **Reset visibility** — remove the filter.

None of these mutates persistent SelectionAssets.

## Exporting the WorkingSelection

The Interaction section exposes **Export selection…**. Choose app-native features such as:

```text
position
timeline
selection:<asset>
cluster:<asset>
density:<asset>
segmentation:<asset>
exploration:<asset>
```

and export CSV or JSONL. Export is chunked and uses the same `FeatureProvider` as the REST API.

The REST API additionally exposes paged feature retrieval for the current WorkingSelection.

## Predicate-change events

The visible Point Predicate editor is runtime state. v0.5.4 emits `point_predicate.changed` when its effective expression/source changes. The event contains a query hash and saved-query source metadata, not the complete expression or matching row set.

Use:

```text
GET /views/{view}/predicate/state
```

to retrieve the complete current PointQuery JSON. This endpoint is a cheap in-memory state read; it does not evaluate the query. Use `/query` or `/query/features` only when matching rows/features are actually required.
