# HyCompass -- Embedding Visualizer & Explorer

HyCompass is a visualizer and interactive explorer for 2D-projected embeddings of media. 

The goal of this project is to provide a "map" of large domains of media, as well as a representation for the observer's current "position", "direction", and "explored territory".

The general idea from this project comes from a practical problem -- there are far too many media files to reasonably keep track of with conventional means of bookkeeping. Tag-based browsing works extremely well for locally understood areas, but it quickly gets out of hand when you're dealing with *millions* of files and/or if some meaningful information cannot easily be represented through small phrases or words. This project hopes to mitigate these issues by incorporating Representation Learning techniques to enable some human perception of many high-dimensional data points. 

HyCompass is directly inspired by the idea of having a physical map and being able to not only understand what's "around you", but also to "explore":

<style>
.responsive-image-pair {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
}

.responsive-image-pair img {
  height: 350px;
  width: auto;
  object-fit: contain;
  border: 2px solid #000000;
}

/* Phones / narrow screens */
@media (max-width: 768px) {
  .responsive-image-pair {
    flex-direction: column;
  }

  .responsive-image-pair img {
    height: auto;
    width: auto;
    max-width: 100%;
  }
}
</style>

<div class="responsive-image-pair">
  <img src="img/physical_map_analogy.png" alt="Physical map analogy">
  <img src="img/map_analogy_hycompass_projection.png" alt="Map Analogy HyCompass Projection">
</div>

Similar to how physical maps have evolved throughout history, HyCompass doesn't assume that there is any one "objective" type of map. A major feature of this project is to be able to represent *any* representations that can be projected into 2D.

Importantly HyCompass does not attempt to implement any known embedding or projection methodologies, but instead offers an interface + an API to visualize and explore them.

For example, below is just one type of embedding domain + 2-D projection. It is hoped that any users will be able to create their own "maps" or incorporate existing embedding datasets to facilitate exploration.

<div style="text-align: center;">
  <img
    src="img/danbooru_swinv2_embedding_card.png"
    alt="Embedding card for Danbooru Swinv2 dataset."
    style="
      width: 100%;
      max-width: 800px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

Likewise, there are many different means of segmenting the map's notable features:

<div style="text-align: center;">
  <img
    src="img/segmenting_samples.png"
    alt="alt text"
    style="
      width: 100%;
      max-width: 800px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

The hope of this project is to let users understand and model larger datasets of media.

The broader hope is that this project helps enable users to regain their digital autonomy by letting them develop their own definitions of meaning and be able to navigate more effectively across the vast "sea" of modern information. 


Using HyCompass and some supplemental viewer, you can easily explore recorded items and where they are on the map. An example is with the supported [Hydrus viewer + embedding tracker](./guides/hydrus_network_integration.md).

<div style="text-align: center;">
  <img
    src="img/sample_landmark_vibe_reads.png"
    alt="Sample 'vibe' reads of landmarks in Danbooru Swinv2 dataset."
    style="
      width: 100%;
      max-width: 1200px;
      border: 2px solid #000000;
      padding: 4px;
    "
  >
</div>

!!! important "Interpretability Consideration"

    Assigning human-readable labels to **landmarks**, **regions**, or other geometric structures is itself an interpretability problem. A cluster or persistent geometric feature does not necessarily correspond cleanly to a single human concept. Our society usually tries to mitigate this issue by enforcing standardized meaning through shared conventions, standardized taxonomies, and other large complex systems -- this is not as applicable here due to the relatively ad hoc & decentralized nature of this cartography application. 

    If you have some meaning that you care about, prefer embedding and projection methods that **preserve or expose meaningful structure in the underlying representation**, so that important distinctions are visible in the geometry itself rather than existing only as post-hoc labels. Keep in mind that dimensionality reduction can distort distances, neighborhoods, densities, and topology, so interpretations made from the projected geometry should ideally be checked against the original high-dimensional representation. See the [Representation Learning Resources Page](resources/representation_learning_resources.md) for some starting points.

    If you want to automatically generate standardized human-interpretable labels for regions of a projected representation, an **LLM can serve as one possible observer**. However, those labels should be treated as an additional interpretive layer rather than as ground truth.

    Ideally, the observer should be:

    - **Reproducible** — equivalent inputs should normally produce equivalent labels.
    - **Stable over time** — unchanged geometry should not acquire substantially different interpretations merely because the labeling process was rerun.
    - **Low-variance** — repeated evaluations should have a relatively narrow distribution of plausible outputs.
    - **Versioned** — the model, prompt, decoding parameters, and other relevant observer settings should be recorded so that labels can be reproduced and compared across runs.

    For applications where consistency matters more than linguistic variety, deterministic or tightly constrained decoding is generally preferable.


## Documentation Structure

HyCompass documentation is built as one "Material for MkDocs" site. 

Below is an overview of what each tab contains.

- **Guide** explains the architecture and major concepts.
- **REST API** combines hand-written behavioral documentation with a reference generated from FastAPI/OpenAPI.
- **Python Reference** embeds selected signatures and Google-style docstrings from the implementation.


## **Where to Start**

If you are changing the implementation, start with [Architecture](./guides/architecture.md). If you are writing an HTTP client, start with the [REST API overview](api/index.md).
