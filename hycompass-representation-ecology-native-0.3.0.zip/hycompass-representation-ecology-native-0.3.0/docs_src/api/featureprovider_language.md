
# FeatureProvider language

`FeatureProvider.records(rows, features)` exposes point features using a small string language.

REST endpoints that accept a `features` field use the same language. At the REST boundary, an omitted or empty feature list defaults to:

```json
["position"]
```

The provider itself receives the effective list from its caller.

## Record shape

Every record always contains:

```json
{
  "row": 42,
  "item_id": "..."
}
```

This remains true even if neither `row` nor `item_id` appears in the requested feature list.

Requested features add fields directly to that same object. The public wire format remains dynamic; there is no nested `features` object.

---

## Built-in features

### `position`, `x`, `y`

Requesting **any** of:

```text
position
x
y
```

causes both `x` and `y` to be emitted:

```json
{
  "row": 42,
  "item_id": "...",
  "x": 0.123,
  "y": -0.456
}
```

This is historical behavior. Requesting only `x` still emits `y`, and requesting only `y` still emits `x`.

Non-finite coordinates are serialized as JSON `null`.

### `timeline`

Requesting:

```text
timeline
```

adds:

```json
{
  "timestamp": 1720000000,
  "observed_now": true
}
```

The exact timestamp value comes from `ViewData.row_timestamp(...)`; `observed_now` is evaluated using the View's current Timeline progress.

Raster-backed features are sampled at the point's projected coordinate. A point outside the Projection receives `null` for floating fields and background-like `0` for categorical raster sampling.


### `row` and `item_id`

These names are valid built-ins, but the corresponding fields are already present in every record.

#### Explicit rows/item IDs

```http
POST /items/features
```

By rows:

```json
{
  "domain": "swinv2-v3",
  "projection": "external-umap",
  "rows": [17, 29],
  "features": [
    "position",
    "timeline",
    "selection:favorites",
    "cluster:hdbscan-v4",
    "density:adaptive-kde",
    "segmentation:external-regions",
    "exploration:favorites-history"
  ]
}
```

By IDs:

```json
{
  "view": "default",
  "item_ids": ["item-a", "item-b"],
  "features": ["position", "density:adaptive-kde"]
}
```

Response:

```json
{
  "items": [
    {
      "row": 17,
      "item_id": "item-a",
      "x": 0.142,
      "y": -0.821,
      "timestamp": 1641044542,
      "observed_now": true,
      "selection:favorites": true,
      "cluster:hdbscan-v4": 3,
      "density:adaptive-kde": 0.763,
      "segmentation:external-regions": 7,
      "exploration:favorites-history": 0.184
    }
  ]
}
```

The endpoint is limited to 10,000 items per request.


---

## Asset-backed feature names

Asset features use:

```text
kind:asset
```

The string is split at the first `:`. The complete requested feature string becomes the output key.

### Selection

```text
selection:favorites
selection:active
```

Example output:

```json
{
  "selection:favorites": true
}
```

Selection compatibility and `active` semantics are exactly the same as `PointQueryEngine.selection_values(...)`.

### Clustering

```text
cluster:hdbscan-v4
cluster:active
```

Example output:

```json
{
  "cluster:hdbscan-v4": 17
}
```

Clustering compatibility and active-clustering behavior are shared with PointQuery.

### Density

```text
density:adaptive-kde
```

Example output:

```json
{
  "density:adaptive-kde": 0.7124
}
```

The Density must belong to the current projection.

### Segmentation

```text
segmentation:external-regions
```

Example output:

```json
{
  "segmentation:external-regions": 9
}
```

### Exploration

```text
exploration:favorites-history
```

For temporal Exploration assets, the sampled frame is selected from the View's current Timeline progress, exactly as in PointQuery.

---

## Feature errors

A non-built-in feature without `:` raises:

```text
feature '<name>' needs kind:asset
```

An unknown `kind` raises:

```text
unsupported feature '<kind>:<asset>'
```

Asset compatibility errors are raised by the same `PointQueryEngine` helpers used for PointQuery predicates.

---

## JSON conversion rules

Before records are returned:

- NumPy scalar values are converted to their corresponding Python scalar;
- non-finite Python floating-point feature values are converted to `null`;
- boolean, integer, and finite floating-point values retain their natural JSON-compatible type.

---

## Predicate-based feature retrieval

`/items/features` may use `where` instead of explicit `rows`/`item_ids`:

```json
{
  "domain": "swinv2-v3",
  "projection": "external-umap",
  "where": {
    "feature": "selection",
    "asset": "favorites",
    "cmp": "member"
  },
  "features": ["position", "cluster:hdbscan-v4"],
  "offset": 0,
  "limit": 1000
}
```

---

## Query + features in one request

```http
POST /query/features
```

Example:

```json
{
  "domain": "swinv2-v3",
  "projection": "external-umap",
  "timeline": "archive-time",
  "where": {
    "op": "and",
    "args": [
      {
        "op": "or",
        "args": [
          {
            "feature": "cluster",
            "asset": "hdbscan-v4",
            "cmp": "in",
            "values": [1, 2]
          },
          {
            "feature": "cluster",
            "asset": "kmeans-v2",
            "cmp": "in",
            "values": [4, 5]
          }
        ]
      },
      {
        "feature": "density",
        "asset": "adaptive-kde",
        "cmp": ">=",
        "percentile": 90
      }
    ]
  },
  "features": [
    "position",
    "timeline",
    "cluster:hdbscan-v4",
    "cluster:kmeans-v2",
    "density:adaptive-kde"
  ],
  "offset": 0,
  "limit": 1000
}
```

Response:

```json
{
  "total": 4205,
  "offset": 0,
  "items": [],
  "next_offset": 1000
}
```

`items` contains the feature records described above.

---

