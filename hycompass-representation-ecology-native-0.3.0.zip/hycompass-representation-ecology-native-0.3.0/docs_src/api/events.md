# Event stream

HyCompass exposes runtime changes through the `/events` Server-Sent Events (SSE) endpoint.

Use this page for the behavioral contract of the stream. Exact query parameters and HTTP response details are generated in the REST reference.

## Connection

```http
GET /events
Accept: text/event-stream
```

The stream can be filtered by event type, view, or domain. Clients may also resume from a prior event identifier.

## Event identifiers and replay

Events may include an `event_id`. A reconnecting client can supply either the `since_event_id` query parameter or the standard `Last-Event-ID` header.

If the requested history has expired, the stream emits `stream.resync_required`. The client should obtain a fresh snapshot from the relevant state endpoint before continuing with incremental events.

## Relationship to REST state

The event stream is incremental; REST state endpoints are authoritative snapshots.

The integration model is:

```text
GET /events   (SSE)
    -> small notification that state changed

cheap state endpoints
    -> revision/count/source metadata

revisioned snapshot/delta endpoints
    -> authoritative WorkingSelection identities

/query, /query/features, /items/features
    -> application-native point data when required
```

The SSE stream is intentionally **not** a bulk item transport. A selection containing millions of rows still produces a small event containing its revision and count.

## Recommended synchronization algorithm

```text
1. Connect to GET /events.
2. Keep the last SSE event_id for reconnect.
3. Track the last WorkingSelection revision per View.
4. On active_view.changed, decide whether to follow the new View.
5. On point_predicate.changed, fetch predicate/state only if the full query matters.
6. On working_selection.changed:
     a. request /working-selection/delta from the last known revision;
     b. apply it if snapshot_required=false;
     c. otherwise fetch a revision-pinned paginated snapshot.
7. Resolve item IDs against external data in bulk.
8. Use /items/features or /query/features only for application-native features actually needed.
9. Return external results through ResultSets/highlights/focus if desired.
```

This makes event handling independent of Selection size.

## Runtime event envelope

Normal persisted events have this JSON shape:

```json
{
  "event_id": 42,
  "type": "working_selection.changed",
  "revision": 7,
  "time": "2026-09-15T09:23:39.009Z",
  "view": "default",
  "domain": "domain",
  "projection": "global",
  "data": {}
}
```

Fields:

- `event_id` — process-wide monotonically increasing SSE/replay ID.
- `type` — event family.
- `revision` — revision of the state family named by the event.
- `time` — UTC timestamp.
- `view` — runtime View ID when applicable.
- `domain` — Domain ID when applicable.
- `projection` — Projection ID when applicable.
- `data` — small event-specific metadata.

`event_id` and runtime revisions are process-local synchronization numbers. They are not durable workspace/version identifiers and reset when the process restarts.

## SSE endpoint

```http
GET /events
```

Example:

```bash
curl -N http://127.0.0.1:8765/events
```

Filter by View:

```bash
curl -N 'http://127.0.0.1:8765/events?view=default'
```

Filter by event type:

```bash
curl -N 'http://127.0.0.1:8765/events?types=working_selection.changed,point_predicate.changed,active_view.changed'
```

A type ending in `*` is a prefix filter, for example:

```text
types=view.*,working_selection.changed
```

Supported query parameters:

```text
view=<runtime-view-id>
domain=<domain-id>
types=<comma-separated exact/prefix event filters>
heartbeat=<2..60 seconds>
since_event_id=<event id>
```

Idle streams emit SSE comment keepalives. They are not application events.

### Reconnect and replay

Clients may reconnect with the standard SSE:

```http
Last-Event-ID: <event id>
```

or use:

```text
since_event_id=<event id>
```

A bounded event history is retained in memory. If the requested range is still retained, matching events are replayed before live delivery.

If replay is no longer possible, the stream emits:

```text
stream.resync_required
```

The client should recover through `/state` and the relevant View state/snapshot endpoints.

A slow subscriber never blocks Latent Observer. If its bounded delivery queue overflows it also receives `stream.resync_required` and should resynchronize from REST.

## Event types

### `working_selection.changed`

Emitted when a temporary WorkingSelection changes through GUI interaction or REST.

Example `data`:

```json
{
  "count": 532,
  "previous_count": 519,
  "cause": "lasso",
  "delta": {
    "available": true,
    "added_count": 15,
    "removed_count": 2,
    "added_rows": [17, 28],
    "removed_rows": [91]
  }
}
```

The inline row lists are included only for very small differences. Do not depend on them being present. Use the delta endpoint or a revision-pinned snapshot for authoritative synchronization.

Common causes include:

```text
click
lasso
point_predicate
clear
api
api_clear
```

### `point_predicate.changed`

Emitted when the Point Predicate controls or active Saved Query override changes.

It does **not** evaluate the predicate or transmit matching points.

Example data:

```json
{
  "source": "controls",
  "saved_query_id": null,
  "saved_query_name": null,
  "query_hash": "9fd3c1f3e7436a80"
}
```

Fetch the complete current JSON expression from:

```http
GET /views/{view}/predicate/state
```

### `active_view.changed`

Emitted when the active main-window tab changes.

Example:

```json
{
  "active_view": "miku-global",
  "previous_view": "global",
  "cause": "tab"
}
```

The event envelope is scoped to the newly active View/Domain/Projection when there is one.

### View lifecycle

```text
view.opened
view.closed
view.reconfigured
```

A companion application can use these to refresh its known runtime View set or follow changes in View composition.

### Visibility

```text
visibility.changed
```

Carries whether a visibility predicate is enabled, visible count when known, cause, and query hash. The full query remains available through normal state/View APIs rather than being repeatedly duplicated into events.

### Timeline

```text
timeline.changed
```

The runtime Timeline value/revision updates immediately. GUI SSE emission is debounced so dragging and continuous playback do not create a high-frequency event flood. The event contains the settled normalized Timeline progress.

### External interaction state

```text
highlights.changed
focus.changed
result_set.changed
camera.fit_requested
```

These are independent of WorkingSelection and are useful for external detail/ranking/navigation interfaces.

### Workspace/catalog state

```text
asset.registered
workspace.reloaded
saved_query.changed
saved_view.changed
```

These use a workspace revision rather than a View state-family revision. Asset events include Domain/Projection scope in the event envelope when it is known.

## Cheap runtime-state endpoints

These endpoints are intended to be safe frequent-polling fallbacks. They inspect small in-memory runtime state and do not evaluate PointQueries or enumerate point arrays.

### Global runtime state

```http
GET /state
```

Example:

```json
{
  "version": "0.5.4",
  "head_event_id": 184,
  "workspace_revision": 3,
  "active_view_revision": 12,
  "active_view": {
    "view": "default",
    "title": "Default view",
    "domain": "domain",
    "projection": "global"
  },
  "runtime_view_count": 2
}
```

### Active View state

```http
GET /active-view/state
```

### Aggregate View state

```http
GET /views/{view}/state
```

Returns:

- View/Domain/Projection identity;
- active status;
- per-family revisions;
- WorkingSelection and highlight counts;
- visible count when known;
- current Timeline progress;
- Point Predicate source/hash;
- VisibilityQuery hash;
- focused row;
- current `head_event_id`.

### WorkingSelection state

```http
GET /views/{view}/working-selection/state
```

Example:

```json
{
  "type": "working_selection",
  "view": "default",
  "domain": "domain",
  "projection": "global",
  "revision": 31,
  "count": 54231,
  "updated_at": "2026-09-15T09:23:39.009Z",
  "head_event_id": 184
}
```

### Point Predicate state

```http
GET /views/{view}/predicate/state
```

This includes the complete active PointQuery JSON plus:

```text
revision
source
saved_query_id
saved_query_name
query_hash
```

## Revision-pinned WorkingSelection snapshots

The existing paginated endpoint returns a Selection revision:

```http
GET /views/{view}/working-selection?offset=0&limit=10000
```

Example:

```json
{
  "revision": 31,
  "total": 54231,
  "offset": 0,
  "rows": [17, 22, 91],
  "item_ids": ["a", "b", "c"],
  "next_offset": 10000
}
```

For a consistent multi-page snapshot, pin subsequent pages to that revision:

```http
GET /views/default/working-selection?revision=31&offset=10000&limit=10000
```

If the Working Selection changes while the client is paging, the server responds `409 Conflict` rather than mixing two revisions. Restart from the current revision.

`POST /views/{view}/working-selection/features` likewise accepts an optional `revision` field so feature paging can be pinned to the same WorkingSelection state.

## WorkingSelection deltas

```http
GET /views/{view}/working-selection/delta?since_revision=30
```

Small retained transition:

```json
{
  "from_revision": 30,
  "to_revision": 31,
  "snapshot_required": false,
  "count": 54231,
  "added_rows": [17, 22],
  "removed_rows": [9]
}
```

Optionally resolve the changed rows to canonical item IDs:

```http
GET /views/default/working-selection/delta?since_revision=30&include_item_ids=true
```

If the change was too large/expensive, the required transition has aged out of the bounded history, or the requested revision cannot be bridged, the response is:

```json
{
  "from_revision": 30,
  "to_revision": 37,
  "snapshot_required": true,
  "count": 900000
}
```

The client should fetch a fresh revision-pinned snapshot.

The delta endpoint can combine several retained consecutive revisions. Add/remove operations that cancel across the chain are collapsed before being returned.

## Recommended companion-application loop

```text
connect GET /events
        |
        +-- active_view.changed
        |      -> choose/follow the new View
        |
        +-- point_predicate.changed
        |      -> fetch predicate/state only if relevant
        |
        +-- working_selection.changed
               -> compare selection revision
               -> request delta from last known revision
               -> if snapshot_required: fetch pinned snapshot
               -> bulk-resolve item IDs in external database
               -> update external UI
```

The event is a notification that state changed; it is not the source of truth for a large selection.
