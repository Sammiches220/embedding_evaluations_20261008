# PointQuery language

PointQuery is a small JSON predicate language used by:

- `/query`;
- `/query/features`;
- predicate-based `/items/features`;
- View visibility filters;
- GUI point-predicate interaction;
- saved queries/predicate state.

A query is either a logical expression or a leaf feature predicate. Logical expressions may contain other logical expressions recursively.

## Default / match-all behavior

At the top-level `PointQueryEngine.query(...)` call, all of the following are treated as the no-filter/default query:

```json
null
```

```json
{}
```

```json
{"op": "all"}
```

For these top-level forms, HyCompass returns only rows with finite projected positions.

An explicit `{"op": "all"}` used *inside* a larger logical expression evaluates to `true` for every candidate row. 

## Logical operators

### AND

```json
{
  "op": "and",
  "args": [
    {"feature": "selection", "asset": "favorites", "cmp": "member"},
    {"feature": "density", "asset": "adaptive-kde", "cmp": ">=", "value": 0.7}
  ]
}
```

`args` must be a JSON list.

An empty `and` evaluates to `true` for every candidate row:

```json
{"op": "and", "args": []}
```

### OR

```json
{
  "op": "or",
  "args": [
    {"feature": "cluster", "asset": "hdbscan-v4", "cmp": "in", "values": [2, 3]},
    {"feature": "cluster", "asset": "kmeans-v2", "cmp": "in", "values": [8, 9]}
  ]
}
```

An empty `or` evaluates to `false` for every candidate row:

```json
{"op": "or", "args": []}
```

### NOT

```json
{
  "op": "not",
  "arg": {
    "feature": "selection",
    "asset": "favorites",
    "cmp": "member"
  }
}
```

`not` negates the child predicate element-wise.

### Evaluation order

Logical children are evaluated from left to right. `and` and `or` deliberately evaluate every child rather than skipping later predicates once the boolean result is already known. This preserves error and asset-validation behavior for later predicates.

The implementation uses an explicit evaluator stack rather than recursive Python calls. This allows very large/deep expression trees to be traversed without imposing Python's function-recursion limit on the PointQuery language.

---

## Selection membership

```json
{
  "feature": "selection",
  "asset": "favorites",
  "cmp": "member"
}
```

`asset: "active"`, an omitted asset, or an empty asset selects the View/context's active Selection.

If the active View has no selection mask, active selection membership evaluates to `true` for every supplied row.

To select non-members, prefer wrapping the predicate in `not`:

```json
{
  "op": "not",
  "arg": {
    "feature": "selection",
    "asset": "favorites",
    "cmp": "member"
  }
}
```

For compatibility, selection comparisons `member`, `==`, and `true` return membership; other comparison strings take the negated membership branch. New callers should use `member` plus logical `not` rather than depending on that fallback.

---

## Clustering

Single category:

```json
{
  "feature": "cluster",
  "asset": "hdbscan-v4",
  "cmp": "==",
  "value": 17
}
```

Multiple categories:

```json
{
  "feature": "cluster",
  "asset": "hdbscan-v4",
  "cmp": "in",
  "values": [17, 22, 31]
}
```

`asset: "active"`, an omitted asset, or an empty asset uses the View's active clustering. If no active clustering exists, the query raises `QueryError("no active clustering")`.

Named clustering assets must belong to the current domain. A clustering that specifies a projection must also match the current projection.

Multiple clustering assets can be combined with logical operators.

Supported comparisons are:

```text
==
!=
>
>=
<
<=
in
not in
```

The following aliases are accepted:

```text
eq  -> ==
ne  -> !=
gt  -> >
ge  -> >=
lt  -> <
le  -> <=
```

---

## Segmentation

```json
{
  "feature": "segmentation",
  "asset": "external-regions",
  "cmp": "in",
  "values": [4, 7, 9]
}
```

The sampled value is the segment ID beneath each point's projected position.

The Segmentation must belong to the current projection. Multiple Segmentation assets may appear in the same logical query.

Rows that cannot be sampled from an integer Segmentation raster receive the internal sampled value `0`, matching existing behavior.

---

## Density

Raw value:

```json
{
  "feature": "density",
  "asset": "adaptive-kde",
  "cmp": ">=",
  "value": 0.7
}
```

Percentile:

```json
{
  "feature": "density",
  "asset": "adaptive-kde",
  "cmp": ">=",
  "percentile": 90
}
```

For Density, percentile thresholds are computed from that Density sampled over the complete projected population, not merely the current candidate/lasso rows. This keeps GUI and API semantics consistent.

Example: densest 10%:

```json
{
  "feature": "density",
  "asset": "adaptive-kde",
  "cmp": ">=",
  "percentile": 90
}
```

The Density must belong to the current projection.

Rows outside the raster/projectable sampling region receive `NaN` before comparison.

---

## Exploration

Inside a boundary:

```json
{
  "feature": "exploration",
  "asset": "favorites-history",
  "cmp": "inside",
  "threshold": 0.38
}
```

Outside:

```json
{
  "feature": "exploration",
  "asset": "favorites-history",
  "cmp": "outside",
  "threshold": 0.38
}
```

If `threshold` is omitted, the View's current exploration threshold is used.

Numeric comparisons are also supported:

```json
{
  "feature": "exploration",
  "asset": "favorites-history",
  "cmp": "<",
  "value": 0.25
}
```

For temporal Exploration, the raster frame is selected from the request/View's current Timeline progress.

The Exploration asset must belong to the current projection. If the Exploration declares a Timeline, it must be the same Timeline used by the query context.

---

## Timeline

Observed by the current time:

```json
{
  "feature": "timeline",
  "cmp": "observed"
}
```

Not yet observed:

```json
{
  "feature": "timeline",
  "cmp": "future"
}
```

`"unobserved"` is accepted as an alias for `future`.

An explicit normalized current point may be supplied:

```json
{
  "feature": "timeline",
  "cmp": "observed",
  "current": 0.8
}
```

Normally use context-level `timeline_progress` instead.

If the View has no normalized Timeline, Timeline predicates evaluate to `false` for every supplied row.

Other ordinary numeric comparisons are passed through the common comparison implementation.

---

## Projected state

Finite projected rows:

```json
{
  "feature": "projected",
  "cmp": "finite"
}
```

`finite`, `==`, and `true` select finite projected positions. Other comparison strings take the historical negated branch. Prefer `finite` plus logical `not` for non-projected rows:

```json
{
  "op": "not",
  "arg": {
    "feature": "projected",
    "cmp": "finite"
  }
}
```

---

## Domain row

```json
{
  "feature": "row",
  "cmp": "in",
  "values": [100, 200, 300]
}
```

Row predicates use the same common comparisons as clustering, density, and other numeric values.

---

## Common comparison behavior

For `in` and `not in`, use `values`:

```json
{
  "feature": "row",
  "cmp": "not in",
  "values": [1, 2, 3]
}
```

For scalar comparisons, use `value`:

```json
{
  "feature": "row",
  "cmp": ">=",
  "value": 100
}
```

If a scalar comparison is requested without `value` or `percentile`, HyCompass raises a `QueryError`.

A generic `percentile` key is implemented by the common comparator as well. Density has additional behavior: its percentile is deliberately resolved against the complete projected population before comparison.

---

## Candidate rows

Python callers may pass `candidate_rows` to `PointQueryEngine.query(...)`:

```python
rows = engine.query(expression, candidate_rows=candidates)
```

The result preserves candidate-row order.

The no-expression/default forms still remove candidates whose projected positions are non-finite.

---

## Resolving rows and item IDs

`PointQueryEngine.resolve_rows(...)` accepts domain rows, item IDs, or both:

```python
rows = engine.resolve_rows(
    rows=[12, 4],
    item_ids=["abc", "def"],
)
```

Behavior is intentionally unchanged:

- rows outside the domain raise `QueryError("row outside domain")`;
- item IDs are resolved by scanning the domain's item-ID array in chunks;
- unknown IDs raise `QueryError`;
- row inputs are followed by item-ID inputs;
- later duplicates are removed;
- first-occurrence ordering is preserved rather than sorted.

For large external workflows, retaining domain rows after the first resolution avoids repeatedly scanning a very large item-ID array.

---

## Large-expression behavior

Recursive Python evaluation is avoided since it may be an implementation bottleneck.

The evaluator now uses an explicit stack, so a query containing tens of thousands of logical/predicate nodes can be traversed without failing merely because its tree depth exceeds Python's function-recursion limit.

The computational cost of the predicates themselves remains real. In the worst case, evaluating `E` predicates over `N` candidate rows is approximately proportional to `E × N`, plus asset/raster sampling costs. A flat expression containing tens of thousands of expensive predicates over millions of candidate rows can therefore still be expensive even though parsing/traversal is safe.

The evaluator intentionally does **not** introduce logical short-circuiting. The previous implementation evaluated every child, so skipping later children could change which incompatible-asset/error condition is observed. Preserving that behavior takes priority over speculative optimization.

For very large workloads, the safest current techniques are:

- provide `candidate_rows` when the caller already has a smaller relevant population;
- reuse one `PointQueryEngine` when repeatedly querying the same View so its existing point-feature cache can be reused;
- retain domain rows rather than repeatedly resolving large item-ID lists;
- avoid mechanically duplicating equivalent predicates in generated expressions.

If profiling later shows that expressions with tens of thousands of predicates are a dominant workload, a separate optimization pass could add expression compilation, repeated-leaf caching, or candidate-mask pruning. Such work should be benchmarked and compatibility-tested independently because preserving evaluation/error ordering is part of the current behavior.

### Pagination and transfer guidance

Query endpoints use offset pagination:

```text
offset
limit
next_offset
```

Maximum query/feature page size:

```text
10,000
```

For large result sets:

1. retain Domain row numbers when possible;
2. page `/query` or `/query/features`;
3. request only needed features;
4. avoid giant one-shot JSON payloads;
5. use file-based exchange/Parquet/Arrow in external pipelines when moving large tables.

The bundled Embedding Atlas adapter demonstrates paged export.

### HTTP parser consideration

The engine itself no longer depends on Python recursion for expression traversal. Extremely deeply nested JSON submitted over HTTP is still first parsed by the web/JSON stack before `PointQueryEngine` sees it. A pathological expression nested thousands of levels deep may therefore encounter limits outside the query engine. Large *flat* or normally balanced expressions with tens of thousands of nodes do not have that particular issue.

