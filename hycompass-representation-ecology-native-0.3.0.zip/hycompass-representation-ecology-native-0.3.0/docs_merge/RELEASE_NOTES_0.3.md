# 0.3.0 — navigation, geometry profiles and standard ML metrics

- 2D left-drag pans; 3D Navigate left-drag orbits. Middle-drag or explicit Pan mode pans either view. Cursor-anchored 2D zoom and 3D camera magnification are independent of the observer. The 3D viewport uses the full rectangular canvas with equal projected pixel scales; 3D zoom retains complete mesh world bounds instead of shrinking the source clipping volume. Viewport cropping at high magnification is expected; pan to inspect the rest. Camera offsets are saved. The optional 3D coordinate box is hidden by default.
- Scalar and categorical legends occupy separate native side panels outside the camera canvas. They show actual display limits, named categories and signed zero; long category lists scroll. Unavailable evidence has no invented numerical scale. Signed contrast is symmetric.
- Geometry in context restores scrollable per-measurement profiles with numeric here/ahead median endpoints and sample counts. Its exact table remains in a separate subtab. Click a profile to map it.
- The new `directions` instrument saves actual centered tangent-neighborhood PC scores. Here/ahead dimension ribbons show one line per measured neighbor across supported directions, distinct from descriptive profile spread bands. Local bases have independent signs/orientations.
- Shapes & spectra has both endpoint neighborhoods' actual PCA-3 hull/clouds, complete local variance spectra, and a geometry line profile instead of the two-bar comparison. Unsupported endpoints remain unavailable.
- The `probe_metrics` instrument replays frozen group-held-out fold models. Regression tables show MAE, RMSE, R2, baseline MAE and gain. Classification tables show accuracy, balanced accuracy, observed-class macro F1, supported AUC, log loss, Brier and baseline skill. Values are color coded by metric, with explicit matched support. Existing models are not refitted. The UI uses cohort/standard metric terminology instead of question wording.
- Independent draggable splitters resize the scale chart/table section and the directional-profile/dimension-ribbon section.
- Freehand lasso works in 2D and the current 3D projection. Shift adds; Ctrl subtracts. It resolves canonical measured-anchor IDs through the existing kept-selection/link/export path. It is not an occlusion test or a full-corpus geometric selection.
- Values & deltas filters rows by measurement family and feature; item tables use overview/geometry/source/reconstruction column groups rather than one growing all-feature join.
- Reference / help and Help → Atlas / model reference (F1) open a searchable native offline reference. Its bundled source is `ecology/atlas_reference.html`; no web engine or network is required.

## Validation and limits

The suite contains 60 tests, including camera bounds/pan, lasso modifiers/identity, color scales, score/spectrum agreement, standard metric edge cases, replayed loss agreement, paired evidence, grouped tables and offline help. The synthetic demo remains 360 canonical items, up to 144 evaluation anchors and 288 context rows. No production-scale benchmark was run.

Offscreen native rendering and model/runtime interactions were verified. Desktop population OpenGL/compositor behavior remains unverified here. CPU 3D and projected selection remain bounded detail. A timer interval is not a universal frame-rate guarantee.

The models remain Ridge regression and clipped/normalized Ridge probability decoders, not a new logistic/forest suite. Undefined AUC, R2 and baseline skills remain unavailable. Exploratory held-out metrics are not an untouched final test after repeated adaptive inspection. Inferential null-test workflows and interactive route-set navigation remain outside this release.

The rectangular viewport adapter is verified on Matplotlib 3.10.8; requirements constrain the supported 3.10 release family. Standard probe tables include explicit score/improvement color keys.
