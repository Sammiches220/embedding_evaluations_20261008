# Source provenance

Inputs supplied in this request:

- `hycompass_20261101_archive(2).zip`: native application foundation. Existing model, API, interaction, rendering and asset preparation remain present.
- `representation-ecology-1.3.0.zip`: numerical and behavioral baseline. No later population-extension version was used.

`ecology/kernels/accessibility.py` comes from `src/representation_ecology/accessibility.py` in 1.3.0. The numerical definitions are retained. The only adaptation adds an optional cooperative checkpoint callback at fold, target and evaluation-batch boundaries.

`ecology/kernels/geometry.py` contains selected functions from `src/geometric_ecology/core.py` in 1.3.0: unit normalization, exact nearest neighbors, radius dimension, neighbor overlap, sparse mutual graph assembly, fixed-graph deletion influence and Dijkstra routes. Unused report pipelines and browser code were not imported.

Native neighborhood spectra use a centered tangent-neighborhood SVD, equivalent to 1.3.0's Gram eigenspectrum. The golden test fixture was produced directly by the supplied `geometric_ecology/mesh.py::neighborhood_spectra`, using 48 rows × 8 dimensions and 8 neighbors. The independent accessibility fixture was produced by the unmodified supplied 1.3.0 kernel on 144 rows × 8 dimensions, grouped in threes, using the settings in its adjacent JSON file. Fixtures are numerical regression evidence, not compatibility readers for old reports.

Boolean/category probability decoders, persistent canonical identity, frozen account reevaluation, bounded native jobs, artifact storage and Qt exploration canvases are new implementation. They are not presented as byte-for-byte ports of browser controls or of every expert report.

`ecology/kernels/neighborhood_hull.py` and `route_set.py` retain the supplied 1.3.0 local hull and bounded near-shortest loopless route kernels. They support native hull rendering and saved route-entropy evidence respectively.
