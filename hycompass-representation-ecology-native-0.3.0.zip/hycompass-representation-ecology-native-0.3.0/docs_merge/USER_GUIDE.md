# Native field guide: run and use

Python 3.10+ and a desktop OpenGL 3.3 context are required for HyCompass population views. The exploration guide is native Qt with bounded CPU-rendered charts; no browser is needed.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python main.py --workspace demo_workspace --exploration shared-base
```

Windows activation: `.venv\Scripts\activate`. Installation and population asset commands are unchanged from `README_POPULATION.md`.

## Start with the question

The population remains the first tab. Select items with the existing picking/lasso/query tools and choose **Explore selection**. An empty working selection is explicitly treated as the full domain. The definition freezes canonical membership, embeddings, context, features and budgets. Visibility, render caps and observer motion never change that question.

Open **shared-base** in the included small demo to see all new guide panels. Its question has 288 items; 144 anchors carry detailed geometry; feature audit distributions cover the full 288-item question. The second embedding has shuffled rows and partial identity coverage. Other saved explorations show embedding comparisons, context boundaries and frozen broad-account evaluation.

## Read the field guide

Use four questions above the map:

1. **What shape is this?** Choose a readable geometry/stability/compression measurement.
2. **What changes here?** Follow a typed source feature. Category codes use distinct named colors and no artificial scalar category height.
3. **What doesn't fit?** Map supported signed feature-to-geometry residuals.
4. **Will it predict here?** Choose a feature, retained-direction count and held-out broad/local/gain/baseline account.

Geometry profile controls the geometry lane independently while following another feature/error. Missing computations show an explicit message and neutral unavailable-point glyphs instead of retaining a misleading previous field. Geometry and model readings are separate channels, not one comprehension score.

### Observer and ribbon

Click the map for keyboard focus. **WASD moves**, **← / → turns**, **↑ / ↓ changes look distance**. Right-click places the observer in 2D. There is no mouse capture. Motion uses smoothed time-based updates; 2D navigation does not rebuild the terrain. Wheel zooms; 3D axes can be rotated by dragging.

Yellow is here; coral is ahead. The translucent map corridor shows the observation footprint. Here/ahead are projected regions, not guaranteed original-vector neighborhoods. The three profile lanes display geometry, the selected observed feature and explanation residuals simultaneously. Bands show local interquartile spread, not confidence intervals. Empty support and graph-component boundaries break traces; binary/category profiles show shares rather than treating category codes as magnitudes.

### Evidence tabs

- **Here → ahead:** three simultaneous profiles with spread ribbons.
- **Geometry in context:** all available geometry, stability, compression and route measurements, with here/ahead medians, support and deltas. Click a row to map it.
- **Shapes & spectra:** actual tangent-neighborhood PCA-3 hull/cloud, complete variance spectrum and linked regional readings.
- **Feature audit:** summary/prediction evidence, distributions and associations are separate subtabs. Full-question knownness, missingness, numeric moments/ranges/histograms and Boolean/category counts remain distinct from measured-anchor associations and local distributions. Click a feature row to follow it. Reload editable JSON category names/colors without refitting.
- **What survives scale?:** matched broad/local error curves across retained directions; choose here, ahead, kept or all measured anchors. Subtabs contain exact values/gains, validation-selected account choices and cross-region transfer losses/support. MAE is used for numeric targets; Boolean/category models use their declared Brier losses. Negative local gains remain visible. Frozen-reference explorations reuse saved transforms and models without refitting.
- **Values & deltas:** exact here/ahead means, medians, support, signed deltas, plus a separate item-value table with canonical IDs, source values, geometry and chosen model losses. Category codes are not averaged into magnitudes. Ctrl+C copies selected cells. Item tables show at most 2,000 rows and explicitly report the display limit; measurements/membership are not truncated.
- **Kept selection:** IDs and available displayed values for the explicit kept set, separate from current here/ahead attention.

## Keep and link a selection

Click a point to keep it; Shift-click adds/removes. **Keep here**, **Keep ahead**, **Keep connected extent** and **Feature query** provide explicit alternatives. A count and outlines show what is kept, including unavailable-value anchors. Unmeasured/unprojected members remain in the count and in exports. Missing values are shown with neutral crosses rather than zero.

With **Link to all open population windows** enabled, selection actions update compatible attached tabs and detached population windows. No tab switch is required, and coordinates/cameras/working selections remain untouched. **Link now** reapplies that link; feedback reports present/missing coverage per window. **Export kept** exports the entire kept membership. **Explore kept** creates a new frozen question. **Save view** and tab close preserve the observer/camera and separate kept membership; the original question remains unchanged.

## Slide filtration and resize the chart

The live slider uses actual source-distance thresholds on the frozen mutual candidate graph. Its label reports chord distance, components and eligible edges. Dragging changes component boundaries/field support without changing source measurements. It is candidate-graph H0, not full-corpus topology. **Keep connected extent** keeps the measured component nearest the observer.

Drag the splitters to resize the sidebar, map and evidence. **Expand chart** temporarily hides the guide/evidence panels; **Expand evidence** gives tables/plots the full area. **Fit map** preserves aspect and shows the full extent. **Fill viewport (crop edges)** fills the viewport by camera cropping, never by stretching coordinates. Relief, contrast, zoom, look distance, attention radius, filtration and retained dimensions remain independent controls.

## Compute / storage

**Saved** means computed results exist on disk. **Loaded** means the viewer has those results available now. Loading never fits a model or reruns an analysis. Unloading never deletes a result.

Each row offers **Compute**, **Load** or **View** as appropriate. Choose an analysis to inspect its cost; **Compute missing** computes that analysis/dependencies, while **Compute preset** completes the saved bundle. Stage, progress, completion, failure and cancellation are reported. Completed work loads for viewing after computation. Cancel is cooperative at bounded stage/batch/fold boundaries. Detailed method/provenance and numerical estimates remain available as optional inspections.

The cost preview includes question/evaluation/context counts, structural work, RAM/output estimates, nominal source payload and feature-column scans. Light/moderate/heavy is relative to the selected work budget, not a universal timing prediction. Existing generation times describe that saved scope. A full-question audit may scan large source columns even when geometry uses only a few anchors. No large-population benchmark was run.

Resident arrays remain bounded per tab (64 MB); disk cleanup is explicit and dependency-aware. Closing unused tabs limits total residency. Do not run separate CLI and GUI writers concurrently on the same workspace.

## Offline and source registration

```bash
python -m ecology.cli --workspace demo_workspace plan shared-base --instruments feature_audit
python -m ecology.cli --workspace demo_workspace generate shared-base --instruments feature_audit
python -m ecology.cli --workspace demo_workspace inspect shared-base
python -m ecology.cli --workspace demo_workspace compare shared-base shared-distorted --instrument geometry
python -m ecology.cli --workspace demo_workspace open upper-reference
```

For new workspaces, use the existing HyCompass `workspace_tool.py` to register domains/projections, then:

```bash
python -m ecology.cli --workspace YOUR_WORKSPACE register-collection items --ids arrays/item_ids.npy --groups arrays/group_ids.npy
python -m ecology.cli --workspace YOUR_WORKSPACE register-domain embedding_a items
python -m ecology.cli --workspace YOUR_WORKSPACE register-feature score items --kind numeric --values arrays/score.npy --valid arrays/score_valid.npy
```

Source columns use non-pickled NumPy arrays aligned to canonical collection rows, explicit validity, numeric/Boolean/disjoint-category types, at most 16 active features and at most 64 category codes. Unknown is distinct from zero/false/category zero. No arbitrary ETL or automatic schema inference is included. `define --membership` expects canonical collection rows; `controlled-pair` resolves shared eligible identities before comparable experiments.

Source arrays are immutable registration inputs. Explicitly re-register changes. The fast portable change sentinel checks file size and first/last 64 KiB (small files are fully hashed); edits confined to an unsampled middle can evade that sentinel without explicit registration. No full vector checksum is taken on each observer step. Relative demo dependencies support moving/extracting the workspace.

## Larger user-run recipe — not executed

Register your prepared memory-mapped population and narrow features, browse it normally, then begin with 128 anchors, 512 context rows, k=12 and geometry only. Review cost, measure a local pilot and add reconstruction/audit/stability independently. Increase question size separately from anchor/context support. A 10M × 1,024 float32 matrix alone occupies 40.96 GB; full-question audits still incur real column IO. No global exact graph or topology is required or implemented. Verify actual desktop GL behavior and RSS/storage costs on your machine before scaling.

## 0.3.0: camera, lasso, ribbons, metrics and reference

Use the mouse-tool selector above the map. **Navigate** pans on 2D left-drag and orbits on 3D left-drag. **Middle-drag** pans in either view. **Pan** makes left-drag pan either view. **Lasso** draws a freehand polygon; Shift adds and Ctrl subtracts. It selects projected visible measured anchors, through depth in 3D, rather than unmeasured corpus members or an occlusion-limited surface.

2D wheel zoom anchors at the cursor. 3D wheel zoom magnifies the camera without shrinking the mesh's world bounds. Zoomed geometry may extend beyond the viewport; pan to inspect its sides. Coordinate-box display is optional. Camera pan and observer position are independent and saved separately. Color legends occupy separate side panels, signed contrast remains symmetric, and long categorical legends scroll.

**Geometry in context → Profiles & endpoints** restores immediate line readings with numeric here/ahead medians and support; its exact table is another subtab. **Shapes & spectra** includes both neighborhoods' hulls/clouds, complete spectra and a line profile. Use its scroll area or Expand evidence for the full paired view.

**Here → ahead** now includes actual dimension ribbons: one polyline per neighbor across its local PCA coordinates. Generate **Direction ribbons** once for older saved explorations. They are not uncertainty bands or globally aligned trajectories. The upper lanes retain descriptive local spread bands. Drag their separator to resize them independently.

**Feature audit → Regression probes / Classification probes** shows standard held-out metrics and raw sample counts in metric-specific colors. Generate **Held-out probe metrics** to replay the saved reconstruction models. Existing models are not refitted; missing reconstruction is an explicit prerequisite calculation. The retained-direction control selects the displayed dimension. Regression uses MAE, RMSE, R2 and a training-mean baseline. Boolean/category probabilities use accuracy, balanced accuracy, observed-class macro F1, AUC when defined, log loss and the declared Brier convention. Broad/regional rows use matched finite held-out anchors. There is no mixed-target aggregate quality score.

**What survives scale?** has a draggable divider between curves and tables. **Values & deltas** filters summaries by family/feature; item values have separate overview, geometry, source and reconstruction column families.

Open **Reference / help**, or **Help → Atlas / model reference (F1)**, for the offline searchable reference covering controls, units, methods, standard metrics, color scales, scopes and unsupported cases. The local source is `ecology/atlas_reference.html`.

```bash
python -m ecology.cli --workspace demo_workspace generate shared-base --instruments directions probe_metrics
```
