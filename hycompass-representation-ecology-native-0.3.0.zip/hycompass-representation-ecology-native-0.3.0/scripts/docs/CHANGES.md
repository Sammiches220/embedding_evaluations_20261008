# Changes from the first Context Builder implementation

1. `export_openapi.py` accepts `--public-output` and writes an identical static copy.
2. The Context Builder fetches `../assets/generated/openapi.json` instead of the
   OpenAPI plugin's source path.
3. `serve_docs.sh` generates both schema copies before starting `mkdocs serve` on
   `127.0.0.1:8678`.
4. `build_docs.sh` generates both copies and, after MkDocs finishes, explicitly
   restores `docs_generated/site/openapi/openapi.json` for static hosting.
5. Error text now points to the published static asset and the serving script.
