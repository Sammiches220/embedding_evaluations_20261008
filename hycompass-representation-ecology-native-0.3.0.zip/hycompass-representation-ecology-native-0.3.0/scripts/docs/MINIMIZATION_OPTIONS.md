# Context minimization choices

## Python

Implemented reductions are chosen to be understandable and independently selectable for prompt construction:

- **Comments:** located by Python `tokenize`, not regex.
- **Docstrings:** located as the first string-expression in module/class/function bodies via `ast`.
- **Main guards:** top-level `if __name__ == "__main__"` blocks located via `ast`.
- **Whitespace:** trailing whitespace trimming and repeated-blank-line collapse.
- **Signature/outline mode:** AST-derived representation retaining signatures, decorators, classes, annotations, compact assignments, and optional imports/docstrings while replacing function bodies with `...`.
- **Visibility:** outline mode can include or exclude single-underscore private definitions while retaining protocol/dunder methods.

Deliberately not implemented as generic source-minification toggles:

- removing type annotations from executable source;
- pruning imports from full source based on guessed usage;
- deleting constants or assignment values from full source;
- identifier renaming;
- indentation/token whitespace minification.

Those transformations can substantially alter Python runtime semantics or make the context harder to reason about. Import removal and assignment compaction are available only in the non-executable AST outline representation where that tradeoff is explicit.

## Markdown

Implemented reductions focus on presentation overhead while retaining useful hierarchy:

- front matter;
- HTML comments;
- raw HTML tags;
- image destinations, with optional alt-text retention;
- link destinations/reference definitions while retaining visible labels;
- fenced code blocks;
- MkDocs admonition wrapper syntax while retaining title/body content;
- heading attribute lists;
- horizontal rules;
- pipe-table padding;
- repeated blank lines and trailing whitespace.

Deliberately retained by default or left without generic stripping controls:

- heading hierarchy;
- list/numbering structure;
- emphasis markers;
- inline code;
- footnote content;
- blockquote content.

Their token savings are usually small relative to their semantic/structural value. The transformer is conservative around fenced code and does not claim to be a complete CommonMark parser.
