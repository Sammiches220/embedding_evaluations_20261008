from __future__ import annotations

import argparse
import ast
import io
import json
import tokenize
from copy import deepcopy
from pathlib import Path
from typing import Iterable

import pathspec


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DOCS_ROOT = PROJECT_ROOT / "docs_src"
GITIGNORE_PATH: Path | None = PROJECT_ROOT / ".gitignore"

# Keep this aligned with generate_python_reference.py so the Python context
# generator exposes the same importable project surface as the Python reference.
EXCLUDED_PATHS = {
    Path(".git"),
    Path(".github"),
    Path(".idea"),
    Path(".mypy_cache"),
    Path(".pytest_cache"),
    Path(".ruff_cache"),
    Path(".venv"),
    Path("build"),
    Path("dist"),
    Path("docs_generated"),
    Path("docs_src"),
    Path("site"),
    Path("tests"),
    Path("venv"),
}


Span = list[int]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate browser-readable source manifests for the documentation context generators."
    )
    parser.add_argument(
        "--project-root",
        type=Path,
        default=PROJECT_ROOT,
        help="Project root to inspect.",
    )
    parser.add_argument(
        "--python-output",
        type=Path,
        default=DOCS_ROOT / "assets/generated/python_context.json",
        help="Generated Python source manifest.",
    )
    parser.add_argument(
        "--markdown-output",
        type=Path,
        default=DOCS_ROOT / "assets/generated/markdown_context.json",
        help="Generated Markdown source manifest.",
    )
    return parser.parse_args()


def _load_gitignore(root: Path) -> pathspec.PathSpec | None:
    path = root / ".gitignore"
    if not path.is_file():
        return None
    return pathspec.PathSpec.from_lines(
        "gitwildmatch",
        path.read_text(encoding="utf-8").splitlines(),
    )


def _is_explicitly_excluded(path: Path, root: Path) -> bool:
    relative = path.relative_to(root)
    return any(relative == excluded or excluded in relative.parents for excluded in EXCLUDED_PATHS)


def _is_gitignored(path: Path, *, root: Path, spec: pathspec.PathSpec | None) -> bool:
    if spec is None:
        return False
    relative = path.relative_to(root).as_posix()
    if path.is_dir():
        relative += "/"
    return spec.match_file(relative)


def _is_excluded(path: Path, *, root: Path, gitignore: pathspec.PathSpec | None) -> bool:
    return _is_explicitly_excluded(path, root) or _is_gitignored(
        path,
        root=root,
        spec=gitignore,
    )


def _public_package_roots(root: Path, gitignore: pathspec.PathSpec | None) -> list[Path]:
    return sorted(
        (
            child
            for child in root.iterdir()
            if child.is_dir()
            and not _is_excluded(child, root=root, gitignore=gitignore)
            and not child.name.startswith((".", "_"))
            and (child / "__init__.py").is_file()
        ),
        key=lambda path: path.name.casefold(),
    )


def _python_files(
    package_roots: Iterable[Path],
    *,
    root: Path,
    gitignore: pathspec.PathSpec | None,
) -> list[Path]:
    files: list[Path] = []
    for package_root in package_roots:
        for path in package_root.rglob("*.py"):
            relative = path.relative_to(package_root)
            if _is_excluded(path, root=root, gitignore=gitignore):
                continue
            if path.name == "__main__.py":
                continue
            if any(part.startswith("_") for part in relative.parts[:-1]):
                continue
            if path.name.startswith("_") and path.name != "__init__.py":
                continue
            files.append(path)
    return sorted(files, key=lambda path: path.as_posix().casefold())


def _module_name(path: Path, root: Path) -> str:
    relative = path.relative_to(root).with_suffix("")
    parts = list(relative.parts)
    if parts and parts[-1] == "__init__":
        parts.pop()
    return ".".join(parts)


def _token_comment_spans(source: str) -> list[Span]:
    spans: list[Span] = []
    try:
        tokens = tokenize.generate_tokens(io.StringIO(source).readline)
        for token in tokens:
            if token.type == tokenize.COMMENT:
                (start_line, start_col) = token.start
                (end_line, end_col) = token.end
                spans.append([start_line, start_col, end_line, end_col])
    except (tokenize.TokenError, IndentationError):
        return []
    return spans


def _byte_column_to_char_column(line: str, byte_column: int) -> int:
    prefix = line.encode("utf-8")[:byte_column]
    return len(prefix.decode("utf-8", errors="ignore"))


def _node_span(node: ast.AST, source_lines: list[str]) -> Span | None:
    lineno = getattr(node, "lineno", None)
    col_offset = getattr(node, "col_offset", None)
    end_lineno = getattr(node, "end_lineno", None)
    end_col_offset = getattr(node, "end_col_offset", None)
    if None in (lineno, col_offset, end_lineno, end_col_offset):
        return None

    start_line_text = source_lines[lineno - 1] if lineno - 1 < len(source_lines) else ""
    end_line_text = source_lines[end_lineno - 1] if end_lineno - 1 < len(source_lines) else ""
    return [
        lineno,
        _byte_column_to_char_column(start_line_text, col_offset),
        end_lineno,
        _byte_column_to_char_column(end_line_text, end_col_offset),
    ]


def _docstring_nodes(tree: ast.AST) -> list[ast.Expr]:
    result: list[ast.Expr] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        body = getattr(node, "body", None) or []
        if not body:
            continue
        first = body[0]
        if (
            isinstance(first, ast.Expr)
            and isinstance(first.value, ast.Constant)
            and isinstance(first.value.value, str)
        ):
            result.append(first)
    return result


def _main_guard_nodes(tree: ast.AST) -> list[ast.If]:
    result: list[ast.If] = []
    for node in getattr(tree, "body", []):
        if not isinstance(node, ast.If):
            continue
        test = node.test
        if not isinstance(test, ast.Compare) or len(test.ops) != 1 or len(test.comparators) != 1:
            continue
        if not isinstance(test.ops[0], ast.Eq):
            continue
        left, right = test.left, test.comparators[0]
        pairs = [(left, right), (right, left)]
        if any(
            isinstance(a, ast.Name)
            and a.id == "__name__"
            and isinstance(b, ast.Constant)
            and b.value == "__main__"
            for a, b in pairs
        ):
            result.append(node)
    return result


def _is_public_name(name: str) -> bool:
    if name == "__all__":
        return True
    if name.startswith("__") and name.endswith("__"):
        return True
    return not name.startswith("_")


def _is_docstring_expr(node: ast.stmt) -> bool:
    return (
        isinstance(node, ast.Expr)
        and isinstance(node.value, ast.Constant)
        and isinstance(node.value.value, str)
    )


def _compact_assignment(node: ast.Assign | ast.AnnAssign) -> ast.Assign | ast.AnnAssign:
    result = deepcopy(node)
    value = getattr(result, "value", None)
    if value is None:
        return result
    try:
        rendered = ast.unparse(value)
    except Exception:
        rendered = ""
    if len(rendered) > 160 or "\n" in rendered:
        result.value = ast.Constant(value=Ellipsis)
    return result


def _outline_statement(
    node: ast.stmt,
    *,
    include_private: bool,
    include_docstrings: bool,
    include_imports: bool,
) -> ast.stmt | None:
    if isinstance(node, (ast.Import, ast.ImportFrom)):
        return deepcopy(node) if include_imports else None

    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        if not include_private and not _is_public_name(node.name):
            return None
        result = deepcopy(node)
        body: list[ast.stmt] = []
        if include_docstrings and node.body and _is_docstring_expr(node.body[0]):
            body.append(deepcopy(node.body[0]))
        body.append(ast.Expr(value=ast.Constant(value=Ellipsis)))
        result.body = body
        return result

    if isinstance(node, ast.ClassDef):
        if not include_private and not _is_public_name(node.name):
            return None
        result = deepcopy(node)
        body: list[ast.stmt] = []
        for index, child in enumerate(node.body):
            if index == 0 and _is_docstring_expr(child):
                if include_docstrings:
                    body.append(deepcopy(child))
                continue
            outlined = _outline_statement(
                child,
                include_private=include_private,
                include_docstrings=include_docstrings,
                include_imports=include_imports,
            )
            if outlined is not None:
                body.append(outlined)
        if not body:
            body.append(ast.Expr(value=ast.Constant(value=Ellipsis)))
        result.body = body
        return result

    if isinstance(node, (ast.Assign, ast.AnnAssign)):
        names: list[str] = []
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        for target in targets:
            if isinstance(target, ast.Name):
                names.append(target.id)
        if names and (include_private or any(_is_public_name(name) for name in names)):
            return _compact_assignment(node)
        return None

    return None


def _build_outline(
    tree: ast.Module,
    *,
    include_private: bool,
    include_docstrings: bool,
    include_imports: bool,
) -> str:
    body: list[ast.stmt] = []
    for index, node in enumerate(tree.body):
        if index == 0 and _is_docstring_expr(node):
            if include_docstrings:
                body.append(deepcopy(node))
            continue
        outlined = _outline_statement(
            node,
            include_private=include_private,
            include_docstrings=include_docstrings,
            include_imports=include_imports,
        )
        if outlined is not None:
            body.append(outlined)
    module = ast.Module(body=body, type_ignores=[])
    ast.fix_missing_locations(module)
    return ast.unparse(module).rstrip() + ("\n" if body else "")


def _python_record(path: Path, root: Path) -> dict[str, object]:
    source = path.read_text(encoding="utf-8")
    relative = path.relative_to(root).as_posix()
    record: dict[str, object] = {
        "path": relative,
        "module": _module_name(path, root),
        "package": relative.split("/", 1)[0],
        "source": source,
        "bytes": len(source.encode("utf-8")),
        "lines": source.count("\n") + (0 if source.endswith("\n") or not source else 1),
        "comments": _token_comment_spans(source),
        "docstrings": [],
        "mainGuards": [],
        "outlines": {},
        "parseError": None,
    }

    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError as exc:
        record["parseError"] = f"{exc.msg} (line {exc.lineno})"
        return record

    source_lines = source.splitlines()
    record["docstrings"] = [
        span
        for node in _docstring_nodes(tree)
        if (span := _node_span(node, source_lines)) is not None
    ]
    record["mainGuards"] = [
        span
        for node in _main_guard_nodes(tree)
        if (span := _node_span(node, source_lines)) is not None
    ]

    outlines: dict[str, str] = {}
    for private_key, include_private in (("public", False), ("all", True)):
        for docs_key, include_docstrings in (("docs", True), ("nodocs", False)):
            for imports_key, include_imports in (("imports", True), ("noimports", False)):
                key = f"{private_key}_{docs_key}_{imports_key}"
                outlines[key] = _build_outline(
                    tree,
                    include_private=include_private,
                    include_docstrings=include_docstrings,
                    include_imports=include_imports,
                )
    record["outlines"] = outlines
    return record


def build_python_manifest(root: Path) -> dict[str, object]:
    gitignore = _load_gitignore(root)
    packages = _public_package_roots(root, gitignore)
    files = _python_files(packages, root=root, gitignore=gitignore)
    return {
        "version": 1,
        "kind": "python",
        "sourceRoot": ".",
        "files": [_python_record(path, root) for path in files],
    }


def _markdown_title(source: str, fallback: str) -> str:
    in_fence: str | None = None
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            marker = stripped[:3]
            in_fence = None if in_fence == marker else (marker if in_fence is None else in_fence)
            continue
        if in_fence is not None:
            continue
        if stripped.startswith("# "):
            title = stripped[2:].strip()
            if title:
                return title
    return fallback


def build_markdown_manifest(root: Path) -> dict[str, object]:
    docs_root = root / "docs_src"
    files: list[dict[str, object]] = []
    if docs_root.is_dir():
        for path in sorted(docs_root.rglob("*.md"), key=lambda item: item.as_posix().casefold()):
            source = path.read_text(encoding="utf-8")
            relative = path.relative_to(docs_root).as_posix()
            files.append(
                {
                    "path": relative,
                    "group": relative.split("/", 1)[0] if "/" in relative else "Root",
                    "title": _markdown_title(source, path.stem),
                    "source": source,
                    "bytes": len(source.encode("utf-8")),
                    "lines": source.count("\n") + (0 if source.endswith("\n") or not source else 1),
                }
            )
    return {
        "version": 1,
        "kind": "markdown",
        "sourceRoot": "docs_src",
        "files": files,
    }


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )


def main() -> None:
    args = parse_args()
    root = args.project_root.resolve()
    python_manifest = build_python_manifest(root)
    markdown_manifest = build_markdown_manifest(root)
    _write_json(args.python_output, python_manifest)
    _write_json(args.markdown_output, markdown_manifest)
    print(f"Wrote Python context manifest to {args.python_output.resolve()}")
    print(f"  {len(python_manifest['files'])} Python files")
    print(f"Wrote Markdown context manifest to {args.markdown_output.resolve()}")
    print(f"  {len(markdown_manifest['files'])} Markdown files")


if __name__ == "__main__":
    main()
