from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUTPUT = PROJECT_ROOT / "docs_src/openapi/openapi.json"
DEFAULT_PUBLIC_OUTPUT = PROJECT_ROOT / "docs_src/assets/generated/openapi.json"

# Allow imports such as `from api.server import create_app` regardless of the
# directory from which this script is invoked.
sys.path.insert(0, str(PROJECT_ROOT))

from api.server import create_app


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Export HyCompass OpenAPI without starting the runtime."
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
        help="Canonical OpenAPI JSON path used by the documentation plugin.",
    )
    parser.add_argument(
        "--public-output",
        type=Path,
        default=DEFAULT_PUBLIC_OUTPUT,
        help=(
            "Static OpenAPI JSON copy published by MkDocs for browser-side tools "
            "such as the API Context Builder."
        ),
    )
    return parser.parse_args()


def write_json(path: Path, text: str) -> None:
    """Write generated JSON, creating parent directories as necessary."""
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def main() -> None:
    args = parse_args()

    # Route registration and schema generation do not execute request handlers,
    # so no live workspace/session/runtime is necessary.
    app = create_app(session=None, runtime=None)
    schema = app.openapi()

    # Serialize exactly once so the plugin input and browser-visible copy are
    # byte-for-byte identical.
    text = json.dumps(schema, indent=2, ensure_ascii=False) + "\n"

    output = args.output.resolve()
    public_output = args.public_output.resolve()

    write_json(output, text)
    print(f"Wrote canonical OpenAPI schema to {output}")

    if public_output != output:
        write_json(public_output, text)
        print(f"Wrote public OpenAPI schema to {public_output}")


if __name__ == "__main__":
    main()
