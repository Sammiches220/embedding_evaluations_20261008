#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"

CANONICAL_OPENAPI="$PROJECT_ROOT/docs_src/openapi/openapi.json"
PUBLIC_OPENAPI="$PROJECT_ROOT/docs_src/assets/generated/openapi.json"
PYTHON_CONTEXT="$PROJECT_ROOT/docs_src/assets/generated/python_context.json"
MARKDOWN_CONTEXT="$PROJECT_ROOT/docs_src/assets/generated/markdown_context.json"

cd "$PROJECT_ROOT"

echo "Generating OpenAPI contract..."
python "$SCRIPT_DIR/export_openapi.py" \
    --output "$CANONICAL_OPENAPI" \
    --public-output "$PUBLIC_OPENAPI"

echo "Generating Python and Markdown context manifests..."
python "$SCRIPT_DIR/generate_context_assets.py" \
    --project-root "$PROJECT_ROOT" \
    --python-output "$PYTHON_CONTEXT" \
    --markdown-output "$MARKDOWN_CONTEXT"

echo "Serving combined documentation at http://127.0.0.1:8678/ ..."
python -m mkdocs serve \
    -f "$SCRIPT_DIR/mkdocs.yml" \
    -a 127.0.0.1:8678
