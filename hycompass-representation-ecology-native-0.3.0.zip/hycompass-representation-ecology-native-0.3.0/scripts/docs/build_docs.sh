#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"

CANONICAL_OPENAPI="$PROJECT_ROOT/docs_src/openapi/openapi.json"
PUBLIC_OPENAPI="$PROJECT_ROOT/docs_src/assets/generated/openapi.json"
PYTHON_CONTEXT="$PROJECT_ROOT/docs_src/assets/generated/python_context.json"
MARKDOWN_CONTEXT="$PROJECT_ROOT/docs_src/assets/generated/markdown_context.json"
SITE_OPENAPI="$PROJECT_ROOT/docs_generated/site/openapi/openapi.json"

cd "$PROJECT_ROOT"

echo "Generating OpenAPI contract..."
python "$SCRIPT_DIR/export_openapi.py" \
    --output "$CANONICAL_OPENAPI" \
    --public-output "$PUBLIC_OPENAPI"

echo "Generating Python and Markdown context manifests..."
python "$SCRIPT_DIR/generate_context_assets.py" \
    --project-root "$PROJECT_ROOT" \
    --python-output "$PYTHON_CONTEXT" \
    --markdown-output "$MARKDOWN_CONTEXT"

echo "Building combined documentation..."
python -m mkdocs build \
    --clean \
    -f "$SCRIPT_DIR/mkdocs.yml"

# The OpenAPI MkDocs plugin consumes the canonical source document and may not
# publish that exact source path. Restore it explicitly for static hosting so
# /openapi/openapi.json remains a valid raw-contract URL in the built site.
mkdir -p "$(dirname -- "$SITE_OPENAPI")"
cp "$CANONICAL_OPENAPI" "$SITE_OPENAPI"

echo
echo "Documentation built:"
echo "  $PROJECT_ROOT/docs_generated/site/index.html"
echo "Raw OpenAPI contract:"
echo "  $SITE_OPENAPI"
echo "Context generator assets:"
echo "  $PROJECT_ROOT/docs_generated/site/assets/generated/"
