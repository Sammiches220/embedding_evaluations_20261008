# HyCompass Context Generators

This patch expands the original OpenAPI Context Builder into a top-level **Context Generators** documentation tab with three independent static tools:

1. **OpenAPI** — semantic OpenAPI subset selection with recursive `$ref` closure.
2. **Python** — module/file selection from the same importable source surface used by the Python Reference.
3. **Markdown** — file/folder selection across every physical `.md` source under `docs_src/`.

The normal OpenAPI reference, Python Reference, and Markdown documentation remain authoritative. The context tools only consume generated static manifests and produce copy/download output in the browser.

## Build flow

Both `scripts/docs/build_docs.sh` and `scripts/docs/serve_docs.sh` now run:

```text
app.openapi()
    -> docs_src/openapi/openapi.json
    -> docs_src/assets/generated/openapi.json

project Python packages
    -> docs_src/assets/generated/python_context.json

docs_src/**/*.md
    -> docs_src/assets/generated/markdown_context.json

MkDocs
    -> docs_generated/site/
```

Because all three browser inputs are normal files beneath `docs_src/assets/generated/`, `mkdocs serve` exposes them and a GitHub Pages build publishes them as ordinary static assets.

## Python minimization strategy

`generate_context_assets.py` uses Python's own parsing facilities rather than regexes:

- comments are located with `tokenize`;
- module/class/function docstrings are identified with `ast`;
- top-level `if __name__ == "__main__"` blocks are identified with `ast`;
- the public/signature representation is generated from an AST copy with function bodies replaced by `...`.

Available browser options include:

- source vs signatures/outline representation;
- remove comments;
- remove docstrings;
- remove `__main__` guards;
- collapse blank lines;
- trim trailing whitespace;
- include/exclude private definitions in outline mode;
- include/exclude imports in outline mode;
- include file-boundary markers.

Presets:

- **Balanced implementation** — source, comments removed, docstrings retained.
- **Compact implementation** — source, comments and docstrings removed.
- **Public API surface** — public AST outline with imports/docstrings and function bodies replaced by ellipses.
- **Full source** — faithful selected source.

The generated output is prompt context, not a source-rewriting format. In particular, the outline representation is intentionally non-round-trippable.

## Markdown minimization strategy

The Markdown transformer protects fenced code from unrelated inline transformations and provides independent controls for:

- front matter;
- HTML comments;
- raw HTML tags;
- image targets, with a separate option to retain or remove alt text;
- link destinations while retaining labels;
- fenced code blocks;
- MkDocs admonition wrapper syntax while retaining body/title text;
- heading attribute lists;
- horizontal rules;
- compact pipe tables;
- repeated blank lines;
- trailing whitespace;
- file boundaries.

Presets:

- **Balanced documentation** — keeps prose/code/tables but removes common source/presentation overhead.
- **Prose focused** — omits fenced code and presentation markup.
- **Minimal text** — aggressive text-oriented prompt context.
- **Full Markdown source** — selected source with no minimization.

The Markdown transformation intentionally does not attempt to be a complete CommonMark parser. It is conservative around fenced code and avoids transformations whose token savings are small relative to the risk of changing meaning, such as stripping emphasis or heading hierarchy.


## Static-hosting visibility

The Python and Markdown tools are client-side, so their generated manifests contain the source text needed by the browser. A public GitHub Pages deployment therefore makes those manifest contents public. This is normally harmless for a public repository, but a public docs site must not publish `python_context.json` from a private codebase. The Markdown manifest likewise includes physical `.md` files even when they are not linked in MkDocs navigation.

## Navigation

With Material's `navigation.tabs` enabled, the new top-level section becomes its own tab:

```text
Context Generators
  Overview
  OpenAPI
  Python
  Markdown
```

The old `api/context_builder.md` remains as a compatibility page but is no longer in the REST API navigation.

## Files added or changed

```text
scripts/docs/
  build_docs.sh
  serve_docs.sh
  generate_context_assets.py
  mkdocs.yml

docs_src/context_generators/
  index.md
  openapi.md
  python.md
  markdown.md

docs_src/assets/javascripts/
  api_context_builder.js
  python_context_builder.js
  markdown_context_builder.js

docs_src/assets/stylesheets/
  context_generators.css
```

`export_openapi.py` and `generate_python_reference.py` are retained from the previous implementation.
