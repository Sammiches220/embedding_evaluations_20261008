# Changes from API Context Builder v2

- Moved context tooling into a top-level **Context Generators** MkDocs tab.
- Moved the OpenAPI tool to `context_generators/openapi.md` while retaining the old API page as a compatibility link.
- Added a Python context generator using the same package/file discovery model as the generated Python Reference.
- Added tokenizer-derived Python comment spans, AST-derived docstring/main-guard spans, and AST-generated signature outlines.
- Added Python presets for balanced source, compact source, public API surface, and full source.
- Added a Markdown context generator over all physical `docs_src/**/*.md` files.
- Added Markdown presets and independent minimization controls for front matter, comments, links, images, code, admonitions, HTML, tables, attributes, separators, and whitespace.
- Added `generate_context_assets.py` to produce static browser manifests before MkDocs runs.
- Updated both `build_docs.sh` and `serve_docs.sh` so all context manifests are available under MkDocs development serving and GitHub Pages/static builds.
- Replaced the API-specific stylesheet registration with shared Context Generator styling and registered the Python/Markdown browser scripts.
