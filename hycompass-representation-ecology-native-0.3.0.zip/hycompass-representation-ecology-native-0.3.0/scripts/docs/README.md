# HyCompass API Context Builder — updated static-hosting implementation

This version keeps the Context Builder as a browser-side consumer of the canonical
OpenAPI contract while making the schema available consistently under both
`mkdocs serve` and static/GitHub Pages builds.

## Why the previous version failed under `mkdocs serve`

The OpenAPI documentation plugin consumes `docs_src/openapi/openapi.json` as an
input. That source file is not guaranteed to be emitted as a normal static MkDocs
asset. The Context Builder therefore must not fetch the plugin input path directly.

## Generated OpenAPI files

`export_openapi.py` now writes the same serialized schema to two source locations:

- `docs_src/openapi/openapi.json` — canonical plugin input.
- `docs_src/assets/generated/openapi.json` — browser-visible static asset.

The Context Builder fetches:

```text
../assets/generated/openapi.json
```

from `api/context_builder.html`. Because this is a relative URL, it works under:

- `http://127.0.0.1:8678/` from `mkdocs serve`;
- GitHub Pages project sites such as `https://owner.github.io/repository/`;
- other static HTTP hosting under a non-root base path.

For a production build, `build_docs.sh` also copies the canonical source to:

```text
docs_generated/site/openapi/openapi.json
```

This preserves a direct raw-contract URL even if the OpenAPI MkDocs plugin consumes
rather than publishes its source document.

## Development server

Run:

```bash
./scripts/docs/serve_docs.sh
```

This regenerates both OpenAPI source files and launches MkDocs at:

```text
http://127.0.0.1:8678/
```

The API Context Builder is available at:

```text
http://127.0.0.1:8678/api/context_builder.html
```

The exporter runs once when the shell script starts. Restart `serve_docs.sh` after
changing API routes or Pydantic/OpenAPI models if you need the schema regenerated.
Ordinary Markdown/CSS/JavaScript changes continue to use MkDocs' normal live reload.

## Static / GitHub Pages build

Run:

```bash
./scripts/docs/build_docs.sh
```

The relevant output is:

```text
docs_generated/site/
├── api/
│   └── context_builder.html
├── assets/
│   └── generated/
│       └── openapi.json
└── openapi/
    └── openapi.json
```

The `assets/generated/openapi.json` copy is what the Context Builder consumes. The
`openapi/openapi.json` copy is retained as a convenient raw-contract URL.

## Files changed

- `scripts/docs/export_openapi.py`
- `scripts/docs/build_docs.sh`
- `scripts/docs/serve_docs.sh` (new)
- `docs_src/api/context_builder.md`
- `docs_src/assets/javascripts/api_context_builder.js`

The Context Builder filtering, presets, dependency traversal, and CSS are otherwise
unchanged.
