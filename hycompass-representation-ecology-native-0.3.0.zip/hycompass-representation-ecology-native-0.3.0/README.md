# HyCompass + Representation Ecology — native field guide 0.3.0

A single PySide6 desktop application: HyCompass population browsing plus saved, bounded Representation Ecology explorations. The supplied Representation Ecology **1.3.0** is the numerical baseline. No browser, embedded web view or separate analysis application is used for detailed interaction.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python main.py --workspace demo_workspace --exploration shared-base
```

The included 360-item demo already contains two partially overlapping, shuffled embeddings; explicit canonical item identity; narrow typed features; five reopenable explorations; native 2D/3D terrain, observer, profiles and spectra; held-out broad/local experiments; frozen-reference evaluation; comparison maps; source feature queries; incremental jobs and offline commands.

- [What changed in 0.3.0](docs_merge/RELEASE_NOTES_0.3.md)
- [What changed in 0.2.0](docs_merge/RELEASE_NOTES_0.2.md)
- [User guide and offline commands](docs_merge/USER_GUIDE.md)
- [Baseline/capability matrix and remaining gaps](docs_merge/BASELINE_CAPABILITIES.md)
- [Architecture](docs_merge/ARCHITECTURE.md)
- [Validation and measured small pilots](docs_merge/VALIDATION.md)
- [Source provenance](docs_merge/PROVENANCE.md)
- [Original population documentation](README_POPULATION.md)

This release does **not** claim full native parity with every original expert viewer tool. Feature audit distributions, associations, held-out error summaries, linked ribbon profiles and exact tables are now native. Comprehensive inferential null-test audits, interactive route-set navigation and the full expert interpretation suite remain unfinished. Optional higher-order topology is unavailable. Population OpenGL rendering requires desktop verification; detailed offscreen Qt rendering and numerical/model tests were executed. Large-scale throughput is unbenchmarked. See the matrix for exact boundaries.

Use `python -m pip install -r requirements-dev.txt` and `QT_QPA_PLATFORM=offscreen OPENBLAS_NUM_THREADS=1 python -m pytest` for the small regression suite. Native detail is CPU-rendered and intended for bounded landscapes; population rendering retains HyCompass's existing OpenGL pipeline.

New in 0.3: camera pan/zoom, 2D/3D lasso, geometry profiles with endpoint values, actual neighbor direction ribbons, paired hulls/spectra, standard color-coded ML metrics, resizable scale evidence and grouped tables. Open **Reference / help**, or **Help → Atlas / model reference (F1)**, for the searchable offline guide.
