#!/usr/bin/env python3

"""Run the Latent Observer REST/query service without the Qt visualization."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import argparse

import uvicorn

##### Internal Imports #####
from api.app import create_app
from api.runtime import RuntimeState
from model.workspace import WorkspaceSession


################################################################################
# MAIN
################################################################################
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()

    session = WorkspaceSession(args.workspace)
    runtime = RuntimeState()
    for spec in session.views():
        runtime.register_view(spec)

    uvicorn.run(
        create_app(session, runtime), 
        host=args.host, 
        port=args.port, 
        log_level="info"
    )


################################################################################
if __name__ == "__main__":
    main()
