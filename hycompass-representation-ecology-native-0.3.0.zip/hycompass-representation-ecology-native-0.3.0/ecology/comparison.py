"""Explicit controlled and changed-population comparisons on canonical rows."""
import numpy as np
from .instruments import resolve
from .store import Store


def controlled_pair(store,title,domain_a,domain_b,membership,settings):
    c=store.catalog
    if c.raw['domains'][domain_a]['collection']!=c.raw['domains'][domain_b]['collection']:raise ValueError('Different item collections')
    a,_=c.to_domain(domain_a,membership);b,_=c.to_domain(domain_b,membership);shared=np.intersect1d(a,b)
    # Invalid source vectors are explicitly excluded before resolving equal cohorts.
    good=np.ones(len(shared),bool)
    for domain in [domain_a,domain_b]:
        x=c.load(c.manifest.domains[domain].embeddings);r=c.maps(domain)[1][shared]
        for start in range(0,len(shared),1024):
            z=np.asarray(x[r[start:start+1024]]);good[start:start+len(z)] &= np.isfinite(z).all(1)&(np.linalg.norm(z,axis=1)>1e-8)
    shared=shared[good]
    cfg={**settings,'context':'selection','projection':None}
    da=store.create(title+' / '+domain_a,domain_a,shared,cfg);db=store.create(title+' / '+domain_b,domain_b,shared,cfg)
    return dict(a=da['id'],b=db['id'],requested=len(membership),shared=len(shared),excluded=len(membership)-len(shared),
                policy='Same eligible items, uniform matched anchor identities and context, shared group assignments/settings; separate original-space fits and independent PCA displays')


def compare(store,a,b,instrument='geometry'):
    da,db=store.validate(a),store.validate(b)
    if da['collection']!=db['collection']:raise ValueError('Cannot align different collections')
    aa,ma=store.artifact(a,instrument);bb,mb=store.artifact(b,instrument)
    shared,ia,ib=np.intersect1d(aa['anchor_rows'],bb['anchor_rows'],return_indices=True)
    membership_a=np.asarray(store.membership(a));membership_b=np.asarray(store.membership(b));changed=[]
    if da['domain']!=db['domain']:changed.append('embedding')
    if not np.array_equal(membership_a,membership_b):changed.append('question population')
    for k in da['settings']:
        if da['settings'][k]!=db['settings'].get(k):changed.append(k)
    fields=[]
    for name,x in aa.items():
        if name in ('anchor_rows','context_rows','regions','filtration_radii','filtration_labels','lengths','mean') or name not in bb or x.ndim!=1 or len(x)!=len(aa['anchor_rows']) or len(bb[name])!=len(bb['anchor_rows']):continue
        y=bb[name];valid=np.isfinite(x[ia])&np.isfinite(y[ib]);xa=x[ia][valid];yb=y[ib][valid]
        fields.append(dict(field=name,matched=int(valid.sum()),a_mean=float(xa.mean()) if len(xa) else None,b_mean=float(yb.mean()) if len(yb) else None,delta_b_minus_a=float((yb-xa).mean()) if len(xa) else None))
    return dict(a=a,b=b,instrument=instrument,changed_factors=changed,question_a=len(membership_a),question_b=len(membership_b),
                membership_overlap=len(np.intersect1d(membership_a,membership_b)),measured_overlap=len(shared),fields=fields,
                context_matched=bool(np.array_equal(aa.get('context_rows',[]),bb.get('context_rows',[]))),
                interpretation='Paired finite measured items only. Changed context/selection/settings confound embedding attribution; independent display coordinates are not registered.')
