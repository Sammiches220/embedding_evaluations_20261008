"""Evaluate persisted broad/local accounts without refitting on a new selection."""
import numpy as np
from .kernels.accessibility import fold_ids,labels


def evaluate_reference(ctx,store,key,token,progress):
    reference=ctx['cfg']['reference_exploration']
    if not reference:raise ValueError('Select a saved reconstruction reference in the definition')
    source=store.validate(reference);target=ctx['definition']
    if source['domain_revision']!=target['domain_revision'] or any(source['feature_revisions'].get(f)!=r for f,r in target['feature_revisions'].items()):raise ValueError('Reference embedding/feature revisions differ')
    _,meta=store.artifact(reference,'reconstruction');c=store.catalog;n=ctx['n'];x=ctx['x'][:n];rows=ctx['anchors']
    groups=c.group_values(target['collection'],rows);fold=fold_ids(groups,source['settings']['folds']);centers=np.asarray(meta['numeric']['router']['centers']);region=labels(x,centers)
    transforms={t['fold']:t for t in meta['numeric']['transforms']};outputs={};summaries=[]
    for name in target['settings']['features']:
        values,known=c.feature(name,rows);kind=c.raw['features'][name]['kind']
        qs=meta['numeric']['dimensions']
        for q in qs:
            arrays={m:np.full(n,np.nan) for m in ['broad','local','gain','baseline']}
            if kind=='numeric':
                accounts=[a for a in meta['numeric']['accounts'] if a['feature']==name and a['dimension']==q]
            else:accounts=[a for a in meta['classification_accounts'] if a['feature']==name and a['dimension']==q]
            for a in accounts:
                token.check();f=a['fold'];ix=np.flatnonzero((fold==f)&known)
                if not len(ix):continue
                t=transforms.get(f) if kind=='numeric' else a
                if t is None:continue
                z=(x[ix]-np.asarray(t['mean']))@np.asarray(t['components']).T;z=z[:,:q]
                def predict(m):
                    coef=np.asarray(m.get('coefficients',m.get('coef')));intercept=np.asarray(m.get('intercept'))
                    return z@coef.T+intercept
                bp=predict(a['broad']);lp=np.full(bp.shape,np.nan)
                for r,m in a['local'].items():
                    mask=region[ix]==int(r)
                    if mask.any():lp[mask]=predict(m)[mask]
                if kind=='numeric':
                    truth=values[ix];baseline=np.repeat(a['baseline'],len(ix));be=np.abs(truth-bp);le=np.abs(truth-lp);base=np.abs(truth-baseline)
                else:
                    if bp.ndim==1:bp=bp[:,None];lp=lp[:,None]
                    prior=np.asarray(a['prior']);truth=values[ix,None] if kind=='boolean' else np.eye(len(prior))[values[ix].astype(int)]
                    def probability(p):
                        p=np.clip(p,0,1)
                        if kind=='category':
                            sums=p.sum(1,keepdims=True);p=np.divide(p,sums,out=np.broadcast_to(prior,p.shape).copy(),where=sums>1e-12)
                            # Missing local models remain missing, never replaced by priors.
                            p[~np.isfinite(sums[:,0])]=np.nan
                        return p
                    be=np.sum((truth-probability(bp))**2,1);le=np.sum((truth-probability(lp))**2,1);base=np.sum((truth-prior)**2,1)
                for m,v in [('broad',be),('local',le),('gain',be-le),('baseline',base)]:arrays[m][ix]=v
            for m,v in arrays.items():outputs[f'{name}__q{q}__{m}']=v
            matched=np.isfinite(arrays['broad'])&np.isfinite(arrays['local'])
            summaries.append(dict(feature=name,dimension=q,n_matched=int(matched.sum()),broad=float(arrays['broad'][matched].mean()) if matched.any() else None,local=float(arrays['local'][matched].mean()) if matched.any() else None,gain=float(arrays['gain'][matched].mean()) if matched.any() else None))
    outputs['anchor_rows']=rows
    return outputs,dict(reference=reference,reference_revision=source['revision'],support=ctx['support'],summaries=summaries,
        protocol='No refitting. Evaluate each item using its group-assigned outer-fold account from saved reference. Separate embeddings cannot share coefficients.',
        scope='Reference training population remains frozen; target question/evaluation membership is separate. Adaptive exploratory evaluation.')
