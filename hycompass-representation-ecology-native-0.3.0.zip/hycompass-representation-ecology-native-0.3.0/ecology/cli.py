"""Offline and native workflows share definitions, instruments and contracts."""
import argparse
import json
from pathlib import Path
from .catalog import Catalog,clean
from .store import Store
from .instruments import REGISTRY,plan,generate
from .demo import demo
from .comparison import compare,controlled_pair


def main(argv=None):
    parser=argparse.ArgumentParser(description='HyCompass native representation ecology')
    parser.add_argument('--workspace',type=Path,default=Path('demo_workspace'))
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('demo');p.add_argument('--rows',type=int,default=360);p.add_argument('--no-generate',action='store_true')
    p=sub.add_parser('define');p.add_argument('--domain',required=True);p.add_argument('--membership',type=Path,required=True,help='Canonical collection-row .npy');p.add_argument('--settings',type=Path);p.add_argument('--title',default='Exploration')
    for cmd in ['plan','generate','inspect','open']:
        p=sub.add_parser(cmd);p.add_argument('exploration',nargs='?' if cmd=='open' else None);p.add_argument('--instruments',nargs='+',choices=list(REGISTRY),default=['geometry'])
    p=sub.add_parser('compare');p.add_argument('a');p.add_argument('b');p.add_argument('--instrument',default='geometry',choices=list(REGISTRY))
    p=sub.add_parser('controlled-pair');p.add_argument('a');p.add_argument('b');p.add_argument('--membership',type=Path,required=True);p.add_argument('--settings',type=Path);p.add_argument('--title',default='Controlled comparison')
    p=sub.add_parser('delete-artifact');p.add_argument('exploration');p.add_argument('instrument',choices=list(REGISTRY))
    p=sub.add_parser('register-collection');p.add_argument('name');p.add_argument('--ids',required=True);p.add_argument('--groups')
    p=sub.add_parser('register-domain');p.add_argument('domain');p.add_argument('collection')
    p=sub.add_parser('register-feature');p.add_argument('name');p.add_argument('collection');p.add_argument('--kind',required=True,choices=['numeric','boolean','category']);p.add_argument('--values',required=True);p.add_argument('--valid',required=True);p.add_argument('--labels');p.add_argument('--cardinality',type=int)
    args=parser.parse_args(argv)
    import numpy as np
    if args.command=='demo':print(demo(args.workspace,args.rows,not args.no_generate));return
    if args.command=='open':
        from main import main as app_main
        return app_main(['--workspace',str(args.workspace)]+(['--exploration',args.exploration] if args.exploration else []))
    if args.command.startswith('register-'):
        c=Catalog(args.workspace)
        if args.command=='register-collection':c.register_collection(args.name,args.ids,args.groups)
        elif args.command=='register-domain':c.register_domain(args.domain,args.collection)
        else:c.register_feature(args.name,args.collection,args.kind,args.values,args.valid,args.labels,args.cardinality)
        print('Registered');return
    store=Store(args.workspace)
    if args.command=='define':result=store.create(args.title,args.domain,np.load(args.membership,allow_pickle=False),json.loads(args.settings.read_text()) if args.settings else None)
    elif args.command=='plan':result=plan(store,args.exploration,args.instruments)
    elif args.command=='generate':result=generate(store,args.exploration,args.instruments,progress=lambda s,f:print(f'{s}: {f:.0%}',flush=True))
    elif args.command=='inspect':result=dict(definition=store.read(args.exploration),status=store.status(args.exploration),disk_bytes=store.disk_bytes(args.exploration))
    elif args.command=='compare':result=compare(store,args.a,args.b,args.instrument)
    elif args.command=='controlled-pair':result=controlled_pair(store,args.title,args.a,args.b,np.load(args.membership,allow_pickle=False),json.loads(args.settings.read_text()) if args.settings else {})
    else:store.delete_artifact(args.exploration,args.instrument);result='Deleted'
    print(json.dumps(clean(result),indent=2))

if __name__=='__main__':main()
