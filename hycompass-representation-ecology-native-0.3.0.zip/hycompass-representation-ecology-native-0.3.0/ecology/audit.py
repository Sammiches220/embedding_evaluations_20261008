"""Narrow typed feature audit; full question summaries, explicitly sampled relations."""
import numpy as np
from scipy.stats import spearmanr, chi2_contingency


def association(a,ak,atype,b,bk,btype):
    known=ak&bk; a=a[known];b=b[known];n=len(a)
    if n<4:return dict(n=n,value=None,method='insufficient support')
    if atype=='category' and btype=='category':
        _,ai=np.unique(a,return_inverse=True);_,bi=np.unique(b,return_inverse=True)
        table=np.zeros((ai.max()+1,bi.max()+1));np.add.at(table,(ai,bi),1)
        if min(table.shape)<2:return dict(n=n,value=None,method='Cramér V: constant category')
        value=np.sqrt(chi2_contingency(table,correction=False)[0]/n/min(table.shape[0]-1,table.shape[1]-1));method='Cramér V'
    elif atype=='category' or btype=='category':
        category,values=(a,b) if atype=='category' else (b,a);total=np.sum((values-values.mean())**2)
        value=sum(np.sum(category==code)*(values[category==code].mean()-values.mean())**2 for code in np.unique(category))/total if total>1e-15 else np.nan;method='eta² (category → numeric variation)'
    else:
        value=spearmanr(a,b).statistic if np.ptp(a)>0 and np.ptp(b)>0 else np.nan;method='Spearman rho'
    return dict(n=n,value=float(value) if np.isfinite(value) else None,method=method)


def feature_audit(ctx,store,key,token,progress):
    c=store.catalog;rows=store.membership(key);features=ctx['cfg']['features'];n=len(rows);summaries={};arrays={};anchor_columns={};batch=65536
    if not features:raise ValueError('Choose at least one source feature to audit')
    for fi,name in enumerate(features):
        spec=c.raw['features'][name];kind=spec['kind'];count=0;missing=0;mean=0.;m2=0.;low=np.inf;high=-np.inf;counts=np.zeros(spec.get('cardinality') or 2,np.int64)
        for start in range(0,n,batch):
            token.check();values,known=c.feature(name,rows[start:start+batch]);v=values[known].astype(float);missing+=len(values)-len(v)
            if len(v):
                cm=float(v.mean());delta=cm-mean;new=count+len(v);m2+=float(np.sum((v-cm)**2))+delta*delta*count*len(v)/new;mean+=delta*len(v)/new;count=new;low=min(low,float(v.min()));high=max(high,float(v.max()))
                if kind!='numeric':counts+=np.bincount(v.astype(int),minlength=len(counts))
            progress('feature audit: '+name,(fi+(start+len(values))/max(1,n))/len(features))
        record=dict(kind=kind,question_rows=n,known=count,missing=missing,known_fraction=count/max(1,n),provenance=spec['provenance'])
        if kind=='numeric':
            edges=np.linspace(low,high,25) if count and high>low else np.linspace((low if count else 0)-.5,(low if count else 0)+.5,25);hist=np.zeros(24,np.int64)
            for start in range(0,n,batch):
                token.check();values,known=c.feature(name,rows[start:start+batch]);hist+=np.histogram(values[known],edges)[0]
            record.update(mean=mean if count else None,std=np.sqrt(m2/count) if count else None,min=low if count else None,max=high if count else None,histogram=dict(edges=edges,counts=hist))
        else:record.update(counts=counts,positive_fraction=float(counts[1]/count) if count and kind=='boolean' else None)
        values,known=c.feature(name,ctx['anchors']);arrays[name+'__values']=values;arrays[name+'__known']=known;anchor_columns[name]=(values,known,kind)
        summaries[name]=record
    geo,_=store.artifact(key,'geometry');relations=[]
    for name,(values,known,kind) in anchor_columns.items():
        for metric in ['effective_dimension','radius','hidden_two','radius_dimension']:
            token.check();v=np.asarray(geo[metric]);relations.append(dict(feature=name,geometry=metric,**association(values,known,kind,v,np.isfinite(v),'numeric')))
    pairs=[]
    for i,a in enumerate(features):
        for b in features[i+1:]:
            token.check();pairs.append(dict(a=a,b=b,**association(*anchor_columns[a],*anchor_columns[b])))
    return arrays,dict(support=ctx['support'],features=summaries,geometry_associations=relations,feature_associations=pairs,
        distribution_scope='Entire frozen canonical question, including members absent from the embedding. Numeric histograms use two exact column passes; no approximate quantiles.',
        relation_scope='Measured evaluation anchors only; descriptive associations, not held-out causal or semantic evidence.',
        units='Original feature units; knownness fractions; declared association statistics')
