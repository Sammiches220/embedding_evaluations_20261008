"""Selected unchanged v1.3.0 numerical function. See docs_merge/PROVENANCE.md."""
import numpy as np
from scipy.spatial import ConvexHull,QhullError

def neighborhood_hull(lens):
    """Convex envelope of actual first-three-PC offsets; never add random jitter.

    Rank-two neighborhoods are triangulated planar envelopes. A line or a
    coincident neighborhood has no fabricated surface triangles.
    """
    points = np.asarray(lens['offsets'], dtype=float)
    centered = points - points.mean(axis=0)
    singular = np.linalg.svd(centered, compute_uv=False)
    rank = int(np.sum(singular > max(1e-12, singular[0] * 1e-6))) if len(singular) else 0
    triangles = []
    try:
        if rank >= 3:
            triangles = ConvexHull(points).simplices.tolist()
        elif rank == 2:
            # Stored coordinates are ordered principal directions.
            boundary = ConvexHull(points[:, :2]).vertices
            triangles = [[int(boundary[0]), int(boundary[i]), int(boundary[i + 1])]
                         for i in range(1, len(boundary) - 1)]
    except QhullError:
        # Exact duplicates/degeneracy remain visible as points and lines.
        triangles = []
    radius = float(np.max(np.linalg.norm(points, axis=1))) if len(points) else 0.
    return dict(vertices=points.tolist(), triangles=triangles, rank=rank, radius=radius,
                projected_variance=float(sum(lens['spectrum'][:3])),
                note='Actual PCA-3 neighbor envelope in a local frame; footprint normalized for legibility. Facet count is not dimension.')
