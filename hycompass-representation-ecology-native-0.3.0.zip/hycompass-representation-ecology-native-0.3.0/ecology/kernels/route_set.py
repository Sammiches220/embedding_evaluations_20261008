"""Selected unchanged v1.3.0 numerical function. See docs_merge/PROVENANCE.md."""
import numpy as np
from scipy.sparse.csgraph import yen

def route_set(graph, source, target, limit=12, detour=1.25, temperature=.10):
    """Entropy of enumerated simple routes, not local degree or all route entropy.

Retain up to `limit` shortest loopless routes whose cost is at most detour*best.
Softmax weights use excess cost / (temperature*best). A cap flag exposes truncation.
    """
    if source==target:
        return dict(paths=[[int(source)]],costs=[0.],probabilities=[1.],entropy_bits=0.,effective_routes=1.,capped=False,reachable=True)
    distances,predecessors=yen(graph,int(source),int(target),limit+1,directed=False,return_predecessors=True)
    if not len(distances):
        return dict(paths=[],costs=[],probabilities=[],entropy_bits=None,effective_routes=0.,capped=False,reachable=False)
    eligible=np.flatnonzero(distances<=distances[0]*detour+1e-10)
    capped=len(eligible)>limit
    keep=eligible[:limit]
    paths=[]
    for rank in keep:
        path=[int(target)]
        while path[-1]!=source:
            prev=int(predecessors[rank,path[-1]])
            if prev<0:raise RuntimeError('Invalid shortest-route predecessor.')
            path.append(prev)
        paths.append(path[::-1])
    costs=distances[keep]
    weights=np.exp(-(costs-costs[0])/max(temperature*costs[0],1e-10))
    weights/=weights.sum()
    entropy=float(-np.sum(weights*np.log(weights)))
    return dict(paths=paths,costs=costs.tolist(),probabilities=weights.tolist(),entropy_bits=entropy/np.log(2),
                effective_routes=float(np.exp(entropy)),capped=bool(capped),reachable=True,
                cost_band_sensitivity=[dict(detour=float(1+(detour-1)*factor),
                    enumerated_qualifying=int(np.sum(distances[:limit]<=distances[0]*(1+(detour-1)*factor)+1e-10)),
                    truncated=bool(len(distances)>limit and distances[limit]<=distances[0]*(1+(detour-1)*factor)+1e-10)) for factor in [.5,1.,2.]],
                scope=f'at most {limit} regional simple routes, cost <= {detour} times shortest; temperature={temperature}')
