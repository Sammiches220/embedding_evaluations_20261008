"""Selected unchanged numerical functions from supplied geometric_ecology/core.py v1.3.0. See PROVENANCE.md."""
import hashlib

import heapq

import json

import time

from collections import Counter

import numpy as np

from scipy.sparse import csr_matrix

from scipy.sparse.csgraph import connected_components, dijkstra

from sklearn.decomposition import PCA

from sklearn.neighbors import NearestNeighbors

from threadpoolctl import threadpool_limits

EPS = 1e-8

def normalize(values):
    """Reject invalid/zero rows, rather than silently changing corpus membership."""
    x = np.asarray(values, dtype=np.float64)
    if x.ndim != 2 or x.shape[1] < 2 or len(x) == 0:
        raise ValueError("Expected a nonempty numeric matrix of shape (items, dimensions>=2).")
    bad = ~np.isfinite(x).all(axis=1) | (np.linalg.norm(x, axis=1) <= EPS)
    if bad.any():
        raise ValueError(f"Invalid/zero embedding rows {np.flatnonzero(bad)[:20].tolist()}; filter explicitly and keep aligned IDs.")
    return (x / np.linalg.norm(x, axis=1, keepdims=True)).astype(np.float32)

def knn(x, k, queries=None, exclude_self=False):
    """Exact, batched search. Self is removed by ID, including tied duplicates."""
    query = x if queries is None else queries
    extra = int(exclude_self)
    if k + extra > len(x):
        raise ValueError("Not enough reference points for requested k.")
    index = NearestNeighbors(algorithm="brute", metric="euclidean", n_jobs=1).fit(x)
    ds, ns = [], []
    with threadpool_limits(limits=1):
        for start in range(0, len(query), 256):
            d, ids = index.kneighbors(query[start:start + 256], n_neighbors=k + extra)
            if exclude_self:
                out_d, out_i = [], []
                for offset, (dd, ii) in enumerate(zip(d, ids)):
                    keep = ii != start + offset
                    out_d.append(dd[keep][:k])
                    out_i.append(ii[keep][:k])
                d, ids = np.asarray(out_d), np.asarray(out_i)
            ds.append(d)
            ns.append(ids)
    return np.maximum(np.concatenate(ds), 0), np.concatenate(ns)

def local_dimension(distances):
    """Neighbor-radius log-ratio estimate; ties/duplicates return NaN.

This is a local proxy, especially unreliable with few neighbors or curvature.
The small finite-sample correction uses (k-2), rather than (k-1).
"""
    k = distances.shape[1]
    denom = np.log(np.maximum(distances[:, -1:], EPS) / np.maximum(distances[:, :-1], EPS)).sum(axis=1)
    valid = (distances[:, 0] > EPS) & (denom > EPS) & (k >= 4)
    out = np.full(len(distances), np.nan)
    out[valid] = (k - 2) / denom[valid]
    return out

def neighbor_overlap(a, b):
    """Row-wise Jaccard; both arrays refer to the same point-identity universe."""
    return np.array([len(set(x) & set(y)) / max(1, len(set(x) | set(y))) for x, y in zip(a, b)])

def sparse_graph(n, edges, weights):
    if len(edges) == 0:
        return csr_matrix((n, n), dtype=float)
    u, v = edges.T
    # Sparse graph algorithms treat absent entries as no edge; duplicates need
    # positive machine-scale weights to remain connected.
    w = np.maximum(weights, EPS)
    return csr_matrix((np.r_[w, w], (np.r_[u, v], np.r_[v, u])), shape=(n, n))

def multiscale_edges(neighbors, distances, scales):
    """Mutual kNN edges. Frequency across nested k is rank support, not stability."""
    counts, lengths = Counter(), {}
    labels = []
    n = len(neighbors)
    for k in scales:
        sets = [set(row[:k]) for row in neighbors]
        current = []
        for i, row in enumerate(neighbors[:, :k]):
            for rank, j in enumerate(row):
                j = int(j)
                if i < j and i in sets[j]:
                    edge = (i, j)
                    counts[edge] += 1
                    lengths[edge] = float(distances[i, rank])
                    current.append(edge)
        es = np.asarray(current, dtype=int).reshape(-1, 2)
        labels.append(connected_components(sparse_graph(n, es, np.ones(len(es))), directed=False)[1])
    edges = np.asarray(sorted(counts), dtype=int).reshape(-1, 2)
    return edges, np.array([lengths[tuple(e)] for e in edges]), np.array([counts[tuple(e)] / len(scales) for e in edges]), np.array(labels)

def deletion_influence(graph):
    """Exact connectivity damage on a FIXED sparse graph, in O(V+E).

Fraction of remaining same-component pairs disconnected by deleting a vertex.
Neighbors are NOT refilled: this is an ablation proxy, not full leave-one-out.
"""
    n = graph.shape[0]
    disc, low, parent = np.full(n, -1), np.zeros(n, int), np.full(n, -1)
    subtree = np.ones(n, int)
    pieces = [[] for _ in range(n)]
    result = np.zeros(n)
    clock = 0
    for root in range(n):
        if disc[root] >= 0:
            continue
        disc[root] = low[root] = clock
        clock += 1
        stack = [(root, iter(graph.indices[graph.indptr[root]:graph.indptr[root + 1]]))]
        members = [root]
        while stack:
            u, it = stack[-1]
            v = next(it, None)
            if v is not None:
                v = int(v)
                if disc[v] < 0:
                    parent[v] = u
                    disc[v] = low[v] = clock
                    clock += 1
                    members.append(v)
                    stack.append((v, iter(graph.indices[graph.indptr[v]:graph.indptr[v + 1]])))
                elif v != parent[u]:
                    low[u] = min(low[u], disc[v])
            else:
                stack.pop()
                p = parent[u]
                if p >= 0:
                    subtree[p] += subtree[u]
                    low[p] = min(low[p], low[u])
                    if low[u] >= disc[p]:
                        pieces[p].append(int(subtree[u]))
        total = len(members) - 1
        for u in members:
            parts = pieces[u] + [total - sum(pieces[u])]
            if total > 1:
                result[u] = (total * total - sum(s * s for s in parts)) / (total * (total - 1))
    return result

def route(graph, start, end, forbidden_edge=None):
    """Dijkstra with actual settled-node count and optional edge ablation."""
    n = graph.shape[0]
    if not (0 <= start < n and 0 <= end < n):
        raise ValueError("Route endpoint outside corpus.")
    distance, previous = np.full(n, np.inf), np.full(n, -1)
    distance[start] = 0
    queue, expanded = [(0.0, start)], 0
    while queue:
        cost, u = heapq.heappop(queue)
        if cost > distance[u]:
            continue
        expanded += 1
        if u == end:
            path = [end]
            while path[-1] != start:
                path.append(int(previous[path[-1]]))
            return {"path": path[::-1], "cost": cost, "expansions": expanded, "reachable": True}
        for p in range(graph.indptr[u], graph.indptr[u + 1]):
            v, weight = int(graph.indices[p]), graph.data[p]
            if forbidden_edge is not None and {u, v} == set(forbidden_edge):
                continue
            candidate = cost + weight
            if candidate < distance[v]:
                distance[v], previous[v] = candidate, u
                heapq.heappush(queue, (candidate, v))
    return {"path": [], "cost": None, "expansions": expanded, "reachable": False}
