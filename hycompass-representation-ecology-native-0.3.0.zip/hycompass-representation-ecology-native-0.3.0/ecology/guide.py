"""Offline, searchable native reference; only internal document links."""
from pathlib import Path
from PySide6.QtCore import QUrl
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLineEdit,QPushButton,QTextBrowser,QComboBox

class ReferenceDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent);self.setWindowTitle('HyCompass · atlas and model reference');self.resize(1020,820)
        layout=QVBoxLayout(self);bar=QHBoxLayout();self.topics=QComboBox()
        for title,anchor in [('Start here','start'),('Camera / resizing / lasso','camera'),('Here and ahead','attention'),('Geometry metrics','geometry'),('Dimension ribbons and hulls','ribbons'),('Regression and classification probes','probes'),('Color scales and missing evidence','colors'),('Scale and transfer','scale'),('Compute, saved, loaded','compute'),('Identity and selection','identity')]:self.topics.addItem(title,anchor)
        self.search=QLineEdit();self.search.setPlaceholderText('Find reference text…');next_button=QPushButton('Find next');bar.addWidget(self.topics);bar.addWidget(self.search,1);bar.addWidget(next_button);layout.addLayout(bar)
        self.browser=QTextBrowser();self.browser.setOpenExternalLinks(False);self.browser.setSource(QUrl.fromLocalFile(str(Path(__file__).with_name('atlas_reference.html').resolve())));layout.addWidget(self.browser)
        self.topics.currentIndexChanged.connect(lambda _:self.browser.scrollToAnchor(self.topics.currentData()));next_button.clicked.connect(self.find_next);self.search.returnPressed.connect(self.find_next)
    def find_next(self):
        if not self.browser.find(self.search.text()):self.browser.moveCursor(QTextCursor.MoveOperation.Start);self.browser.find(self.search.text())
