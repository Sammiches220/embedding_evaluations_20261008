"""Typed column predicates over canonical membership; never infer unknown=false."""
import numpy as np
from .store import Token


def query(catalog,collection,rows,feature,operator,value=None,token=None,max_output_bytes=256_000_000):
    token=token or Token();spec=catalog.raw['features'][feature]
    if spec['collection']!=collection:raise ValueError('Feature belongs to another collection')
    if operator not in ('known','unknown','eq','lt','gt'):raise ValueError('Unknown predicate operator')
    if spec['kind']=='category' and operator in ('lt','gt'):raise ValueError('Category codes are not ordinal')
    if len(rows)*8>max_output_bytes:raise ValueError('Selection output upper bound exceeds byte budget')
    result=[]
    for start in range(0,len(rows),65536):
        token.check();r=np.asarray(rows[start:start+65536]);v,known=catalog.feature(feature,r)
        if operator=='known':mask=known
        elif operator=='unknown':mask=~known
        elif operator=='eq':mask=known&(v==value)
        elif operator=='lt':mask=known&(v<value)
        else:mask=known&(v>value)
        result.append(r[mask])
    return np.concatenate(result) if result else np.empty(0,np.int64)
