"""One bounded local worker; GUI polls data, never touches widgets from worker."""
from concurrent.futures import ThreadPoolExecutor
from queue import SimpleQueue
from .store import Store,Token
from .instruments import generate

class Jobs:
    def __init__(self,root): self.root=root;self.executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='ecology');self.tasks={};self.events=SimpleQueue();self.progress={}
    def submit(self,key,names):
        if (existing:=self.tasks.get(key)) is not None and not existing[0].done():raise ValueError('This exploration already has queued/running work')
        token=Token();store=Store(self.root)
        for name in names:
            if not store.artifact_path(key,name).exists():store.set_status(key,name,status='queued')
        def run():
            try:
                def report(stage,fraction):
                    self.progress[key]=(stage,fraction);self.events.put((key,stage,fraction))
                result=generate(store,key,names,token,report)
                self.progress[key]=('complete',1.)
                self.events.put((key,'complete',result));return result
            except Exception as exc:
                self.progress[key]=('error',str(exc))
                for name in names:
                    if store.status(key).get(name,{}).get('status')=='queued':store.set_status(key,name,status='cancelled',error=str(exc))
                self.events.put((key,'error',str(exc)));raise
        future=self.executor.submit(run);self.tasks[key]=(future,token)
        future.add_done_callback(lambda f:self.tasks.pop(key,None) if self.tasks.get(key,(None,))[0] is f else None)
        return future
    def cancel(self,key):
        entry=self.tasks.get(key)
        if entry is not None:entry[1].cancel()
    def busy(self,key):
        entry=self.tasks.get(key);return entry is not None and not entry[0].done()
    def close(self):
        for f,t in list(self.tasks.values()):t.cancel()
        self.executor.shutdown(wait=False,cancel_futures=False)
