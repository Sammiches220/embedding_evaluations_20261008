"""Immutable experiment definitions, atomic artifact publication and bounded residency."""
from __future__ import annotations
from collections import OrderedDict
from pathlib import Path
import json
import os
import shutil
import threading
import uuid
import numpy as np
from .catalog import Catalog, atomic_json, digest, rows_checked, stamp, array_digest

DEFAULTS=dict(anchors=192,context_cap=768,k=12,seed=42,context='selection',dimensions=[1,2,4,8],
              folds=3,regions=3,min_train=8,repeats=3,max_ram_bytes=256_000_000,max_work=500_000_000,
              max_output_bytes=64_000_000,max_seconds=120,features=[],projection=None,reference_exploration=None,instruments=['geometry'])


class Cancelled(Exception): pass


class Token:
    def __init__(self): self.event=threading.Event(); self.deadline=None
    def cancel(self): self.event.set()
    def check(self):
        import time
        if self.event.is_set(): raise Cancelled('Cancelled at bounded checkpoint')
        if self.deadline is not None and time.monotonic()>self.deadline: raise Cancelled('Time budget reached at checkpoint')


class Residency:
    def __init__(self,max_bytes=64_000_000): self.max_bytes=max_bytes; self.cache=OrderedDict(); self.pins=set()
    @property
    def nbytes(self): return sum(v.nbytes for v in self.cache.values())
    def put(self,key,value):
        if value.nbytes>self.max_bytes: raise ValueError('Artifact exceeds residency budget')
        old=self.cache.pop(key,None); self.cache[key]=value
        while self.nbytes>self.max_bytes:
            victim=next((k for k in self.cache if k not in self.pins and k!=key),None)
            if victim is None:
                self.cache.pop(key)
                if old is not None:self.cache[key]=old
                raise ValueError('Pinned cache exceeds budget; unpin or unload')
            self.cache.pop(victim)
    def clear(self): self.cache.clear(); self.pins.clear()


class Store:
    def __init__(self,root):
        self.catalog=Catalog(root); self.root=self.catalog.root/'analyses'; self.root.mkdir(exist_ok=True)
    def folder(self,key):
        if not key or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in key): raise ValueError('Invalid exploration ID')
        return self.root/key
    def definitions(self):
        return [json.loads(p.read_text()) for p in sorted(self.root.glob('*/definition.json'))]
    def read(self,key): return json.loads((self.folder(key)/'definition.json').read_text())
    def create(self,title,domain,membership,settings=None,*,key=None):
        c=self.catalog; d=c.raw['domains'][domain]; c.validate_sources(domain)
        rows=rows_checked(membership,c.n(d['collection']))
        if not len(rows): raise ValueError('Empty question population')
        cfg={**DEFAULTS,**(settings or {})}
        if set(cfg)-set(DEFAULTS): raise ValueError('Unknown exploration settings')
        from .instruments import REGISTRY
        if not isinstance(cfg['instruments'],list) or any(n not in REGISTRY for n in cfg['instruments']):raise ValueError('Invalid instrument preset')
        for k in ['anchors','context_cap','k','folds','regions','min_train','max_ram_bytes','max_work','max_output_bytes','max_seconds']:
            if type(cfg[k]) is not int or cfg[k]<1: raise ValueError('Invalid '+k)
        if cfg['context'] not in ('selection','reference') or cfg['context_cap']<cfg['anchors'] or cfg['k']>=cfg['anchors'] or not 3<=cfg['folds']<=10 or not 1<=cfg['regions']<=32 or not 0<=cfg['repeats']<=32: raise ValueError('Invalid context, neighborhood, fold or repeat budget')
        if len(cfg['features'])>16 or any(c.raw['features'][f]['collection']!=d['collection'] for f in cfg['features']): raise ValueError('Feature collection mismatch or >16 active features')
        if not cfg['dimensions'] or len(cfg['dimensions'])>12 or any(type(q) is not int or q<1 for q in cfg['dimensions']): raise ValueError('Invalid retained dimensions')
        reference_revision=None
        if cfg['reference_exploration']:
            ref=self.validate(cfg['reference_exploration'])
            if ref['domain']!=domain:raise ValueError('Reference must use same embedding domain')
            reference_revision=ref['revision']
        key=key or uuid.uuid4().hex[:12]; folder=self.folder(key)
        if folder.exists():raise ValueError('Exploration exists; create a new definition revision')
        folder.mkdir(); np.save(folder/'membership.npy',rows)
        definition=dict(reference_revision=reference_revision,id=key,title=title,domain=domain,collection=d['collection'],membership='membership.npy',n_members=len(rows),
            membership_digest=array_digest(rows),settings=cfg,domain_revision=d['revision'],collection_revision=c.collection(d['collection'])['revision'],
            feature_revisions={f:c.raw['features'][f]['revision'] for f in cfg['features']},groups_stamp=stamp(c.resolve(c.collection(d['collection'])['groups'])) if c.collection(d['collection']).get('groups') else None,
            projection_stamp=stamp(c.resolve(c.manifest.projections[cfg['projection']].positions)) if cfg['projection'] else None)
        definition['revision']=digest(definition); atomic_json(folder/'definition.json',definition)
        atomic_json(folder/'status.json',{}); return definition
    def membership(self,key): return np.load(self.folder(key)/'membership.npy',mmap_mode='r',allow_pickle=False)
    def validate(self,key):
        d=self.read(key); c=self.catalog
        c.raw=json.loads(c.path.read_text())
        c.validate_sources(d['domain'])
        if d['settings'].get('reference_exploration'):
            ref=self.read(d['settings']['reference_exploration'])
            if ref['revision']!=d['reference_revision']:raise ValueError('Stale frozen reference')
        if d['domain_revision']!=c.raw['domains'][d['domain']]['revision'] or d['collection_revision']!=c.collection(d['collection'])['revision']:raise ValueError('Stale collection/domain revision')
        g=c.collection(d['collection']).get('groups')
        if g and d['groups_stamp']!=stamp(c.resolve(g)):raise ValueError('Stale group assignments')
        p=d['settings']['projection']
        if p and d['projection_stamp']!=stamp(c.resolve(c.manifest.projections[p].positions)):raise ValueError('Stale display coordinates')
        if array_digest(self.membership(key))!=d['membership_digest']: raise ValueError('Frozen membership was modified')
        for f,r in d['feature_revisions'].items():
            if r!=c.raw['features'][f]['revision']:raise ValueError('Stale feature registration')
            for path,s in c.raw['features'][f]['source_stamps'].items():
                if stamp(c.resolve(path))!=s:raise ValueError('Stale feature array')
        return d
    def status(self,key): return json.loads((self.folder(key)/'status.json').read_text())
    def set_status(self,key,instrument,**state):
        s=self.status(key); s[instrument]=state; atomic_json(self.folder(key)/'status.json',s)
    def artifact_path(self,key,instrument): return self.folder(key)/instrument
    def artifact(self,key,instrument):
        self.validate(key); p=self.artifact_path(key,instrument)
        meta=json.loads((p/'metadata.json').read_text())
        if meta['definition_revision']!=self.read(key)['revision']:raise ValueError('Stale artifact')
        arrays={f.stem:np.load(f,mmap_mode='r',allow_pickle=False) for f in p.glob('*.npy')}
        return arrays,meta
    def signature(self,key,instrument):
        d=self.read(key); cfg=d['settings']
        common=['anchors','context_cap','k','seed','context','projection']
        extra={'geometry':[],'reconstruction':['features','dimensions','folds','regions','min_train'],
               'discrepancy':['features','folds'],'stability':['repeats'],'routes':[],'reference_evaluation':['features','reference_exploration'],'compression':['dimensions'],'feature_audit':['features'],'directions':[],'probe_metrics':['features','dimensions','folds','regions','min_train']}[instrument]
        features=d['feature_revisions'] if instrument in ('reconstruction','discrepancy','reference_evaluation','feature_audit','probe_metrics') else {}
        return digest(dict(instrument=instrument,kernel_revision=1,membership=d['membership_digest'],domain=d['domain_revision'],
            settings={k:cfg[k] for k in common+extra},features=features,groups=d['groups_stamp'] if instrument in ('reconstruction','discrepancy','probe_metrics') else None,
            projection=d['projection_stamp']))
    def reusable(self,key,instrument):
        signature=self.signature(key,instrument)
        for d in self.definitions():
            if d['id']==key:continue
            p=self.artifact_path(d['id'],instrument)/'metadata.json'
            if not p.exists():continue
            meta=json.loads(p.read_text())
            if meta.get('result_signature')==signature:
                try:self.validate(d['id'])
                except ValueError:continue
                return d['id']
        return None
    def publish(self,key,instrument,arrays,metadata,token):
        d=self.validate(key)
        if metadata.get('origin_revision',d['revision'])!=d['revision']:raise ValueError('Stale job: definition revision changed during generation')
        temp=self.folder(key)/('.pending-'+uuid.uuid4().hex)
        temp.mkdir()
        try:
            for name,a in arrays.items(): token.check(); np.save(temp/(name+'.npy'),a,allow_pickle=False)
            atomic_json(temp/'metadata.json',{**metadata,'definition_revision':d['revision'],'result_signature':self.signature(key,instrument)})
            size=sum(p.stat().st_size for p in temp.iterdir())
            if size+self.disk_bytes(key)>d['settings']['max_output_bytes']:raise ValueError('Output byte budget exceeded')
            token.check(); self.validate(key)
            target=self.artifact_path(key,instrument)
            if target.exists():raise ValueError('Artifact already exists; explicitly delete before regeneration')
            os.replace(temp,target)
            support=metadata.get('support',{});sampled=support.get('valid_anchors',0)<support.get('question_members',0)
            self.set_status(key,instrument,status='generated_sampled' if sampled else 'generated',bytes=size,definition_revision=d['revision'],support=support)
        finally:
            if temp.exists():shutil.rmtree(temp)
    def delete_artifact(self,key,instrument):
        from .instruments import REGISTRY
        if instrument not in REGISTRY:raise ValueError('Unknown instrument')
        dependents=[n for n,s in REGISTRY.items() if instrument in s.dependencies and self.artifact_path(key,n).exists()]
        if dependents:raise ValueError('Delete dependent artifacts first: '+', '.join(dependents))
        shutil.rmtree(self.artifact_path(key,instrument),ignore_errors=True)
        self.set_status(key,instrument,status='not_generated')
    def disk_bytes(self,key):return sum(p.stat().st_size for p in self.folder(key).rglob('*') if p.is_file())
    def save_navigation(self,key,state):atomic_json(self.folder(key)/'navigation.json',state)
    def navigation(self,key):
        p=self.folder(key)/'navigation.json';return json.loads(p.read_text()) if p.exists() else {}
