"""Metric-specific colors; no cross-type aggregate quality score."""
import numpy as np
from PySide6.QtGui import QColor,QBrush


def strength_color(strength):
    strength=float(np.clip(strength,-1,1));base=np.array([28,39,52]);target=np.array([37,119,110]) if strength>=0 else np.array([139,64,70]);rgb=base+(target-base)*min(.85,abs(strength)*.85+.12)
    return QColor(*rgb.astype(int))

def scale_key_html():
    def cells(values):return ''.join(f"<td bgcolor='{strength_color(value).name()}'><font color='#ecf3fa'>&nbsp;{text}&nbsp;</font></td>" for value,text in values)
    return '<table cellspacing="2"><tr><td>Score scale:</td>'+cells([(0,'0'),(.5,'0.5'),(1,'1')])+'<td>&nbsp;R² / relative improvement:</td>'+cells([(-1,'≤ −1'),(0,'0'),(1,'≥ +1')])+'</tr></table>'

def color_metric(table,row,column,value,mode='score',baseline=None):
    if value is None or not np.isfinite(value):return
    if mode=='loss':
        strength=float(np.clip((baseline-value)/max(abs(baseline),1e-12),-1,1)) if baseline is not None and np.isfinite(baseline) and abs(baseline)>1e-12 else 0
    elif mode=='signed':strength=float(np.clip(value,-1,1))
    else:strength=float(np.clip(value,0,1))
    table.item(row,column).setBackground(QBrush(strength_color(strength)));table.item(row,column).setForeground(QBrush(QColor('#ecf3fa')))


def draw_probe_tables(panel):
    w=panel.owner;result=w.loaded.get('probe_metrics');records=result[1]['metrics'] if result else [];reg=[];classification=[];used_reg=[];used_class=[]
    for r in records:
        if r['scope']!='Matched broad/local held-out support' or r['dimension']!=int(w.dimension.currentText()):continue
        model='Broad Ridge' if r['account']=='broad' else 'Regional Ridge';start=[r['feature'],model,r['dimension'],r['n']]
        if r['kind']=='numeric':reg.append(start+[r.get(k) for k in ['mae','rmse','r2','baseline_mae','mae_gain']]);used_reg.append(r)
        else:classification.append([r['feature'],r['kind'],model,r['dimension'],r['n']]+[r.get(k) for k in ['accuracy','balanced_accuracy','macro_f1','roc_auc','log_loss','brier','baseline_brier','brier_skill']]);used_class.append(r)
    panel.regression_probes.fill(reg);panel.classification_probes.fill(classification)
    for row,r in enumerate(used_reg):
        color_metric(panel.regression_probes,row,4,r.get('mae'),'loss',r.get('baseline_mae'));color_metric(panel.regression_probes,row,6,r.get('r2'),'signed')
        if r.get('mae_gain') is not None:color_metric(panel.regression_probes,row,8,r['mae_gain']/max(1e-12,r.get('baseline_mae') or 0),'signed')
    for row,r in enumerate(used_class):
        for column,key in [(5,'accuracy'),(6,'balanced_accuracy'),(7,'macro_f1'),(8,'roc_auc')]:color_metric(panel.classification_probes,row,column,r.get(key))
        color_metric(panel.classification_probes,row,10,r.get('brier'),'loss',r.get('baseline_brier'));color_metric(panel.classification_probes,row,12,r.get('brier_skill'),'signed')
    panel.probe_legend.setText(('Matched held-out anchors · Numeric: MAE↓ RMSE↓ R²↑. Classification: accuracy↑ balanced accuracy↑ macro F1↑ AUC↑ log loss↓ Brier↓. Colors are metric-specific; gray = unavailable; skill/gain uses the training-only baseline. Macro F1 uses observed test classes. Selected dimension: '+w.dimension.currentText()) if result else 'Compute / load Held-out probe metrics for standard ML metrics from frozen reconstruction models. Existing models are replayed, not refitted. Missing reconstruction is an explicit prerequisite calculation.')
