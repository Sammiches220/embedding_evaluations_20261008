"""Full rectangular 3D viewport with isotropic projected screen units.

Stock Axes3D.apply_aspect crops its active bbox to a square. Merely magnifying
that box clips the scene early inside a wide Qt canvas. Keep the full bbox and
expand the projected viewing interval, preserving physical x/y pixel scale.
"""
from mpl_toolkits.mplot3d import Axes3D

class ViewportAxes3D(Axes3D):
    def apply_aspect(self,position=None):
        position=self.get_position(original=True) if position is None else position
        self._set_position(position,'active')
        box=position.transformed(self.get_figure().transSubfigure);ratio=box.width/max(1,box.height)
        low=-.95/self._dist;high=.9/self._dist;center=(low+high)/2;half=(high-low)/2
        self.viewLim.intervalx=(center-half*max(1,ratio),center+half*max(1,ratio))
        self.viewLim.intervaly=(center-half*max(1,1/ratio),center+half*max(1,1/ratio))
        self._pseudo_w=self.viewLim.width;self._pseudo_h=self.viewLim.height

class CameraProjection:
    def _as_mpl_axes(self):return ViewportAxes3D,{}

CAMERA_PROJECTION=CameraProjection()
