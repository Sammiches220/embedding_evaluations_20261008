"""Actual centered tangent-neighborhood PC scores, not decorative spread bands."""
import numpy as np
from threadpoolctl import threadpool_limits


def directions(ctx,store,key,token,progress):
    geometry,_=store.artifact(key,'geometry');neighbors=np.asarray(geometry['neighbors']);x=ctx['x'];n,k=neighbors.shape;rank=min(k,x.shape[1]);scores=np.empty((n,k,rank),np.float32)
    if not np.array_equal(geometry['anchor_rows'],ctx['anchors']) or not np.array_equal(geometry['context_rows'],ctx['rows']):raise ValueError('Direction ribbon context differs from saved geometry')
    for i in range(n):
        token.check();offset=x[neighbors[i]].astype(float)-x[i];offset-=(offset@x[i])[:,None]*x[i];offset-=offset.mean(0)
        with threadpool_limits(1):u,s,_=np.linalg.svd(offset,full_matrices=False)
        scores[i]=u*s[None,:]
        if i%16==0:progress('Neighbor direction ribbons',i/max(1,n))
    return dict(direction_scores=scores),dict(support=ctx['support'],units='signed centered tangent PCA scores in normalized-vector chord units',
        meaning='One ribbon per actual neighbor across all supported PCA directions. Local bases have independent signs/orientations; a ribbon is not a path between items or regions.',
        scope='Same frozen source neighborhoods as geometry; hull offsets and complete spectrum are retained separately.')
