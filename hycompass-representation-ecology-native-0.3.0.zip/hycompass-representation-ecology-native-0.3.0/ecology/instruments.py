"""Bounded native instruments; display coordinates never define analytical eligibility."""
from __future__ import annotations
from dataclasses import dataclass
import time
import numpy as np
from scipy.spatial.distance import cdist
from scipy.sparse.csgraph import connected_components
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from .catalog import clean
from .store import Token
from .kernels import geometry as g
from .kernels import accessibility as acc

@dataclass(frozen=True)
class Instrument:
    name: str
    dependencies: tuple
    units: str
    question: str

REGISTRY={
 'directions':Instrument('directions',('geometry',),'tangent PCA scores','Unfolded measured neighbor directions'),
 'probe_metrics':Instrument('probe_metrics',('reconstruction',),'standard held-out ML metrics','Re-evaluate frozen fold models without fitting'),
 'feature_audit':Instrument('feature_audit',('geometry',),'typed feature summaries and associations','Full frozen-question feature distributions and anchor-scoped relationships'),
 'geometry':Instrument('geometry',(),'chord distance; covariance variance fraction','Unit-vector neighborhoods in explicit context; mutual graph among evaluation anchors'),
 'reconstruction':Instrument('reconstruction',(),'numeric MAE; Boolean Brier; categorical multiclass Brier','Group-held-out frozen broad/local feature reconstruction'),
 'discrepancy':Instrument('discrepancy',('geometry',),'signed chord residual','Feature-account prediction of pair distances with endpoint-group holdout'),
 'stability':Instrument('stability',('geometry',),'neighbor Jaccard','Repeated coordinate perturbation and reference resampling'),
 'compression':Instrument('compression',('geometry',),'neighbor Jaccard; squared residual fraction','Declared context-fitted PCA reduction and independently measured display-neighbor distortion'),
 'reference_evaluation':Instrument('reference_evaluation',(),'numeric MAE; probability Brier','Evaluate frozen saved accounts in a new selection without refitting'),
 'routes':Instrument('routes',('geometry',),'chord path length; disconnected-pair fraction','Shortest routes and fixed-graph deletion influence'),
}


def resolve(store,key,token=None):
    token=token or Token(); d=store.validate(key); c=store.catalog; cfg=d['settings'];domain=d['domain']
    members=np.asarray(store.membership(key)); available,domain_rows=c.to_domain(domain,members)
    rng=np.random.default_rng(cfg['seed'])
    # Uniform deterministic bounded sampling, never truncate saved membership.
    anchors=np.sort(rng.choice(available,min(cfg['anchors'],len(available)),replace=False))
    if cfg['context']=='selection': pool=available
    else: pool=np.flatnonzero(c.maps(domain)[1]>=0)
    extras=np.setdiff1d(pool,anchors,assume_unique=True)
    extra=np.sort(rng.choice(extras,min(len(extras),max(0,cfg['context_cap']-len(anchors))),replace=False))
    rows=np.r_[anchors,extra]; _,inverse=c.maps(domain); erows=inverse[rows]
    vectors=c.load(c.manifest.domains[domain].embeddings)
    estimated=(len(rows)*vectors.shape[1]*16+len(anchors)*cfg['k']*vectors.shape[1]*16)
    if estimated>cfg['max_ram_bytes']:raise ValueError('Gather and tangent workspace exceed RAM budget')
    x=np.empty((len(rows),vectors.shape[1]),np.float32)
    # Sorted gathers preserve requested analytical order; byte-sized chunks.
    order=np.argsort(erows);batch=max(1,min(4096,cfg['max_ram_bytes']//max(1,vectors.shape[1]*32)))
    for start in range(0,len(rows),batch):
        token.check(); ix=order[start:start+batch]; x[ix]=vectors[erows[ix]]
    valid=np.isfinite(x).all(axis=1)&(np.linalg.norm(x,axis=1)>1e-8)
    anchor_valid=valid[:len(anchors)]; anchors=anchors[anchor_valid]
    valid_indices=np.flatnonzero(valid); x=g.normalize(x[valid]); rows=rows[valid]
    n=len(anchors)
    if n<4 or len(rows)<=cfg['k']:raise ValueError('Insufficient valid anchor/context support')
    projection=cfg['projection']; xy=np.full((n,2),np.nan,np.float32)
    if projection:
        p=c.manifest.projections[projection]
        if p.domain!=domain:raise ValueError('Projection belongs to another domain')
        xy[:]=c.load(p.positions)[inverse[anchors]]
        provenance='Original population coordinates; missing positions remain missing'
    else:
        with threadpool_limits(1):xy[:]=PCA(n_components=2,svd_solver='full').fit_transform(x[:n])
        provenance='PCA-2 fitted to normalized evaluation anchors; scoped display only'
    return dict(definition=d,cfg=cfg,x=x,rows=rows,anchors=anchors,n=n,xy=xy,
                provenance=provenance,support=dict(question_members=len(members),embedding_available=len(available),
                sampled_anchors_before_validity=int(len(anchor_valid)),valid_anchors=n,context_rows=len(rows),invalid_sampled_vectors=int((~valid).sum()),
                finite_display_anchors=int(np.isfinite(xy).all(1).sum()),context_policy=cfg['context'],sampling='uniform without replacement; seed recorded',
                metric='Euclidean chord on individually unit-normalized source vectors',scope='within selected context' if cfg['context']=='selection' else 'relative to explicitly sampled embedding reference; not corpus kNN'))


def plan(store,key,instruments=None):
    d=store.validate(key); c=store.catalog;cfg=d['settings'];v=c.load(c.manifest.domains[d['domain']].embeddings)
    membership=store.membership(key);m=len(membership);reverse=c.maps(d['domain'])[1];available=0
    for start in range(0,m,65536):available+=int(np.count_nonzero(reverse[membership[start:start+65536]]>=0))
    a=min(cfg['anchors'],available);r=min(cfg['context_cap'],available if cfg['context']=='selection' else len(v));dim=v.shape[1];f=len(cfg['features'])
    channels=sum(c.raw['features'][name].get('cardinality') or 1 for name in cfg['features'])
    names=list(instruments or REGISTRY)
    if any(n not in REGISTRY for n in names):raise ValueError('Unknown instrument')
    feature_reads=sum(m*(c.load(c.raw['features'][name]['values']).dtype.itemsize+1)*(2 if c.raw['features'][name]['kind']=='numeric' else 1) for name in cfg['features'])
    work={ 'directions':int(a*cfg['k']**2*dim),'probe_metrics':int(a*dim*len(cfg['dimensions'])*max(1,channels)*8), 'feature_audit':int(m*max(1,f)*4+a*max(1,f)**2), 'geometry':int(a*r*dim+a*cfg['k']**3+a*cfg['k']*dim),
          'reconstruction':int(cfg['folds']*r*dim*min(r,dim)+cfg['folds']*r*dim*len(cfg['dimensions'])*max(1,f)*8),
          'discrepancy':int(a*cfg['k']*max(1,f)*cfg['folds']*16),
          'stability':int(cfg['repeats']*a*r*dim*2), 'compression':int(r*dim*min(r,dim)+len(cfg['dimensions'])*a*r*max(cfg['dimensions'])),'routes':int(a*a*cfg['k']*8*5),'reference_evaluation':int(a*dim*len(cfg['dimensions'])*max(1,f)*16)}
    requested=set(names)
    for name in names:requested.update(REGISTRY[name].dependencies)
    mapping_workspace=int(m*72+(len(reverse)+len(v)*16 if cfg['context']=='reference' else 0))
    ram=int((a*cfg['k']*min(cfg['k'],dim)*4 if 'directions' in requested else 0)+(a*max(1,channels)*len(cfg['dimensions'])*24 if 'probe_metrics' in requested else 0)+(min(m,65536)*32 if 'feature_audit' in requested else 0)+mapping_workspace+r*dim*48+a*cfg['k']*dim*16+min(64,a)*r*8+min(r,dim)**2*24+r*channels*32)
    out=int(a*(cfg['k']*32+dim*4+channels*len(cfg['dimensions'])*48)+cfg['folds']*(dim*min(dim,max(cfg['dimensions']))+f*cfg['regions']*len(cfg['dimensions'])*max(cfg['dimensions']))*16+2_000_000)
    out+=int((a*cfg['k']*min(cfg['k'],dim)*4 if 'directions' in requested else 0)+(a*max(1,channels)*len(cfg['dimensions'])*12+100000 if 'probe_metrics' in requested else 0))
    reusable={n:store.reusable(key,n) for n in requested}
    total=sum(work[n] for n in requested if not store.artifact_path(key,n).exists() and not reusable[n])
    return dict(question_members=m,embedding_available=available,evaluation_anchor_cap=a,context_cap=r,dimensions=dim,features=f,
        metric='unit-normalized chord',representation='original vectors',temporary_ram_estimate_bytes=ram,membership_mapping_workspace_estimate_bytes=mapping_workspace,output_estimate_bytes=out,
        source_read_estimate_bytes=int(r*dim*v.dtype.itemsize),source_feature_read_estimate_bytes=feature_reads if 'feature_audit' in requested else 0,full_feature_column_passes=sum(2 if c.raw['features'][name]['kind']=='numeric' else 1 for name in cfg['features']) if 'feature_audit' in requested else 0,source_full_scans=0,source_access='one bounded sorted random-row gather shared within this job; OS page reads may exceed payload',
        candidate_distance_products=int(a*r*dim),work_estimates=work,total_missing_work=total,
        reusable=reusable,cached=[n for n in requested if store.artifact_path(key,n).exists()],missing=[n for n in requested if not store.artifact_path(key,n).exists()],
        over_budget=bool(ram>cfg['max_ram_bytes'] or total>cfg['max_work'] or out>cfg['max_output_bytes']),
        timing='Uncalibrated; no wall-time prediction. Kernel interruption occurs between bounded stages/batches.',
        limits=dict(ram_bytes=cfg['max_ram_bytes'],work=cfg['max_work'],output_bytes=cfg['max_output_bytes'],seconds=cfg['max_seconds']))


def nearest(x,query,k,token,exclude_ids=None):
    ids=[]; distances=[]
    for start in range(0,len(query),32):
        token.check();ds=cdist(query[start:start+32],x)
        if exclude_ids is not None:ds[np.arange(len(ds)),exclude_ids[start:start+len(ds)]]=np.inf
        ix=np.argsort(ds,axis=1,kind='stable')[:,:k]
        ids.append(ix);distances.append(np.take_along_axis(ds,ix,axis=1))
    return np.concatenate(distances),np.concatenate(ids)


def geometry(ctx,store,key,token,progress):
    x,n,cfg=ctx['x'],ctx['n'],ctx['cfg'];k=min(cfg['k'],n-1,len(x)-1)
    ds,ns=nearest(x,x[:n],k,token,np.arange(n));spectra=[];offsets=[]
    for i in range(n):
        token.check(); off=x[ns[i]].astype(float)-x[i];off-=(off@x[i])[:,None]*x[i]
        off-=off.mean(0)
        with threadpool_limits(1):u,s,_=np.linalg.svd(off,full_matrices=False)
        energy=s*s;sp=energy/max(energy.sum(),1e-15);shape=np.zeros((k,3));rank=min(3,len(s));shape[:,:rank]=u[:,:rank]*s[None,:rank]
        spectra.append(np.pad(sp,(0,max(0,k-len(sp))))[:k]);offsets.append(shape)
        if i%16==0:progress('spectra',i/n)
    spectra=np.asarray(spectra);valid=spectra.sum(1)>.5
    effective=np.divide(1,np.sum(spectra**2,1),out=np.full(n,np.nan),where=valid)
    ad,an=nearest(x[:n],x[:n],k,token,np.arange(n))
    edges,lengths,freq,_=g.multiscale_edges(an,ad,[k]); fil=acc.filtration(n,edges,lengths)
    return dict(xy=ctx['xy'],anchor_rows=ctx['anchors'],context_rows=ctx['rows'],neighbors=ns,distances=ds,
                spectrum=spectra,offsets=np.asarray(offsets),effective_dimension=effective,hidden_two=np.where(valid,1-spectra[:,:2].sum(1),np.nan),
                radius=ds[:,-1],radius_dimension=g.local_dimension(ds),edges=edges,lengths=lengths,
                filtration_labels=np.asarray([v['labels'] for v in fil['levels']]),filtration_radii=np.asarray([v['radius'] for v in fil['levels']])),dict(
                support=ctx['support'],units=REGISTRY['geometry'].units,coordinate_provenance=ctx['provenance'],
                graph_scope='Fixed maximum-k mutual graph among evaluation anchors only; local spectra use explicit larger context',filtration=fil,
                caveat='Covariance participation and radius-growth dimension are distinct proxies; no semantic knownness score')


def compression(ctx,store,key,token,progress):
    cfg=ctx['cfg'];x=ctx['x'];n=ctx['n'];geom,_=store.artifact(key,'geometry');base=np.asarray(geom['neighbors']);k=base.shape[1]
    qs=[q for q in cfg['dimensions'] if q<=min(len(x)-1,x.shape[1])]
    if not qs:raise ValueError('No retained dimension has adequate context support')
    token.check()
    with threadpool_limits(1):pca=PCA(n_components=max(qs),svd_solver='full').fit(x)
    z=pca.transform(x);total=np.sum((x[:n]-pca.mean_)**2,1);arrays=dict(anchor_rows=ctx['anchors'],context_rows=ctx['rows'],mean=pca.mean_,components=pca.components_)
    for q in qs:
        token.check();_,neighbors=nearest(z[:,:q],z[:n,:q],k,token,np.arange(n))
        arrays[f'pca_q{q}_jaccard']=g.neighbor_overlap(base,neighbors)
        arrays[f'pca_q{q}_residual_fraction']=np.maximum(0,1-np.divide(np.sum(z[:n,:q]**2,1),total,out=np.full(n,np.nan),where=total>1e-12))
    xy=ctx['xy'];finite=np.flatnonzero(np.isfinite(xy).all(1));display=np.full(n,np.nan)
    if len(finite)>k:
        _,source_ns=nearest(x[finite],x[finite],k,token,np.arange(len(finite)))
        _,display_ns=nearest(xy[finite],xy[finite],k,token,np.arange(len(finite)))
        display[finite]=g.neighbor_overlap(source_ns,display_ns)
    arrays['projection_neighbor_jaccard']=display
    return arrays,dict(support=ctx['support'],units=REGISTRY['compression'].units,
        transform='Descriptive PCA fitted to frozen normalized context, not a held-out decoder; unrenormalized retained coordinates preserve chord units',
        projection='Source/display neighbor overlap among finite-display evaluation anchors only, with identical candidates. Missing display coordinates remain unavailable.',
        distinction='Projection-neighbor distortion, discarded vector energy, feature discrepancy and held-out reconstruction are separate channels.')


def reconstruction(ctx,store,key,token,progress):
    cfg=ctx['cfg'];rows=ctx['rows'];x=ctx['x'];c=store.catalog;d=ctx['definition'];n=ctx['n']
    targets={};target_specs={};category_sets={}
    for name in cfg['features']:
        values,known=c.feature(name,rows);spec=c.raw['features'][name];kind=spec['kind']; target_specs[name]=spec
        if kind=='category':
            names=[]
            for code in range(spec['cardinality']):
                target=f'{name}__class{code}';targets[target]=np.where(known,(values==code).astype(float),np.nan);names.append(target)
            category_sets[name]=names
        else:targets[name]=np.where(known,values,np.nan)
    if not targets:raise ValueError('No requested features for reconstruction')
    # Numeric branch is the v1.3.0 protocol; Boolean/category use its frozen
    # transforms/router/splits, with probability losses in a separate decoder.
    groups=c.group_values(d['collection'],rows)
    cfg_acc=dict(dimensions=cfg['dimensions'],folds=cfg['folds'],regions=cfg['regions'],min_train=cfg['min_train'],train_cap=max(len(x),cfg['min_train']*2),batch_rows=64)
    numeric={name:y for name,y in targets.items() if name in target_specs and target_specs[name]['kind']=='numeric'}
    outputs={};meta={};
    token.check()
    result=acc.analyze(x,numeric,groups,cfg_acc,cfg['seed'],np.arange(n),sink=lambda _:token.check(),checkpoint=token.check)
    for name,curves in result['views'].items():
        for q,measures in curves.items():
            for m,v in measures.items():outputs[f'{name}__q{q}__{m}']=v
    meta['numeric']=clean(result);meta['numeric']['views']={};meta['numeric']['selected_loss']={}
    # Separate classification decoders; train-only PCA and training priors.
    classification=[];accounts=[]
    fold=acc.fold_ids(groups,cfg['folds']);centers=np.asarray(result['router']['centers']);region=acc.labels(x,centers)
    qs=[q for q in cfg['dimensions'] if q<=x.shape[1]]
    names=[f for f in cfg['features'] if target_specs[f]['kind']!='numeric']
    for name in names:
        token.check();spec=target_specs[name];kind=spec['kind'];a,known=c.feature(name,rows)
        y=a[:,None].astype(float) if kind=='boolean' else np.zeros((len(a),spec['cardinality']))
        if kind=='category':y[known]=np.eye(spec['cardinality'])[a[known].astype(int)]
        dimensions={q:{m:np.full(n,np.nan) for m in ['broad','local','gain','baseline','selected']} for q in qs}
        for f in range(cfg['folds']):
            token.check(); train=np.flatnonzero((fold!=f)&(fold!=(f+1)%cfg['folds'])&known);val=np.flatnonzero((fold==(f+1)%cfg['folds'])&known);test=np.flatnonzero((fold==f)&known)
            if len(train)<cfg['min_train'] or len(val)<2:
                classification.append(dict(feature=name,fold=f,status='insufficient_training_or_validation'));continue
            with threadpool_limits(1):pca=PCA(n_components=min(max(qs),len(train)-1,x.shape[1]),svd_solver='full').fit(x[train])
            z=pca.transform(x);prior=y[train].mean(0);candidates=[];models={}
            def probability(pred):
                pred=np.clip(pred,0,1)
                if pred.ndim==1:pred=pred[:,None]
                if kind=='category':
                    total=pred.sum(1,keepdims=True); pred=np.divide(pred,total,out=np.broadcast_to(prior,pred.shape).copy(),where=total>1e-12)
                return pred
            def loss(truth,pred):return np.sum((truth-pred)**2,axis=1)
            for q in qs:
                if q>z.shape[1]:continue
                token.check(); broad=Ridge(alpha=.01).fit(z[train,:q],y[train]);local={}
                for r in range(len(centers)):
                    subset=train[region[train]==r]
                    if len(subset)>=cfg['min_train']:local[r]=Ridge(alpha=.01).fit(z[subset,:q],y[subset])
                bp=probability(broad.predict(z[:,:q]));lp=np.full(y.shape,np.nan)
                for r,m in local.items():
                    mask=region==r;lp[mask]=probability(m.predict(z[mask,:q]))
                base=loss(y,np.broadcast_to(prior,y.shape));be=loss(y,bp);le=loss(y,lp)
                matched=np.isfinite(le)
                for m,v in [('broad',be),('local',le),('gain',be-le),('baseline',base)]:
                    mask=(fold[:n]==f)&known[:n];dimensions[q][m][mask]=v[:n][mask]
                for account,pred in [('broad',be),('local',le)]:
                    vv=pred[val];good=np.isfinite(vv);mae=float(vv[good].mean()) if good.any() else None
                    candidates.append(dict(account=account,dimension=q,validation_loss=mae,n_validation=int(good.sum()),adequate=bool(good.all() and base[val].mean()>1e-12 and mae<=.8*base[val].mean())))
                models[q]=(be,le)
                classification.append(dict(feature=name,fold=f,dimension=q,loss='Brier' if kind=='boolean' else 'multiclass Brier (sum over classes)',
                    broad_mean=float(be[test].mean()) if len(test) else None,local_mean=float(le[test][matched[test]].mean()) if matched[test].any() else None,
                    matched_broad_mean=float(be[test][matched[test]].mean()) if matched[test].any() else None,
                    matched_gain=float((be[test]-le[test])[matched[test]].mean()) if matched[test].any() else None,n_test=len(test),n_matched=int(matched[test].sum()),baseline=float(base[test].mean()) if len(test) else None))
                accounts.append(dict(feature=name,fold=f,dimension=q,mean=pca.mean_,components=pca.components_,prior=prior,broad=dict(coef=broad.coef_,intercept=broad.intercept_),local={r:dict(coef=m.coef_,intercept=m.intercept_) for r,m in local.items()}))
            pick=next((v for v in sorted(candidates,key=lambda v:(v['account']=='local',v['dimension'])) if v['adequate']),None)
            classification.append(dict(feature=name,fold=f,selected=pick,candidates=candidates))
            if pick:
                mask=(fold[:n]==f)&known[:n];dimensions[pick['dimension']]['selected'][mask]=models[pick['dimension']][pick['account']=='local'][:n][mask]
        for q,ms in dimensions.items():
            for m,v in ms.items():outputs[f'{name}__q{q}__{m}']=v
    outputs['anchor_rows']=ctx['anchors'];outputs['context_rows']=rows;outputs['regions']=region[:n]
    return outputs,dict(support=ctx['support'],units=REGISTRY['reconstruction'].units,numeric=meta['numeric'],classification=classification,classification_accounts=accounts,
        protocol='Frozen transductive unlabeled router; group-separated outer test/inner validation/train; training-only PCA and decoders. Evaluation of sampled reference is not a census.',
        caveat='Broad/local gains require matched finite losses; missing support remains NaN. Adaptive exploratory evaluation, not a reserved final test.')


def discrepancy(ctx,store,key,token,progress):
    geom,_=store.artifact(key,'geometry');rows=ctx['anchors'];cfg=ctx['cfg'];c=store.catalog
    ns=np.asarray(geom['neighbors']);# context neighbor endpoints include nonanchors; use anchor candidate edges plus bounded random pairs
    pairs={tuple(e) for e in np.asarray(geom['edges'],int)};rng=np.random.default_rng(cfg['seed']);n=ctx['n']
    for _ in range(n*cfg['k']):
        i,j=sorted(rng.choice(n,2,replace=False));pairs.add((int(i),int(j)))
    pairs=np.asarray(sorted(pairs),int);columns=[];names=[]
    for name in cfg['features']:
        v,known=c.feature(name,rows);kind=c.raw['features'][name]['kind'];a,b=pairs.T
        delta=np.abs(v[a].astype(float)-v[b]) if kind=='numeric' else (v[a]!=v[b]).astype(float)
        delta[~(known[a]&known[b])]=np.nan;columns.append(delta);names.append(name)
    if not columns:raise ValueError('No features for discrepancy')
    features=np.asarray(columns).T;target=np.linalg.norm(ctx['x'][pairs[:,0]]-ctx['x'][pairs[:,1]],axis=1)
    fold=acc.fold_ids(c.group_values(ctx['definition']['collection'],rows),cfg['folds']);residual=np.full(len(pairs),np.nan);predicted=residual.copy();summaries=[]
    for f in range(cfg['folds']):
        token.check();tr=(fold[pairs[:,0]]!=f)&(fold[pairs[:,1]]!=f);te=(fold[pairs[:,0]]==f)&(fold[pairs[:,1]]==f)
        if tr.sum()<max(8,len(names)+2) or te.sum()<2:summaries.append(dict(fold=f,status='insufficient_endpoint_disjoint_pairs'));continue
        # Train-only median imputation; missingness remains a separate explanatory input.
        med=np.array([np.median(col[np.isfinite(col)]) if np.isfinite(col).any() else 0 for col in features[tr].T]);filled=np.where(np.isfinite(features),features,med)
        values=np.c_[filled,~np.isfinite(features)];scale=StandardScaler().fit(values[tr]);z=scale.transform(values)
        model=Ridge(alpha=10).fit(z[tr],target[tr]);p=model.predict(z[te]);predicted[te]=p;residual[te]=target[te]-p
        base=float(target[tr].mean());summaries.append(dict(fold=f,n_train=int(tr.sum()),n_test=int(te.sum()),mae=float(np.abs(residual[te]).mean()),baseline_mae=float(np.abs(target[te]-base).mean()),status='held_out'))
    field=np.full(n,np.nan)
    for i in range(n):
        values=residual[np.any(pairs==i,axis=1)];values=values[np.isfinite(values)]
        if len(values):field[i]=np.mean(values)
    return dict(anchor_rows=rows,pairs=pairs,observed=target,predicted=predicted,residual=residual,discrepancy=field),dict(support=ctx['support'],units='signed chord residual; positive = farther than feature account predicts',summaries=summaries,features=names,
        scope='Endpoint-group held-out enriched anchor pairs; mean residual per supported anchor; not reconstruction or projection loss')


def stability(ctx,store,key,token,progress):
    cfg=ctx['cfg'];x=ctx['x'];n=ctx['n'];geom,_=store.artifact(key,'geometry');base=np.asarray(geom['neighbors']);k=base.shape[1];rng=np.random.default_rng(cfg['seed']);noise=[];resamples=[]
    if cfg['repeats']<1:raise ValueError('Stability requires positive repeats')
    for rep in range(cfg['repeats']):
        token.check();pert=g.normalize(x+rng.normal(0,.01,x.shape));_,pn=nearest(pert,pert[:n],k,token,np.arange(n));noise.append(g.neighbor_overlap(base,pn))
        keep=np.sort(rng.choice(len(x),max(k+1,int(.8*len(x))),replace=False));ds=cdist(x[:n],x[keep]);ds[np.arange(n)[:,None]==keep[None,:]]=np.inf
        ns=keep[np.argsort(ds,axis=1,kind='stable')[:,:k]];retained=set(keep)
        resamples.append([len(set(a)&set(b))/max(1,len(set(a)|set(b))) for a,b in zip([set(v)&retained for v in base],ns)])
        progress('resample', (rep+1)/cfg['repeats'])
    return dict(anchor_rows=ctx['anchors'],perturbation=np.asarray(noise),resampling=np.asarray(resamples),perturbation_jaccard=np.mean(noise,0),resampling_jaccard=np.mean(resamples,0)),dict(support=ctx['support'],units='Jaccard',repeats=cfg['repeats'],perturbation_sigma=.01,reference_fraction=.8,caveat='Explicit perturbation and resampling sensitivity; not confidence in semantics')


def routes(ctx,store,key,token,progress):
    geom,_=store.artifact(key,'geometry');edges=np.asarray(geom['edges']);lengths=np.asarray(geom['lengths']);graph=g.sparse_graph(ctx['n'],edges,lengths);token.check();damage=g.deletion_influence(graph);examples=[]
    from .kernels.route_set import route_set
    near_shortest=[]
    for target in np.linspace(0,ctx['n']-1,min(8,ctx['n']),dtype=int):
        token.check();examples.append(g.route(graph,0,int(target)));near_shortest.append(route_set(graph,0,int(target),limit=5))
    return dict(anchor_rows=ctx['anchors'],deletion_damage=damage),dict(support=ctx['support'],units=REGISTRY['routes'].units,routes=examples,near_shortest_route_sets=near_shortest,scope='Fixed mutual anchor graph; absent route says nothing about excluded corpus paths')

from .reference import evaluate_reference
from .audit import feature_audit
from .directions import directions
from .probes import probe_metrics
FUNCTIONS={n:globals()[n] for n in REGISTRY if n!='reference_evaluation'}
FUNCTIONS['reference_evaluation']=evaluate_reference


def generate(store,key,names,token=None,progress=None):
    token=token or Token();progress=progress or (lambda stage,fraction:None)
    estimate=plan(store,key,names)
    if estimate['over_budget']:raise ValueError('Over budget: inspect plan and create explicit revised definition')
    origin_revision=store.read(key)['revision'];cfg=store.read(key)['settings'];token.deadline=time.monotonic()+cfg['max_seconds'];done=[];shared_context=[]
    def run(name):
        if name not in REGISTRY:raise ValueError('Unknown instrument '+name)
        if store.artifact_path(key,name).exists():store.artifact(key,name);return
        for dep in REGISTRY[name].dependencies:run(dep)
        store.set_status(key,name,status='running');start=time.perf_counter()
        try:
            token.check();donor=store.reusable(key,name)
            if donor:
                arrays,meta=store.artifact(donor,name)
                store.publish(key,name,arrays,{**meta,'reused_from':donor,'origin_revision':origin_revision},token);done.append(name);progress(name,1);return
            progress(name,0)
            if not shared_context:shared_context.append(resolve(store,key,token))
            ctx=shared_context[0]
            with threadpool_limits(1):arrays,meta=FUNCTIONS[name](ctx,store,key,token,progress)
            arrays.setdefault('anchor_rows',ctx['anchors']);arrays.setdefault('context_rows',ctx['rows'])
            token.check();store.publish(key,name,arrays,{**meta,'elapsed_seconds':time.perf_counter()-start,'plan':estimate,'origin_revision':origin_revision},token);done.append(name);progress(name,1)
        except Exception as exc:
            from .store import Cancelled
            store.set_status(key,name,status='cancelled' if isinstance(exc,Cancelled) else 'failed',error=str(exc));raise
    for name in names:run(name)
    return done
