"""Native Qt exploration workspace. Matplotlib Qt canvases render bounded CPU meshes.

The population remains HyCompass OpenGL; detail owns no shared GL allocations.
"""
from __future__ import annotations
import csv
import json
import math
import time
import numpy as np
from scipy.spatial import Delaunay,QhullError
import matplotlib
matplotlib.use('QtAgg')
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.tri import Triangulation
from PySide6.QtCore import Qt,QTimer,QEvent,Signal
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,QSplitter,QComboBox,QDoubleSpinBox,QSpinBox,
 QCheckBox,QPushButton,QLabel,QPlainTextEdit,QListWidget,QListWidgetItem,QDialog,QDialogButtonBox,QLineEdit,
 QMessageBox,QFileDialog,QInputDialog,QScrollArea,QTabWidget,QSlider,QTableWidget,QTableWidgetItem)
from .catalog import clean
from .store import Store,Residency,DEFAULTS
from .instruments import REGISTRY,plan
from .comparison import compare
from .camera import CAMERA_PROJECTION


class DefinitionDialog(QDialog):
    def __init__(self,catalog,domain,parent=None):
        super().__init__(parent);self.setWindowTitle('Define saved exploration');self.resize(480,650)
        self.catalog=catalog;self.domain=domain;layout=QVBoxLayout(self);form=QFormLayout();layout.addLayout(form)
        self.title=QLineEdit('Selected items');form.addRow('Title',self.title)
        self.preset=QComboBox();self.preset.addItems(['Geometry','Geometry + features','Detailed']);form.addRow('Preset',self.preset)
        self.anchors=QSpinBox();self.anchors.setRange(16,100000);self.anchors.setValue(192);form.addRow('Evaluation anchor budget',self.anchors)
        self.context=QComboBox();self.context.addItems(['selection','reference']);form.addRow('Context pool',self.context)
        self.context_cap=QSpinBox();self.context_cap.setRange(32,1000000);self.context_cap.setValue(768);form.addRow('Context row budget',self.context_cap)
        self.k=QSpinBox();self.k.setRange(4,128);self.k.setValue(12);form.addRow('Neighbor count',self.k)
        self.dims=QLineEdit('1,2,4,8');form.addRow('Retained dimension ladder',self.dims)
        self.ram=QSpinBox();self.ram.setRange(16,32768);self.ram.setValue(256);form.addRow('Temporary RAM budget (MiB)',self.ram)
        self.work=QSpinBox();self.work.setRange(1,2000000);self.work.setValue(500);form.addRow('Work budget (million products)',self.work)
        self.repeats=QSpinBox();self.repeats.setRange(0,32);self.repeats.setValue(3);form.addRow('Validation repeats',self.repeats)
        self.projection=QComboBox();self.projection.addItem('Scoped PCA-2',None)
        for p in catalog.manifest.projections.values():
            if p.domain==domain:self.projection.addItem('Population: '+p.id,p.id)
        form.addRow('Coordinate provenance',self.projection)
        self.reference=QComboBox();self.reference.addItem('No frozen reference',None)
        for d in Store(catalog.root).definitions():
            if d['domain']==domain and (Store(catalog.root).artifact_path(d['id'],'reconstruction')/'metadata.json').exists():self.reference.addItem(d['title'],d['id'])
        form.addRow('Frozen reconstruction reference',self.reference)
        self.features=QListWidget();collection=catalog.raw['domains'][domain]['collection']
        for key,f in catalog.raw['features'].items():
            if f['collection']==collection:
                item=QListWidgetItem(key);item.setCheckState(Qt.CheckState.Checked);self.features.addItem(item)
        form.addRow('Active typed features',self.features)
        self.note=QLabel('Membership is frozen independently of anchor, context and render budgets.\nA reference context is a bounded sample, not corpus kNN.');self.note.setWordWrap(True);layout.addWidget(self.note)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);layout.addWidget(buttons)
    def settings(self):
        return dict(instruments=self.instruments(),anchors=self.anchors.value(),context=self.context.currentText(),context_cap=self.context_cap.value(),k=self.k.value(),
                    dimensions=[int(s) for s in self.dims.text().split(',')],max_ram_bytes=self.ram.value()*1024**2,max_work=self.work.value()*1_000_000,
                    repeats=self.repeats.value(),projection=self.projection.currentData(),reference_exploration=self.reference.currentData(),features=[self.features.item(i).text() for i in range(self.features.count()) if self.features.item(i).checkState()==Qt.CheckState.Checked])
    def instruments(self):return [['geometry'],['geometry','reconstruction','discrepancy','feature_audit','directions','probe_metrics'],[n for n in REGISTRY if n!='reference_evaluation' or self.reference.currentData()]][self.preset.currentIndex()]


def supported_triangles(xy,labels=None):
    finite=np.isfinite(xy).all(1);indices=np.flatnonzero(finite)
    if len(indices)<3:return np.empty((0,3),int)
    try:tri=indices[Delaunay(xy[indices]).simplices]
    except QhullError:return np.empty((0,3),int)
    if labels is not None:tri=tri[np.all(labels[tri]==labels[tri[:,0]][:,None],axis=1)]
    # Conservative projected-gap mask is display support only, never analytical connectivity.
    if len(tri):
        lengths=np.linalg.norm(xy[tri]-xy[np.roll(tri,1,axis=1)],axis=2)
        tri=tri[lengths.max(1)<=max(1e-10,np.median(lengths)*4)]
    return tri


def mesh_heights(values,relief):
    a=np.asarray(values,float);finite=np.isfinite(a)
    scale=max(1e-12,np.max(np.abs(a[finite]))) if finite.any() else 1
    return np.where(finite,a/scale*relief,np.nan)


class Landscape(QWidget):
    changed=Signal()
    selected=Signal(object)
    def __init__(self,parent=None):
        super().__init__(parent);layout=QHBoxLayout(self);layout.setContentsMargins(0,0,0,0)
        self.fig=Figure(facecolor='#161d27');self.canvas=FigureCanvasQTAgg(self.fig);layout.addWidget(self.canvas,1);self.legend_fig=Figure(facecolor='#161d27');self.legend_canvas=FigureCanvasQTAgg(self.legend_fig);self.legend_canvas.setFixedWidth(155);self.legend_scroll=QScrollArea();self.legend_scroll.setWidgetResizable(True);self.legend_scroll.setWidget(self.legend_canvas);self.legend_scroll.setFixedWidth(175);layout.addWidget(self.legend_scroll)
        self.canvas.setFocusPolicy(Qt.FocusPolicy.StrongFocus);self.canvas.installEventFilter(self)
        self.canvas.mpl_connect('button_press_event',self._press);self.canvas.mpl_connect('motion_notify_event',self._motion);self.canvas.mpl_connect('button_release_event',self._release);self.canvas.mpl_connect('scroll_event',self._scroll)
        self.show_axes3d=False;self.mouse_mode='Navigate';self._drag=None;self._lasso_artist=None;self.camera_pan=np.zeros(3);self.color_label='Measurement';self.force_signed=False;self.colorbar=None
        self.arrays=None;self.values=None;self.categorical=False;self.category_colors=[];self.category_labels={};self.highlights=np.empty(0,np.int64);self.color_limit=None;self.rows=None;self.position=np.zeros(2);self.yaw=0.;self.radius=.35;self.relief=.5;self.contrast=1.;self.zoom=1.;self.mode3d=False;self.points=True;self.contours=True;self.field=True;self.filtration_index=-1;self.display_cap=10000;self.keys=set();self.attention_selected=np.empty(0,int)
        self.velocity=np.zeros(2);self.turn_velocity=0.;self.look_distance=2.;self._last_tick=time.monotonic();self._observer_artists=[];self._background=None;self.component_labels=None
        self.canvas.mpl_connect("draw_event",self._capture_background)
        self._resize_timer=QTimer(self);self._resize_timer.setSingleShot(True);self._resize_timer.setInterval(80);self._resize_timer.timeout.connect(self.redraw);self.canvas.mpl_connect('resize_event',lambda event:self._resize_timer.start())
        self.timer=QTimer(self);self.timer.setInterval(16);self.timer.timeout.connect(self._move);self.timer.start()
    def eventFilter(self,obj,event):
        if event.type() in (QEvent.Type.KeyPress,QEvent.Type.KeyRelease):
            key=event.key()
            if key in [Qt.Key.Key_W,Qt.Key.Key_A,Qt.Key.Key_S,Qt.Key.Key_D,Qt.Key.Key_Left,Qt.Key.Key_Right,Qt.Key.Key_Up,Qt.Key.Key_Down]:
                if event.type()==QEvent.Type.KeyPress:self.keys.add(key)
                elif not event.isAutoRepeat():self.keys.discard(key)
                return True
        if event.type()==QEvent.Type.FocusOut:self.keys.clear()
        return super().eventFilter(obj,event)
    def _move(self,dt=None):
        if dt is None and not self.isVisible():self.keys.clear();self.velocity[:]=0;return
        now=time.monotonic();dt=max(.001,min(.05,now-self._last_tick)) if dt is None else dt;self._last_tick=now
        if self.arrays is None:return
        moving=bool(self.keys) or np.linalg.norm(self.velocity)>self.span*1e-5 or abs(self.turn_velocity)>1e-5
        if not moving:return
        forward=np.array([math.cos(self.yaw),math.sin(self.yaw)]);side=np.array([-forward[1],forward[0]])
        target=forward*(int(Qt.Key.Key_W in self.keys)-int(Qt.Key.Key_S in self.keys))+side*(int(Qt.Key.Key_A in self.keys)-int(Qt.Key.Key_D in self.keys))
        norm=np.linalg.norm(target)
        if norm>0:target/=norm
        blend=1-math.exp(-dt*14);self.velocity+=(target*self.span*.18-self.velocity)*blend
        turn=(int(Qt.Key.Key_Left in self.keys)-int(Qt.Key.Key_Right in self.keys))*1.7
        self.turn_velocity+=(turn-self.turn_velocity)*blend;self.yaw+=self.turn_velocity*dt;self.position+=self.velocity*dt
        vertical=int(Qt.Key.Key_Up in self.keys)-int(Qt.Key.Key_Down in self.keys)
        self.look_distance=float(np.clip(self.look_distance+vertical*dt*3,.5,12))
        self._update_observer();self.changed.emit()
    def _click(self,event):
        if event.inaxes!=getattr(self,'ax',None) or event.xdata is None:return
        self.canvas.setFocus()
        if not self.mode3d and event.button==3:
            self.position=np.array([event.xdata,event.ydata]);self.velocity[:]=0;self._update_observer();self.changed.emit()
        elif event.button==1 and self.rows is not None:
            finite,pixels=self.projected_pixels()
            if not len(finite):return
            dist=np.linalg.norm(pixels-np.array([event.x,event.y]),axis=1);i=finite[dist.argmin()]
            if dist.min()>12:return
            row=self.rows[i];chosen=np.array([row],np.int64)
            if event.key=='shift':chosen=np.setxor1d(self.highlights,chosen)
            self.selected.emit(chosen)
    def _capture_background(self,event):
        if self.mode3d or self.arrays is None or not hasattr(self,'ax'):return
        self._background=self.canvas.copy_from_bbox(self.ax.bbox)
        for artist in self._observer_artists:self.ax.draw_artist(artist)
    def _make_observer(self):
        self._observer_artists=[]
        for color in ['#ffdb6e','#ff9970','#ffdb6e']:
            args=([],[],[]) if self.mode3d else ([],[])
            artist,=self.ax.plot(*args,color=color,linewidth=1.4,animated=not self.mode3d,zorder=30);self._observer_artists.append(artist)
        if not self.mode3d:
            from matplotlib.patches import Polygon
            self.ribbon=Polygon(np.zeros((4,2)),facecolor='#e5c36b',edgecolor='none',alpha=.10,animated=True,zorder=25);self.ax.add_patch(self.ribbon);self._observer_artists.append(self.ribbon)
        if self.mode3d:
            from mpl_toolkits.mplot3d.art3d import Poly3DCollection
            self.ribbon=Poly3DCollection([np.zeros((4,3))],facecolors='#e5c36b',edgecolors='none',alpha=.12);self.ax.add_collection3d(self.ribbon);self._observer_artists.append(self.ribbon)
        self._background=None;self._update_observer(draw=False)
    def _update_observer(self,draw=True):
        if self.arrays is None or len(self._observer_artists)<3:return
        here=self.position;direction=np.array([math.cos(self.yaw),math.sin(self.yaw)]);ahead=here+direction*self.radius*self.look_distance;theta=np.linspace(0,2*np.pi,60)
        for artist,p in zip(self._observer_artists[:2],[here,ahead]):
            xx=p[0]+np.cos(theta)*self.radius;yy=p[1]+np.sin(theta)*self.radius
            if self.mode3d:artist.set_data_3d(xx,yy,np.zeros_like(xx))
            else:artist.set_data(xx,yy)
        line=self._observer_artists[2]
        if self.mode3d:
            line.set_data_3d([here[0],ahead[0]],[here[1],ahead[1]],[0,0]);side=np.array([-direction[1],direction[0]])*self.radius;corners=np.array([here-side,here+side,ahead+side,ahead-side]);self.ribbon.set_verts([np.c_[corners,np.zeros(4)]])
        else:
            line.set_data([here[0],ahead[0]],[here[1],ahead[1]])
            side=np.array([-direction[1],direction[0]])*self.radius;self.ribbon.set_xy([here-side,here+side,ahead+side,ahead-side])
        if draw:
            if not self.mode3d and self._background is not None:
                self.canvas.restore_region(self._background)
                for artist in self._observer_artists:self.ax.draw_artist(artist)
                self.canvas.blit(self.ax.bbox)
            else:self.canvas.draw_idle()
    def set_mouse_mode(self,mode):
        self.mouse_mode=mode
        if getattr(getattr(self,'ax',None),'name',None)=='3d':
            if mode=='Navigate':self.ax.mouse_init(rotate_btn=1,pan_btn=[],zoom_btn=[])
            else:self.ax.disable_mouse_rotation()
    def _press(self,event):
        if event.inaxes!=getattr(self,'ax',None):return
        self.canvas.setFocus()
        if event.button==3:self._click(event);return
        if event.button not in (1,2):return
        kind='lasso' if event.button==1 and self.mouse_mode=='Lasso' else 'pan' if event.button==2 or self.mouse_mode=='Pan' or not self.mode3d else 'orbit'
        self._drag=dict(kind=kind,start=np.array([event.x,event.y]),last=np.array([event.x,event.y]),points=[[event.x,event.y]],key=event.key)
        if kind=='lasso':
            from matplotlib.lines import Line2D
            from matplotlib.transforms import IdentityTransform
            self._lasso_artist=Line2D([event.x],[event.y],color='#c293ff',lw=1.7,transform=IdentityTransform(),zorder=1000);self.fig.add_artist(self._lasso_artist)
    def pan_pixels(self,dx,dy):
        if self.arrays is None:return
        if self.mode3d:
            az=math.radians(self.ax.azim);el=math.radians(self.ax.elev);right=np.array([-math.sin(az),math.cos(az),0.]);up=np.array([-math.cos(az)*math.sin(el),-math.sin(az)*math.sin(el),math.cos(el)])
            scale=self.span*1.7/max(1,min(self.ax.bbox.width,self.ax.bbox.height))/self.zoom;self.camera_pan-=(right*dx+up*dy)*scale
        else:
            self.camera_pan[0]-=dx*(self.ax.get_xlim()[1]-self.ax.get_xlim()[0])/max(1,self.ax.bbox.width);self.camera_pan[1]-=dy*(self.ax.get_ylim()[1]-self.ax.get_ylim()[0])/max(1,self.ax.bbox.height)
        self._apply_camera();self.canvas.draw_idle()
    def _motion(self,event):
        if self._drag is None:return
        now=np.array([event.x,event.y]);delta=now-self._drag['last'];self._drag['last']=now
        if self._drag['kind']=='pan':self.pan_pixels(*delta)
        elif self._drag['kind']=='lasso':
            if np.linalg.norm(now-np.array(self._drag['points'][-1]))>=2:self._drag['points'].append(now.tolist())
            points=np.asarray(self._drag['points']);self._lasso_artist.set_data(points[:,0],points[:,1]);self.canvas.draw_idle()
    def projected_pixels(self):
        self.ax.apply_aspect()
        xy=np.asarray(self.arrays['xy']);finite=np.flatnonzero(np.isfinite(xy).all(1))
        if self.mode3d:
            from mpl_toolkits.mplot3d import proj3d
            z=mesh_heights(self.values,self.relief)*self.span*.3 if not self.categorical else np.zeros(len(xy));px,py,_=proj3d.proj_transform(xy[finite,0],xy[finite,1],np.nan_to_num(z[finite],nan=0.),self.ax.get_proj());pixels=self.ax.transData.transform(np.c_[px,py])
        else:pixels=self.ax.transData.transform(xy[finite])
        return finite,pixels
    def select_lasso(self,vertices,key=None):
        from matplotlib.path import Path
        if self.arrays is None or len(vertices)<3:return
        ids,pixels=self.projected_pixels();inside=Path(np.vstack([vertices,vertices[0]]),closed=True).contains_points(pixels,radius=.5);visible=self.ax.bbox.contains
        inside&=np.array([visible(*p) for p in pixels]);rows=self.rows[ids[inside]]
        if key and 'shift' in key:rows=np.union1d(self.highlights,rows)
        elif key and ('control' in key or 'ctrl' in key):rows=np.setdiff1d(self.highlights,rows)
        self.selected.emit(np.asarray(rows,np.int64))
    def _release(self,event):
        drag=self._drag;self._drag=None
        if drag is None:return
        distance=np.linalg.norm(np.array([event.x,event.y])-drag['start'])
        if drag['kind']=='lasso':
            self._lasso_artist.remove();self._lasso_artist=None;self.select_lasso(drag['points'],drag['key']);self.canvas.draw_idle()
        elif distance<4:
            event.key=drag['key'];self._click(event)
    def _apply_camera(self):
        if self.arrays is None:return
        xy=np.asarray(self.arrays['xy']);finite=np.isfinite(xy).all(1);center=np.mean(xy[finite],axis=0) if finite.any() else np.zeros(2);aspect=max(1,self.ax.bbox.width)/max(1,self.ax.bbox.height)
        if self.mode3d:
            # Keep the complete mesh's world bounds fixed under zoom. Zoom is a
            # camera magnification; panning translates the camera volume.
            half=self.span*.57;hx=hy=half
            self.ax.set_box_aspect((1,1,.55),zoom=float(np.clip(.94*self.zoom,.15,12)))
            self.ax.set_zlim(-self.span*.4+self.camera_pan[2],self.span*.4+self.camera_pan[2])
        else:
            half=self.span*.56/self.zoom;hx=half*max(1,aspect);hy=half*max(1,1/aspect);self.ax.set_aspect('equal',adjustable='box')
        self.ax.set_xlim(center[0]+self.camera_pan[0]-hx,center[0]+self.camera_pan[0]+hx);self.ax.set_ylim(center[1]+self.camera_pan[1]-hy,center[1]+self.camera_pan[1]+hy)
    def _scroll(self,event):
        if self.arrays is None:return
        old=self.zoom;factor=1.13 if event.button=='up' else 1/1.13;self.zoom=float(np.clip(old*factor,.15,12))
        if not self.mode3d and event.inaxes==self.ax and event.xdata is not None:
            xy=self.arrays['xy'];good=np.isfinite(xy).all(1);center=np.mean(xy[good],0)+self.camera_pan[:2];anchor=np.array([event.xdata,event.ydata]);self.camera_pan[:2]+=(anchor-center)*(1-old/self.zoom)
        self._apply_camera();self.canvas.draw_idle()
    def set_geometry(self,arrays):
        self.component_labels=None;self.arrays=arrays;self.rows=np.asarray(arrays['anchor_rows']);xy=np.asarray(arrays['xy']);finite=np.isfinite(xy).all(1)
        if finite.any():self.position=np.mean(xy[finite],0);self.span=max(1e-6,np.ptp(xy[finite],axis=0).max())
        else:self.span=1
        self.radius=self.span*.09;self.values=np.asarray(arrays['effective_dimension']);self.redraw()
    def attention(self,ahead=False):
        if self.arrays is None:return np.empty(0,int)
        p=self.position+(np.array([math.cos(self.yaw),math.sin(self.yaw)])*self.radius*self.look_distance if ahead else 0)
        return np.flatnonzero(np.linalg.norm(self.arrays['xy']-p,axis=1)<=self.radius)
    def redraw(self):
        self._observer_artists=[];self._background=None;self.ribbon=None
        pose=(self.ax.elev,self.ax.azim,self.ax.roll) if self.mode3d and getattr(getattr(self,'ax',None),'name',None)=='3d' else None
        self.colorbar=None;self.legend_fig.clear();self.legend_canvas.draw_idle();self.fig.clear();self.ax=self.fig.add_subplot(111,projection=CAMERA_PROJECTION if self.mode3d else None)
        if pose:self.ax.view_init(elev=pose[0],azim=pose[1],roll=pose[2])
        ax=self.ax;ax=self.ax;ax.set_facecolor('#161d27');ax.tick_params(colors='#94a6ba',labelsize=8)
        if self.arrays is None:
            text=ax.text2D if self.mode3d else ax.text
            text(.1,.5,'Generate or load geometry to navigate',color='white',transform=ax.transAxes);self.canvas.draw_idle();return
        xy=np.asarray(self.arrays['xy']);values=np.asarray(self.values,float);labels=self.component_labels if self.component_labels is not None else np.asarray(self.arrays['filtration_labels'])[self.filtration_index];tri=supported_triangles(xy,labels)
        if len(xy)>2048:
            render_rows=np.sort(np.random.default_rng(0).choice(len(xy),2048,replace=False));keep=np.zeros(len(xy),bool);keep[render_rows]=True
            reduced=supported_triangles(xy[render_rows],labels[render_rows]);tri=render_rows[reduced]
        finite=np.isfinite(values)&np.isfinite(xy).all(1)
        tri=tri[np.all(finite[tri],axis=1)] if len(tri) else tri
        extent=self.span;z=mesh_heights(values,self.relief)*extent*.3
        vmax=max(1e-12,np.nanmax(np.abs(values[finite]))) if finite.any() else 1
        signed=bool(self.force_signed or finite.any() and np.any(values[finite]<0));vmin=-vmax if signed else 0
        display_max=(self.color_limit if self.color_limit is not None else vmax)/max(.05,self.contrast);vmin=-display_max if signed else 0;cmap='coolwarm' if signed else 'viridis'
        self.legend_canvas.setMinimumHeight(max(200,len(self.category_colors)*22+100) if self.categorical else 0)
        if self.categorical:
            from matplotlib.colors import ListedColormap
            cmap=ListedColormap(self.category_colors or ['#648fba']);vmin=-.5;display_max=len(self.category_colors)-.5;z=np.where(finite,0.,np.nan)
        if len(tri):
            # Matplotlib triangulation requires finite vertices even when unused.
            good=np.flatnonzero(np.isfinite(xy).all(1));inv=np.full(len(xy),-1);inv[good]=np.arange(len(good));t=Triangulation(xy[good,0],xy[good,1],inv[tri]);vv=values[good];zz=z[good]
            if self.mode3d:
                if self.field and not self.categorical:
                    mesh=ax.plot_trisurf(t,zz,linewidth=.15,alpha=.83,shade=False)
                    mesh.set_array(np.mean(vv[t.triangles],axis=1));mesh.set_cmap(cmap);mesh.set_clim(vmin,display_max)
                if self.contours and not self.categorical and np.ptp(vv[np.isfinite(vv)])>1e-12:
                    ax.tricontour(t,vv,levels=8,zdir='z',offset=0,colors='#aabccc',linewidths=.4)
            else:
                if self.field and not self.categorical:ax.tripcolor(t,vv,shading='gouraud',cmap=cmap,vmin=vmin,vmax=display_max,alpha=.8)
                if self.contours and not self.categorical and np.ptp(vv[np.isfinite(vv)])>1e-12:ax.tricontour(t,vv,levels=8,colors='#b0bfcc',linewidths=.5,alpha=.65)
        ids=np.flatnonzero(finite);ids=ids[:self.display_cap]
        if self.points and len(ids):
            args=(xy[ids,0],xy[ids,1],z[ids]) if self.mode3d else (xy[ids,0],xy[ids,1])
            ax.scatter(*args,c=values[ids],cmap=cmap,vmin=vmin,vmax=display_max,s=10,edgecolors='#111820',linewidths=.3)
        unknown=np.flatnonzero(np.isfinite(xy).all(1)&~np.isfinite(values))[:self.display_cap]
        if self.points and len(unknown):
            args=(xy[unknown,0],xy[unknown,1],np.zeros(len(unknown))) if self.mode3d else (xy[unknown,0],xy[unknown,1])
            ax.scatter(*args,s=14,marker='x',color='#8e9ba9',linewidths=.7)
        linked=np.flatnonzero(np.isin(self.rows,self.highlights)&np.isfinite(xy).all(1))
        if len(linked):
            args=(xy[linked,0],xy[linked,1],np.nan_to_num(z[linked],nan=0.)) if self.mode3d else (xy[linked,0],xy[linked,1])
            ax.scatter(*args,s=55,facecolors='none',edgecolors='#c293ff',linewidths=1.8)
        self.fig.subplots_adjust(left=.045,right=.985,bottom=.07,top=.94);self._apply_camera();self.set_mouse_mode(self.mouse_mode)
        from matplotlib.cm import ScalarMappable
        from matplotlib.colors import Normalize,BoundaryNorm
        if finite.any():
            norm=BoundaryNorm(np.arange(len(self.category_colors)+1)-.5,len(self.category_colors)) if self.categorical and self.category_colors else Normalize(vmin,display_max)
            scalar=ScalarMappable(norm=norm,cmap=cmap);cax=self.legend_fig.add_axes([.10,.18,.16,.64]);self.colorbar=self.legend_fig.colorbar(scalar,cax=cax,extend='both' if not self.categorical else 'neither');self.colorbar.ax.tick_params(colors='#c5d3df',labelsize=8)
            import textwrap
            self.colorbar.set_label('\n'.join(textwrap.wrap(self.color_label if finite.any() else 'No finite evidence · scale unavailable',36)),color='#c5d3df',fontsize=8)
            if self.categorical:
                codes=np.arange(len(self.category_colors));self.colorbar.set_ticks(codes);self.colorbar.set_ticklabels([self.category_labels.get(str(int(c)),{}).get('name',str(int(c))) for c in codes])
        else:self.legend_fig.text(.08,.6,"No finite evidence\nScale unavailable",color="#b6c5d3",fontsize=9);self.colorbar=None
        self.legend_canvas.draw_idle()
        if self.mode3d and not self.show_axes3d:ax.set_axis_off()
        ax.set_title('Sampled anchor field • yellow: here • orange: ahead',color='#dce7f2',fontsize=10)
        self._make_observer();self.canvas.draw_idle()


class ExplorationWidget(QWidget):
    def __init__(self,root,key,jobs,link_callback,parent=None):
        super().__init__(parent)
        from .evidence import EvidencePanel,TITLES,NAMES
        from PySide6.QtWidgets import QProgressBar,QTableWidget,QHeaderView
        self.store=Store(root);self.key=key;self.jobs=jobs;self.link_callback=link_callback;self.cache=Residency();self.definition=self.store.read(key);self.fields={};self.loaded={};self.selected_rows=np.empty(0,np.int64);self._reloading=False;self._view_loaded_once=False;self._last_status=None;self._lens='geometry'
        saved_selection=self.store.folder(key)/'kept_selection.npy'
        if saved_selection.exists():self.selected_rows=np.load(saved_selection,allow_pickle=False)
        layout=QVBoxLayout(self);layout.setContentsMargins(5,5,5,5)
        self.split=QSplitter();layout.addWidget(self.split)
        self.sidebar=QTabWidget();self.sidebar.setMinimumWidth(290);self.sidebar.setMaximumWidth(460);self.split.addWidget(self.sidebar)
        guide=QWidget();gl=QVBoxLayout(guide);title=QLabel(self.definition['title']);title.setWordWrap(True);title.setStyleSheet('font-size:17px;font-weight:600');gl.addWidget(title)
        self.scope=QLabel(f"{self.definition['n_members']:,} cohort items\nEmbedding: {self.definition['domain']}");self.scope.setWordWrap(True);gl.addWidget(self.scope)
        self.feature=QComboBox();self.feature.addItems(self.definition['settings']['features']);self.dimension=QComboBox();self.dimension.addItems([str(q) for q in self.definition['settings']['dimensions']]);self.account=QComboBox()
        for text,key2 in [('Broad probe loss','broad'),('Regional probe loss','local'),('Broad − regional loss gain','gain'),('Training baseline loss','baseline'),('Validation-selected error','selected')]:self.account.addItem(text,key2)
        self.geometry_metric=QComboBox()
        for name in ['effective_dimension','hidden_two','radius','radius_dimension']:self.geometry_metric.addItem(NAMES[name],name)
        self.measure=QComboBox();self.field=QComboBox();self.field.hide()
        form=QFormLayout();form.addRow('Follow feature',self.feature);form.addRow('Geometry profile',self.geometry_metric);form.addRow('Map measurement',self.measure);form.addRow('Retained directions',self.dimension);form.addRow('Prediction account',self.account);gl.addLayout(form)
        self.map_reading=QLabel();self.map_reading.setWordWrap(True);gl.addWidget(self.map_reading)
        display=QFormLayout();self.relief=QDoubleSpinBox();self.relief.setRange(0,8);self.relief.setSingleStep(.1);self.relief.setValue(.5);display.addRow('Relief height',self.relief)
        self.contrast=QDoubleSpinBox();self.contrast.setRange(.05,10);self.contrast.setValue(1);display.addRow('Color contrast',self.contrast)
        self.radius=QDoubleSpinBox();self.radius.setRange(.001,10000);self.radius.setDecimals(3);display.addRow('Attention radius',self.radius)
        self.look=QDoubleSpinBox();self.look.setRange(.5,12);self.look.setValue(2);display.addRow('Look distance × radius',self.look)
        self.cap=QSpinBox();self.cap.setRange(1,100000);self.cap.setValue(10000);display.addRow('Point display cap',self.cap);gl.addLayout(display)
        self.mode=QCheckBox('3D terrain');self.point_toggle=QCheckBox('Actual points');self.point_toggle.setChecked(True);self.contour_toggle=QCheckBox('Contours');self.contour_toggle.setChecked(True);self.field_toggle=QCheckBox('Continuous supported field');self.field_toggle.setChecked(True)
        toggles=QHBoxLayout();toggles.addWidget(self.mode);toggles.addWidget(self.point_toggle);toggles.addWidget(self.contour_toggle);gl.addLayout(toggles);self.axes_3d=QCheckBox('Show 3D coordinate box');self.axes_3d.toggled.connect(lambda v:self.setting('show_axes3d',v));gl.addWidget(self.axes_3d);gl.addWidget(self.field_toggle)
        help_label=QLabel('WASD moves smoothly · ← → turn · ↑ ↓ change look distance. Right-click places the observer. Click an item to keep it; Shift-click adds/removes. Wheel zooms.');help_label.setWordWrap(True);gl.addWidget(help_label)
        selection=QHBoxLayout()
        for text,slot in [('Keep here',lambda:self.keep_region(False)),('Keep ahead',lambda:self.keep_region(True)),('Clear',lambda:self.set_selection(np.empty(0,np.int64)))]:
            button=QPushButton(text);button.clicked.connect(slot);selection.addWidget(button)
        gl.addLayout(selection);self.link_auto=QCheckBox('Link to all open population windows');self.link_auto.setChecked(True);gl.addWidget(self.link_auto)
        self.selection_info=QLabel('No items kept. Purple outlines show the kept selection.');self.selection_info.setWordWrap(True);gl.addWidget(self.selection_info)
        actions=QHBoxLayout()
        for text,slot in [('Link now',self.link_here),('Export kept',self.export),('Feature query',self.query_feature)]:
            button=QPushButton(text);button.clicked.connect(slot);actions.addWidget(button)
        gl.addLayout(actions)
        more=QHBoxLayout()
        for text,slot in [('Explore kept',self.explore_query),('Reload labels',self.labels),('Save view',self.save_navigation)]:
            button=QPushButton(text);button.clicked.connect(slot);more.addWidget(button)
        gl.addLayout(more);self.reading=QLabel();self.reading.setWordWrap(True);gl.addWidget(self.reading);gl.addStretch()
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(guide);self.sidebar.addTab(scroll,'Field guide')
        compute=QWidget();cl=QVBoxLayout(compute);explain=QLabel('Compute creates results and saves them. Load opens saved results for viewing without refitting. Changing the view does not recompute analyses.');explain.setWordWrap(True);cl.addWidget(explain)
        self.analysis_table=QTableWidget(0,4);self.analysis_table.setHorizontalHeaderLabels(['Analysis','Saved','Loaded','Action']);self.analysis_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents);self.analysis_table.horizontalHeader().setStretchLastSection(False);self.analysis_table.verticalHeader().hide();self.analysis_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
        for col,width in [(1,58),(2,58),(3,70)]:self.analysis_table.horizontalHeader().setSectionResizeMode(col,QHeaderView.ResizeMode.Fixed);self.analysis_table.setColumnWidth(col,width);self.analysis_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers);cl.addWidget(self.analysis_table)
        self.instrument=QComboBox()
        for name in REGISTRY:self.instrument.addItem(TITLES.get(name,name),name)
        self.instrument.setCurrentIndex(self.instrument.findData('geometry'));cl.addWidget(self.instrument)
        self.cost=QLabel();self.cost.setWordWrap(True);cl.addWidget(self.cost);self.progress=QProgressBar();self.progress.setRange(0,100);cl.addWidget(self.progress)
        self.status=QLabel();self.status.setWordWrap(True);cl.addWidget(self.status)
        buttons=QHBoxLayout()
        for name,slot in [('Compute missing',self.generate),('Compute preset',self.generate_preset),('Cancel',self.cancel_work)]:
            b=QPushButton(name);b.clicked.connect(slot);buttons.addWidget(b)
        cl.addLayout(buttons);load_buttons=QHBoxLayout()
        for name,slot in [('Load saved results',self.reload),('Unload viewer',self.unload)]:
            b=QPushButton(name);b.clicked.connect(slot);load_buttons.addWidget(b)
        cl.addLayout(load_buttons)
        for name,slot in [('Inspect method & support',self.inspect_evidence),('Inspect detailed cost estimate',self.show_cost_details),('Delete selected saved result',self.delete)]:
            b=QPushButton(name);b.clicked.connect(slot);cl.addWidget(b)
        self.plan_text=QPlainTextEdit();self.plan_text.setReadOnly(True);self.plan_text.hide();self.feedback_log=QPlainTextEdit();self.feedback_log.setReadOnly(True);self.feedback_log.setMaximumBlockCount(150);cl.addWidget(self.feedback_log)
        self.sidebar.addTab(compute,'Compute / storage')
        self.right=QWidget();rl=QVBoxLayout(self.right);rl.setContentsMargins(0,0,0,0);self.split.addWidget(self.right);self.split.setSizes([340,1150]);self.split.setStretchFactor(1,1)
        lenses=QHBoxLayout();self.lens_buttons={}
        for name,text in [('geometry','01  What shape is this?'),('feature','02  What changes here?'),('gap',"03  What doesn't fit?"),('prediction','04  Will it predict here?')]:
            b=QPushButton(text);b.setCheckable(True);b.clicked.connect(lambda _,n=name:self.set_lens(n));lenses.addWidget(b);self.lens_buttons[name]=b
        rl.addLayout(lenses);filtration_bar=QHBoxLayout();filtration_bar.addWidget(QLabel('Distance filtration'))
        self.filtration=QSlider(Qt.Orientation.Horizontal);self.filtration.setRange(0,1000);self.filtration.setValue(1000);filtration_bar.addWidget(self.filtration,1);self.filtration_reading=QLabel();filtration_bar.addWidget(self.filtration_reading)
        keep=QPushButton('Keep connected extent');keep.clicked.connect(self.keep_component);filtration_bar.addWidget(keep);rl.addLayout(filtration_bar)
        map_actions=QHBoxLayout();self.mouse_tool=QComboBox();self.mouse_tool.addItems(['Navigate','Pan','Lasso']);self.mouse_tool.setToolTip('Navigate: 2D drag pans, 3D drag orbits. Middle-drag pans in either view. Lasso uses projected visible measured anchors; Shift adds, Ctrl subtracts.');map_actions.addWidget(self.mouse_tool);self.mouse_tool.currentTextChanged.connect(lambda mode:self.landscape.set_mouse_mode(mode));fit=QPushButton('Fit map');fit.clicked.connect(self.fit_map);map_actions.addWidget(fit)
        self.fill_view=QCheckBox('Fill viewport (crop edges)');self.fill_view.toggled.connect(self.fit_map);map_actions.addWidget(self.fill_view)
        self.full_map=QPushButton('Expand chart');self.full_map.setCheckable(True);self.full_map.toggled.connect(self.expand_chart);map_actions.addWidget(self.full_map);self.full_evidence=QPushButton('Expand evidence');self.full_evidence.setCheckable(True);self.full_evidence.toggled.connect(self.expand_evidence);map_actions.addWidget(self.full_evidence);reference_button=QPushButton('Reference / help');reference_button.clicked.connect(self.open_reference);map_actions.addWidget(reference_button);map_actions.addStretch();self.feedback=QLabel('Ready');self.feedback.setWordWrap(True);self.feedback.setMaximumWidth(450);self.feedback.setMaximumHeight(45);map_actions.addWidget(self.feedback);rl.addLayout(map_actions)
        self.vertical=QSplitter(Qt.Orientation.Vertical);rl.addWidget(self.vertical,1);self.landscape=Landscape();self.landscape.setMinimumHeight(220);self.vertical.addWidget(self.landscape)
        self.evidence=EvidencePanel(self);self.vertical.addWidget(self.evidence);self.vertical.setSizes([570,400]);self.vertical.setChildrenCollapsible(False)
        self.plots=self.evidence.anatomy_fig;self.profile_canvas=self.evidence.anatomy_canvas
        from PySide6.QtWidgets import QSizePolicy
        for combo in [self.feature,self.dimension,self.account,self.geometry_metric,self.measure]:combo.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Fixed);combo.setMinimumWidth(110)
        self.field.currentTextChanged.connect(self.change_field);self.feature.currentTextChanged.connect(self.feature_changed);self.dimension.currentTextChanged.connect(self.reconstruction_field);self.account.currentIndexChanged.connect(self.reconstruction_field);self.measure.currentIndexChanged.connect(self.measure_changed);self.geometry_metric.currentIndexChanged.connect(self.geometry_changed)
        for control,key2 in [(self.relief,'relief'),(self.contrast,'contrast'),(self.radius,'radius'),(self.cap,'display_cap'),(self.look,'look_distance')]:control.valueChanged.connect(lambda v,k=key2:self.setting(k,v))
        for control,key2 in [(self.mode,'mode3d'),(self.point_toggle,'points'),(self.contour_toggle,'contours'),(self.field_toggle,'field')]:control.toggled.connect(lambda v,k=key2:self.setting(k,v))
        self.filtration_timer=QTimer(self);self.filtration_timer.setSingleShot(True);self.filtration_timer.setInterval(35);self.filtration_timer.timeout.connect(self.apply_filtration);self.filtration.valueChanged.connect(lambda _:self.filtration_timer.start() if not self.filtration_timer.isActive() else None)
        self.profile_timer=QTimer(self);self.profile_timer.setSingleShot(True);self.profile_timer.setInterval(160);self.profile_timer.timeout.connect(self.update_evidence)
        self.landscape.changed.connect(self.schedule_evidence);self.landscape.selected.connect(self.set_selection);self.instrument.currentIndexChanged.connect(self.inspect_plan)
        self.timer=QTimer(self);self.timer.setInterval(250);self.timer.timeout.connect(self.refresh_status);self.timer.start();self.reload();self.inspect_plan();self.set_lens('geometry');self.refresh_status()
    def open_reference(self):
        from .guide import ReferenceDialog
        if not hasattr(self,'reference_dialog'):self.reference_dialog=ReferenceDialog(self)
        self.reference_dialog.show();self.reference_dialog.raise_();self.reference_dialog.activateWindow()
    def notice(self,text):
        self.feedback.setText(str(text));self.feedback.setToolTip(str(text));self.feedback_log.appendPlainText(str(text))
    def error(self,exc):self.notice('Unable to complete action: '+str(exc))
    def refresh_status(self):
        from .evidence import TITLES
        try:
            if getattr(self,'query_future',None) is not None and self.query_future.done():
                try:self.query_rows=self.query_future.result();self.set_selection(self.query_rows);self.notice(f'Feature query kept {len(self.query_rows):,} canonical items. Full question is unchanged.')
                except Exception as exc:self.error(exc)
                self.query_future=None
            future=getattr(self,'generation_future',None)
            if future is not None and future.done():
                try:future.result();self.notice('Computation finished. Results saved; loading them for viewing.');self.reload()
                except Exception as exc:self.error(exc)
                self.generation_future=None;self.inspect_plan()
            states=self.store.status(self.key);state_key=json.dumps(states,sort_keys=True)+str(sorted(self.loaded))+str(self.jobs.busy(self.key))
            if state_key!=self._last_status:
                self.analysis_table.setRowCount(len(REGISTRY))
                for row,name in enumerate(REGISTRY):
                    saved=(self.store.artifact_path(self.key,name)/'metadata.json').exists();state=states.get(name,{});status=state.get('status','Not computed')
                    text='Sampled' if saved and status=='generated_sampled' else 'Yes' if saved else status.replace('_',' ').capitalize()
                    if name in getattr(self,'load_errors',{}):text='Invalid / stale'
                    for col,value in enumerate([TITLES.get(name,name),text,'Yes' if name in self.loaded else 'No']):self.analysis_table.setItem(row,col,QTableWidgetItem(value))
                    button=QPushButton('View' if name in self.loaded else 'Load' if saved else 'Compute');button.clicked.connect(lambda _,n=name:self.analysis_action(n));button.setEnabled(not self.jobs.busy(self.key));self.analysis_table.setCellWidget(row,3,button)
                self._last_status=state_key
            stage,value=self.jobs.progress.get(self.key,('Ready',0))
            if self.jobs.busy(self.key):
                self.progress.setValue(int(float(value)*100) if isinstance(value,(int,float)) else 0);self.status.setText('Computing: '+TITLES.get(stage,stage))
            else:self.progress.setValue(100 if stage=='complete' else 0);self.status.setText(f'{len(self.loaded)} analyses loaded for viewing · {self.cache.nbytes/1024**2:.2f} MiB resident\n{self.store.disk_bytes(self.key)/1024**2:.2f} MiB saved on disk')
        except Exception as exc:self.status.setText(str(exc))
    def analysis_action(self,name):
        self.instrument.setCurrentIndex(self.instrument.findData(name))
        if name not in self.loaded:
            if (self.store.artifact_path(self.key,name)/'metadata.json').exists():self.reload()
            else:self.generate();return
        self.sidebar.setCurrentIndex(0);self.evidence.setCurrentIndex({'feature_audit':3,'geometry':1,'reconstruction':4,'reference_evaluation':4,'probe_metrics':3,'directions':0,'compression':4}.get(name,5));self.evidence.refresh()
    def inspect_preset(self):self.inspect_plan(names=self.definition['settings'].get('instruments',['geometry']))
    def inspect_plan(self,*_,names=None):
        from .evidence import TITLES
        try:
            result=plan(self.store,self.key,names or [self.instrument.currentData()]);self.plan_text.setPlainText(json.dumps(result,indent=2));ratio=result['total_missing_work']/max(1,result['limits']['work']);grade='Already saved; no computation needed' if not result['missing'] else ('Light' if ratio<.01 else 'Moderate' if ratio<.2 else 'Heavy')+' relative to selected work budget'
            read=result['source_read_estimate_bytes']+result.get('source_feature_read_estimate_bytes',0)
            self.cost.setText(f"{grade}\n{result['evaluation_anchor_cap']:,} anchors / {result['question_members']:,} cohort items · context ≤ {result['context_cap']:,}\nTemporary RAM ≈ {result['temporary_ram_estimate_bytes']/1024**2:.2f} MiB\nSource payload ≈ {read/1024**2:.2f} MiB · output ≈ {result['output_estimate_bytes']/1024**2:.2f} MiB\nMissing work: {result['total_missing_work']:,} estimated operations\n"+('Over budget: revise the definition before computing.' if result['over_budget'] else 'Estimates are structural; disk page reads and library workspaces can cost more.'))
            if result.get('full_feature_column_passes'):self.cost.setText(self.cost.text()+f"\n{result['full_feature_column_passes']} full feature-column passes; no full vector scan.")
            previous=self.loaded.get(self.instrument.currentData())
            if previous and previous[1].get('elapsed_seconds') is not None:self.cost.setText(self.cost.text()+f"\nSaved scope's original generation: {previous[1]['elapsed_seconds']:.3f} s (observed, not a forecast).")
        except Exception as exc:self.cost.setText('Estimate unavailable: '+str(exc));self.plan_text.setPlainText(str(exc))
    def show_cost_details(self):
        dlg=QDialog(self);dlg.setWindowTitle('Detailed computation estimate');dlg.resize(800,650);layout=QVBoxLayout(dlg);text=QPlainTextEdit();text.setReadOnly(True);text.setPlainText(self.plan_text.toPlainText());layout.addWidget(text);dlg.exec()
    def generate(self):
        try:self.generation_future=self.jobs.submit(self.key,[self.instrument.currentData()]);self.notice('Queued '+self.instrument.currentText()+'. Watch progress in Compute & storage.');self.refresh_status()
        except Exception as exc:self.error(exc)
    def generate_preset(self):
        try:self.generation_future=self.jobs.submit(self.key,self.definition['settings'].get('instruments',['geometry']));self.notice('Queued missing analyses from the saved preset.');self.refresh_status()
        except Exception as exc:self.error(exc)
    def inspect_evidence(self):
        try:
            _,meta=self.store.artifact(self.key,self.instrument.currentData());dlg=QDialog(self);dlg.setWindowTitle('Method, support and provenance');dlg.resize(900,700);layout=QVBoxLayout(dlg);text=QPlainTextEdit();text.setReadOnly(True);text.setPlainText(json.dumps(clean(meta),indent=2));layout.addWidget(text);dlg.exec()
        except Exception as exc:self.error(exc)
    def unload(self):
        self.loaded.clear();self.fields.clear();self.cache.clear();self.landscape.arrays=None;self.landscape.rows=None;self.landscape.values=None;self.landscape.component_labels=None;self.landscape._drag=None;self.landscape._lasso_artist=None;self.landscape.redraw();self.field.clear()
        for fig in [self.evidence.journey_fig,self.evidence.anatomy_fig,self.evidence.audit_fig,self.evidence.scale_fig,self.evidence.direction_fig,self.evidence.geometry_fig]:fig.clear()
        for view in [self.evidence.journey_canvas,self.evidence.anatomy_canvas,self.evidence.audit_canvas,self.evidence.scale_canvas,self.evidence.direction_canvas,self.evidence.geometry_canvas]:view.draw_idle()
        for table in [self.evidence.geometry,self.evidence.audit_table,self.evidence.associations,self.evidence.scale_table,self.evidence.account_table,self.evidence.exact_table,self.evidence.anchor_table,self.evidence.transfer_table,self.evidence.selection_table,self.evidence.regression_probes,self.evidence.classification_probes]:table.fill([])
        if not self._reloading:self.notice('Viewer unloaded. Saved analyses remain on disk.');self.refresh_status()
    def delete(self):
        if self.jobs.busy(self.key):self.error('Cancel and wait for active work first');return
        try:self.store.delete_artifact(self.key,self.instrument.currentData());self.reload();self.notice('Deleted selected saved result. Other analyses and source arrays are unchanged.')
        except Exception as exc:self.error(exc)
    def pin(self):
        name=self.instrument.currentData();keys=[k for k in self.cache.cache if k.startswith(name+'/')]
        if all(k in self.cache.pins for k in keys):self.cache.pins.difference_update(keys)
        else:self.cache.pins.update(keys)
    def reload(self):
        current=self.field.currentText();l=self.landscape;pose=dict(position=l.position.copy(),yaw=l.yaw,zoom=l.zoom,look_distance=l.look_distance,camera_pan=l.camera_pan.copy()) if self._view_loaded_once else self.store.navigation(self.key)
        self._reloading=True;self.field.blockSignals(True)
        try:
            self.unload();self.store=Store(self.store.catalog.root);self.store.validate(self.key);self.load_errors={}
            for instrument in REGISTRY:
                if not (self.store.artifact_path(self.key,instrument)/'metadata.json').exists():continue
                try:
                    arrays,meta=self.store.artifact(self.key,instrument)
                    if self.cache.nbytes+sum(v.nbytes for v in arrays.values())>self.cache.max_bytes:self.load_errors[instrument]='Exceeds remaining viewer memory; close/unload other analyses.';continue
                    copied={}
                    for k,v in arrays.items():value=np.asarray(v).copy();self.cache.put(instrument+'/'+k,value);copied[k]=value
                    self.loaded[instrument]=(copied,meta)
                except Exception as exc:self.load_errors[instrument]=str(exc)
            if 'geometry' in self.loaded:
                arrays,meta=self.loaded['geometry'];l.set_geometry(arrays)
                self.radius.blockSignals(True);self.radius.setValue(l.radius);self.radius.blockSignals(False)
                for name in ['effective_dimension','hidden_two','radius','radius_dimension']:self.fields['geometry/'+name]=arrays[name]
                for instrument,(a,m) in self.loaded.items():
                    for name in ['discrepancy','perturbation_jaccard','resampling_jaccard','deletion_damage']:
                        if name in a:self.fields[instrument+'/'+name]=a[name]
                for name in self.definition['settings']['features']:
                    values,known=self.store.catalog.feature(name,l.rows);self.fields['feature/'+name]=np.where(known,values,np.nan)
                for instrument in ['reconstruction','reference_evaluation','compression']:
                    if instrument in self.loaded:
                        for name,v in self.loaded[instrument][0].items():
                            if v.ndim==1 and len(v)==len(l.rows) and name not in ('anchor_rows','context_rows','mean'):self.fields[instrument+'/'+name]=v
                self.field.addItems(self.fields);self.field.setCurrentText(current if current in self.fields else next(iter(self.fields),''))
                if pose:
                    l.position=np.asarray(pose.get('position',l.position));l.yaw=pose.get('yaw',0);l.zoom=pose.get('zoom',1);l.look_distance=pose.get('look_distance',2);l.camera_pan=np.asarray(pose.get('camera_pan',[0.,0.,0.]),float)
                    if not self._view_loaded_once:
                        for control,k,default in [(self.relief,'relief',.5),(self.mode,'mode3d',False),(self.filtration,'filtration_slider',1000)]:
                            control.blockSignals(True)
                            if isinstance(control,QCheckBox):control.setChecked(pose.get(k,default));l.mode3d=pose.get(k,default)
                            else:control.setValue(pose.get(k,default))
                            control.blockSignals(False)
                        l.relief=self.relief.value()
                l.highlights=self.selected_rows;self._view_loaded_once=True
            self.field.blockSignals(False);self._reloading=False;self.rebuild_measure_choices();self.change_field();self.apply_filtration();self.evidence.draw_anatomy() if l.arrays is not None else None;self.evidence.refresh();self.update_selection_info()
            self.notice(f'Loaded {len(self.loaded)} saved analyses. No models were refitted.'+(' Some results could not be loaded: '+str(self.load_errors) if self.load_errors else ''))
        except Exception as exc:self.error('Load failed: '+str(exc))
        finally:self.field.blockSignals(False);self._reloading=False
    def setting(self,k,v):
        if self._reloading:return
        setattr(self.landscape,k,v)
        if k in ('radius','look_distance'):self.landscape._update_observer()
        else:self.landscape.redraw()
        self.schedule_evidence()
    def set_lens(self,lens):
        self._lens=lens
        for name,button in self.lens_buttons.items():button.setChecked(name==lens)
        self.rebuild_measure_choices()
        if lens=='feature':self.feature_changed()
        elif lens=='prediction':self.reconstruction_field()
        elif lens=='gap':self.show_key('discrepancy/discrepancy','discrepancy')
        else:self.measure_changed()
    def rebuild_measure_choices(self):
        from .evidence import label
        current=self.field.currentText();self.measure.blockSignals(True);self.measure.clear()
        keys=[k for k in self.fields if k.startswith(('geometry/','compression/','stability/','routes/'))] if self._lens=='geometry' else [k for k in self.fields if k.startswith('discrepancy/')] if self._lens=='gap' else []
        for k in keys:self.measure.addItem(label(k),k)
        found=self.measure.findData(current)
        if found>=0:self.measure.setCurrentIndex(found)
        self.measure.setEnabled(bool(keys));self.measure.blockSignals(False)
    def measure_changed(self,*_):
        if not self._reloading and self.measure.currentData():self.show_key(self.measure.currentData(),'geometry')
    def geometry_changed(self,*_):
        if self._lens=='geometry':self.show_key('geometry/'+self.geometry_metric.currentData(),'geometry')
        self.schedule_evidence()
    def feature_changed(self,*_):
        if self._lens=='prediction':self.reconstruction_field()
        elif self._lens=='feature':self.show_key('feature/'+self.feature.currentText(),'geometry')
        self.schedule_evidence()
    def reconstruction_field(self,*_):
        if self._reloading:return
        if self._lens=='prediction':
            prefix='reconstruction' if 'reconstruction' in self.loaded else 'reference_evaluation';key=f'{prefix}/{self.feature.currentText()}__q{self.dimension.currentText()}__{self.account.currentData()}'
            self.show_key(key,prefix)
        self.schedule_evidence()
    def show_key(self,key,instrument):
        if key in self.fields:self.field.setCurrentText(key);self.change_field()
        else:
            self.map_reading.setText('This measurement is not computed / loaded. Open Compute & storage → '+instrument.replace('_',' ')+'.')
            if self.landscape.arrays is not None:self.landscape.values=np.full(len(self.landscape.rows),np.nan);self.landscape.categorical=False;self.landscape.redraw()
    def change_field(self,*_):
        if self._reloading:return
        from .evidence import label
        key=self.field.currentText();l=self.landscape
        if key not in self.fields:return
        prefix=key.split('/',1)[0];self._lens='feature' if prefix=='feature' else 'gap' if prefix=='discrepancy' else 'prediction' if prefix in ('reconstruction','reference_evaluation') else 'geometry'
        for name,button in self.lens_buttons.items():button.setChecked(name==self._lens)
        if prefix=='feature':
            self.feature.blockSignals(True);self.feature.setCurrentText(key.split('/',1)[1]);self.feature.blockSignals(False)
        elif '__q' in key:
            target,parts=key.split('/',1)[1].split('__q',1);q,measure=parts.split('__',1)
            for control,value in [(self.feature,target),(self.dimension,q)]:control.blockSignals(True);control.setCurrentText(value);control.blockSignals(False)
            self.account.blockSignals(True);self.account.setCurrentIndex(self.account.findData(measure));self.account.blockSignals(False)
        self.rebuild_measure_choices()
        l.categorical=key.startswith('feature/') and self.store.catalog.raw['features'][key.split('/',1)[1]]['kind']=='category'
        if l.categorical:
            name=key.split('/',1)[1];spec=self.store.catalog.raw['features'][name];dictionary=self.store.catalog.labels(name);l.category_labels=dictionary;l.category_colors=[dictionary.get(str(code),{}).get('color',matplotlib.colormaps['tab20'](code%20)) for code in range(spec['cardinality'])]
        l.values=self.fields[key];l.force_signed=key.endswith('__gain') or key=='discrepancy/discrepancy';l.color_label=label(key)
        if '__q' in key and key.startswith(('reconstruction/','reference_evaluation/')):
            target,tail=key.split('/',1)[1].split('__q',1);q,account=tail.split('__',1);kind=self.store.catalog.raw['features'][target]['kind'];unit='MAE' if kind=='numeric' else 'binary Brier' if kind=='boolean' else 'multiclass Brier';l.color_label=f'{target} · {account} {unit} · {q} PCs'
        self.map_reading.setText(label(key)+f'\n{np.isfinite(l.values).sum():,} measured anchors with values. Gray/blank = unavailable.');l.redraw();self.schedule_evidence()
    def profiles(self):self.schedule_evidence()
    def schedule_evidence(self):
        if not self.profile_timer.isActive():self.profile_timer.start()
    def update_evidence(self):
        if self.landscape.arrays is None:return
        self.look.blockSignals(True);self.look.setValue(self.landscape.look_distance);self.look.blockSignals(False)
        self.evidence.refresh();here=self.landscape.attention();ahead=self.landscape.attention(True);self.reading.setText(f'Here: {len(here)} measured anchors · Ahead: {len(ahead)}\nRibbon width = attention region. Profiles show local spread, not confidence.');self.update_selection_info()
    def apply_filtration(self):
        l=self.landscape
        if l.arrays is None:return
        from scipy.sparse.csgraph import connected_components
        from .kernels.geometry import sparse_graph
        lengths=l.arrays['lengths'];radius=float(lengths.max())*self.filtration.value()/1000 if len(lengths) else 0.;keep=lengths<=radius;graph=sparse_graph(len(l.rows),l.arrays['edges'][keep],lengths[keep]);count,labels=connected_components(graph,directed=False)
        l.component_labels=labels;self.filtration_radius=radius;self.filtration_reading.setText(f'{radius:.4g} chord · {count} components · {int(keep.sum())} edges');l.redraw();self.schedule_evidence()
    def keep_component(self):
        l=self.landscape
        if l.arrays is None:return
        finite=np.flatnonzero(np.isfinite(l.arrays['xy']).all(1))
        if not len(finite):return
        i=finite[np.argmin(np.linalg.norm(l.arrays['xy'][finite]-l.position,axis=1))];labels=l.component_labels if l.component_labels is not None else l.arrays['filtration_labels'][-1];self.set_selection(l.rows[labels==labels[i]])
    def keep_region(self,ahead):
        if self.landscape.arrays is not None:self.set_selection(self.landscape.rows[self.landscape.attention(ahead)])
    def set_selection(self,rows):
        from .catalog import rows_checked
        self.selected_rows=rows_checked(np.asarray(rows,np.int64),self.store.catalog.n(self.definition['collection']));self.query_rows=self.selected_rows;self.landscape.highlights=self.selected_rows;self.landscape.redraw();self.update_selection_info();self.schedule_evidence()
        if self.link_auto.isChecked():self.send_selection()
    def update_selection_info(self):
        count=len(self.selected_rows);l=self.landscape
        plotted=int(np.count_nonzero(np.isin(l.rows,self.selected_rows)&np.isfinite(l.arrays['xy']).all(1))) if l.rows is not None else 0
        self.selection_info.setText(f'{count:,} canonical items kept · {plotted:,} projected measured anchors outlined · {count-plotted:,} unmeasured/unprojected. Kept membership is separate from attention.')
    def send_selection(self):
        try:
            result=self.link_callback(self.definition['collection'],self.selected_rows);self.notice(result or f'Linked {len(self.selected_rows):,} kept items to compatible population views.')
        except Exception as exc:self.error(exc)
    def fit_map(self,*_):
        l=self.landscape;l.zoom=min(1.,1/max(1.,l.relief*.4)) if l.mode3d else 1.;l.camera_pan[:]=0
        if self.fill_view.isChecked() and l.arrays is not None:
            xy=l.arrays['xy'];xy=xy[np.isfinite(xy).all(1)];span=np.ptp(xy,axis=0) if len(xy) else np.ones(2);aspect=max(1,l.canvas.width())/max(1,l.canvas.height());l.zoom=max(1,aspect if span[0]<=span[1] else 1/aspect)
        l.redraw()
    def expand_chart(self,expanded):
        if expanded:self.full_evidence.setChecked(False)
        self.sidebar.setVisible(not expanded);self.evidence.setVisible(not expanded);self.landscape.setVisible(True);self.full_map.setText('Restore panels' if expanded else 'Expand chart');QTimer.singleShot(0,self.fit_map)
    def expand_evidence(self,expanded):
        if expanded:self.full_map.setChecked(False)
        self.landscape.setVisible(not expanded);self.full_evidence.setText('Restore chart' if expanded else 'Expand evidence')
        if expanded:self.evidence.refresh()
    def cancel_work(self):
        if self.jobs.busy(self.key) or getattr(self,'query_future',None) is not None and not self.query_future.done():self.notice('Cancellation requested; waiting for the current bounded step.')
        self.jobs.cancel(self.key)
        if getattr(self,'query_token',None) is not None:self.query_token.cancel()
    def query_feature(self):
        from .selection import query
        feature=self.feature.currentText()
        operator,ok=QInputDialog.getItem(self,'Query frozen cohort','Operator',['eq','gt','lt','known','unknown'],0,False)
        if not ok:return
        value=None
        if operator not in ('known','unknown'):
            value,ok=QInputDialog.getDouble(self,'Query frozen cohort','Numeric value or category code',0,-1e12,1e12,6)
            if not ok:return
        if getattr(self,'query_future',None) is not None:return
        from .store import Token
        self.query_token=Token()
        self.query_future=self.jobs.executor.submit(query,self.store.catalog,self.definition['collection'],self.store.membership(self.key),feature,operator,value,self.query_token)
        self.notice('Feature query queued on the background worker. Kept results will be outlined; the question remains unchanged.')
    def explore_query(self):
        if not len(getattr(self,'query_rows',[])):self.error('Run a nonempty feature query first');return
        try:
            d=self.store.create('Query of '+self.definition['title'],self.definition['domain'],self.query_rows,self.definition['settings'])
            window=self.window()
            if hasattr(window,'open_exploration'):window.open_exploration(d['id'])
        except Exception as exc:self.error(exc)
    def link_here(self):self.send_selection()
    def link_all(self):self.set_selection(np.asarray(self.store.membership(self.key)))
    def export(self):
        path,_=QFileDialog.getSaveFileName(self,'Export entire kept selection','kept-selection.csv','CSV (*.csv)')
        if not path:return
        rows=self.selected_rows;ids=self.store.catalog.load(self.store.catalog.collection(self.definition['collection'])['item_ids'])[rows];lookup={int(r):i for i,r in enumerate(self.landscape.rows)} if self.landscape.rows is not None else {}
        with open(path,'w',newline='') as stream:
            out=csv.writer(stream);out.writerow(['item_id','collection_row','mapped_value','measured_anchor'])
            for item,row in zip(ids,rows):
                i=lookup.get(int(row));v=self.landscape.values[i] if i is not None else np.nan;out.writerow([str(item),int(row),float(v) if np.isfinite(v) else '',i is not None])
        self.notice(f'Exported all {len(rows):,} kept canonical items.')
    def labels(self):
        try:
            f=self.feature.currentText();labels=self.store.catalog.labels(f);self.label_names=labels;self.change_field();QMessageBox.information(self,'Label dictionary',json.dumps(labels,indent=2))
        except Exception as exc:self.error(exc)
    def save_navigation(self):
        import os
        folder=self.store.folder(self.key);temporary=folder/'kept_selection.pending.npy';np.save(temporary,self.selected_rows,allow_pickle=False);os.replace(temporary,folder/'kept_selection.npy')
        l=self.landscape;self.store.save_navigation(self.key,dict(position=l.position,yaw=l.yaw,zoom=l.zoom,relief=l.relief,mode3d=l.mode3d,look_distance=l.look_distance,filtration_slider=self.filtration.value(),mapped_field=self.field.currentText(),camera_pan=l.camera_pan))
    def dispose(self):
        self.cancel_work();self.save_navigation();self.timer.stop();self.profile_timer.stop();self.filtration_timer.stop();self.landscape.timer.stop();self.landscape._resize_timer.stop();self.unload();self.landscape.fig.clear()


class ComparisonWidget(QWidget):
    def __init__(self,root,parent=None):
        super().__init__(parent);self.store=Store(root);layout=QVBoxLayout(self);row=QHBoxLayout();layout.addLayout(row)
        self.a=QComboBox();self.b=QComboBox();self.instrument=QComboBox();self.instrument.addItems(REGISTRY);self.instrument.setCurrentText('geometry');self.channel=QComboBox()
        for d in self.store.definitions():self.a.addItem(d['title'],d['id']);self.b.addItem(d['title'],d['id'])
        if self.b.count()>1:self.b.setCurrentIndex(1)
        for w in [self.a,self.b,self.instrument,self.channel]:row.addWidget(w)
        button=QPushButton('Compare canonical items');button.clicked.connect(self.refresh);row.addWidget(button)
        maps=QSplitter();self.left=Landscape();self.right=Landscape();maps.addWidget(self.left);maps.addWidget(self.right);layout.addWidget(maps,3)
        self.text=QPlainTextEdit();self.text.setReadOnly(True);layout.addWidget(self.text,1)
        self.left.changed.connect(lambda:self.link(self.left,self.right));self.right.changed.connect(lambda:self.link(self.right,self.left));self.channel.currentTextChanged.connect(self.change_channel);self.values={};self.refresh()
    def link(self,source,target):
        if source.arrays is None or target.arrays is None:return
        target.highlights=source.rows[source.attention()];target.redraw()
    def refresh(self):
        try:
            a,b=self.a.currentData(),self.b.currentData();instrument=self.instrument.currentText()
            result=compare(self.store,a,b,instrument);self.text.setPlainText(json.dumps(clean(result),indent=2))
            ga,_=self.store.artifact(a,'geometry');gb,_=self.store.artifact(b,'geometry');self.left.set_geometry(ga);self.right.set_geometry(gb)
            aa,_=self.store.artifact(a,instrument);bb,_=self.store.artifact(b,instrument)
            self.values={k:(aa[k],bb[k]) for k in aa if k in bb and aa[k].ndim==1 and len(aa[k])==len(ga['anchor_rows']) and len(bb[k])==len(gb['anchor_rows']) and k not in ['anchor_rows','context_rows','regions','filtration_radii','lengths','mean']}
            self.channel.clear();self.channel.addItems(self.values);self.change_channel()
        except Exception as exc:self.text.setPlainText(str(exc))
    def change_channel(self,*_):
        pair=self.values.get(self.channel.currentText())
        if pair is None:return
        finite=np.r_[pair[0][np.isfinite(pair[0])],pair[1][np.isfinite(pair[1])]];limit=max(1e-12,np.max(np.abs(finite))) if len(finite) else 1
        for view,values in zip([self.left,self.right],pair):view.values=values;view.force_signed=bool(np.any(finite<0) or 'gain' in self.channel.currentText() or self.channel.currentText()=='discrepancy');view.color_limit=limit;view.color_label=self.channel.currentText().replace('_',' ');view.redraw()
    def dispose(self):
        for view in [self.left,self.right]:view.timer.stop();view.fig.clear();view.arrays=None
