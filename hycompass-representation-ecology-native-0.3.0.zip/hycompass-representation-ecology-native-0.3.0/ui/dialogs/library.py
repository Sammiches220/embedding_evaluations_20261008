################################################################################
# CONFIGURATION
################################################################################
from __future__ import annotations

import re
from dataclasses import dataclass

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QMessageBox, QPushButton, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
)


################################################################################
# FUNCTIONS
################################################################################
def normalized_folder(value: str) -> str:
    parts = [p.strip() for p in str(value or "").replace("\\", "/").split("/") if p.strip()]
    return "/".join(parts)


def library_id(prefix: str, folder: str, title: str, existing: set[str]) -> str:
    base = "/".join(x for x in (normalized_folder(folder), title.strip()) if x)
    slug = re.sub(r"[^a-zA-Z0-9._/-]+", "-", base).strip("-/").replace("/", "__").lower()
    slug = slug or prefix
    candidate = f"{prefix}:{slug}"
    i = 2
    while candidate in existing:
        candidate = f"{prefix}:{slug}-{i}"
        i += 1
    return candidate


################################################################################
# CLASSES
################################################################################
@dataclass(frozen=True)
class LibraryEntry:
    id: str
    title: str
    folder: str = ""

class SaveLibraryItemDialog(QDialog):
    def __init__(self, *, noun: str, title: str = "", folder: str = "", parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(f"Save {noun}")
        layout = QVBoxLayout(self)
        hint = QLabel("Use / in the folder name to create a hierarchy.")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        form = QFormLayout()
        self.folder_edit = QLineEdit(normalized_folder(folder))
        self.title_edit = QLineEdit(title)
        form.addRow("Folder", self.folder_edit)
        form.addRow("Name", self.title_edit)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _accept(self) -> None:
        if not self.title_edit.text().strip():
            QMessageBox.warning(self, "Name required", "Enter a name before saving.")
            return
        self.accept()

    @property
    def item_title(self) -> str:
        return self.title_edit.text().strip()

    @property
    def folder(self) -> str:
        return normalized_folder(self.folder_edit.text())


class LibraryBrowserDialog(QDialog):
    """Hierarchical browser for saved Views or SavedQueries."""

    def __init__(self, entries: list[LibraryEntry], *, noun: str, allow_delete: bool = True, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(f"Saved {noun}s")
        self.resize(520, 560)
        self._noun = noun
        self._entries = {e.id: e for e in entries}
        self.selected_id: str | None = None
        layout = QVBoxLayout(self)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels([f"Saved {noun}s"])
        self.tree.itemDoubleClicked.connect(self._double_clicked)
        layout.addWidget(self.tree, 1)
        row = QHBoxLayout()
        self.open_btn = QPushButton("Load")
        self.delete_btn = QPushButton("Delete")
        self.close_btn = QPushButton("Close")
        row.addWidget(self.open_btn)
        if allow_delete:
            row.addWidget(self.delete_btn)
        row.addStretch(1)
        row.addWidget(self.close_btn)
        layout.addLayout(row)
        self.open_btn.clicked.connect(self._open)
        self.delete_btn.clicked.connect(self._delete_selected)
        self.close_btn.clicked.connect(self.reject)
        self.deleted_ids: list[str] = []
        self._populate()

    def _populate(self) -> None:
        self.tree.clear()
        folder_nodes: dict[str, QTreeWidgetItem] = {"": self.tree.invisibleRootItem()}
        for entry in sorted(self._entries.values(), key=lambda e: (normalized_folder(e.folder).lower(), e.title.lower())):
            folder = normalized_folder(entry.folder)
            parent = self.tree.invisibleRootItem()
            current = ""
            for part in ([p for p in folder.split("/") if p]):
                current = f"{current}/{part}".strip("/")
                if current not in folder_nodes:
                    node = QTreeWidgetItem([part])
                    node.setData(0, Qt.ItemDataRole.UserRole, None)
                    parent.addChild(node)
                    folder_nodes[current] = node
                parent = folder_nodes[current]
            item = QTreeWidgetItem([entry.title])
            item.setData(0, Qt.ItemDataRole.UserRole, entry.id)
            item.setToolTip(0, entry.id)
            parent.addChild(item)
        self.tree.expandToDepth(1)

    def _current_id(self) -> str | None:
        item = self.tree.currentItem()
        return item.data(0, Qt.ItemDataRole.UserRole) if item else None

    def _open(self) -> None:
        item_id = self._current_id()
        if item_id:
            self.selected_id = str(item_id)
            self.accept()

    def _double_clicked(self, item, _column) -> None:
        item_id = item.data(0, Qt.ItemDataRole.UserRole)
        if item_id:
            self.selected_id = str(item_id)
            self.accept()

    def _delete_selected(self) -> None:
        item_id = self._current_id()
        if not item_id:
            return
        entry = self._entries[str(item_id)]
        answer = QMessageBox.question(self, f"Delete {self._noun}", f"Delete {entry.title!r} from the saved library?")
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.deleted_ids.append(str(item_id))
        self._entries.pop(str(item_id), None)
        self._populate()


################################################################################
if __name__=="__main__":
    pass
