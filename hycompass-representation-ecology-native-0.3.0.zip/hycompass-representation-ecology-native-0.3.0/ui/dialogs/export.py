################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QComboBox, QDialog, QDialogButtonBox, QLabel, QListWidget, QListWidgetItem, QVBoxLayout


################################################################################
# CLASSES
################################################################################
class FeatureExportDialog(QDialog):
    def __init__(self, features: list[tuple[str, str]], parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Export selected points")
        self.resize(480, 560)
        layout = QVBoxLayout(self)
        label = QLabel("Choose Latent Observer-native features to export with the current Working Selection.")
        label.setWordWrap(True)
        layout.addWidget(label)
        self.features = QListWidget()
        for display, feature in features:
            item = QListWidgetItem(display)
            item.setData(Qt.ItemDataRole.UserRole, feature)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            default = feature in {"position", "timeline"} or feature.startswith(("density:", "segmentation:", "exploration:"))
            item.setCheckState(Qt.CheckState.Checked if default else Qt.CheckState.Unchecked)
            self.features.addItem(item)
        layout.addWidget(self.features, 1)
        self.format = QComboBox()
        self.format.addItem("CSV", "csv")
        self.format.addItem("JSON Lines", "jsonl")
        layout.addWidget(self.format)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def selected_features(self) -> list[str]:
        return [
            str(self.features.item(i).data(Qt.ItemDataRole.UserRole))
            for i in range(self.features.count())
            if self.features.item(i).checkState() == Qt.CheckState.Checked
        ]


################################################################################
if __name__=="__main__":
    pass
