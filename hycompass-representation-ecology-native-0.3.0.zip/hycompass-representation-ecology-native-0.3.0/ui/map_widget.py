################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

import numpy as np
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtWidgets import QFileDialog
import traceback

##### Internal Imports #####
from interaction.controller import InteractionController
from model.workspace.session import ViewData
from render.camera import Camera
from render.renderer import Renderer


################################################################################
# CLASSES
################################################################################
class MapWidget(QOpenGLWidget):
    pointHovered = Signal(object)
    pointClicked = Signal(object)
    landmarkClicked = Signal(int)
    lassoFinished = Signal(object)

    def __init__(self, dataset: ViewData, parent=None) -> None:
        super().__init__(parent)
        self.dataset = dataset
        self.camera = Camera(dataset.bounds)
        self.renderer = Renderer(dataset, self.camera)
        self.interaction = InteractionController(dataset, self.camera)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.frameSwapped.connect(self.renderer.frame_swapped)
        self._restore_camera()

    @property
    def state(self):
        return self.renderer.state

    def initializeGL(self) -> None:
        try:
            self.renderer.initialize()
        except Exception:
            print("MapWidget OpenGL initialization failed.")
            traceback.print_exc()
            return

    def resizeGL(self, width: int, height: int) -> None:
        self.renderer.resize(width, height, self.devicePixelRatioF())

    def paintGL(self) -> None:
        self.renderer.draw(self.width(), self.height(), self.devicePixelRatioF())

    def paintEvent(self, event) -> None:
        # Let QOpenGLWidget composite the framebuffer first.
        super().paintEvent(event)

        painter = QPainter(self)

        try:
            painter.setRenderHint(
                QPainter.RenderHint.Antialiasing,
                True
            )

            if self.renderer.initialization_error is not None:
                painter.setPen(
                    self._qcolor(
                        self.dataset.theme.color("points.active")
                    )
                )

                message = (
                    "OpenGL renderer initialization failed.\n\n"
                    f"{type(self.renderer.initialization_error).__name__}: "
                    f"{self.renderer.initialization_error}"
                )

                painter.drawText(
                    self.rect().adjusted(24, 24, -24, -24),
                    (
                        Qt.AlignmentFlag.AlignLeft
                        | Qt.AlignmentFlag.AlignTop
                        | Qt.TextFlag.TextWordWrap
                    ),
                    message,
                )

                return

            self._paint_lasso(painter)
            self._paint_segment_labels(painter)

        finally:
            painter.end()

    @staticmethod
    def _qcolor(rgba) -> QColor:
        vals = list(rgba)
        if len(vals) == 3:
            vals.append(1.0)
        return QColor.fromRgbF(*map(float, vals[:4]))

    def _paint_lasso(self, painter: QPainter) -> None:
        points = self.interaction.lasso_points
        if len(points) < 2:
            return
        color = self._qcolor(self.dataset.theme.color("lasso"))
        pen = QPen(color)
        pen.setWidthF(max(1.0, self.state.point_size * 0.9))
        pen.setCosmetic(True)
        painter.setPen(pen)
        last = None
        for world in points:
            x, y = self.camera.world_to_screen(world, self.width(), self.height())
            current = QPointF(x, y)
            if last is not None:
                painter.drawLine(last, current)
            last = current

    def _paint_segment_labels(self, painter: QPainter) -> None:
        if not self.state.show_segmentations:
            return
        occupied: list[QRectF] = []
        for binding in self.dataset.segmentations:
            style = self.dataset.spec.segmentation_styles.get(binding.spec.id, {})
            if not style.get("labels", self.state.segmentation_labels):
                continue
            opacity=float(np.clip(style.get("label_opacity",1.0),0.0,1.0))
            label_rgba=list(style.get("label_color",self.dataset.theme.color("segmentation.label")))
            outline_rgba=list(style.get("label_outline_color",self.dataset.theme.color("segmentation.label_outline")))
            while len(label_rgba)<4: label_rgba.append(1.0)
            while len(outline_rgba)<4: outline_rgba.append(1.0)
            label_rgba[3]*=opacity; outline_rgba[3]*=opacity
            label_color=self._qcolor(label_rgba); outline=self._qcolor(outline_rgba)
            font=painter.font()
            base_size=float(style.get("label_size",14.0))
            zoom_boost=max(0.0,np.log2(max(self.camera.zoom,1.0))*0.55)
            font.setPointSizeF(max(8.0,min(48.0,base_size+zoom_boost)))
            painter.setFont(font)
            outline_width=max(0.0,float(style.get("label_outline_width",3.5)))
            # Prioritize populated regions and cap labels to avoid pathological overlays.
            stats=sorted(binding.stats,key=lambda s:int(s.get("population",0)),reverse=True)[:250]
            for st in stats:
                x,y=self.camera.world_to_screen(np.array([st.get("x",0.0),st.get("y",0.0)]),self.width(),self.height())
                if x<0 or y<0 or x>self.width() or y>self.height():
                    continue
                text=str(st.get("name") or st.get("label") or f"L{int(st.get('id',0))}")
                path=QPainterPath(); path.addText(QPointF(0.0,0.0),font,text)
                br=path.boundingRect(); path.translate(x-br.center().x(),y-br.center().y())
                box=path.boundingRect().adjusted(-outline_width-4,-outline_width-3,outline_width+4,outline_width+3)
                if any(box.intersects(other) for other in occupied):
                    continue
                occupied.append(box)
                painter.setBrush(label_color)
                pen=QPen(outline); pen.setWidthF(outline_width); pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin); pen.setCosmetic(True)
                painter.setPen(pen); painter.drawPath(path)


    def set_selection(self, rows: np.ndarray) -> None:
        self.renderer.selection_layer.set_selection(rows)
        self.update()

    def clear_selection(self) -> None:
        self.set_selection(np.empty(0, dtype=np.uint32))

    def set_highlights(self, rows: np.ndarray) -> None:
        self.renderer.selection_layer.set_highlights(rows)
        self.update()

    def clear_highlights(self) -> None:
        self.set_highlights(np.empty(0, dtype=np.uint32))

    def set_visibility_mask(self, mask: np.ndarray | None) -> None:
        self.renderer.resources.set_visibility_mask(mask)
        self.update()

    def set_pick_filter(self, callback) -> None:
        self.interaction.set_pick_filter(callback)

    def set_mode(self, mode: str) -> None:
        self.interaction.set_mode(mode)
        self.update()

    def reset_view(self) -> None:
        self.camera.reset()
        self.update()

    def focus_row(self, row: int) -> None:
        self.camera.focus(self.dataset.positions[int(row)])
        self.update()

    def fit_rows(self, rows: np.ndarray) -> None:
        rows = np.asarray(rows, dtype=np.uint32)
        if len(rows):
            self.camera.fit_points(self.dataset.positions[rows], self.width(), self.height())
            self.update()

    def camera_state(self) -> dict:
        return {"center": [float(x) for x in self.camera.view_center], "zoom": float(self.camera.zoom)}

    def _restore_camera(self) -> None:
        camera = self.dataset.spec.metadata.get("camera") if isinstance(self.dataset.spec.metadata, dict) else None
        if not isinstance(camera, dict):
            return
        center = camera.get("center")
        if isinstance(center, list) and len(center) == 2:
            self.camera.view_center = np.asarray(center, dtype=np.float64)
        if camera.get("zoom") is not None:
            self.camera.zoom = float(camera["zoom"])

    def wheelEvent(self, event) -> None:
        steps = event.angleDelta().y() / 120
        if steps:
            self.camera.zoom_at(steps, event.position().x(), event.position().y(), self.width(), self.height())
            self.update()
        event.accept()

    def mousePressEvent(self, event) -> None:
        if event.button() != Qt.MouseButton.LeftButton:
            return
        self.interaction.press(event.position(), self.width(), self.height())
        if self.interaction.mode == "pan":
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
        self.update()
        event.accept()

    def mouseMoveEvent(self, event) -> None:
        if self.interaction.dragging:
            if self.interaction.move_drag(event.position(), self.width(), self.height()):
                self.update()
        else:
            emitted, row = self.interaction.hover(event.position(), self.width(), self.height())
            if emitted:
                self.pointHovered.emit(row)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() != Qt.MouseButton.LeftButton:
            return
        result = self.interaction.release(event.position(), self.width(), self.height())
        self.unsetCursor()
        if result.polygon is not None:
            self.lassoFinished.emit(result.polygon)
        elif result.point_row is not None:
            self.pointClicked.emit(result.point_row)
        elif result.landmark_id:
            self.landmarkClicked.emit(result.landmark_id)
        self.update()
        event.accept()

    def mouseDoubleClickEvent(self, event) -> None:
        self.reset_view()
        event.accept()

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key.Key_Escape and self.interaction.mode == "lasso":
            self.interaction.cancel_lasso()
            self.update()
            return
        super().keyPressEvent(event)

    def save_png(self) -> None:
        filename, _ = QFileDialog.getSaveFileName(self, "Save map", str(Path.home() / "latent_map.png"), "PNG (*.png)")
        if filename:
            self.grabFramebuffer().save(filename, "PNG")


################################################################################
if __name__=="__main__":
    pass
