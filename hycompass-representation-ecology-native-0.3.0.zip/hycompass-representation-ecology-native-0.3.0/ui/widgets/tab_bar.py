################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QTabBar


################################################################################
# CLASSES
################################################################################
class LibraryTabBar(QTabBar):
    emptyDoubleClicked = Signal()
    middleCloseRequested = Signal(int)

    def mouseDoubleClickEvent(self, event) -> None:
        if self.tabAt(event.position().toPoint()) < 0:
            self.emptyDoubleClicked.emit()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.MiddleButton:
            index = self.tabAt(event.position().toPoint())
            if index >= 0:
                self.middleCloseRequested.emit(index)
                event.accept()
                return
        super().mouseReleaseEvent(event)


################################################################################
if __name__=="__main__":
    pass
