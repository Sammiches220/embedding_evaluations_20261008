################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtGui import QColor
from PySide6.QtWidgets import QColorDialog, QPushButton


################################################################################
# CLASSES
################################################################################
class ColorButton(QPushButton):
    """Compact RGBA color editor whose value is a normalized four-float list."""

    def __init__(self, rgba=(1.0, 1.0, 1.0, 1.0), parent=None) -> None:
        super().__init__(parent)
        self._rgba = [1.0, 1.0, 1.0, 1.0]
        self.set_rgba(rgba)
        self.clicked.connect(self._choose)

    def rgba(self) -> list[float]:
        return list(self._rgba)

    def set_rgba(self, rgba) -> None:
        vals = list(rgba or [1, 1, 1, 1])
        if len(vals) == 3:
            vals.append(1.0)
        self._rgba = [max(0.0, min(1.0, float(x))) for x in vals[:4]]
        self._refresh()

    def _refresh(self) -> None:
        c = QColor.fromRgbF(*self._rgba)
        text = c.name(QColor.NameFormat.HexRgb)
        self.setText(text)
        fg = "#000000" if c.lightnessF() > 0.62 else "#ffffff"
        self.setStyleSheet(f"QPushButton {{ background: {text}; color: {fg}; }}")

    def _choose(self) -> None:
        current = QColor.fromRgbF(*self._rgba)
        chosen = QColorDialog.getColor(current, self, "Choose color", QColorDialog.ColorDialogOption.ShowAlphaChannel)
        if not chosen.isValid():
            return
        self._rgba = [chosen.redF(), chosen.greenF(), chosen.blueF(), chosen.alphaF()]
        self._refresh()


################################################################################
if __name__=="__main__":
    pass
