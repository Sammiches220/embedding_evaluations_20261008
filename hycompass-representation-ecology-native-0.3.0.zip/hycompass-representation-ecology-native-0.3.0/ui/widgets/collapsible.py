################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QToolButton, QVBoxLayout, QWidget


################################################################################
# CLASSES
################################################################################
class CollapsibleSection(QWidget):
    """Small disclosure section used by the long per-view sidebar."""

    def __init__(self, title: str, content: QWidget, *, expanded: bool = False, parent=None) -> None:
        super().__init__(parent)
        self.content = content
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 4)
        layout.setSpacing(2)

        self.toggle = QToolButton()
        self.toggle.setText(title)
        self.toggle.setCheckable(True)
        self.toggle.setChecked(bool(expanded))
        self.toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.toggle.setArrowType(Qt.ArrowType.DownArrow if expanded else Qt.ArrowType.RightArrow)
        self.toggle.setStyleSheet("QToolButton { font-weight: 600; text-align: left; padding: 5px; }")
        self.toggle.toggled.connect(self._set_expanded)
        layout.addWidget(self.toggle)

        # The child panels historically were QGroupBoxes with their own heading.
        # Hide that duplicate heading when used inside the disclosure wrapper.
        if hasattr(content, "setTitle"):
            content.setTitle("")
        content.setVisible(bool(expanded))
        layout.addWidget(content)

    def _set_expanded(self, expanded: bool) -> None:
        self.toggle.setArrowType(Qt.ArrowType.DownArrow if expanded else Qt.ArrowType.RightArrow)
        self.content.setVisible(expanded)


################################################################################
if __name__=="__main__":
    pass
