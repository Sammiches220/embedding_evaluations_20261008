################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtWidgets import QDoubleSpinBox, QFormLayout, QGroupBox, QSpinBox


################################################################################
# FUNCTIONS
################################################################################
def _spin(a: float, b: float, value: float, step: float = 0.01, decimals: int = 2) -> QDoubleSpinBox:
    spin = QDoubleSpinBox()
    spin.setRange(a, b)
    spin.setValue(value)
    spin.setSingleStep(step)
    spin.setDecimals(decimals)
    return spin


################################################################################
# CLASSES
################################################################################
class FieldDisplayPanel(QGroupBox):
    def __init__(self, parent=None) -> None:
        super().__init__("Field display", parent)
        form = QFormLayout(self)
        self.exploration_threshold = _spin(0.02, 0.95, 0.38)
        self.exploration_opacity = _spin(0.0, 1.0, 0.66, 0.05)
        self.density_threshold = _spin(0.0, 1.0, 0.04)
        self.density_opacity = _spin(0.0, 1.0, 0.42, 0.05)
        self.contours = QSpinBox()
        self.contours.setRange(1, 80)
        self.contours.setValue(12)
        form.addRow("Exploration threshold", self.exploration_threshold)
        form.addRow("Exploration opacity", self.exploration_opacity)
        form.addRow("Density threshold", self.density_threshold)
        form.addRow("Density opacity", self.density_opacity)
        form.addRow("Topo contours", self.contours)

    def configure(self, dataset) -> None:
        self.exploration_threshold.setEnabled(dataset.has_exploration)
        self.exploration_opacity.setEnabled(dataset.has_exploration)
        self.density_threshold.setEnabled(bool(dataset.densities))
        self.density_opacity.setEnabled(bool(dataset.densities))
        self.contours.setEnabled(bool(dataset.densities))


################################################################################
if __name__=="__main__":
    pass
