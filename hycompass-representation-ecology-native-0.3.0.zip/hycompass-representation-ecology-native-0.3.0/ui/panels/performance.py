################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtWidgets import QCheckBox, QFormLayout, QGroupBox, QSpinBox


################################################################################
# CLASSES
################################################################################
class PerformancePanel(QGroupBox):
    def __init__(self, parent=None) -> None:
        super().__init__("Performance", parent)
        form = QFormLayout(self)
        self.cap = QCheckBox("Cap inactive/background points")
        self.cap_count = QSpinBox(); self.cap_count.setRange(50_000, 10_000_000); self.cap_count.setValue(1_000_000); self.cap_count.setSingleStep(50_000)
        self.continuous = QCheckBox("Continuous render benchmark")
        form.addRow(self.cap)
        form.addRow("Approx. visible cap", self.cap_count)
        form.addRow(self.continuous)


################################################################################
if __name__=="__main__":
    pass
