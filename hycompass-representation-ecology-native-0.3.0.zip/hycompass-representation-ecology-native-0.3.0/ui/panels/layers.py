################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox, QDoubleSpinBox, QFormLayout, QGroupBox, QPushButton, QVBoxLayout,
)


################################################################################
# CLASSES
################################################################################
class LayersPanel(QGroupBox):
    def __init__(self, parent=None) -> None:
        super().__init__("Rendering", parent)
        root = QVBoxLayout(self)

        points_box = QGroupBox("Points")
        points = QFormLayout(points_box)
        self.point_size = QDoubleSpinBox(); self.point_size.setRange(0.5, 12); self.point_size.setValue(1.25); self.point_size.setSingleStep(0.25); self.point_size.setDecimals(2)
        self.show_active = QCheckBox("Show active selection"); self.show_active.setChecked(True)
        self.show_future = QCheckBox("Show selected future / missing-time items"); self.show_future.setChecked(True)
        self.show_outside = QCheckBox("Show outside-selection domain"); self.show_outside.setChecked(True)
        self.cluster_colors = QCheckBox("Color points by active clustering")
        points.addRow("Point size", self.point_size)
        for w in (self.show_active, self.show_future, self.show_outside, self.cluster_colors): points.addRow(w)
        root.addWidget(points_box)

        fields_box = QGroupBox("Field layers")
        fields = QVBoxLayout(fields_box)
        self.show_exploration = QCheckBox("Show exploration field"); self.show_exploration.setChecked(True)
        self.show_exploration_boundary = QCheckBox("Show exploration boundary"); self.show_exploration_boundary.setChecked(True)
        self.show_density = QCheckBox("Show density topography"); self.show_density.setChecked(True)
        self.show_segmentations = QCheckBox("Show segmentation boundaries"); self.show_segmentations.setChecked(True)
        self.segmentation_fill = QCheckBox("Fill segmentation regions")
        for w in (self.show_exploration, self.show_exploration_boundary, self.show_density, self.show_segmentations, self.segmentation_fill): fields.addWidget(w)
        root.addWidget(fields_box)

        output_box = QGroupBox("Output")
        output = QVBoxLayout(output_box)
        self.save_btn = QPushButton("Save PNG…")
        output.addWidget(self.save_btn)
        root.addWidget(output_box)

    def configure(self, dataset) -> None:
        self.show_future.setEnabled(dataset.has_timeline)
        self.cluster_colors.setEnabled(dataset.has_clusters)
        self.show_exploration.setEnabled(dataset.has_exploration)
        self.show_exploration_boundary.setEnabled(dataset.has_exploration)
        self.show_density.setEnabled(bool(dataset.densities))
        self.show_segmentations.setEnabled(bool(dataset.segmentations))
        self.segmentation_fill.setEnabled(bool(dataset.segmentations))
        self.show_exploration.setChecked(dataset.has_exploration)
        self.show_density.setChecked(bool(dataset.densities))
        self.show_segmentations.setChecked(bool(dataset.segmentations))


################################################################################
if __name__=="__main__":
    pass
