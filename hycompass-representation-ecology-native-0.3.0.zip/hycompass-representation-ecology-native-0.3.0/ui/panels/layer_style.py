################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QGroupBox, QSpinBox, QVBoxLayout

##### Internal Imports #####
from ui.widgets.color_button import ColorButton


################################################################################
# FUNCTIONS
################################################################################
def dspin(a, b, value, step=0.05):
    s=QDoubleSpinBox(); s.setRange(a,b); s.setValue(value); s.setSingleStep(step); s.setDecimals(2); return s


################################################################################
# CLASSES
################################################################################
class LayerStylePanel(QGroupBox):
    changed = Signal()

    def __init__(self, dataset, parent=None) -> None:
        super().__init__("Layer styles", parent)
        self.dataset=dataset
        root=QVBoxLayout(self)

        # Density -----------------------------------------------------------
        density_box=QGroupBox("Density")
        form=QFormLayout(density_box)
        self.density=QComboBox(); [self.density.addItem(d.spec.id,d.spec.id) for d in dataset.densities]
        self.density_mode=QComboBox(); [self.density_mode.addItem(x,x) for x in ("both","field","contours")]
        self.density_threshold=dspin(0,1,0.04,0.01); self.density_opacity=dspin(0,1,0.42); self.contours=QSpinBox(); self.contours.setRange(0,80); self.contours.setValue(12)
        self.density_contour_color=ColorButton([0.96,0.96,0.96,0.38])
        form.addRow("Layer",self.density); form.addRow("Display",self.density_mode); form.addRow("Threshold",self.density_threshold); form.addRow("Opacity",self.density_opacity); form.addRow("Contours",self.contours); form.addRow("Contour color",self.density_contour_color)
        root.addWidget(density_box)

        # Exploration -------------------------------------------------------
        exploration_box=QGroupBox("Exploration")
        form=QFormLayout(exploration_box)
        self.exploration_mode=QComboBox(); [self.exploration_mode.addItem(x,x) for x in ("both","field","boundary")]
        self.exploration_threshold=dspin(0,1,0.38,0.01); self.exploration_opacity=dspin(0,1,0.66); self.exploration_boundary=QCheckBox("Draw boundary"); self.exploration_boundary.setChecked(True)
        self.exploration_boundary_color=ColorButton([1,1,1,0.92])
        form.addRow("Display",self.exploration_mode); form.addRow("Threshold",self.exploration_threshold); form.addRow("Opacity",self.exploration_opacity); form.addRow(self.exploration_boundary); form.addRow("Boundary color",self.exploration_boundary_color)
        root.addWidget(exploration_box)

        # Segmentation ------------------------------------------------------
        segmentation_box=QGroupBox("Segmentation")
        form=QFormLayout(segmentation_box)
        self.segmentation=QComboBox(); [self.segmentation.addItem(s.spec.id,s.spec.id) for s in dataset.segmentations]
        self.seg_boundary=QCheckBox("Draw boundary"); self.seg_boundary.setChecked(True)
        self.seg_width=dspin(0.25,12,1.0,0.25)
        self.seg_width_mode=QComboBox(); self.seg_width_mode.addItem("Screen pixels", "pixels"); self.seg_width_mode.addItem("Relative to point size", "point-size")
        self.seg_boundary_opacity=dspin(0,1,0.78,0.05); self.seg_boundary_color=ColorButton(dataset.theme.color("segmentation.boundary"))
        self.seg_fill=QCheckBox("Fill regions"); self.seg_fill_opacity=dspin(0,1,0.12); self.seg_labels=QCheckBox("Show region labels")
        self.seg_label_size=dspin(8,40,14.0,1.0); self.seg_label_opacity=dspin(0,1,1.0,0.05); self.seg_label_outline=dspin(0,8,3.5,0.5)
        self.seg_label_color=ColorButton(dataset.theme.color("segmentation.label")); self.seg_label_outline_color=ColorButton(dataset.theme.color("segmentation.label_outline"))
        form.addRow("Layer",self.segmentation); form.addRow(self.seg_boundary); form.addRow("Boundary width",self.seg_width); form.addRow("Width mode",self.seg_width_mode); form.addRow("Boundary opacity",self.seg_boundary_opacity); form.addRow("Boundary color",self.seg_boundary_color); form.addRow(self.seg_fill); form.addRow("Fill opacity",self.seg_fill_opacity); form.addRow(self.seg_labels); form.addRow("Label size",self.seg_label_size); form.addRow("Label opacity",self.seg_label_opacity); form.addRow("Label outline width",self.seg_label_outline); form.addRow("Label color",self.seg_label_color); form.addRow("Label outline color",self.seg_label_outline_color)
        root.addWidget(segmentation_box)

        # Working selection / external highlight --------------------------
        overlay_box=QGroupBox("Selection / highlight overlays")
        form=QFormLayout(overlay_box)
        self.selection_visible=QCheckBox("Show Working Selection"); self.selection_visible.setChecked(True)
        self.selection_color=ColorButton(dataset.theme.color("working_selection")); self.selection_size=dspin(1,20,4.5,0.5)
        self.highlight_visible=QCheckBox("Show external/API highlights"); self.highlight_visible.setChecked(True)
        self.highlight_color=ColorButton(dataset.theme.color("highlight")); self.highlight_size=dspin(1,24,7.0,0.5)
        form.addRow(self.selection_visible); form.addRow("Selection color",self.selection_color); form.addRow("Selection point size",self.selection_size)
        form.addRow(self.highlight_visible); form.addRow("Highlight color",self.highlight_color); form.addRow("Highlight point size",self.highlight_size)
        root.addWidget(overlay_box)

        self.density.currentIndexChanged.connect(self._load_density)
        self.segmentation.currentIndexChanged.connect(self._load_seg)
        widgets=(self.density_mode,self.density_threshold,self.density_opacity,self.contours,self.density_contour_color,
                 self.exploration_mode,self.exploration_threshold,self.exploration_opacity,self.exploration_boundary,self.exploration_boundary_color,
                 self.seg_boundary,self.seg_width,self.seg_width_mode,self.seg_boundary_opacity,self.seg_boundary_color,self.seg_fill,self.seg_fill_opacity,self.seg_labels,self.seg_label_size,self.seg_label_opacity,self.seg_label_outline,self.seg_label_color,self.seg_label_outline_color,
                 self.selection_visible,self.selection_color,self.selection_size,self.highlight_visible,self.highlight_color,self.highlight_size)
        for w in widgets:
            signal = getattr(w, "valueChanged", None) or getattr(w, "toggled", None) or getattr(w, "currentIndexChanged", None) or getattr(w, "clicked", None)
            if signal is not None: signal.connect(self._save)
        self.exploration_mode.setCurrentText(str(self.dataset.spec.exploration_style.get("display_mode","both")))
        self._load_density(); self._load_seg(); self._load_overlay(); self.configure()

    def configure(self):
        for w in (self.density,self.density_mode,self.density_threshold,self.density_opacity,self.contours,self.density_contour_color): w.setEnabled(bool(self.dataset.densities))
        for w in (self.exploration_mode,self.exploration_threshold,self.exploration_opacity,self.exploration_boundary,self.exploration_boundary_color): w.setEnabled(self.dataset.has_exploration)
        for w in (self.segmentation,self.seg_boundary,self.seg_width,self.seg_width_mode,self.seg_boundary_opacity,self.seg_boundary_color,self.seg_fill,self.seg_fill_opacity,self.seg_labels,self.seg_label_size,self.seg_label_opacity,self.seg_label_outline,self.seg_label_color,self.seg_label_outline_color): w.setEnabled(bool(self.dataset.segmentations))

    def _load_density(self):
        aid=self.density.currentData()
        if not aid:return
        st=self.dataset.spec.density_styles.get(aid,{})
        self.density_mode.blockSignals(True); self.density_mode.setCurrentText(str(st.get("display_mode","both"))); self.density_mode.blockSignals(False)
        for w,v in ((self.density_threshold,st.get("threshold",0.04)),(self.density_opacity,st.get("opacity",0.42)),(self.contours,st.get("contours",12))):
            w.blockSignals(True); w.setValue(v); w.blockSignals(False)
        self.density_contour_color.set_rgba(st.get("contour_color",[0.96,0.96,0.96,0.38]))

    def _load_seg(self):
        aid=self.segmentation.currentData()
        if not aid:return
        st=self.dataset.spec.segmentation_styles.get(aid,{})
        vals=((self.seg_boundary,st.get("boundary",True)),(self.seg_width,st.get("boundary_width",1.0)),(self.seg_boundary_opacity,st.get("boundary_opacity",0.78)),(self.seg_fill,st.get("fill",False)),(self.seg_fill_opacity,st.get("fill_opacity",0.12)),(self.seg_labels,st.get("labels",False)),(self.seg_label_size,st.get("label_size",14.0)),(self.seg_label_opacity,st.get("label_opacity",1.0)),(self.seg_label_outline,st.get("label_outline_width",3.5)))
        for w,v in vals:
            w.blockSignals(True); w.setChecked(v) if hasattr(w,"setChecked") else w.setValue(v); w.blockSignals(False)
        self.seg_width_mode.blockSignals(True); self.seg_width_mode.setCurrentIndex(max(0,self.seg_width_mode.findData(st.get("boundary_width_mode","pixels")))); self.seg_width_mode.blockSignals(False)
        self.seg_boundary_color.set_rgba(st.get("boundary_color",self.dataset.theme.color("segmentation.boundary")))
        self.seg_label_color.set_rgba(st.get("label_color",self.dataset.theme.color("segmentation.label")))
        self.seg_label_outline_color.set_rgba(st.get("label_outline_color",self.dataset.theme.color("segmentation.label_outline")))

    def _load_overlay(self):
        style=self.dataset.spec.overlay_style
        sel=style.get("working_selection",{}) if isinstance(style,dict) else {}
        hi=style.get("highlight",{}) if isinstance(style,dict) else {}
        self.selection_visible.setChecked(bool(sel.get("visible",True))); self.selection_color.set_rgba(sel.get("color",self.dataset.theme.color("working_selection"))); self.selection_size.setValue(float(sel.get("size",4.5)))
        self.highlight_visible.setChecked(bool(hi.get("visible",True))); self.highlight_color.set_rgba(hi.get("color",self.dataset.theme.color("highlight"))); self.highlight_size.setValue(float(hi.get("size",7.0)))

    def _save(self,*_):
        did=self.density.currentData()
        if did:
            self.dataset.spec.density_styles.setdefault(did,{}).update({"display_mode":self.density_mode.currentText(),"threshold":float(self.density_threshold.value()),"opacity":float(self.density_opacity.value()),"contours":int(self.contours.value()),"contour_color":self.density_contour_color.rgba()})
        self.dataset.spec.exploration_style.update({"display_mode":self.exploration_mode.currentText(),"threshold":float(self.exploration_threshold.value()),"opacity":float(self.exploration_opacity.value()),"boundary":bool(self.exploration_boundary.isChecked()),"boundary_color":self.exploration_boundary_color.rgba()})
        self.dataset.current_exploration_threshold=float(self.exploration_threshold.value())
        sid=self.segmentation.currentData()
        if sid:
            self.dataset.spec.segmentation_styles.setdefault(sid,{}).update({"boundary":bool(self.seg_boundary.isChecked()),"boundary_width":float(self.seg_width.value()),"boundary_width_mode":self.seg_width_mode.currentData(),"boundary_opacity":float(self.seg_boundary_opacity.value()),"boundary_color":self.seg_boundary_color.rgba(),"fill":bool(self.seg_fill.isChecked()),"fill_opacity":float(self.seg_fill_opacity.value()),"labels":bool(self.seg_labels.isChecked()),"label_size":float(self.seg_label_size.value()),"label_opacity":float(self.seg_label_opacity.value()),"label_outline_width":float(self.seg_label_outline.value()),"label_color":self.seg_label_color.rgba(),"label_outline_color":self.seg_label_outline_color.rgba()})
        self.dataset.spec.overlay_style={
            "working_selection":{"visible":bool(self.selection_visible.isChecked()),"color":self.selection_color.rgba(),"size":float(self.selection_size.value())},
            "highlight":{"visible":bool(self.highlight_visible.isChecked()),"color":self.highlight_color.rgba(),"size":float(self.highlight_size.value())},
        }
        self.changed.emit()


################################################################################
if __name__=="__main__":
    pass
