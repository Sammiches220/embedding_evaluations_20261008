################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtWidgets import QCheckBox, QComboBox, QGroupBox, QHBoxLayout, QPushButton, QVBoxLayout


################################################################################
# CLASSES
################################################################################
class InteractionPanel(QGroupBox):
    def __init__(self, parent=None) -> None:
        super().__init__("Interaction", parent)
        root = QVBoxLayout(self)

        selection_box = QGroupBox("Point selection")
        layout = QVBoxLayout(selection_box)
        self.lasso_btn = QPushButton("Lasso select"); self.lasso_btn.setCheckable(True)
        layout.addWidget(self.lasso_btn)
        self.combine_mode = QComboBox()
        self.combine_mode.addItem("Replace selection", "replace")
        self.combine_mode.addItem("Add to selection", "add")
        self.combine_mode.addItem("Subtract from selection", "subtract")
        self.combine_mode.addItem("Intersect selection", "intersect")
        layout.addWidget(self.combine_mode)
        self.restrict_predicates = QCheckBox("Restrict click/lasso to active point predicates"); self.restrict_predicates.setChecked(True)
        self.restrict_visible = QCheckBox("Restrict click/lasso to currently visible points"); self.restrict_visible.setChecked(True)
        layout.addWidget(self.restrict_predicates); layout.addWidget(self.restrict_visible)
        self.clear_selection_btn = QPushButton("Clear selection")
        layout.addWidget(self.clear_selection_btn)
        root.addWidget(selection_box)

        actions_box = QGroupBox("View / selection actions")
        actions = QVBoxLayout(actions_box)
        row = QHBoxLayout()
        self.reset_btn = QPushButton("Reset view")
        self.export_btn = QPushButton("Export selection…")
        row.addWidget(self.reset_btn); row.addWidget(self.export_btn)
        actions.addLayout(row)
        root.addWidget(actions_box)

    def configure(self, spatial_index: bool) -> None:
        self.lasso_btn.setEnabled(spatial_index)
        if not spatial_index:
            self.lasso_btn.setToolTip("This projection has no x_order/x_sorted index")


################################################################################
if __name__=="__main__":
    pass
