################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDoubleSpinBox, QFormLayout, QGroupBox, QLabel, QPushButton, QSpinBox,
    QTreeWidget, QVBoxLayout,
)


################################################################################
# FUNCTIONS
################################################################################
def _weight(value: float = 1.0) -> QDoubleSpinBox:
    spin = QDoubleSpinBox()
    spin.setRange(0, 10)
    spin.setValue(value)
    spin.setSingleStep(0.1)
    spin.setDecimals(1)
    return spin


################################################################################
# CLASSES
################################################################################
class CandidatesPanel(QGroupBox):
    def __init__(self, parent=None) -> None:
        super().__init__("Selected-region candidates", parent)
        layout = QVBoxLayout(self)
        self.analyze_btn = QPushButton("Analyze selected nodes")
        layout.addWidget(self.analyze_btn)

        form = QFormLayout()
        self.region_weight = _weight()
        self.unknown_weight = _weight()
        self.list_count = QSpinBox()
        self.list_count.setRange(10, 1000)
        self.list_count.setValue(100)
        form.addRow("Region weight", self.region_weight)
        form.addRow("Unexplored weight", self.unknown_weight)
        form.addRow("List rows", self.list_count)
        layout.addLayout(form)

        self.selection_label = QLabel("Lasso-select a region.")
        self.selection_label.setWordWrap(True)
        layout.addWidget(self.selection_label)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["#", "Row", "Score", "Region", "Unknown", "LM"])
        self.tree.setMinimumHeight(220)
        self.tree.setRootIsDecorated(False)
        layout.addWidget(self.tree)

    def configure_capabilities(self, *, spatial_index: bool, density: bool, unknownness: bool) -> None:
        available = spatial_index and density
        self.analyze_btn.setEnabled(available)
        self.region_weight.setEnabled(density)
        self.unknown_weight.setEnabled(available and unknownness)
        if not unknownness:
            self.unknown_weight.setValue(0.0)
            self.unknown_weight.setToolTip("Requires an exploration field or active timeline")
        if not spatial_index:
            self.selection_label.setText("Candidate analysis needs the spatial index for lasso selection.")
        elif not density:
            self.selection_label.setText("Candidate analysis needs density.npy.")


################################################################################
if __name__=="__main__":
    pass
