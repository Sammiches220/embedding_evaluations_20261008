################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QGroupBox, QLabel, QVBoxLayout


################################################################################
# CLASSES
################################################################################
class InspectionPanel(QGroupBox):
    def __init__(self, parent=None) -> None:
        super().__init__("Inspection / state", parent)
        root = QVBoxLayout(self)
        point_box = QGroupBox("Point inspection")
        point_layout = QVBoxLayout(point_box)
        self.inspect = QLabel("Hover or click a point.")
        self.inspect.setWordWrap(True)
        self.inspect.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        point_layout.addWidget(self.inspect)
        root.addWidget(point_box)

        state_box = QGroupBox("View state")
        state_layout = QVBoxLayout(state_box)
        self.stats = QLabel(); self.stats.setWordWrap(True)
        self.stats.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        state_layout.addWidget(self.stats)
        root.addWidget(state_box)


################################################################################
if __name__=="__main__":
    pass
