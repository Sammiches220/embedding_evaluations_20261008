################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import itertools
from dataclasses import replace

import numpy as np
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction
from PySide6.QtWidgets import QMainWindow, QMessageBox, QTabWidget, QToolBar

##### Internal Imports #####
from api.runtime import RuntimeState
from model.workspace import ViewSpec, WorkspaceSession
from ui.dialogs.library import LibraryBrowserDialog, LibraryEntry, SaveLibraryItemDialog, library_id
from ui.widgets.tab_bar import LibraryTabBar
from .view_widget import ViewWidget


################################################################################
# CLASSES
################################################################################
class DetachedViewWindow(QMainWindow):
    def __init__(self, session: WorkspaceSession, spec: ViewSpec, runtime: RuntimeState, parent=None) -> None:
        super().__init__(parent)
        self.session, self.spec, self.runtime = session, spec, runtime
        self.setWindowTitle(f"Latent Observer — {spec.title}"); self.resize(1450,900)
        self.view=ViewWidget(session,spec,runtime); self.setCentralWidget(self.view)
        self.runtime.register_view(spec)
        self.runtime.set_predicate(spec.id,self.view.query_panel.expression(),source="controls")
        if self.view.visibility_query is not None:self.runtime.set_visibility(spec.id,self.view.visibility_query,visible_count=int(np.count_nonzero(self.view.visibility_mask)),cause="view_open")
        self.view.reconfigureRequested.connect(self._reconfigure)
    def _reconfigure(self,spec):
        try:new=ViewWidget(self.session,spec,self.runtime)
        except Exception as exc: QMessageBox.critical(self,"Unable to apply view",f"{type(exc).__name__}: {exc}"); return
        old_id=self.spec.id
        old=self.takeCentralWidget(); old.deleteLater(); self.spec=spec; self.view=new; self.setCentralWidget(new); new.reconfigureRequested.connect(self._reconfigure); self.setWindowTitle(f"Latent Observer — {spec.title}")
        if old_id != spec.id:self.runtime.unregister_view(old_id)
        self.runtime.register_view(spec)
        self.runtime.set_predicate(spec.id,new.query_panel.expression(),source="controls")
        if new.visibility_query is not None:self.runtime.set_visibility(spec.id,new.visibility_query,visible_count=int(np.count_nonzero(new.visibility_mask)),cause="view_reconfigure")

    def closeEvent(self,event):
        self._closed=True
        self.runtime.unregister_view(self.spec.id)
        super().closeEvent(event)


class MainWindow(QMainWindow):
    def __init__(self, session: WorkspaceSession, runtime: RuntimeState | None = None):
        super().__init__(); self.session=session; self.runtime=runtime or RuntimeState(); self._id_counter=itertools.count(1); self._detached=[]; self._widgets_by_id={}
        self.setWindowTitle("HyCompass — Representation Ecology"); self.resize(1550,960); self.setMinimumSize(1100,720)
        self.tabs=QTabWidget()
        # Install the custom tab bar *before* enabling Qt's close/move behavior;
        # replacing a QTabWidget tab bar afterwards can drop close-button state.
        tab_bar=LibraryTabBar(); self.tabs.setTabBar(tab_bar)
        self.tabs.setTabsClosable(True); self.tabs.setMovable(True); self.tabs.tabBar().setMovable(True)
        tab_bar.emptyDoubleClicked.connect(self._open_view_library); tab_bar.middleCloseRequested.connect(self._close_tab)
        self.tabs.tabCloseRequested.connect(self._close_tab); self.tabs.currentChanged.connect(self._active_changed); self.setCentralWidget(self.tabs)
        from ecology.jobs import Jobs
        self.ecology_jobs=Jobs(session.manifest.root)
        self._build_toolbar()
        reference_action=QAction("Atlas / model reference",self);reference_action.setShortcut("F1");reference_action.triggered.connect(self._open_reference);self.menuBar().addMenu("Help").addAction(reference_action)
        views=session.views()
        if not views: raise ValueError("Workspace contains no projections/views")
        # Saved Views are now a library, not an instruction to open every preset.
        # Start with the first/default preset; load others on demand.
        self._add_view(views[0])
        self.action_timer=QTimer(self); self.action_timer.setInterval(40); self.action_timer.timeout.connect(self._poll_api_actions); self.action_timer.start()

    def _define_exploration(self):
        from ecology.native import DefinitionDialog
        from ecology.store import Store
        c=self._current()
        if c is None:return
        try:
            store=Store(self.session.manifest.root)
            if c.spec.domain not in store.catalog.raw['domains']:
                raise ValueError('Register this domain against a canonical item collection first. See docs_merge/USER_GUIDE.md.')
            rows=c.selected_rows if len(c.selected_rows) else np.arange(c.dataset.n,dtype=np.int64)
            membership=store.catalog.to_collection(c.spec.domain,rows)
            dlg=DefinitionDialog(store.catalog,c.spec.domain,self)
            dlg.title.setText('Working selection' if len(c.selected_rows) else 'Full domain (no working selection)')
            if not dlg.exec():return
            d=store.create(dlg.title.text(),c.spec.domain,membership,dlg.settings())
            widget=self.open_exploration(d['id']);widget.instrument.setCurrentIndex(widget.instrument.findData(dlg.instruments()[0]))
        except Exception as exc:QMessageBox.warning(self,'Define exploration',str(exc))

    def open_exploration(self,key):
        from ecology.native import ExplorationWidget
        for i in range(self.tabs.count()):
            w=self.tabs.widget(i)
            if isinstance(w,ExplorationWidget) and w.key==key:self.tabs.setCurrentIndex(i);return w
        w=ExplorationWidget(self.session.manifest.root,key,self.ecology_jobs,self._highlight_collection)
        self.tabs.setCurrentIndex(self.tabs.addTab(w,'Explore: '+w.definition['title']));return w

    def _open_exploration(self):
        from ecology.store import Store
        from PySide6.QtWidgets import QInputDialog
        defs=Store(self.session.manifest.root).definitions()
        if not defs:QMessageBox.information(self,'Explorations','Create an exploration from a population selection.');return
        names=[d['title']+' ['+d['id']+']' for d in defs];name,ok=QInputDialog.getItem(self,'Open saved exploration','Exploration',names,0,False)
        if ok:
            try:self.open_exploration(defs[names.index(name)]['id'])
            except Exception as exc:QMessageBox.warning(self,'Open exploration',str(exc))

    def _compare_explorations(self):
        from ecology.native import ComparisonWidget
        w=ComparisonWidget(self.session.manifest.root);self.tabs.setCurrentIndex(self.tabs.addTab(w,'Comparison'))

    def _highlight_collection(self,collection,rows):
        from ecology.catalog import Catalog
        c=Catalog(self.session.manifest.root);counts=[]
        views=list(self._widgets_by_id.values())+[win.view for win in self._detached if not getattr(win,'_closed',False)]
        for w in views:
            d=c.raw['domains'].get(w.spec.domain)
            if d and d['collection']==collection:
                available,mapped=c.to_domain(w.spec.domain,rows);w.set_highlights(mapped.astype(np.uint32),cause='canonical_link')
                counts.append(f'{w.spec.title}: {len(mapped)} present, {len(rows)-len(mapped)} absent')
        message='; '.join(counts) or 'Open a compatible population view first'
        self.statusBar().showMessage(message,15000)
        return message

    def _link_current(self):
        from ecology.catalog import Catalog
        w=self._current()
        if w is None:return
        try:
            c=Catalog(self.session.manifest.root);d=c.raw['domains'][w.spec.domain]
            self._highlight_collection(d['collection'],c.to_collection(w.spec.domain,w.selected_rows))
        except Exception as exc:QMessageBox.warning(self,'Link selection',str(exc))

    def closeEvent(self,event):
        for i in range(self.tabs.count()):
            w=self.tabs.widget(i)
            if hasattr(w,'dispose'):w.dispose()
        self.ecology_jobs.close()
        super().closeEvent(event)

    def _open_reference(self):
        from ecology.guide import ReferenceDialog
        if not hasattr(self,'reference_dialog'):self.reference_dialog=ReferenceDialog(self)
        self.reference_dialog.show();self.reference_dialog.raise_();self.reference_dialog.activateWindow()

    def _build_toolbar(self):
        bar=QToolBar("Views"); bar.setMovable(False); self.addToolBar(Qt.ToolBarArea.TopToolBarArea,bar)
        actions=(
            ("Open saved view…",self._open_view_library),
            ("Save view…",self._save_current),
            ("New tab",self._new_default),
            ("Duplicate tab",self._duplicate_current),
            ("Detach view",self._detach_current),
            ("Explore selection…",self._define_exploration),
            ("Open exploration…",self._open_exploration),
            ("Compare explorations",self._compare_explorations),
            ("Link selection across embeddings",self._link_current),
        )
        for text,slot in actions:
            a=QAction(text,self); a.triggered.connect(slot); bar.addAction(a)

    def _add_view(self,spec,index=None):
        # A saved View ID maps to one live tab. Loading it again simply activates it.
        if spec.id in self._widgets_by_id:
            idx=self.tabs.indexOf(self._widgets_by_id[spec.id])
            if idx>=0:self.tabs.setCurrentIndex(idx)
            return self._widgets_by_id[spec.id]
        try:w=ViewWidget(self.session,spec,self.runtime)
        except Exception as exc: QMessageBox.critical(self,"Unable to open view",f"{type(exc).__name__}: {exc}"); return None
        w.reconfigureRequested.connect(lambda new_spec,ww=w:self._reconfigure(ww,new_spec)); self._widgets_by_id[spec.id]=w; self.runtime.register_view(spec); self.runtime.set_predicate(spec.id,w.query_panel.expression(),source="controls")
        if w.visibility_query is not None:self.runtime.set_visibility(spec.id,w.visibility_query,visible_count=int(np.count_nonzero(w.visibility_mask)),cause="view_open")
        idx=self.tabs.addTab(w,spec.title) if index is None else self.tabs.insertTab(index,w,spec.title); self.tabs.setCurrentIndex(idx); return w

    def _reconfigure(self,w,spec):
        idx=self.tabs.indexOf(w)
        if idx<0:return
        try:new=ViewWidget(self.session,spec,self.runtime)
        except Exception as exc: QMessageBox.critical(self,"Unable to apply view",f"{type(exc).__name__}: {exc}"); return
        old_id=w.spec.id
        new.reconfigureRequested.connect(lambda ns,ww=new:self._reconfigure(ww,ns)); self.tabs.removeTab(idx); self._widgets_by_id.pop(old_id,None); w.deleteLater(); self.tabs.insertTab(idx,new,spec.title); self.tabs.setCurrentIndex(idx); self._widgets_by_id[spec.id]=new
        if old_id != spec.id:self.runtime.unregister_view(old_id)
        self.runtime.register_view(spec); self.runtime.set_predicate(spec.id,new.query_panel.expression(),source="controls")
        if new.visibility_query is not None:self.runtime.set_visibility(spec.id,new.visibility_query,visible_count=int(np.count_nonzero(new.visibility_mask)),cause="view_reconfigure")
        self._active_changed(idx)

    def _current(self):
        w=self.tabs.currentWidget(); return w if isinstance(w,ViewWidget) else None
    def _next_id(self,base="runtime-view"): return f"{base}-{next(self._id_counter):03d}"

    def _duplicate_current(self):
        c=self._current()
        if c:self._add_view(c.snapshot_spec().clone(new_id=self._next_id("runtime-copy"),title=f"{c.spec.title} copy"))

    def _new_default(self):
        base=self.session.views()[0]
        self._add_view(base.clone(new_id=self._next_id(),title="New view"))

    def _detach_current(self):
        c=self._current()
        if not c:return
        spec=c.snapshot_spec().clone(new_id=self._next_id("detached"),title=c.spec.title)
        win=DetachedViewWindow(self.session,spec,self.runtime); self._detached.append(win); win.destroyed.connect(lambda *_:self._detached.remove(win) if win in self._detached else None); win.show()

    def _close_tab(self,index):
        w=self.tabs.widget(index)
        if hasattr(w,"dispose"):w.dispose()
        self.tabs.removeTab(index)
        if isinstance(w,ViewWidget): self._widgets_by_id.pop(w.spec.id,None); self.runtime.unregister_view(w.spec.id)
        if w is not None:w.deleteLater()

    def _view_entries(self) -> list[LibraryEntry]:
        return [LibraryEntry(v.id,v.title,v.folder) for v in self.session.manifest.views]

    def _open_view_library(self):
        dlg=LibraryBrowserDialog(self._view_entries(),noun="view",allow_delete=True,parent=self)
        result=dlg.exec()
        changed=False
        for view_id in dlg.deleted_ids:
            changed |= self.session.manifest.delete_view(view_id)
        if changed:
            self.session.manifest.save()
            self.runtime.workspace_changed("saved_view.changed",{"action":"deleted","view_ids":list(dlg.deleted_ids)})
        if result and dlg.selected_id:
            spec=next((v for v in self.session.manifest.views if v.id==dlg.selected_id),None)
            if spec:self._add_view(spec)

    def _save_current(self):
        c=self._current()
        if not c:return
        dlg=SaveLibraryItemDialog(noun="view",title=c.spec.title,folder=c.spec.folder,parent=self)
        if not dlg.exec():return
        title,folder=dlg.item_title,dlg.folder
        existing=next((v for v in self.session.manifest.views if v.folder==folder and v.title==title),None)
        if existing is not None:
            answer=QMessageBox.question(self,"Overwrite saved view",f"A saved view named {title!r} already exists in this folder. Overwrite it?")
            if answer!=QMessageBox.StandardButton.Yes:return
            view_id=existing.id
        else:
            view_id=library_id("view",folder,title,{v.id for v in self.session.manifest.views})
        spec=replace(c.snapshot_spec(),id=view_id,title=title,folder=folder)
        self.session.manifest.upsert_view(spec); self.session.manifest.save()
        self.runtime.workspace_changed("saved_view.changed",{"action":"saved","view_id":view_id},domain=spec.domain,projection=spec.projection)
        # Make the current tab the just-saved preset so subsequent Save updates it.
        self._reconfigure(c,spec)
        self.statusBar().showMessage(f"Saved view {folder + '/' if folder else ''}{title}",3000)

    def _active_changed(self,index):
        w=self.tabs.widget(index)
        if isinstance(w,ViewWidget):
            self.setStyleSheet(w.dataset.theme.stylesheet or "")
            self.runtime.set_active_view(w.spec.id,cause="tab")
        else:
            self.setStyleSheet("")
            self.runtime.set_active_view(None,cause="tab")

    def _reload_open_views(self):
        manifest_views={v.id:v for v in self.session.manifest.views}
        current_id=self._current().spec.id if self._current() else None
        snapshots=[]
        for i in range(self.tabs.count()):
            w=self.tabs.widget(i)
            if isinstance(w,ViewWidget): snapshots.append((w,manifest_views.get(w.spec.id,w.snapshot_spec())))
        for old,spec in snapshots:
            self._reconfigure(old,spec); new=self._widgets_by_id.get(spec.id)
            if new is not None:
                with self.runtime.lock:
                    working=self.runtime.working.get(spec.id,np.empty(0,np.uint32)).copy(); highlights=self.runtime.highlights.get(spec.id,np.empty(0,np.uint32)).copy(); visibility=self.runtime.visibility_queries.get(spec.id)
                new.set_external_working_selection(working); new.set_external_highlights(highlights)
                if visibility is not None:
                    try:
                        rows=new.query_engine.query(visibility); mask=np.zeros(new.dataset.n,dtype=np.uint8); mask[rows]=1
                        new.set_external_visibility(mask,visibility)
                    except Exception:pass
        for win in list(self._detached):
            try:win._reconfigure(manifest_views.get(win.spec.id,win.view.snapshot_spec()))
            except Exception:pass
        if current_id and current_id in self._widgets_by_id:
            idx=self.tabs.indexOf(self._widgets_by_id[current_id])
            if idx>=0:self.tabs.setCurrentIndex(idx)

    def _poll_api_actions(self):
        for _ in range(100):
            try:key,stage,value=self.ecology_jobs.events.get_nowait()
            except Exception:break
            self.statusBar().showMessage(f"Exploration {key}: {stage} {value}",5000)
        for _ in range(100):
            try:a=self.runtime.actions.get_nowait()
            except Exception:break
            action=a.get("action"); view_id=a.get("view_id")
            if action=="reload":
                self.session.reload_manifest(clear_arrays=True); self._reload_open_views(); continue
            w=self._widgets_by_id.get(view_id)
            if w is None:continue
            if action=="working": w.set_external_working_selection(a.get("rows",np.empty(0,np.uint32)))
            elif action=="highlights": w.set_external_highlights(a.get("rows",np.empty(0,np.uint32)))
            elif action=="focus": w.focus_row(int(a["row"]))
            elif action=="fit": w.fit_rows(a.get("rows",np.empty(0,np.uint32)))
            elif action=="visibility": w.set_external_visibility(a.get("mask"),a.get("query"))


################################################################################
if __name__=="__main__":
    pass
