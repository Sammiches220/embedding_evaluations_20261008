################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import numpy as np


################################################################################
# CLASSES
################################################################################
@dataclass(frozen=True)
class CandidateAnalysisResult:
    rows: np.ndarray
    score: np.ndarray
    region: np.ndarray
    unknown: np.ndarray
    density: np.ndarray
    centrality: np.ndarray
    landmark: np.ndarray


class CandidateAnalyzer(Protocol):
    def analyze(
        self,
        rows: np.ndarray,
        timeline: float,
        region_weight: float,
        unknown_weight: float,
        limit: int,
    ) -> CandidateAnalysisResult | None: ...


################################################################################
if __name__=="__main__":
    pass
