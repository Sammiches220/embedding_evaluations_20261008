################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import numpy as np

##### Internal Imports #####
from ..workspace.session import ViewData
from .base import CandidateAnalysisResult


################################################################################
# CLASSES
################################################################################
class RepresentativeCandidateAnalyzer:
    """Capability-aware regional candidate ranking.

    Density is the sole requirement. Segmentation centrality and exploration
    unknownness improve the score when available, but are not mandatory.
    """

    def __init__(self, dataset: ViewData) -> None:
        self.dataset = dataset

    @property
    def available(self) -> bool:
        return self.dataset.density is not None

    @property
    def has_unknownness(self) -> bool:
        return self.dataset.exploration is not None or self.dataset.normalized_timeline is not None

    def analyze(
        self,
        rows: np.ndarray,
        timeline: float,
        region_weight: float,
        unknown_weight: float,
        limit: int,
    ) -> CandidateAnalysisResult | None:
        ds = self.dataset
        rows = np.asarray(rows, dtype=np.uint32)
        if len(rows) == 0 or ds.density is None:
            return None

        iy, ix = ds.grid_sample(ds.density, rows)
        density = np.asarray(ds.density[iy, ix], dtype=np.float32)

        lids = np.zeros(len(rows), dtype=np.int32)
        central = np.ones(len(rows), np.float32)
        if ds.landmarks is not None and ds.landmark_labels is not None:
            liy, lix = ds.grid_sample(ds.landmark_labels, rows)
            lids = np.asarray(ds.landmark_labels[liy, lix], dtype=np.int32)
            valid = (lids > 0) & (lids < len(ds.landmarks.anchor_x))
            central.fill(0.0)
            if np.any(valid):
                xy = np.asarray(ds.positions[rows[valid]], dtype=np.float32)
                lv = lids[valid]
                dist = np.sqrt(
                    np.square(xy[:, 0] - ds.landmarks.anchor_x[lv])
                    + np.square(xy[:, 1] - ds.landmarks.anchor_y[lv])
                )
                central[valid] = np.exp(
                    -0.5 * np.square(dist / ds.landmarks.anchor_scale[lv])
                )
            represent = np.clip(density * (0.35 + 0.65 * central), 0, 1)
        else:
            represent = np.clip(density, 0, 1)

        if ds.exploration is not None:
            frames = ds.exploration.frames
            exploration_t = ds.exploration_progress(timeline)
            frame = int(np.clip(round(exploration_t * (frames.shape[0] - 1)), 0, frames.shape[0] - 1))
            fiy, fix = ds.grid_sample(frames[frame], rows)
            familiar = np.asarray(frames[frame, fiy, fix], dtype=np.float32)
            unknown = np.clip(1.0 - familiar, 0, 1)
        elif ds.normalized_timeline is not None:
            unknown = (np.asarray(ds.normalized_timeline[rows], dtype=np.float32) > timeline).astype(np.float32)
        else:
            unknown = np.zeros(len(rows), np.float32)

        rw = max(float(region_weight), 0.0)
        uw = max(float(unknown_weight), 0.0) if self.has_unknownness else 0.0
        total = rw + uw
        score = (
            np.zeros(len(rows), np.float32)
            if total <= 1e-12
            else (rw * represent + uw * unknown) / total
        )

        k = min(max(1, int(limit)), len(rows))
        if k < len(rows):
            idx = np.argpartition(score, len(score) - k)[-k:]
            idx = idx[np.argsort(score[idx])[::-1]]
        else:
            idx = np.argsort(score)[::-1]

        return CandidateAnalysisResult(
            rows=rows[idx],
            score=score[idx],
            region=represent[idx],
            unknown=unknown[idx],
            density=density[idx],
            centrality=central[idx],
            landmark=lids[idx],
        )


################################################################################
if __name__=="__main__":
    pass
