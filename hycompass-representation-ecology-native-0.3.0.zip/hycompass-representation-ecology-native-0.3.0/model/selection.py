################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import numpy as np


################################################################################
# FUNCTIONS
################################################################################
def decimate_polygon(poly: np.ndarray, max_vertices: int = 64) -> np.ndarray:
    poly = np.asarray(poly, dtype=np.float64)
    if len(poly) <= max_vertices:
        return poly
    idx = np.linspace(0, len(poly) - 1, max_vertices, dtype=np.int64)
    return poly[idx]


def inside_polygon(x: np.ndarray, y: np.ndarray, poly: np.ndarray) -> np.ndarray:
    inside = np.zeros(len(x), dtype=bool)
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        cross = ((yi > y) != (yj > y)) & (
            x < (xj - xi) * (y - yi) / (yj - yi + 1e-20) + xi
        )
        inside ^= cross
        j = i
    return inside



################################################################################
if __name__=="__main__":
    pass