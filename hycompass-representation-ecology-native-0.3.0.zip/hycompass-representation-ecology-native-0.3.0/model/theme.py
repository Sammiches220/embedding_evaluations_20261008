################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

##### Global Variables #####
DEFAULT_THEME_CONFIG: dict[str, Any] = {
    "ui": {"stylesheet": ""},
    "canvas": {"background": [0.015, 0.020, 0.030, 1.0]},
    "points": {
        "active": [1.0, 0.77, 0.25, 0.88],
        "future": [0.64, 0.69, 0.76, 0.18],
        "outside": [0.38, 0.42, 0.48, 0.10],
    },
    "working_selection": [0.35, 0.82, 1.0, 0.95],
    "highlight": [1.0, 0.24, 0.55, 1.0],
    "lasso": [0.25, 0.85, 1.0, 0.95],
    "segmentation": {
        "boundary": [0.96, 0.98, 1.0, 0.78],
        "label": [1.0, 1.0, 1.0, 0.95],
        "label_outline": [0.0, 0.0, 0.0, 0.85],
    },
    "density_palette": [
        [0.025, 0.050, 0.085],
        [0.05, 0.25, 0.38],
        [0.07, 0.49, 0.45],
        [0.90, 0.78, 0.39],
    ],
    "exploration_palette": [
        [0.16, 0.08, 0.35],
        [0.10, 0.43, 0.51],
        [0.20, 0.67, 0.45],
        [0.92, 0.87, 0.28],
    ],
}


################################################################################
# FUNCTIONS
################################################################################
def _rgba(value, default):
    if value is None:
        return tuple(default)
    vals = list(value)
    if len(vals) == 3:
        vals.append(1.0)
    if len(vals) != 4:
        return tuple(default)
    return tuple(float(x) for x in vals)


def load_theme(path: Path | None = None, *, theme_id: str = "default-dark") -> Theme:
    config = json.loads(json.dumps(DEFAULT_THEME_CONFIG))
    if path is not None:
        supplied = json.loads(Path(path).read_text())
        _deep_merge(config, supplied)
    return Theme(theme_id, config)


def _deep_merge(dst: dict[str, Any], src: dict[str, Any]) -> None:
    for key, value in src.items():
        if isinstance(value, dict) and isinstance(dst.get(key), dict):
            _deep_merge(dst[key], value)
        else:
            dst[key] = value


################################################################################
# CLASSES
################################################################################
@dataclass(frozen=True)
class Theme:
    id: str = "default-dark"
    config: dict[str, Any] = field(default_factory=lambda: json.loads(json.dumps(DEFAULT_THEME_CONFIG)))

    @property
    def background(self):
        return _rgba(self.config.get("canvas", {}).get("background"), DEFAULT_THEME_CONFIG["canvas"]["background"])

    def color(self, key: str):
        defaults = DEFAULT_THEME_CONFIG
        value: Any = self.config
        default: Any = defaults
        for part in key.split("."):
            value = value.get(part) if isinstance(value, dict) else None
            default = default.get(part) if isinstance(default, dict) else None
        return _rgba(value, default or [1, 1, 1, 1])

    def palette(self, key: str) -> list[tuple[float, float, float]]:
        raw = self.config.get(key, DEFAULT_THEME_CONFIG[key])
        if not isinstance(raw, list) or len(raw) < 4:
            raw = DEFAULT_THEME_CONFIG[key]
        return [tuple(float(x) for x in row[:3]) for row in raw[:4]]

    @property
    def stylesheet(self) -> str:
        return str(self.config.get("ui", {}).get("stylesheet", ""))


################################################################################
if __name__=="__main__":
    pass
