################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import math

import numpy as np

##### Internal Imports #####
from .selection import decimate_polygon, inside_polygon


################################################################################
# CLASSES
################################################################################
class SpatialIndex:
    """Projected-x index used for rare CPU-side picking and polygon selection."""

    def __init__(
        self,
        positions: np.ndarray,
        x_order: np.ndarray,
        x_sorted: np.ndarray,
    ) -> None:
        self.positions = positions
        self.x_order = x_order
        self.x_sorted = x_sorted

    def pick(
        self,
        x: float,
        y: float,
        dx: float,
        dy: float,
        max_candidates: int = 250_000,
        row_filter=None,
    ) -> int | None:
        lo = int(np.searchsorted(self.x_sorted, x - dx, "left"))
        hi = int(np.searchsorted(self.x_sorted, x + dx, "right"))
        if hi <= lo:
            return None

        rows = np.asarray(self.x_order[lo:hi], dtype=np.uint32)
        if len(rows) > max_candidates:
            step = max(1, int(math.ceil(len(rows) / max_candidates)))
            rows = rows[::step]

        xy = np.asarray(self.positions[rows], dtype=np.float32)
        keep = np.abs(xy[:, 1] - y) <= dy
        if not np.any(keep):
            return None

        rows = rows[keep]
        xy = xy[keep]
        if row_filter is not None and len(rows):
            allowed = np.asarray(row_filter(rows), dtype=bool)
            if allowed.shape != (len(rows),):
                raise ValueError("row_filter must return one boolean per candidate row")
            if not np.any(allowed):
                return None
            rows = rows[allowed]
            xy = xy[allowed]
        d2 = np.square((xy[:, 0] - x) / max(dx, 1e-12)) + np.square(
            (xy[:, 1] - y) / max(dy, 1e-12)
        )
        j = int(np.argmin(d2))
        return int(rows[j]) if d2[j] <= 1.0 else None

    def select_polygon(self, poly: np.ndarray, chunk: int = 500_000) -> np.ndarray:
        poly = decimate_polygon(poly)
        xmin, xmax = float(poly[:, 0].min()), float(poly[:, 0].max())
        ymin, ymax = float(poly[:, 1].min()), float(poly[:, 1].max())
        lo = int(np.searchsorted(self.x_sorted, xmin, "left"))
        hi = int(np.searchsorted(self.x_sorted, xmax, "right"))

        pieces: list[np.ndarray] = []
        for start in range(lo, hi, chunk):
            rows = np.asarray(self.x_order[start : min(hi, start + chunk)], dtype=np.uint32)
            xy = np.asarray(self.positions[rows], dtype=np.float32)
            y_mask = (xy[:, 1] >= ymin) & (xy[:, 1] <= ymax)
            if not np.any(y_mask):
                continue
            rows2 = rows[y_mask]
            xy2 = xy[y_mask]
            mask = inside_polygon(xy2[:, 0], xy2[:, 1], poly)
            if np.any(mask):
                pieces.append(rows2[mask])

        if not pieces:
            return np.empty(0, np.uint32)
        return np.concatenate(pieces).astype(np.uint32, copy=False)



################################################################################
if __name__=="__main__":
    pass
