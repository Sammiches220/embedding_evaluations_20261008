################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, TypeVar

##### Internal Imports #####
from .assets import (
    ClusteringSpec,
    DensitySpec,
    DomainSpec,
    ExplorationSpec,
    ProjectionSpec,
    SavedQuerySpec,
    SegmentationSpec,
    SelectionSpec,
    ThemeSpec,
    TimelineSpec,
    ViewSpec,
)

##### Global Variables #####
T = TypeVar("T")


################################################################################
# CLASSES
################################################################################
class WorkspaceManifest:
    """Catalog for large file-backed assets plus lightweight views/presets."""

    FORMAT_VERSION = 3

    def __init__(self, root: Path, raw: dict[str, Any]) -> None:
        self.root = Path(root).resolve()
        raw = self._migrate_raw(dict(raw))
        self.raw = raw
        self.format_version = int(raw.get("format_version", self.FORMAT_VERSION))
        if self.format_version != self.FORMAT_VERSION:
            raise ValueError(
                f"Unsupported workspace format {self.format_version}; expected {self.FORMAT_VERSION}."
            )

        self.domains = self._parse_map("domains", DomainSpec)
        self.projections = self._parse_map("projections", ProjectionSpec)
        self.selections = self._parse_map("selections", SelectionSpec)
        self.timelines = self._parse_map("timelines", TimelineSpec)
        self.clusterings = self._parse_map("clusterings", ClusteringSpec)
        self.densities = self._parse_map("densities", DensitySpec)
        self.segmentations = self._parse_map("segmentations", SegmentationSpec)
        self.explorations = self._parse_map("explorations", ExplorationSpec)
        self.saved_queries = self._parse_map("saved_queries", SavedQuerySpec)
        self.themes = self._parse_map("themes", ThemeSpec)
        self.views = [ViewSpec(**item) for item in raw.get("views", [])]
        self._validate_references()

    @classmethod
    def _migrate_raw(cls, raw: dict[str, Any]) -> dict[str, Any]:
        """Load v0.4/format-1 workspaces without forcing immediate regeneration."""
        version = int(raw.get("format_version", 1))
        if version == cls.FORMAT_VERSION:
            return raw
        if version not in {1, 2}:
            return raw
        migrated = dict(raw)
        migrated["format_version"] = cls.FORMAT_VERSION
        migrated.setdefault("saved_queries", {})
        migrated.setdefault("themes", {})
        # v3 adds only backwards-compatible defaults: library folders on saved
        # views/queries and per-view overlay styling. Existing workspaces are
        # upgraded in memory and written as v3 on the next save.
        return migrated

    @classmethod
    def load(cls, root: Path) -> "WorkspaceManifest":
        root = Path(root)
        path = root / "workspace.json"
        if not path.exists():
            raise FileNotFoundError(f"Workspace manifest not found: {path}")
        return cls(root, json.loads(path.read_text()))

    @classmethod
    def empty(cls, root: Path) -> "WorkspaceManifest":
        return cls(root, {"format_version": cls.FORMAT_VERSION})

    def resolve(self, value: str) -> Path:
        path = Path(value).expanduser()
        return path.resolve() if path.is_absolute() else (self.root / path).resolve()

    def relative_or_absolute(self, path: Path) -> str:
        path = Path(path).resolve()
        try:
            return str(path.relative_to(self.root))
        except ValueError:
            return str(path)

    def save(self) -> None:
        raw = {
            "format_version": self.FORMAT_VERSION,
            "domains": {k: asdict(v) for k, v in self.domains.items()},
            "projections": {k: asdict(v) for k, v in self.projections.items()},
            "selections": {k: asdict(v) for k, v in self.selections.items()},
            "timelines": {k: asdict(v) for k, v in self.timelines.items()},
            "clusterings": {k: asdict(v) for k, v in self.clusterings.items()},
            "densities": {k: asdict(v) for k, v in self.densities.items()},
            "segmentations": {k: asdict(v) for k, v in self.segmentations.items()},
            "explorations": {k: asdict(v) for k, v in self.explorations.items()},
            "saved_queries": {k: asdict(v) for k, v in self.saved_queries.items()},
            "themes": {k: asdict(v) for k, v in self.themes.items()},
            "views": [asdict(v) for v in self.views],
        }
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "workspace.json").write_text(json.dumps(raw, indent=2) + "\n")
        self.raw = raw

    def _parse_map(self, name: str, cls: type[T]) -> dict[str, T]:
        out: dict[str, T] = {}
        for key, value in self.raw.get(name, {}).items():
            value = dict(value)
            if "id" not in value:
                value = {"id": key, **value}
            obj = cls(**value)
            if obj.id != key:
                raise ValueError(f"{name}.{key}.id must equal its catalog key")
            out[key] = obj
        return out

    def _validate_references(self) -> None:
        for p in self.projections.values():
            domain = self._require(self.domains, p.domain, f"projection {p.id} domain")
            self._require_domain_version(domain, p.domain_version, f"projection {p.id}")
            if p.selection:
                self._require_selection_domain(p.selection, p.domain, f"projection {p.id}")
        for s in self.selections.values():
            domain = self._require(self.domains, s.domain, f"selection {s.id} domain")
            self._require_domain_version(domain, s.domain_version, f"selection {s.id}")
            if s.kind not in {"all", "mask"}:
                raise ValueError(f"selection {s.id} kind must be 'all' or 'mask'")
            if s.kind == "mask" and not s.mask:
                raise ValueError(f"selection {s.id} requires mask")
        for t in self.timelines.values():
            domain = self._require(self.domains, t.domain, f"timeline {t.id} domain")
            self._require_domain_version(domain, t.domain_version, f"timeline {t.id}")
        for c in self.clusterings.values():
            domain = self._require(self.domains, c.domain, f"clustering {c.id} domain")
            self._require_domain_version(domain, c.domain_version, f"clustering {c.id}")
            if c.projection:
                p = self._require(self.projections, c.projection, f"clustering {c.id} projection")
                if p.domain != c.domain:
                    raise ValueError(f"clustering {c.id} projection belongs to another domain")
            if c.selection:
                self._require_selection_domain(c.selection, c.domain, f"clustering {c.id}")
        for d in self.densities.values():
            p = self._require(self.projections, d.projection, f"density {d.id} projection")
            if d.selection:
                self._require_selection_domain(d.selection, p.domain, f"density {d.id}")
        for s in self.segmentations.values():
            p = self._require(self.projections, s.projection, f"segmentation {s.id} projection")
            if s.density:
                d = self._require(self.densities, s.density, f"segmentation {s.id} density")
                if d.projection != s.projection:
                    raise ValueError(f"segmentation {s.id} density uses another projection")
            if s.selection:
                self._require_selection_domain(s.selection, p.domain, f"segmentation {s.id}")
        for e in self.explorations.values():
            p = self._require(self.projections, e.projection, f"exploration {e.id} projection")
            self._require_selection_domain(e.selection, p.domain, f"exploration {e.id}")
            if e.timeline:
                t = self._require(self.timelines, e.timeline, f"exploration {e.id} timeline")
                if t.domain != p.domain:
                    raise ValueError(f"exploration {e.id} timeline belongs to another domain")
        for q in self.saved_queries.values():
            self._require(self.domains, q.domain, f"saved query {q.id} domain")
            if q.projection:
                p = self._require(self.projections, q.projection, f"saved query {q.id} projection")
                if p.domain != q.domain:
                    raise ValueError(f"saved query {q.id}: projection belongs to another domain")
        for theme in self.themes.values():
            if not theme.config:
                raise ValueError(f"theme {theme.id} requires config")
        for v in self.views:
            self.validate_view(v)

    def validate_view(self, v: ViewSpec) -> None:
        domain = self._require(self.domains, v.domain, f"view {v.id} domain")
        projection = self._require(self.projections, v.projection, f"view {v.id} projection")
        if projection.domain != domain.id:
            raise ValueError(f"view {v.id}: projection belongs to another domain")
        self._require_domain_version(domain, projection.domain_version, f"view {v.id} projection")
        if v.selection:
            self._require_selection_domain(v.selection, domain.id, f"view {v.id}")
        if v.timeline:
            t = self._require(self.timelines, v.timeline, f"view {v.id} timeline")
            if t.domain != domain.id:
                raise ValueError(f"view {v.id}: timeline belongs to another domain")
        if v.clustering:
            c = self._require(self.clusterings, v.clustering, f"view {v.id} clustering")
            if c.domain != domain.id or (c.projection and c.projection != v.projection):
                raise ValueError(f"view {v.id}: clustering is incompatible")
        for density_id in v.densities:
            d = self._require(self.densities, density_id, f"view {v.id} density")
            if d.projection != v.projection:
                raise ValueError(f"view {v.id}: density {density_id} uses another projection")
        for seg_id in v.segmentations:
            s = self._require(self.segmentations, seg_id, f"view {v.id} segmentation")
            if s.projection != v.projection:
                raise ValueError(f"view {v.id}: segmentation {seg_id} uses another projection")
        if v.exploration:
            e = self._require(self.explorations, v.exploration, f"view {v.id} exploration")
            if e.projection != v.projection:
                raise ValueError(f"view {v.id}: exploration uses another projection")
            if e.timeline and e.timeline != v.timeline:
                raise ValueError(
                    f"view {v.id}: temporal exploration {e.id} requires timeline {e.timeline!r}"
                )
        if v.theme:
            self._require(self.themes, v.theme, f"view {v.id} theme")

    def compatible_selections(self, domain_id: str) -> list[SelectionSpec]:
        return [s for s in self.selections.values() if s.domain == domain_id]

    def compatible_timelines(self, domain_id: str) -> list[TimelineSpec]:
        return [t for t in self.timelines.values() if t.domain == domain_id]

    def compatible_clusterings(self, domain_id: str, projection_id: str | None = None) -> list[ClusteringSpec]:
        return [
            c for c in self.clusterings.values()
            if c.domain == domain_id and (c.projection is None or projection_id is None or c.projection == projection_id)
        ]

    def compatible_densities(self, projection_id: str) -> list[DensitySpec]:
        return [d for d in self.densities.values() if d.projection == projection_id]

    def compatible_segmentations(self, projection_id: str) -> list[SegmentationSpec]:
        return [s for s in self.segmentations.values() if s.projection == projection_id]

    def compatible_explorations(self, projection_id: str, timeline_id: str | None = None) -> list[ExplorationSpec]:
        return [
            e for e in self.explorations.values()
            if e.projection == projection_id and (e.timeline is None or e.timeline == timeline_id)
        ]

    def compatible_queries(self, domain_id: str, projection_id: str | None = None) -> list[SavedQuerySpec]:
        return [
            q for q in self.saved_queries.values()
            if q.domain == domain_id and (q.projection is None or projection_id is None or q.projection == projection_id)
        ]

    def upsert_view(self, spec: ViewSpec) -> None:
        self.validate_view(spec)
        for i, current in enumerate(self.views):
            if current.id == spec.id:
                self.views[i] = spec
                return
        self.views.append(spec)

    def upsert_saved_query(self, spec: SavedQuerySpec) -> None:
        self.saved_queries[spec.id] = spec
        self._validate_references()

    def delete_view(self, view_id: str) -> bool:
        before = len(self.views)
        self.views = [v for v in self.views if v.id != view_id]
        return len(self.views) != before

    def delete_saved_query(self, query_id: str) -> bool:
        return self.saved_queries.pop(query_id, None) is not None

    @staticmethod
    def _require(mapping: dict[str, T], key: str, label: str) -> T:
        try:
            return mapping[key]
        except KeyError as exc:
            raise ValueError(f"Unknown {label}: {key!r}") from exc

    def _require_selection_domain(self, selection_id: str, domain_id: str, label: str) -> SelectionSpec:
        s = self._require(self.selections, selection_id, f"{label} selection")
        if s.domain != domain_id:
            raise ValueError(f"{label}: selection belongs to another domain")
        return s

    @staticmethod
    def _require_domain_version(domain: DomainSpec, pinned: int | None, label: str) -> None:
        if pinned is not None and int(pinned) != int(domain.version):
            raise ValueError(
                f"{label} was built for domain version {pinned}, but {domain.id} is version {domain.version}."
            )


################################################################################
if __name__=="__main__":
    pass
