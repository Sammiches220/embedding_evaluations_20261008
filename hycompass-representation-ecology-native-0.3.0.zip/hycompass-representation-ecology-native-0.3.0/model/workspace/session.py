################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

##### Internal Imports #####
from model.landmarks import LandmarkMap
from model.spatial_index import SpatialIndex
from model.theme import Theme, load_theme
from .assets import DensitySpec, ExplorationSpec, SegmentationSpec, TimelineSpec, ViewSpec
from .manifest import WorkspaceManifest


################################################################################
# CLASSES
################################################################################
@dataclass(frozen=True)
class DensityBinding:
    spec: DensitySpec
    array: np.ndarray
    cache_key: str


@dataclass(frozen=True)
class SegmentationBinding:
    spec: SegmentationSpec
    labels: np.ndarray
    stats: list[dict]
    landmarks: LandmarkMap
    cache_key: str


@dataclass(frozen=True)
class ExplorationBinding:
    spec: ExplorationSpec
    frames: np.ndarray
    cache_key: str


class ViewData:
    """Resolved read-only composition over shared workspace arrays."""

    def __init__(
        self,
        *,
        session: "WorkspaceSession",
        spec: ViewSpec,
        positions: np.ndarray,
        positions_key: str,
        item_ids: np.ndarray,
        bounds: tuple[float, float, float, float],
        x_order: np.ndarray | None,
        x_sorted: np.ndarray | None,
        selection_mask: np.ndarray | None,
        selection_key: str | None,
        timeline_spec: TimelineSpec | None,
        timestamps: np.ndarray | None,
        normalized_timeline: np.ndarray | None,
        timeline_key: str | None,
        timeline_cdf: np.ndarray | None,
        playback_start: int | None,
        playback_end: int | None,
        cluster: np.ndarray | None,
        cluster_key: str | None,
        densities: list[DensityBinding],
        segmentations: list[SegmentationBinding],
        exploration: ExplorationBinding | None,
        theme: Theme,
    ) -> None:
        self.session = session
        self.spec = spec
        self.positions = positions
        self.positions_key = positions_key
        self.item_ids = item_ids
        self.bounds = bounds
        self.n = int(len(positions))
        self.selection_mask = selection_mask
        self.selection_key = selection_key
        self.timeline_spec = timeline_spec
        self.timestamps = timestamps
        self.normalized_timeline = normalized_timeline
        self.timeline_key = timeline_key
        self.timeline_cdf = timeline_cdf
        self.playback_start = playback_start
        self.playback_end = playback_end
        self.cluster = cluster
        self.cluster_key = cluster_key
        self.densities = densities
        self.segmentations = segmentations
        self.exploration = exploration
        self.theme = theme

        # Runtime state consulted by PointQueryEngine. These are intentionally not
        # authoritative assets; UI/API may change them freely.
        self.current_timeline = 0.5
        self.current_exploration_threshold = float(spec.exploration_style.get("threshold", 0.38))

        self.spatial_index: SpatialIndex | None = None
        if x_order is not None and x_sorted is not None:
            self.spatial_index = SpatialIndex(self.positions, x_order, x_sorted)

        # Compatibility aliases for inspection and existing interaction code.
        self.density = densities[0].array if densities else None
        self.landmarks = segmentations[0].landmarks if segmentations else None
        self.landmark_labels = segmentations[0].labels if segmentations else None
        self.landmark_stats = segmentations[0].stats if segmentations else None

    @property
    def domain_id(self) -> str:
        return self.spec.domain

    @property
    def projection_id(self) -> str:
        return self.spec.projection

    @property
    def has_selection(self) -> bool:
        return self.selection_mask is not None

    @property
    def has_timeline(self) -> bool:
        return self.normalized_timeline is not None

    @property
    def has_clusters(self) -> bool:
        return self.cluster is not None

    @property
    def has_exploration(self) -> bool:
        return self.exploration is not None

    @property
    def projected_count(self) -> int:
        return int(np.count_nonzero(np.isfinite(self.positions).all(axis=1)))

    @property
    def selection_count(self) -> int:
        return self.n if self.selection_mask is None else int(np.count_nonzero(self.selection_mask))

    def item_id(self, row: int) -> str:
        value = self.item_ids[int(row)]
        return value.item() if isinstance(value, np.generic) else str(value)

    def timeline_unix(self, normalized: float) -> int | None:
        if self.playback_start is None or self.playback_end is None:
            return None
        t = float(np.clip(normalized, 0.0, 1.0))
        return int(round(self.playback_start + t * (self.playback_end - self.playback_start)))

    def exploration_progress(self, view_normalized: float) -> float:
        if self.exploration is None:
            return 0.0
        return self.exploration_progress_for(self.exploration.spec, view_normalized)

    def exploration_progress_for(self, spec: ExplorationSpec, view_normalized: float) -> float:
        if spec.timeline is None:
            return 0.0
        unix_time = self.timeline_unix(view_normalized)
        if unix_time is None:
            return float(np.clip(view_normalized, 0.0, 1.0))
        start = spec.metadata.get("timeline_start")
        end = spec.metadata.get("timeline_end")
        if start is None or end is None or int(end) <= int(start):
            return float(np.clip(view_normalized, 0.0, 1.0))
        return float(np.clip((unix_time - int(start)) / float(int(end) - int(start)), 0.0, 1.0))

    def observed_count(self, normalized: float) -> int | None:
        if self.timeline_cdf is None:
            return None
        idx = int(np.clip(round(float(normalized) * 1000.0), 0, 1000))
        return int(self.timeline_cdf[idx])

    def row_selected(self, row: int) -> bool:
        return True if self.selection_mask is None else bool(self.selection_mask[int(row)])

    def row_timestamp(self, row: int) -> int | None:
        if self.timestamps is None or self.timeline_spec is None:
            return None
        value = int(self.timestamps[int(row)])
        return None if value == int(self.timeline_spec.missing_value) else value

    def row_observed(self, row: int, normalized: float) -> bool | None:
        if self.normalized_timeline is None:
            return None
        return bool(float(self.normalized_timeline[int(row)]) <= float(normalized))

    @staticmethod
    def pixel_radius_world(half_w: float, half_h: float, width: int, height: int, pixels: float = 7.0) -> tuple[float, float]:
        return (
            pixels * 2.0 * half_w / max(width, 1),
            pixels * 2.0 * half_h / max(height, 1),
        )

    def grid_sample_safe(self, grid: np.ndarray, rows: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        rows = np.asarray(rows, dtype=np.uint32)
        xy = np.asarray(self.positions[rows], dtype=np.float32)
        valid = np.isfinite(xy).all(axis=1)
        h, w = grid.shape[-2:]
        iy = np.zeros(len(rows), dtype=np.int32)
        ix = np.zeros(len(rows), dtype=np.int32)
        if not np.any(valid):
            return iy, ix, valid
        xmin, xmax, ymin, ymax = self.bounds
        xx = xy[valid]
        vx = ((xx[:, 0] - xmin) * (w / max(xmax - xmin, 1e-12))).astype(np.int32)
        vy = ((xx[:, 1] - ymin) * (h / max(ymax - ymin, 1e-12))).astype(np.int32)
        np.clip(vx, 0, w - 1, out=vx)
        np.clip(vy, 0, h - 1, out=vy)
        ix[valid] = vx
        iy[valid] = vy
        return iy, ix, valid

    def grid_sample(self, grid: np.ndarray, rows: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        iy, ix, _ = self.grid_sample_safe(grid, rows)
        return iy, ix

    @property
    def point_payload_bytes(self) -> int:
        total = int(self.positions.nbytes)
        if self.selection_mask is not None:
            total += int(self.selection_mask.nbytes)
        if self.normalized_timeline is not None:
            total += int(self.normalized_timeline.nbytes)
        if self.cluster is not None:
            total += int(self.cluster.size * 4)
        return total

    @property
    def field_payload_bytes(self) -> int:
        total = sum(int(d.array.nbytes) for d in self.densities)
        total += sum(int(s.labels.nbytes) for s in self.segmentations)
        if self.exploration is not None:
            total += int(self.exploration.frames.nbytes)
        return total


class WorkspaceSession:
    """Workspace loader/cache shared by every tab and the REST service."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root).resolve()
        self.manifest = WorkspaceManifest.load(self.root)
        self._arrays: dict[str, np.ndarray] = {}
        self._json: dict[str, Any] = {}
        self._timeline_runtime: dict[tuple[str, int, int], np.ndarray] = {}
        self._timeline_cdfs: dict[tuple[str, str | None, int, int], np.ndarray] = {}
        self._themes: dict[str, Theme] = {}

    def reload_manifest(self, *, clear_arrays: bool = False) -> None:
        self.manifest = WorkspaceManifest.load(self.root)
        self._json.clear()
        self._themes.clear()
        self._timeline_runtime.clear()
        self._timeline_cdfs.clear()
        if clear_arrays:
            # Explicit reload is the boundary for externally replaced file-backed
            # assets. Existing ViewData objects retain valid references until the
            # GUI rebuilds them; newly built views receive fresh mmaps.
            self._arrays.clear()

    def array(self, path_value: str, *, mmap: bool = True) -> np.ndarray:
        path = self.manifest.resolve(path_value)
        key = str(path)
        if key not in self._arrays:
            if not path.exists():
                raise FileNotFoundError(path)
            self._arrays[key] = np.load(path, mmap_mode="r" if mmap else None, allow_pickle=False)
        return self._arrays[key]

    def invalidate_path(self, path_value: str) -> None:
        path = str(self.manifest.resolve(path_value))
        self._arrays.pop(path, None)
        self._json.pop(path, None)

    def file_cache_key(self, path_value: str) -> str:
        """Version a render/cache key by the backing file's current stat data.

        External assets may be deliberately replaced under the same catalog ID.
        Path-only OpenGL cache keys would then keep serving the old GPU buffer or
        texture after a workspace reload.  Including size+mtime makes refreshed
        files acquire fresh shared GPU resources while preserving sharing across
        views that reference the same current file version.
        """
        path = self.manifest.resolve(path_value)
        stat = path.stat()
        return f"{path}:{stat.st_size}:{stat.st_mtime_ns}"

    def json_value(self, path_value: str) -> Any:
        path = self.manifest.resolve(path_value)
        key = str(path)
        if key not in self._json:
            self._json[key] = json.loads(path.read_text())
        return self._json[key]

    def theme(self, theme_id: str | None) -> Theme:
        key = theme_id or "default-dark"
        if key in self._themes:
            return self._themes[key]
        if theme_id and theme_id in self.manifest.themes:
            spec = self.manifest.themes[theme_id]
            theme = load_theme(self.manifest.resolve(spec.config), theme_id=theme_id)
        else:
            theme = load_theme(None, theme_id="default-dark")
        self._themes[key] = theme
        return theme

    def views(self) -> list[ViewSpec]:
        if self.manifest.views:
            return self.manifest.views
        if not self.manifest.projections:
            return []
        projection = next(iter(self.manifest.projections.values()))
        densities = [d.id for d in self.manifest.compatible_densities(projection.id)[:1]]
        segmentations = [s.id for s in self.manifest.compatible_segmentations(projection.id)[:1]]
        explorations = self.manifest.compatible_explorations(projection.id, None)
        clusterings = self.manifest.compatible_clusterings(projection.domain, projection.id)
        return [ViewSpec(
            id="default", title="Default view", domain=projection.domain, projection=projection.id,
            clustering=clusterings[0].id if clusterings else None,
            densities=densities, segmentations=segmentations,
            exploration=explorations[0].id if explorations else None,
        )]

    def build_view(self, spec: ViewSpec) -> ViewData:
        self.manifest.validate_view(spec)
        domain = self.manifest.domains[spec.domain]
        projection = self.manifest.projections[spec.projection]

        item_ids = self.array(domain.item_ids)
        if domain.n_items is not None:
            n = int(domain.n_items)
        else:
            embeddings = self.array(domain.embeddings)
            if embeddings.ndim != 2:
                raise ValueError(f"domain {domain.id}: embeddings must be [N,D]")
            n = int(embeddings.shape[0])
        if item_ids.ndim != 1 or len(item_ids) != n:
            raise ValueError(f"domain {domain.id}: item_ids must be [N] and match domain size")

        positions = self.array(projection.positions)
        if positions.dtype != np.float32 or positions.shape != (n, 2):
            raise ValueError(f"projection {projection.id}: positions must be domain-aligned float32 [N,2]")
        finite_rows = np.isfinite(positions).all(axis=1)
        if not np.any(finite_rows):
            raise ValueError(f"projection {projection.id}: contains no finite projected rows")
        bounds = projection.world_bounds or self._infer_bounds(positions)

        x_order = self.array(projection.x_order) if projection.x_order else None
        x_sorted = self.array(projection.x_sorted) if projection.x_sorted else None
        if (x_order is None) != (x_sorted is None):
            raise ValueError(f"projection {projection.id}: x_order/x_sorted must be paired")
        if x_order is not None:
            if len(x_order) != len(x_sorted):
                raise ValueError(f"projection {projection.id}: spatial index pair length mismatch")
            if len(x_order) and (int(np.min(x_order)) < 0 or int(np.max(x_order)) >= n):
                raise ValueError(f"projection {projection.id}: spatial index contains invalid domain rows")

        selection_mask = None
        selection_key = None
        if spec.selection:
            selection = self.manifest.selections[spec.selection]
            if selection.kind == "mask":
                selection_mask = self.array(selection.mask)
                if selection_mask.ndim != 1 or len(selection_mask) != n:
                    raise ValueError(f"selection {selection.id}: mask must have shape [N]")
                if selection_mask.dtype.kind not in "biu":
                    raise ValueError(f"selection {selection.id}: mask must be bool/integer")
                selection_key = self.file_cache_key(selection.mask)

        timeline_spec = None
        timestamps = normalized = cdf = None
        timeline_key = None
        playback_start, playback_end = spec.playback_start, spec.playback_end
        if spec.timeline:
            timeline_spec = self.manifest.timelines[spec.timeline]
            if timeline_spec.unit != "unix_seconds":
                raise ValueError(f"timeline {timeline_spec.id}: only unix_seconds is supported")
            timestamps = self.array(timeline_spec.timestamps)
            if timestamps.ndim != 1 or len(timestamps) != n or timestamps.dtype.kind not in "iu":
                raise ValueError(f"timeline {timeline_spec.id}: timestamps must be integer [N]")
            valid = timestamps != int(timeline_spec.missing_value)
            if np.any(valid):
                inferred_start, inferred_end = int(np.min(timestamps[valid])), int(np.max(timestamps[valid]))
            else:
                inferred_start, inferred_end = 0, 1
            playback_start = inferred_start if playback_start is None else int(playback_start)
            playback_end = inferred_end if playback_end is None else int(playback_end)
            if playback_end <= playback_start:
                playback_end = playback_start + 1
            normalized = self._normalized_timeline(timeline_spec, timestamps, playback_start, playback_end)
            timeline_key = f"timeline:{self.file_cache_key(timeline_spec.timestamps)}:{playback_start}:{playback_end}"
            cdf = self._timeline_cdf(timeline_spec, normalized, selection_mask, spec.selection, playback_start, playback_end)

        cluster = None
        cluster_key = None
        if spec.clustering:
            clustering = self.manifest.clusterings[spec.clustering]
            cluster = self.array(clustering.labels)
            if cluster.ndim != 1 or len(cluster) != n or cluster.dtype.kind not in "iu":
                raise ValueError(f"clustering {clustering.id}: labels must be integer [N]")
            cluster_key = self.file_cache_key(clustering.labels)

        densities: list[DensityBinding] = []
        for density_id in spec.densities:
            d = self.manifest.densities[density_id]
            arr = self.array(d.field)
            if arr.ndim != 2:
                raise ValueError(f"density {d.id}: field must be [H,W]")
            densities.append(DensityBinding(d, arr, self.file_cache_key(d.field)))

        segmentations: list[SegmentationBinding] = []
        for segmentation_id in spec.segmentations:
            s = self.manifest.segmentations[segmentation_id]
            labels = self.array(s.labels)
            stats = self.json_value(s.stats)
            if labels.ndim != 2 or not isinstance(stats, list):
                raise ValueError(f"segmentation {s.id}: invalid labels/stats")
            segmentations.append(SegmentationBinding(
                s, labels, stats, LandmarkMap(labels, stats, bounds), self.file_cache_key(s.labels)
            ))

        exploration = None
        if spec.exploration:
            e = self.manifest.explorations[spec.exploration]
            frames = self.array(e.frames)
            if frames.ndim == 2:
                frames = frames[np.newaxis, ...]
            if frames.ndim != 3:
                raise ValueError(f"exploration {e.id}: frames must be [T,H,W] or [H,W]")
            exploration = ExplorationBinding(e, frames, self.file_cache_key(e.frames))

        return ViewData(
            session=self, spec=spec, positions=positions,
            positions_key=self.file_cache_key(projection.positions), item_ids=item_ids,
            bounds=tuple(map(float, bounds)), x_order=x_order, x_sorted=x_sorted,
            selection_mask=selection_mask, selection_key=selection_key,
            timeline_spec=timeline_spec, timestamps=timestamps,
            normalized_timeline=normalized, timeline_key=timeline_key, timeline_cdf=cdf,
            playback_start=playback_start, playback_end=playback_end,
            cluster=cluster, cluster_key=cluster_key,
            densities=densities, segmentations=segmentations, exploration=exploration,
            theme=self.theme(spec.theme),
        )

    def _normalized_timeline(self, spec: TimelineSpec, timestamps: np.ndarray, start: int, end: int) -> np.ndarray:
        key = (spec.id, int(start), int(end))
        cached = self._timeline_runtime.get(key)
        if cached is not None:
            return cached
        out = np.full(len(timestamps), 2.0, dtype=np.float32)
        valid = timestamps != int(spec.missing_value)
        if np.any(valid):
            vals = np.asarray(timestamps[valid], dtype=np.float64)
            out[valid] = ((vals - float(start)) / float(end - start)).astype(np.float32)
        self._timeline_runtime[key] = out
        return out

    def _timeline_cdf(self, spec: TimelineSpec, normalized: np.ndarray, selection_mask: np.ndarray | None, selection_id: str | None, start: int, end: int) -> np.ndarray:
        key = (spec.id, selection_id, int(start), int(end))
        cached = self._timeline_cdfs.get(key)
        if cached is not None:
            return cached
        counts = np.zeros(1001, dtype=np.int64)
        chunk = 1_000_000
        for lo in range(0, len(normalized), chunk):
            hi = min(len(normalized), lo + chunk)
            values = np.asarray(normalized[lo:hi], dtype=np.float32)
            valid = np.isfinite(values) & (values <= 1.0)
            if selection_mask is not None:
                valid &= np.asarray(selection_mask[lo:hi], dtype=bool)
            if np.any(valid):
                bins = np.ceil(np.clip(values[valid], 0.0, 1.0) * 1000.0).astype(np.int32)
                counts += np.bincount(bins, minlength=1001)[:1001]
        cdf = np.cumsum(counts, dtype=np.int64)
        self._timeline_cdfs[key] = cdf
        return cdf

    @staticmethod
    def _infer_bounds(positions: np.ndarray) -> tuple[float, float, float, float]:
        finite = np.isfinite(positions).all(axis=1)
        if not np.any(finite):
            raise ValueError("projection has no finite positions")
        p = np.asarray(positions[finite], dtype=np.float32)
        xmin, xmax = float(np.min(p[:, 0])), float(np.max(p[:, 0]))
        ymin, ymax = float(np.min(p[:, 1])), float(np.max(p[:, 1]))
        if xmax <= xmin:
            xmin, xmax = xmin - 0.5, xmax + 0.5
        if ymax <= ymin:
            ymin, ymax = ymin - 0.5, ymax + 0.5
        return xmin, xmax, ymin, ymax


################################################################################
if __name__=="__main__":
    pass
