################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from scipy import ndimage as ndi


################################################################################
# FUNCTIONS
################################################################################
def _auto_density_grid(n_items: int) -> int:
    """Choose a raster that has useful population occupancy before smoothing.

    Aim for roughly four points per cell before clamping and round upward to a
    power of two. Examples: 100k -> 256, 1M -> 512, 10M -> 1024 (cap).
    """
    target = max(128.0, math.sqrt(max(1, n_items) / 4.0))
    power = 1 << int(math.ceil(math.log2(target)))
    return int(np.clip(power, 128, 1024))

def _auto_density_sigma(grid: int) -> float:
    # Constant fraction of world scale across adaptive raster resolutions.
    return max(2.0, float(grid) / 64.0)

def _auto_peak_distance(grid: int) -> int:
    # About 4% of map width. This is deliberately much coarser than a point.
    return max(5, int(round(grid / 24.0)))

def _auto_min_landmark_population(n_items: int) -> int:
    # Remove only clearly tiny basins by default. The main macro-scale control
    # comes from density smoothing, peak prominence and peak separation.
    return max(25, min(1_000, int(round(max(1, n_items) * 0.0005))))

def _box_blur_axis(array: np.ndarray, radius: int, axis: int) -> np.ndarray:
    if radius <= 0:
        return np.asarray(array, dtype=np.float32)
    width = 2 * radius + 1
    pad = [(0, 0), (0, 0)]
    pad[axis] = (radius, radius)
    padded = np.pad(np.asarray(array, dtype=np.float32), pad, mode="edge")
    cumulative = np.cumsum(padded, axis=axis, dtype=np.float32)

    zero_shape = list(cumulative.shape)
    zero_shape[axis] = 1
    cumulative = np.concatenate(
        [np.zeros(zero_shape, dtype=np.float32), cumulative], axis=axis
    )

    hi = [slice(None), slice(None)]
    lo = [slice(None), slice(None)]
    hi[axis] = slice(width, None)
    lo[axis] = slice(None, -width)
    return (cumulative[tuple(hi)] - cumulative[tuple(lo)]) / float(width)

def _smooth_field(array: np.ndarray, radius: int) -> np.ndarray:
    out = np.asarray(array, dtype=np.float32)
    for _ in range(3):
        out = _box_blur_axis(out, radius, 0)
        out = _box_blur_axis(out, radius, 1)
    return out

def _grid_indices(
    xy: np.ndarray,
    bounds: tuple[float, float, float, float],
    grid: int,
) -> tuple[np.ndarray, np.ndarray]:
    xmin, xmax, ymin, ymax = bounds
    ix = ((xy[:, 0] - xmin) * grid / (xmax - xmin)).astype(np.int32)
    iy = ((xy[:, 1] - ymin) * grid / (ymax - ymin)).astype(np.int32)
    np.clip(ix, 0, grid - 1, out=ix)
    np.clip(iy, 0, grid - 1, out=iy)
    return iy, ix

def _build_density(
    output_dir: Path,
    bounds: tuple[float, float, float, float],
    *,
    n_items: int,
    requested_grid: int | None,
    requested_sigma: float | None,
    normalization_percentile: float,
    chunk_size: int,
) -> dict:
    """Build a macro-scale density estimate from projected point positions."""
    positions = np.load(output_dir / "positions.npy", mmap_mode="r", allow_pickle=False)
    grid = (
        max(16, int(requested_grid))
        if requested_grid is not None
        else _auto_density_grid(n_items)
    )
    sigma = (
        max(0.0, float(requested_sigma))
        if requested_sigma is not None
        else _auto_density_sigma(grid)
    )
    percentile = float(np.clip(normalization_percentile, 90.0, 100.0))

    counts = np.zeros((grid, grid), dtype=np.float32)
    flat_counts = counts.reshape(-1)
    for start in range(0, len(positions), chunk_size):
        stop = min(len(positions), start + chunk_size)
        xy = np.asarray(positions[start:stop], dtype=np.float32)
        finite = np.isfinite(xy).all(axis=1)
        if not np.any(finite):
            continue
        xy = xy[finite]
        iy, ix = _grid_indices(xy, bounds, grid)
        keys = iy.astype(np.int64) * grid + ix.astype(np.int64)
        flat_counts += np.bincount(keys, minlength=grid * grid).astype(np.float32)

    # Smooth counts *before* compression. This behaves like a rasterized KDE and
    # prevents isolated occupied cells from becoming individual topographic hills.
    if sigma > 0.0:
        smoothed = ndi.gaussian_filter(
            counts,
            sigma=sigma,
            mode="constant",
            cval=0.0,
            truncate=4.0,
        ).astype(np.float32, copy=False)
    else:
        smoothed = counts

    field = np.log1p(smoothed).astype(np.float32, copy=False)
    positive = field[field > 0.0]
    if positive.size:
        scale = float(np.percentile(positive, percentile))
        if not np.isfinite(scale) or scale <= 1e-12:
            scale = float(positive.max())
        if scale > 1e-12:
            field /= scale
            np.clip(field, 0.0, 1.0, out=field)

    np.save(output_dir / "density.npy", field.astype(np.float32, copy=False), allow_pickle=False)
    return {
        "method": "gaussian_smoothed_2d_histogram",
        "grid": [grid, grid],
        "sigma_cells": float(sigma),
        "compression": "log1p_after_smoothing",
        "normalization": f"positive_p{percentile:g}",
        "target": "population_macrostructure",
    }

def build_density_asset(
    *,
    positions: np.ndarray,
    bounds: tuple[float, float, float, float],
    output_path: Path,
    selection_mask: np.ndarray | None = None,
    requested_grid: int | None = None,
    requested_sigma: float | None = None,
    normalization_percentile: float = 99.5,
    chunk_size: int = 250_000,
    method: str = "gaussian",
) -> dict:
    """Build one file-backed density asset for a projection and optional selection."""
    n = len(positions)
    if selection_mask is not None and len(selection_mask) != n:
        raise ValueError("selection mask must match positions")
    finite_total = 0
    for lo in range(0, n, max(1, chunk_size)):
        hi = min(n, lo + max(1, chunk_size))
        valid = np.isfinite(np.asarray(positions[lo:hi], dtype=np.float32)).all(axis=1)
        if selection_mask is not None:
            valid &= np.asarray(selection_mask[lo:hi], dtype=bool)
        finite_total += int(np.count_nonzero(valid))
    grid = max(16, int(requested_grid)) if requested_grid is not None else _auto_density_grid(finite_total)
    sigma = max(0.0, float(requested_sigma)) if requested_sigma is not None else _auto_density_sigma(grid)
    percentile = float(np.clip(normalization_percentile, 90.0, 100.0))

    counts = np.zeros((grid, grid), dtype=np.float32)
    flat_counts = counts.reshape(-1)
    for lo in range(0, n, max(1, chunk_size)):
        hi = min(n, lo + max(1, chunk_size))
        xy = np.asarray(positions[lo:hi], dtype=np.float32)
        valid = np.isfinite(xy).all(axis=1)
        if selection_mask is not None:
            valid &= np.asarray(selection_mask[lo:hi], dtype=bool)
        if not np.any(valid):
            continue
        iy, ix = _grid_indices(xy[valid], bounds, grid)
        keys = iy.astype(np.int64) * grid + ix.astype(np.int64)
        flat_counts += np.bincount(keys, minlength=grid * grid).astype(np.float32)

    method = str(method).lower().replace("_", "-")
    if method in {"histogram", "raw-histogram"}:
        smoothed = counts
        method_name = "normalized_2d_histogram"
    elif method in {"adaptive-gaussian", "adaptive"}:
        small = ndi.gaussian_filter(counts, sigma=max(0.5, sigma * 0.55), mode="constant", cval=0.0, truncate=4.0)
        large = ndi.gaussian_filter(counts, sigma=max(1.0, sigma * 1.8), mode="constant", cval=0.0, truncate=4.0)
        # Preserve compact high-density modes while allowing sparse neighborhoods
        # to borrow a broader bandwidth. This is intentionally an inexpensive
        # raster-space adaptive approximation, not a full per-point KDE.
        weight = small / max(float(small.max()), 1e-12)
        smoothed = (weight * small + (1.0 - weight) * large).astype(np.float32, copy=False)
        method_name = "adaptive_gaussian_histogram"
    elif method in {"gaussian", "gaussian-histogram"}:
        smoothed = ndi.gaussian_filter(counts, sigma=sigma, mode="constant", cval=0.0, truncate=4.0).astype(np.float32, copy=False) if sigma > 0.0 else counts
        method_name = "gaussian_smoothed_2d_histogram"
    else:
        raise ValueError(f"unknown density method: {method}")
    field = np.log1p(smoothed).astype(np.float32, copy=False)
    positive = field[field > 0.0]
    if positive.size:
        scale = float(np.percentile(positive, percentile))
        if not np.isfinite(scale) or scale <= 1e-12:
            scale = float(positive.max())
        if scale > 1e-12:
            field /= scale
            np.clip(field, 0.0, 1.0, out=field)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    np.save(output_path, field.astype(np.float32, copy=False), allow_pickle=False)
    return {
        "method": method_name,
        "grid": [grid, grid],
        "sigma_cells": float(sigma),
        "compression": "log1p_after_smoothing",
        "normalization": f"positive_p{percentile:g}",
        "target": "population_macrostructure",
        "population_items": int(finite_total),
    }

def _greedy_separated_peaks(
    y: np.ndarray,
    x: np.ndarray,
    values: np.ndarray,
    *,
    min_distance: int,
    max_peaks: int,
) -> np.ndarray:
    if len(y) == 0:
        return np.empty((0, 2), dtype=np.int32)
    order = np.argsort(values)[::-1]
    chosen: list[tuple[int, int]] = []
    min_d2 = float(max(1, min_distance) ** 2)
    for idx in order:
        py, px = int(y[idx]), int(x[idx])
        if all((py - cy) ** 2 + (px - cx) ** 2 >= min_d2 for cy, cx in chosen):
            chosen.append((py, px))
            if len(chosen) >= max_peaks:
                break
    return np.asarray(chosen, dtype=np.int32)

def _choose_prominent_peaks(
    density: np.ndarray,
    *,
    max_peaks: int,
    threshold: float,
    min_distance: int,
    prominence: float,
) -> tuple[np.ndarray, dict]:
    """Find macro-scale density maxima rather than point-scale local maxima."""
    z = np.asarray(density, dtype=np.float32)
    min_distance = max(1, int(min_distance))

    # A second, gentler blur is intentional: density already suppresses point
    # noise; this suppresses small ripples *within* a broad density mountain.
    peak_sigma = max(1.0, min_distance * 0.22)
    peak_field = ndi.gaussian_filter(z, sigma=peak_sigma, mode="nearest")
    background_sigma = max(peak_sigma * 3.0, min_distance * 1.25)
    background = ndi.gaussian_filter(z, sigma=background_sigma, mode="nearest")
    prominence_field = peak_field - background

    window = 2 * min_distance + 1
    local_max = ndi.maximum_filter(peak_field, size=window, mode="nearest")
    mask = (
        (peak_field >= local_max - 1e-7)
        & (peak_field >= float(threshold))
        & (prominence_field >= float(prominence))
    )

    # A flat summit can contain many equal max pixels. Collapse each plateau to
    # one representative seed before enforcing Euclidean separation.
    plateau_labels, plateau_count = ndi.label(mask, structure=np.ones((3, 3), dtype=np.uint8))
    py: list[int] = []
    px: list[int] = []
    pv: list[float] = []
    for label_id in range(1, plateau_count + 1):
        yy, xx = np.nonzero(plateau_labels == label_id)
        if len(yy) == 0:
            continue
        vals = peak_field[yy, xx]
        best = int(np.argmax(vals))
        py.append(int(yy[best]))
        px.append(int(xx[best]))
        pv.append(float(vals[best]))

    peaks = _greedy_separated_peaks(
        np.asarray(py, dtype=np.int32),
        np.asarray(px, dtype=np.int32),
        np.asarray(pv, dtype=np.float32),
        min_distance=min_distance,
        max_peaks=max_peaks,
    )

    # Fallback: if prominence filtering eliminated everything but there is a
    # meaningful density field, preserve the strongest broad mode.
    if len(peaks) == 0 and float(peak_field.max()) >= float(threshold):
        iy, ix = np.unravel_index(int(np.argmax(peak_field)), peak_field.shape)
        peaks = np.array([[iy, ix]], dtype=np.int32)

    return peaks, {
        "peak_smoothing_sigma_cells": float(peak_sigma),
        "prominence_background_sigma_cells": float(background_sigma),
        "prominence_threshold": float(prominence),
    }

def _ensure_component_markers(
    density: np.ndarray,
    active: np.ndarray,
    peaks_yx: np.ndarray,
) -> np.ndarray:
    """Ensure every disconnected meaningful-density island has a watershed seed."""
    components, count = ndi.label(active, structure=np.ones((3, 3), dtype=np.uint8))
    peaks = [tuple(map(int, p)) for p in np.asarray(peaks_yx)]
    marked_components = {
        int(components[py, px])
        for py, px in peaks
        if 0 <= py < active.shape[0] and 0 <= px < active.shape[1] and components[py, px] > 0
    }
    for component_id in range(1, count + 1):
        if component_id in marked_components:
            continue
        yy, xx = np.nonzero(components == component_id)
        if len(yy) == 0:
            continue
        best = int(np.argmax(density[yy, xx]))
        peaks.append((int(yy[best]), int(xx[best])))
    return np.asarray(peaks, dtype=np.int32)

def _watershed(
    density: np.ndarray,
    peaks_yx: np.ndarray,
    threshold: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Run an actual watershed over the inverted density field."""
    z = np.asarray(density, dtype=np.float32)
    active = z >= float(threshold)
    if not np.any(active):
        return np.zeros(z.shape, dtype=np.uint32), np.empty((0, 2), dtype=np.int32)

    peaks_yx = _ensure_component_markers(z, active, peaks_yx)
    if len(peaks_yx) == 0:
        return np.zeros(z.shape, dtype=np.uint32), peaks_yx

    markers = np.zeros(z.shape, dtype=np.int32)
    for marker_id, (py, px) in enumerate(peaks_yx, start=1):
        if active[py, px]:
            markers[py, px] = marker_id

    # watershed_ift accepts uint8/uint16 elevation maps. High density should be
    # low elevation, so invert the normalized field. Cells outside the active
    # density mask are placed at maximum elevation and are cleared afterward.
    elevation = np.rint((1.0 - np.clip(z, 0.0, 1.0)) * 65535.0).astype(np.uint16)
    elevation[~active] = np.uint16(65535)
    labels = ndi.watershed_ift(elevation, markers, structure=np.ones((3, 3), dtype=np.int8))
    labels = labels.astype(np.uint32, copy=False)
    labels[~active] = 0
    return labels, peaks_yx

def _point_population_by_label(
    positions: np.ndarray,
    labels: np.ndarray,
    bounds: tuple[float, float, float, float],
    *,
    chunk_size: int,
    selection_mask: np.ndarray | None = None,
) -> np.ndarray:
    max_label = int(labels.max())
    population = np.zeros(max_label + 1, dtype=np.int64)
    grid = labels.shape[1]
    if selection_mask is not None and len(selection_mask) != len(positions):
        raise ValueError("selection mask must match positions")
    for start in range(0, len(positions), chunk_size):
        stop = min(len(positions), start + chunk_size)
        xy = np.asarray(positions[start:stop], dtype=np.float32)
        finite = np.isfinite(xy).all(axis=1)
        if selection_mask is not None:
            finite &= np.asarray(selection_mask[start:stop], dtype=bool)
        if not np.any(finite):
            continue
        xy = xy[finite]
        iy, ix = _grid_indices(xy, bounds, grid)
        lid = labels[iy, ix]
        population += np.bincount(lid, minlength=max_label + 1)[: max_label + 1]
    return population

def _build_landmarks(
    output_dir: Path,
    bounds: tuple[float, float, float, float],
    *,
    n_items: int,
    max_landmarks: int,
    threshold: float,
    peak_distance: int | None,
    prominence: float,
    min_population: int | None,
    chunk_size: int,
) -> dict:
    density = np.load(output_dir / "density.npy", mmap_mode="r", allow_pickle=False)
    h, w = density.shape
    max_landmarks = max(1, int(max_landmarks))
    peak_distance = (
        max(1, int(peak_distance))
        if peak_distance is not None
        else _auto_peak_distance(max(h, w))
    )
    min_population = (
        max(1, int(min_population))
        if min_population is not None
        else _auto_min_landmark_population(n_items)
    )

    peaks_yx, peak_meta = _choose_prominent_peaks(
        density,
        max_peaks=max_landmarks,
        threshold=threshold,
        min_distance=peak_distance,
        prominence=max(0.0, float(prominence)),
    )
    labels, peaks_yx = _watershed(density, peaks_yx, threshold)

    if len(peaks_yx) == 0 or int(labels.max()) == 0:
        labels = np.zeros((h, w), dtype=np.uint16)
        np.save(output_dir / "landmark_labels.npy", labels, allow_pickle=False)
        (output_dir / "landmark_stats.json").write_text("[]\n")
        return {
            "method": "scipy_watershed_ift_on_smoothed_density",
            "landmarks": 0,
            "density_threshold": float(threshold),
            "peak_distance_cells": peak_distance,
            "min_population": min_population,
            **peak_meta,
        }

    positions = np.load(output_dir / "positions.npy", mmap_mode="r", allow_pickle=False)
    population = _point_population_by_label(
        positions, labels, bounds, chunk_size=chunk_size
    )

    # Small basins are usually residual sub-peaks. Remove their seeds and rerun
    # watershed so their area is absorbed by surviving, larger density modes.
    peak_ids = np.arange(1, len(peaks_yx) + 1, dtype=np.int32)
    keep = peak_ids[population[peak_ids] >= min_population]
    if len(keep) == 0:
        keep = np.array([int(peak_ids[np.argmax(population[peak_ids])])], dtype=np.int32)

    if len(keep) < len(peaks_yx):
        kept_peaks = peaks_yx[keep - 1]
        labels, peaks_yx = _watershed(density, kept_peaks, threshold)
        population = _point_population_by_label(
            positions, labels, bounds, chunk_size=chunk_size
        )

    # Re-map any non-contiguous marker IDs to [1..K], preserving 0 as outside.
    old_ids = np.unique(labels)
    old_ids = old_ids[old_ids > 0]
    remap = np.zeros(int(labels.max()) + 1, dtype=np.uint32)
    for new_id, old_id in enumerate(old_ids, start=1):
        remap[int(old_id)] = new_id
    labels = remap[labels]

    # Determine the actual peak corresponding to each final basin. Re-running
    # watershed can alter marker numbering, so find the basin's maximum-density
    # cell directly rather than assuming a stale seed-to-label correspondence.
    final_count = int(labels.max())
    final_peaks: list[tuple[int, int]] = []
    for lid in range(1, final_count + 1):
        yy, xx = np.nonzero(labels == lid)
        if len(yy) == 0:
            final_peaks.append((0, 0))
            continue
        best = int(np.argmax(np.asarray(density[yy, xx], dtype=np.float32)))
        final_peaks.append((int(yy[best]), int(xx[best])))

    if final_count <= np.iinfo(np.uint16).max:
        labels_out = labels.astype(np.uint16)
    else:
        # Current renderer normally expects uint16 landmarks; this branch keeps
        # file correctness for unusual explicit landmark counts, but users
        # should keep --landmarks below 65535 for renderer compatibility.
        labels_out = labels.astype(np.uint32)
    np.save(output_dir / "landmark_labels.npy", labels_out, allow_pickle=False)

    population = _point_population_by_label(
        positions, labels, bounds, chunk_size=chunk_size
    )
    area = np.bincount(labels.reshape(-1), minlength=final_count + 1)[: final_count + 1]

    xmin, xmax, ymin, ymax = bounds
    cell_w = (xmax - xmin) / w
    cell_h = (ymax - ymin) / h
    cell_area = abs(cell_w * cell_h)

    stats: list[dict] = []
    for idx, (py, px) in enumerate(final_peaks, start=1):
        x = xmin + (float(px) + 0.5) * cell_w
        y = ymin + (float(py) + 0.5) * cell_h
        basin_area = float(area[idx]) * cell_area
        basin_scale = max(
            math.sqrt(max(basin_area, 0.0) / math.pi),
            max(abs(cell_w), abs(cell_h)),
        )
        stats.append(
            {
                "id": idx,
                "x": float(x),
                "y": float(y),
                "population": int(population[idx]),
                "peak_density": float(density[py, px]),
                "area_cells": int(area[idx]),
                "basin_scale": float(basin_scale),
            }
        )

    (output_dir / "landmark_stats.json").write_text(json.dumps(stats, indent=2) + "\n")
    return {
        "method": "scipy_watershed_ift_on_smoothed_density",
        "landmarks": len(stats),
        "density_threshold": float(threshold),
        "peak_distance_cells": peak_distance,
        "min_population": min_population,
        "small_basin_policy": "remove_seed_and_rerun_watershed",
        **peak_meta,
    }

def build_segmentation_asset(
    *,
    positions: np.ndarray,
    density: np.ndarray,
    bounds: tuple[float, float, float, float],
    labels_path: Path,
    stats_path: Path,
    selection_mask: np.ndarray | None = None,
    max_segments: int = 128,
    threshold: float = 0.04,
    peak_distance: int | None = None,
    prominence: float = 0.02,
    min_population: int | None = None,
    chunk_size: int = 250_000,
    method: str = "watershed",
) -> dict:
    """Build a categorical segmentation raster from an existing density asset."""
    density = np.asarray(density, dtype=np.float32)
    if density.ndim != 2:
        raise ValueError("density must be [H,W]")
    if selection_mask is not None and len(selection_mask) != len(positions):
        raise ValueError("selection mask must match positions")
    valid_population = 0
    for lo in range(0, len(positions), max(1, chunk_size)):
        hi = min(len(positions), lo + max(1, chunk_size))
        valid = np.isfinite(np.asarray(positions[lo:hi], dtype=np.float32)).all(axis=1)
        if selection_mask is not None:
            valid &= np.asarray(selection_mask[lo:hi], dtype=bool)
        valid_population += int(np.count_nonzero(valid))
    max_segments = max(1, int(max_segments))
    peak_distance = max(1, int(peak_distance)) if peak_distance is not None else _auto_peak_distance(max(density.shape))
    min_population = max(1, int(min_population)) if min_population is not None else _auto_min_landmark_population(valid_population)
    threshold = float(np.clip(threshold, 0.0, 1.0))
    method = str(method).lower().replace("_", "-")

    if method in {"connected-components", "components"}:
        active = np.asarray(density >= threshold, dtype=bool)
        labels, count = ndi.label(active, structure=np.ones((3, 3), dtype=np.uint8))
        labels = labels.astype(np.uint32, copy=False)
        population = _point_population_by_label(positions, labels, bounds, chunk_size=max(1, chunk_size), selection_mask=selection_mask)
        keep = [i for i in range(1, count + 1) if population[i] >= min_population]
        if keep:
            remap = np.zeros(count + 1, dtype=np.uint32)
            for new_id, old_id in enumerate(keep, start=1): remap[old_id] = new_id
            labels = remap[labels]
        else:
            labels = np.zeros_like(labels, dtype=np.uint32)
        final_count = int(labels.max())
        labels_out = labels.astype(np.uint16 if final_count <= np.iinfo(np.uint16).max else np.uint32)
        labels_path.parent.mkdir(parents=True, exist_ok=True); stats_path.parent.mkdir(parents=True, exist_ok=True)
        np.save(labels_path, labels_out, allow_pickle=False)
        pop = _point_population_by_label(positions, labels, bounds, chunk_size=max(1, chunk_size), selection_mask=selection_mask)
        area = np.bincount(labels.reshape(-1), minlength=final_count + 1)[: final_count + 1]
        h,w=density.shape; xmin,xmax,ymin,ymax=bounds; cell_w=(xmax-xmin)/w; cell_h=(ymax-ymin)/h; cell_area=abs(cell_w*cell_h)
        stats=[]
        for lid in range(1, final_count+1):
            yy,xx=np.nonzero(labels==lid)
            if len(yy)==0: continue
            best=int(np.argmax(density[yy,xx])); py,px=int(yy[best]),int(xx[best])
            basin_area=float(area[lid])*cell_area
            stats.append({"id":lid,"x":float(xmin+(px+0.5)*cell_w),"y":float(ymin+(py+0.5)*cell_h),"population":int(pop[lid]),"peak_density":float(density[py,px]),"area_cells":int(area[lid]),"basin_scale":float(max(math.sqrt(max(basin_area,0.0)/math.pi),max(abs(cell_w),abs(cell_h))))})
        stats_path.write_text(json.dumps(stats,indent=2)+"\n")
        return {"method":"density_connected_components","segments":len(stats),"density_threshold":threshold,"min_population":min_population}
    if method not in {"watershed", "scipy-watershed"}:
        raise ValueError(f"unknown segmentation method: {method}")

    peaks_yx, peak_meta = _choose_prominent_peaks(
        density,
        max_peaks=max_segments,
        threshold=threshold,
        min_distance=peak_distance,
        prominence=max(0.0, float(prominence)),
    )
    labels, peaks_yx = _watershed(density, peaks_yx, threshold)
    if len(peaks_yx) == 0 or int(labels.max()) == 0:
        labels_path.parent.mkdir(parents=True, exist_ok=True)
        stats_path.parent.mkdir(parents=True, exist_ok=True)
        np.save(labels_path, np.zeros(density.shape, dtype=np.uint16), allow_pickle=False)
        stats_path.write_text("[]\n")
        return {
            "method": "scipy_watershed_ift_on_smoothed_density",
            "segments": 0,
            "density_threshold": threshold,
            "peak_distance_cells": peak_distance,
            "min_population": min_population,
            **peak_meta,
        }

    population = _point_population_by_label(
        positions, labels, bounds, chunk_size=max(1, chunk_size), selection_mask=selection_mask
    )
    peak_ids = np.arange(1, len(peaks_yx) + 1, dtype=np.int32)
    keep = peak_ids[population[peak_ids] >= min_population]
    if len(keep) == 0:
        keep = np.array([int(peak_ids[np.argmax(population[peak_ids])])], dtype=np.int32)
    if len(keep) < len(peaks_yx):
        labels, peaks_yx = _watershed(density, peaks_yx[keep - 1], threshold)

    old_ids = np.unique(labels)
    old_ids = old_ids[old_ids > 0]
    remap = np.zeros(int(labels.max()) + 1, dtype=np.uint32)
    for new_id, old_id in enumerate(old_ids, start=1):
        remap[int(old_id)] = new_id
    labels = remap[labels]
    final_count = int(labels.max())
    final_peaks: list[tuple[int, int]] = []
    for lid in range(1, final_count + 1):
        yy, xx = np.nonzero(labels == lid)
        if len(yy) == 0:
            final_peaks.append((0, 0))
            continue
        best = int(np.argmax(np.asarray(density[yy, xx], dtype=np.float32)))
        final_peaks.append((int(yy[best]), int(xx[best])))

    labels_out = labels.astype(np.uint16 if final_count <= np.iinfo(np.uint16).max else np.uint32)
    labels_path.parent.mkdir(parents=True, exist_ok=True)
    stats_path.parent.mkdir(parents=True, exist_ok=True)
    np.save(labels_path, labels_out, allow_pickle=False)
    population = _point_population_by_label(
        positions, labels, bounds, chunk_size=max(1, chunk_size), selection_mask=selection_mask
    )
    area = np.bincount(labels.reshape(-1), minlength=final_count + 1)[: final_count + 1]
    h, w = density.shape
    xmin, xmax, ymin, ymax = bounds
    cell_w = (xmax - xmin) / w
    cell_h = (ymax - ymin) / h
    cell_area = abs(cell_w * cell_h)
    stats: list[dict] = []
    for idx, (py, px) in enumerate(final_peaks, start=1):
        x = xmin + (float(px) + 0.5) * cell_w
        y = ymin + (float(py) + 0.5) * cell_h
        basin_area = float(area[idx]) * cell_area
        basin_scale = max(math.sqrt(max(basin_area, 0.0) / math.pi), max(abs(cell_w), abs(cell_h)))
        stats.append({
            "id": idx, "x": float(x), "y": float(y),
            "population": int(population[idx]),
            "peak_density": float(density[py, px]),
            "area_cells": int(area[idx]),
            "basin_scale": float(basin_scale),
        })
    stats_path.write_text(json.dumps(stats, indent=2) + "\n")
    return {
        "method": "scipy_watershed_ift_on_smoothed_density",
        "segments": len(stats),
        "density_threshold": threshold,
        "peak_distance_cells": peak_distance,
        "min_population": min_population,
        "small_basin_policy": "remove_seed_and_rerun_watershed",
        **peak_meta,
    }

def build_exploration(
    *,
    positions: np.ndarray,
    bounds: tuple[float, float, float, float],
    output_path: Path,
    selection_mask: np.ndarray | None,
    timestamps: np.ndarray | None = None,
    missing_value: int = -1,
    frames: int = 64,
    grid: int = 256,
    radius: int = 5,
    chunk_size: int = 250_000,
    method: str = "box-blur",
) -> dict:
    """Build a static or temporal exploration field.

    Selection controls *membership*.  Timeline timestamps are optional and only
    control when selected items enter the cumulative exploration field.

    Without timestamps the result has one frame and therefore displays the
    exploration implied by the complete selection immediately.
    """
    n = len(positions)
    if selection_mask is not None and len(selection_mask) != n:
        raise ValueError("selection mask must match positions")
    if timestamps is not None and len(timestamps) != n:
        raise ValueError("timestamps must match positions")

    grid = max(16, int(grid))
    radius = max(0, int(radius))
    temporal = timestamps is not None
    frames = max(2, int(frames)) if temporal else 1

    start_time = end_time = None
    if temporal:
        valid_time = np.asarray(timestamps) != int(missing_value)
        if np.any(valid_time):
            start_time = int(np.min(np.asarray(timestamps)[valid_time]))
            end_time = int(np.max(np.asarray(timestamps)[valid_time]))
        else:
            start_time, end_time = 0, 1
        if end_time <= start_time:
            end_time = start_time + 1

    events = np.zeros((frames, grid, grid), dtype=np.int32)
    plane = grid * grid
    flat = events.reshape(-1)

    for lo in range(0, n, chunk_size):
        hi = min(n, lo + chunk_size)
        mask = np.ones(hi - lo, dtype=bool)
        if selection_mask is not None:
            mask &= np.asarray(selection_mask[lo:hi], dtype=bool)
        if temporal:
            ts = np.asarray(timestamps[lo:hi])
            mask &= ts != int(missing_value)
        if not np.any(mask):
            continue

        block_positions = np.asarray(positions[lo:hi], dtype=np.float32)
        mask &= np.isfinite(block_positions).all(axis=1)
        if not np.any(mask):
            continue
        xy = block_positions[mask]
        iy, ix = _grid_indices(xy, bounds, grid)
        if temporal:
            ts_valid = np.asarray(timestamps[lo:hi][mask], dtype=np.float64)
            norm = (ts_valid - float(start_time)) / float(end_time - start_time)
            frame_idx = np.ceil(np.clip(norm, 0.0, 1.0) * (frames - 1)).astype(np.int32)
        else:
            frame_idx = np.zeros(len(xy), dtype=np.int32)
        keys = frame_idx.astype(np.int64) * plane + iy.astype(np.int64) * grid + ix
        np.add.at(flat, keys, 1)

    method = str(method).lower().replace("_", "-")
    def exploration_field(counts: np.ndarray) -> np.ndarray:
        base = np.log1p(counts).astype(np.float32, copy=False)
        if method in {"box-blur", "coverage", "selection-coverage"}:
            return _smooth_field(base, radius)
        if method in {"gaussian", "gaussian-coverage"}:
            return ndi.gaussian_filter(base, sigma=max(0.5, float(radius)), mode="nearest").astype(np.float32, copy=False)
        if method in {"distance", "distance-coverage"}:
            occupied = counts > 0
            if not np.any(occupied): return np.zeros_like(base, dtype=np.float32)
            dist = ndi.distance_transform_edt(~occupied).astype(np.float32)
            scale=max(float(radius),1.0)
            return np.exp(-0.5*np.square(dist/scale)).astype(np.float32)
        raise ValueError(f"unknown exploration method: {method}")

    final_counts = np.sum(events, axis=0, dtype=np.float32)
    final_field = exploration_field(final_counts)
    normalizer = max(float(final_field.max()), 1e-12)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    out = np.lib.format.open_memmap(
        output_path,
        mode="w+",
        dtype=np.float16,
        shape=(frames, grid, grid),
    )
    running = np.zeros((grid, grid), dtype=np.float32)
    for frame in range(frames):
        running += events[frame]
        field = exploration_field(running)
        np.clip(field / normalizer, 0.0, 1.0, out=field)
        out[frame] = field.astype(np.float16, copy=False)
    out.flush()

    return {
        "method": {"box-blur":"selection_coverage_box_blur","coverage":"selection_coverage_box_blur","selection-coverage":"selection_coverage_box_blur","gaussian":"selection_coverage_gaussian","gaussian-coverage":"selection_coverage_gaussian","distance":"selection_distance_coverage","distance-coverage":"selection_distance_coverage"}.get(method, method),
        "temporal": bool(temporal),
        "frames": int(frames),
        "grid": [int(grid), int(grid)],
        "radius": int(radius),
        "timeline_start": start_time,
        "timeline_end": end_time,
        "selection_items": int(n if selection_mask is None else np.count_nonzero(selection_mask)),
    }


################################################################################
if __name__=="__main__":
    pass
