################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from typing import Protocol

import numpy as np


################################################################################
# CLASSES
################################################################################
class EmbeddingSource(Protocol):
    """Chunk-readable high-dimensional source used by preparation methods."""

    @property
    def n_items(self) -> int: ...

    @property
    def dimensions(self) -> int: ...

    @property
    def dtype(self) -> np.dtype: ...

    def read(self, start: int, stop: int) -> np.ndarray: ...


################################################################################
if __name__=="__main__":
    pass
