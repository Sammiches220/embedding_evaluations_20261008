################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

import numpy as np


################################################################################
# CLASSES
################################################################################
class NumpyEmbeddingSource:
    """Memory-mapped ``.npy`` matrix with shape [N,D]."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.array = np.load(self.path, mmap_mode="r", allow_pickle=False)
        if self.array.ndim != 2:
            raise ValueError(f"embedding array must have shape [N,D], got {self.array.shape}")
        if self.array.shape[0] == 0 or self.array.shape[1] == 0:
            raise ValueError("embedding array must be non-empty")
        if self.array.dtype.kind not in "fiu":
            raise ValueError(f"embedding dtype must be numeric, got {self.array.dtype}")

    @property
    def n_items(self) -> int:
        return int(self.array.shape[0])

    @property
    def dimensions(self) -> int:
        return int(self.array.shape[1])

    @property
    def dtype(self) -> np.dtype:
        return self.array.dtype

    def read(self, start: int, stop: int) -> np.ndarray:
        return np.asarray(self.array[start:stop])


################################################################################
if __name__=="__main__":
    pass
