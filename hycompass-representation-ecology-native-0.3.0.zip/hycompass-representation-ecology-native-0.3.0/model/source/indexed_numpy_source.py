################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

import numpy as np


################################################################################
# CLASSES
################################################################################
class IndexedNumpyEmbeddingSource:
    """Chunk-readable subset of a memory-mapped [N,D] NumPy embedding matrix.

    The source row space is the provided domain-row index vector.  Projection
    methods therefore operate on only the selected rows while callers can later
    scatter the [M,2] result back into a domain-aligned [N,2] projection asset.
    """

    def __init__(self, path: Path, indices: np.ndarray):
        self.path = Path(path)
        self.array = np.load(self.path, mmap_mode="r", allow_pickle=False)
        if self.array.ndim != 2 or self.array.dtype.kind not in "fiu":
            raise ValueError("embedding array must be numeric [N,D]")
        self.indices = np.asarray(indices, dtype=np.int64)
        if self.indices.ndim != 1 or len(self.indices) == 0:
            raise ValueError("indexed projection requires at least one selected row")
        if int(self.indices.min()) < 0 or int(self.indices.max()) >= len(self.array):
            raise ValueError("subset row index is outside the embedding domain")

    @property
    def n_items(self) -> int:
        return int(len(self.indices))

    @property
    def dimensions(self) -> int:
        return int(self.array.shape[1])

    @property
    def dtype(self) -> np.dtype:
        return self.array.dtype

    def read(self, start: int, stop: int) -> np.ndarray:
        rows = self.indices[start:stop]
        return np.asarray(self.array[rows])


################################################################################
if __name__=="__main__":
    pass
