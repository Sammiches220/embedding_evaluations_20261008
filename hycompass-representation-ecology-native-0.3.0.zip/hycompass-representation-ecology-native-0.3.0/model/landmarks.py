################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


################################################################################
# CLASSES
################################################################################
@dataclass(frozen=True)
class LandmarkInfo:
    id: int
    x: float
    y: float
    population: int
    peak_density: float
    area_cells: int
    basin_scale: float


class LandmarkMap:
    def __init__(
        self,
        labels: np.ndarray,
        stats: list[dict],
        bounds: tuple[float, float, float, float],
    ) -> None:
        self.labels = labels
        self.bounds = bounds
        self.stats = stats
        self.by_id = {int(s["id"]): s for s in stats}

        stat_max = max((int(s["id"]) for s in stats), default=0)
        m = stat_max + 1
        self.anchor_x = np.zeros(m, np.float32)
        self.anchor_y = np.zeros(m, np.float32)
        self.anchor_scale = np.ones(m, np.float32)
        self.anchor_population = np.zeros(m, np.int64)
        self.anchor_peak = np.zeros(m, np.float32)
        for s in stats:
            i = int(s["id"])
            self.anchor_x[i] = s["x"]
            self.anchor_y[i] = s["y"]
            self.anchor_scale[i] = max(float(s.get("basin_scale", 1.0)), 1e-5)
            self.anchor_population[i] = int(s["population"])
            self.anchor_peak[i] = float(s["peak_density"])

    def at(self, x: float, y: float) -> int:
        xmin, xmax, ymin, ymax = self.bounds
        h, w = self.labels.shape
        ix = int(np.clip((x - xmin) * w / (xmax - xmin), 0, w - 1))
        iy = int(np.clip((y - ymin) * h / (ymax - ymin), 0, h - 1))
        return int(self.labels[iy, ix])

    def get(self, landmark_id: int) -> dict | None:
        return self.by_id.get(int(landmark_id))


################################################################################
if __name__=="__main__":
    pass
