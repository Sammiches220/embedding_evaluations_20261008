################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path
from typing import Protocol

import numpy as np

##### Internal Imports #####
from model.source.base import EmbeddingSource


################################################################################
# CLASSES
################################################################################
class ClusteringMethod(Protocol):
    name: str

    def cluster(
        self,
        source: EmbeddingSource,
        output_path: Path,
        *,
        chunk_size: int,
    ) -> np.memmap: ...

    def metadata(self) -> dict: ...


################################################################################
if __name__=="__main__":
    pass
