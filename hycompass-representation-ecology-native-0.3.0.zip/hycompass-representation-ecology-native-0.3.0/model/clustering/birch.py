################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

import numpy as np

##### Internal Imports #####
from model.source.base import EmbeddingSource


################################################################################
# CLASSES
################################################################################
class BirchClustering:
    """BIRCH clustering example for modular clustering implementations.

    The implementation fits incrementally where scikit-learn permits and then
    predicts domain-aligned labels in chunks. It complements MiniBatchKMeans by
    using a hierarchical CF-tree rather than centroid mini-batches.
    """

    name = "birch"

    def __init__(self, *, threshold: float = 0.7, n_clusters: int | None = 32) -> None:
        self.threshold = float(threshold)
        self.n_clusters = None if n_clusters is None else int(n_clusters)

    def cluster(self, source: EmbeddingSource, output_path: Path, *, chunk_size: int) -> np.memmap:
        try:
            from sklearn.cluster import Birch
        except ImportError as exc:
            raise RuntimeError("BIRCH clustering requires scikit-learn") from exc
        if source.n_items < 2:
            raise ValueError("BIRCH requires at least two items")
        model = Birch(threshold=self.threshold, n_clusters=self.n_clusters)
        chunk = max(2, int(chunk_size))
        for lo in range(0, source.n_items, chunk):
            hi = min(source.n_items, lo + chunk)
            model.partial_fit(np.asarray(source.read(lo, hi), dtype=np.float32))
        out = np.lib.format.open_memmap(output_path, mode="w+", dtype=np.uint32, shape=(source.n_items,))
        for lo in range(0, source.n_items, chunk):
            hi = min(source.n_items, lo + chunk)
            labels = model.predict(np.asarray(source.read(lo, hi), dtype=np.float32)).astype(np.int64, copy=False)
            # sklearn labels are non-negative here; normalize defensively.
            if labels.size and labels.min() < 0:
                labels = labels - labels.min()
            out[lo:hi] = labels.astype(np.uint32, copy=False)
        out.flush()
        return out

    def metadata(self) -> dict:
        return {"method": self.name, "threshold": self.threshold, "n_clusters": self.n_clusters}


################################################################################
if __name__=="__main__":
    pass
