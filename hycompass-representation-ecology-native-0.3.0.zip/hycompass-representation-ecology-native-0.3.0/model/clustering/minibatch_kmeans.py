################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

import numpy as np

##### Internal Imports #####
from model.source.base import EmbeddingSource


################################################################################
# CLASSES
################################################################################
class MiniBatchKMeansClustering:
    name = "minibatch_kmeans"

    def __init__(self, n_clusters: int = 64, random_state: int = 42) -> None:
        self.n_clusters = int(n_clusters)
        self.random_state = int(random_state)

    def cluster(self, source: EmbeddingSource, output_path: Path, *, chunk_size: int) -> np.memmap:
        try:
            from sklearn.cluster import MiniBatchKMeans
        except ImportError as exc:
            raise RuntimeError(
                "MiniBatchKMeans requires scikit-learn. Install it with: "
                "python -m pip install scikit-learn"
            ) from exc

        if source.n_items < self.n_clusters:
            raise ValueError("n_clusters cannot exceed the number of items")
        model = MiniBatchKMeans(
            n_clusters=self.n_clusters,
            random_state=self.random_state,
            batch_size=max(int(chunk_size), self.n_clusters),
            n_init="auto",
        )
        for start in range(0, source.n_items, chunk_size):
            stop = min(source.n_items, start + chunk_size)
            model.partial_fit(np.asarray(source.read(start, stop), dtype=np.float32))

        out = np.lib.format.open_memmap(
            output_path, mode="w+", dtype=np.uint32, shape=(source.n_items,)
        )
        for start in range(0, source.n_items, chunk_size):
            stop = min(source.n_items, start + chunk_size)
            block = np.asarray(source.read(start, stop), dtype=np.float32)
            out[start:stop] = model.predict(block).astype(np.uint32, copy=False)
        out.flush()
        return out

    def metadata(self) -> dict:
        return {
            "method": self.name,
            "n_clusters": self.n_clusters,
            "random_state": self.random_state,
        }


################################################################################
if __name__=="__main__":
    pass
