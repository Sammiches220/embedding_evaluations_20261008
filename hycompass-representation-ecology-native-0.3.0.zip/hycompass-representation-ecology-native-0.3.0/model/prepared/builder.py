################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

##### Internal Imports #####
from model.clustering.base import ClusteringMethod
from model.projection.base import ProjectionMethod
from model.source.base import EmbeddingSource


################################################################################
# CLASSES
################################################################################
@dataclass(frozen=True)
class PrepareOptions:
    chunk_size: int = 250_000
    density_grid: int = 1024  # retained for API compatibility; density is built as a separate asset
    build_density: bool = False
    build_spatial_index: bool = True


class PreparedRepresentationBuilder:
    """Build one projection asset from a domain embedding source.

    Domain identity, selections, timelines, density, segmentation and exploration
    are intentionally *not* owned by this builder.  They are separate workspace
    assets cataloged by workspace.json.
    """

    def __init__(
        self,
        source: EmbeddingSource,
        projection: ProjectionMethod,
        output_dir: Path,
        *,
        clustering: ClusteringMethod | None = None,
        options: PrepareOptions | None = None,
    ) -> None:
        self.source = source
        self.projection = projection
        self.clustering = clustering
        self.output_dir = Path(output_dir)
        self.options = options or PrepareOptions()

    def build(
        self,
        *,
        cluster_path: Path | None = None,
        representation_id: str | None = None,
    ) -> Path:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        positions_path = self.output_dir / "positions.npy"
        positions = self.projection.project(
            self.source,
            positions_path,
            chunk_size=self.options.chunk_size,
        )
        bounds = self._bounds(positions)

        files: dict[str, str] = {"positions": "positions.npy"}
        if cluster_path is not None:
            self._copy_numeric_vector(
                cluster_path,
                "cluster.npy",
                expected_len=self.source.n_items,
                dtype=np.uint32,
            )
            files["cluster"] = "cluster.npy"
        elif self.clustering is not None:
            self.clustering.cluster(
                self.source,
                self.output_dir / "cluster.npy",
                chunk_size=self.options.chunk_size,
            )
            files["cluster"] = "cluster.npy"

        if self.options.build_spatial_index:
            x_order = np.argsort(np.asarray(positions[:, 0]), kind="stable").astype(np.uint32)
            x_sorted = np.asarray(positions[x_order, 0], dtype=np.float32)
            np.save(self.output_dir / "x_order.npy", x_order, allow_pickle=False)
            np.save(self.output_dir / "x_sorted.npy", x_sorted, allow_pickle=False)
            files["x_order"] = "x_order.npy"
            files["x_sorted"] = "x_sorted.npy"

        meta = {
            "format": "latent-observer-projection-asset",
            "version": 1,
            "world_bounds": [float(v) for v in bounds],
            "files": files,
            "projection": {
                "id": representation_id or self.output_dir.name,
                "source_items": self.source.n_items,
                "source_dimensions": self.source.dimensions,
                "source_dtype": str(self.source.dtype),
                "method": self.projection.metadata(),
            },
            "clustering": self.clustering.metadata() if self.clustering else None,
        }
        (self.output_dir / "metadata.json").write_text(json.dumps(meta, indent=2) + "\n")
        return self.output_dir

    def _copy_numeric_vector(
        self,
        source_path: Path,
        output_name: str,
        *,
        expected_len: int,
        dtype,
    ) -> np.ndarray:
        array = np.load(source_path, mmap_mode="r", allow_pickle=False)
        if array.ndim != 1 or len(array) != expected_len:
            raise ValueError(f"{source_path} must have shape [{expected_len}]")
        out = np.lib.format.open_memmap(
            self.output_dir / output_name,
            mode="w+",
            dtype=dtype,
            shape=(expected_len,),
        )
        for start in range(0, expected_len, self.options.chunk_size):
            stop = min(expected_len, start + self.options.chunk_size)
            out[start:stop] = np.asarray(array[start:stop], dtype=dtype)
        out.flush()
        return out

    @staticmethod
    def _bounds(positions: np.ndarray) -> tuple[float, float, float, float]:
        xmin = float(np.min(positions[:, 0]))
        xmax = float(np.max(positions[:, 0]))
        ymin = float(np.min(positions[:, 1]))
        ymax = float(np.max(positions[:, 1]))
        if xmax <= xmin:
            xmin, xmax = xmin - 0.5, xmax + 0.5
        if ymax <= ymin:
            ymin, ymax = ymin - 0.5, ymax + 0.5
        return xmin, xmax, ymin, ymax


################################################################################
if __name__=="__main__":
    pass
