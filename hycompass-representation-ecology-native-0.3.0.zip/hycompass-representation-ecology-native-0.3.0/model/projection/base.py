################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path
from typing import Protocol

import numpy as np

##### Internal Imports #####
from model.source.base import EmbeddingSource


################################################################################
# CLASSES
################################################################################
class ProjectionMethod(Protocol):
    name: str

    def project(
        self,
        source: EmbeddingSource,
        output_path: Path,
        *,
        chunk_size: int,
    ) -> np.memmap: ...

    def metadata(self) -> dict: ...


################################################################################
if __name__=="__main__":
    pass
