################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

import numpy as np

##### Internal Imports #####
from model.source.base import EmbeddingSource


################################################################################
# CLASSES
################################################################################
class IncrementalPCAProjection:
    name = "incremental_pca"

    def __init__(self, whiten: bool = False) -> None:
        self.whiten = bool(whiten)
        self._explained_variance_ratio: list[float] | None = None

    def project(self, source: EmbeddingSource, output_path: Path, *, chunk_size: int) -> np.memmap:
        try:
            from sklearn.decomposition import IncrementalPCA
        except ImportError as exc:
            raise RuntimeError(
                "Incremental PCA requires scikit-learn. Install it with: "
                "python -m pip install scikit-learn"
            ) from exc

        if source.dimensions < 2:
            raise ValueError("projection requires at least two source dimensions")
        if source.n_items < 2:
            raise ValueError("incremental PCA requires at least two items")

        batch = max(int(chunk_size), 2)
        model = IncrementalPCA(n_components=2, whiten=self.whiten, batch_size=batch)

        # partial_fit requires at least n_components rows in each batch. Merge a
        # tiny tail into the previous chunk by choosing boundaries explicitly.
        starts = list(range(0, source.n_items, batch))
        if len(starts) > 1 and source.n_items - starts[-1] < 2:
            starts.pop()
        for i, start in enumerate(starts):
            stop = starts[i + 1] if i + 1 < len(starts) else source.n_items
            block = np.asarray(source.read(start, stop), dtype=np.float32)
            model.partial_fit(block)

        out = np.lib.format.open_memmap(
            output_path, mode="w+", dtype=np.float32, shape=(source.n_items, 2)
        )
        for start in range(0, source.n_items, batch):
            stop = min(source.n_items, start + batch)
            block = np.asarray(source.read(start, stop), dtype=np.float32)
            out[start:stop] = model.transform(block).astype(np.float32, copy=False)
        out.flush()
        self._explained_variance_ratio = [float(x) for x in model.explained_variance_ratio_]
        return out

    def metadata(self) -> dict:
        result = {"method": self.name, "dimensions": 2, "whiten": self.whiten}
        if self._explained_variance_ratio is not None:
            result["explained_variance_ratio"] = self._explained_variance_ratio
        return result


################################################################################
if __name__=="__main__":
    pass
