from .base import ProjectionMethod
from .incremental_pca import IncrementalPCAProjection
from .passthrough import PassthroughProjection
from .random_projection import GaussianRandomProjection
from .tsne_projection import TSNEProjection
from .umap_projection import UMAPProjection

__all__ = [
    "ProjectionMethod",
    "IncrementalPCAProjection",
    "PassthroughProjection",
    "GaussianRandomProjection",
    "TSNEProjection",
    "UMAPProjection",
]
