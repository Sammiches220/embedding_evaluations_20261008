################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

import numpy as np

##### Internal Imports #####
from model.source.base import EmbeddingSource


################################################################################
# CLASSES
################################################################################
class PassthroughProjection:
    name = "passthrough"

    def project(self, source: EmbeddingSource, output_path: Path, *, chunk_size: int) -> np.memmap:
        if source.dimensions != 2:
            raise ValueError("passthrough projection requires an [N,2] source")
        out = np.lib.format.open_memmap(
            output_path, mode="w+", dtype=np.float32, shape=(source.n_items, 2)
        )
        for start in range(0, source.n_items, chunk_size):
            stop = min(source.n_items, start + chunk_size)
            out[start:stop] = source.read(start, stop).astype(np.float32, copy=False)
        out.flush()
        return out

    def metadata(self) -> dict:
        return {"method": self.name, "dimensions": 2}


################################################################################
if __name__=="__main__":
    pass
