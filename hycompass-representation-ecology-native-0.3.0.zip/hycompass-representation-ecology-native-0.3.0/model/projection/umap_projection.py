################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

import numpy as np

##### Internal Imports #####
from model.source.base import EmbeddingSource


################################################################################
# CLASSES
################################################################################
class UMAPProjection:
    """UMAP adapter intended for datasets that fit the selected UMAP workflow.

    Unlike IncrementalPCA, standard UMAP is not out-of-core. This adapter is
    therefore deliberately explicit about materializing the source matrix.
    """

    name = "umap"

    def __init__(
        self,
        n_neighbors: int = 15,
        min_dist: float = 0.1,
        metric: str = "cosine",
        random_state: int = 42,
    ) -> None:
        self.n_neighbors = int(n_neighbors)
        self.min_dist = float(min_dist)
        self.metric = str(metric)
        self.random_state = int(random_state)

    def project(self, source: EmbeddingSource, output_path: Path, *, chunk_size: int) -> np.memmap:
        try:
            import umap
        except ImportError as exc:
            raise RuntimeError(
                "UMAP projection requires umap-learn. Install it with: "
                "python -m pip install umap-learn"
            ) from exc
        matrix = np.asarray(source.read(0, source.n_items), dtype=np.float32)
        model = umap.UMAP(
            n_components=2,
            n_neighbors=self.n_neighbors,
            min_dist=self.min_dist,
            metric=self.metric,
            random_state=self.random_state,
        )
        projected = np.asarray(model.fit_transform(matrix), dtype=np.float32)
        out = np.lib.format.open_memmap(
            output_path, mode="w+", dtype=np.float32, shape=projected.shape
        )
        out[:] = projected
        out.flush()
        return out

    def metadata(self) -> dict:
        return {
            "method": self.name,
            "dimensions": 2,
            "n_neighbors": self.n_neighbors,
            "min_dist": self.min_dist,
            "metric": self.metric,
            "random_state": self.random_state,
        }


################################################################################
if __name__=="__main__":
    pass
