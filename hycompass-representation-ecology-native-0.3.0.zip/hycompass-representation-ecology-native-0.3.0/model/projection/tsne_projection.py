################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

import numpy as np

##### Internal Imports #####
from model.source.base import EmbeddingSource


################################################################################
# CLASSES
################################################################################
class TSNEProjection:
    """In-memory scikit-learn t-SNE projection.

    t-SNE is intentionally exposed as a modular example rather than a large-N
    default. It materializes the selected source matrix in RAM and is therefore
    best suited to smaller domains or subset-local projections.
    """

    name = "tsne"

    def __init__(
        self,
        *,
        perplexity: float = 30.0,
        max_iter: int = 750,
        metric: str = "euclidean",
        random_state: int = 42,
        learning_rate: str | float = "auto",
    ) -> None:
        self.perplexity = float(perplexity)
        self.max_iter = int(max_iter)
        self.metric = str(metric)
        self.random_state = int(random_state)
        self.learning_rate = learning_rate
        self._effective_perplexity: float | None = None

    def project(self, source: EmbeddingSource, output_path: Path, *, chunk_size: int) -> np.memmap:
        try:
            from sklearn.manifold import TSNE
        except ImportError as exc:
            raise RuntimeError("t-SNE projection requires scikit-learn") from exc
        if source.n_items < 3:
            raise ValueError("t-SNE requires at least three items")
        matrix = np.asarray(source.read(0, source.n_items), dtype=np.float32)
        perplexity = min(self.perplexity, max(1.0, (source.n_items - 1) / 3.0))
        model = TSNE(
            n_components=2,
            perplexity=perplexity,
            max_iter=max(250, self.max_iter),
            metric=self.metric,
            random_state=self.random_state,
            learning_rate=self.learning_rate,
            init="pca" if source.dimensions >= 2 else "random",
            method="barnes_hut",
        )
        projected = np.asarray(model.fit_transform(matrix), dtype=np.float32)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        out = np.lib.format.open_memmap(output_path, mode="w+", dtype=np.float32, shape=projected.shape)
        out[:] = projected
        out.flush()
        self._effective_perplexity = float(perplexity)
        return out

    def metadata(self) -> dict:
        return {
            "method": self.name,
            "dimensions": 2,
            "perplexity": self._effective_perplexity or self.perplexity,
            "max_iter": self.max_iter,
            "metric": self.metric,
            "random_state": self.random_state,
            "memory_model": "in-memory",
        }


################################################################################
if __name__=="__main__":
    pass
