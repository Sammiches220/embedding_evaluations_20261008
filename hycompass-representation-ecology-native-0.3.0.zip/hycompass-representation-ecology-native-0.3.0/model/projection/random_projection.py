################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pathlib import Path

import numpy as np

##### Internal Imports #####
from model.source.base import EmbeddingSource


################################################################################
# CLASSES
################################################################################
class GaussianRandomProjection:
    """Small example of a custom modular ProjectionMethod.

    This intentionally avoids fitting a model: a seeded Gaussian matrix maps the
    source dimensions directly to 2D in chunks. It is useful as a very fast
    baseline and, more importantly, demonstrates how additional projection
    implementations plug into the same ProjectionMethod protocol.
    """

    name = "gaussian_random_projection"

    def __init__(self, seed: int = 42) -> None:
        self.seed = int(seed)
        self._source_dimensions: int | None = None

    def project(self, source: EmbeddingSource, output_path: Path, *, chunk_size: int) -> np.memmap:
        if source.dimensions < 1 or source.n_items < 1:
            raise ValueError("random projection requires a non-empty [N,D] source")
        rng = np.random.default_rng(self.seed)
        # N(0,1/k) is the standard Gaussian random-projection scaling for k
        # target dimensions. Here k=2.
        matrix = rng.normal(0.0, 1.0 / np.sqrt(2.0), size=(source.dimensions, 2)).astype(np.float32)
        out = np.lib.format.open_memmap(output_path, mode="w+", dtype=np.float32, shape=(source.n_items, 2))
        chunk = max(1, int(chunk_size))
        for lo in range(0, source.n_items, chunk):
            hi = min(source.n_items, lo + chunk)
            block = np.asarray(source.read(lo, hi), dtype=np.float32)
            out[lo:hi] = block @ matrix
        out.flush()
        self._source_dimensions = int(source.dimensions)
        return out

    def metadata(self) -> dict:
        return {"method": self.name, "dimensions": 2, "seed": self.seed, "source_dimensions": self._source_dimensions}


################################################################################
if __name__=="__main__":
    pass
