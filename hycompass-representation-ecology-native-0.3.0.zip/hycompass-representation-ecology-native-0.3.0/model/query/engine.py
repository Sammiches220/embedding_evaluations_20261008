"""PointQuery evaluation against a loaded ``ViewData`` instance.

This module contains the implementation behind the historical
``model.query.PointQueryEngine`` public import. The accepted expression language
is unchanged; see ``docs_src/project/POINT_QUERIES.md`` for the complete JSON
language reference.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

import numpy as np

from .types import PointQueryExpression, QueryError


@dataclass(slots=True)
class _LogicalFrame:
    """State for one in-progress iterative ``and``/``or`` evaluation."""

    op: str
    args: list[Any]
    next_index: int = 0
    result: np.ndarray | None = None


@dataclass(slots=True)
class _NotFrame:
    """Marker applied after the child of a ``not`` expression is evaluated."""


class PointQueryEngine:
    """Evaluate application-native point predicates against a ``ViewData``.

    ``PointQueryEngine`` preserves the original dictionary-based JSON language
    and evaluates predicates over NumPy row arrays. Logical expression traversal
    is iterative rather than recursive so large/deep expression trees are not
    constrained by Python's function-recursion limit.

    The evaluator intentionally visits every logical child in the same
    left-to-right order as the previous recursive implementation. In particular,
    ``and`` and ``or`` do not skip later predicates merely because the current
    boolean result is already determined. This preserves validation/error
    behavior for later predicates.

    Args:
        view: Loaded view/data object exposing the same attributes used by the
            original implementation (positions, manifest/session access,
            timeline state, raster sampling helpers, and item IDs).

    Attributes:
        view: Query context supplied by the caller.
        session: Session owning the view.
        manifest: Workspace manifest from ``session``.
    """

    def __init__(self, view) -> None:
        self.view = view
        self.session = view.session
        self.manifest = self.session.manifest
        self._point_feature_cache: dict[tuple[str, str, float], np.ndarray] = {}
        self._domain_rows_cache: np.ndarray | None = None

    def query(
        self,
        expression: PointQueryExpression | None,
        *,
        candidate_rows: np.ndarray | None = None,
    ) -> np.ndarray:
        """Evaluate an expression and return matching domain rows.

        The no-expression forms ``None``, ``{}``, and ``{"op": "all"}``
        retain their historical special behavior: they return only rows with a
        finite projected position. Explicit logical ``{"op": "all"}`` inside a
        larger expression still evaluates to ``True`` for every candidate row,
        exactly as before.

        Args:
            expression: PointQuery expression, or one of the no-expression forms.
            candidate_rows: Optional domain rows to test. If omitted, every
                domain row is considered.

        Returns:
            ``uint32`` domain rows that satisfy the expression, preserving the
            incoming row order.

        Raises:
            QueryError: If the expression references an unsupported feature,
                comparison, or incompatible asset.
        """
        rows = (
            self._domain_rows()
            if candidate_rows is None
            else np.asarray(candidate_rows, dtype=np.uint32)
        )

        if expression in (None, {}, {"op": "all"}):
            return rows[np.isfinite(self.view.positions[rows]).all(axis=1)]

        mask = self._eval(expression, rows)
        return rows[np.asarray(mask, dtype=bool)]

    def _eval(self, expr: PointQueryExpression, rows: np.ndarray) -> np.ndarray:
        """Evaluate one expression without Python recursion.

        This is behaviorally equivalent to the former recursive evaluator. The
        explicit stack exists solely to remove recursion depth as an
        implementation limit for large expression trees.
        """
        stack: list[tuple[str, Any]] = [("eval", expr)]
        result: np.ndarray | None = None

        while stack:
            action, payload = stack.pop()

            if action == "logical":
                frame: _LogicalFrame = payload
                assert result is not None

                if frame.result is None:
                    frame.result = np.asarray(result, dtype=bool).copy()
                elif frame.op == "and":
                    frame.result &= result
                else:
                    frame.result |= result

                frame.next_index += 1
                if frame.next_index < len(frame.args):
                    stack.append(("logical", frame))
                    stack.append(("eval", frame.args[frame.next_index]))
                else:
                    result = frame.result
                continue

            if action == "not":
                assert result is not None
                result = ~result
                continue

            current = payload
            if not isinstance(current, dict):
                raise QueryError("query expression must be an object")

            op = str(current.get("op", "")).lower()

            if op == "all":
                result = np.ones(len(rows), dtype=bool)
                continue

            if op in {"and", "or"}:
                args = current.get("args", [])
                if not isinstance(args, list):
                    raise QueryError(f"{op}.args must be a list")

                if not args:
                    result = (
                        np.ones(len(rows), dtype=bool)
                        if op == "and"
                        else np.zeros(len(rows), dtype=bool)
                    )
                    continue

                frame = _LogicalFrame(op=op, args=args)
                stack.append(("logical", frame))
                stack.append(("eval", args[0]))
                continue

            if op == "not":
                stack.append(("not", _NotFrame()))
                stack.append(("eval", current.get("arg", {})))
                continue

            result = self._leaf(current, rows)

        assert result is not None
        return result

    def _leaf(self, expr: PointQueryExpression, rows: np.ndarray) -> np.ndarray:
        """Evaluate a non-logical PointQuery predicate."""
        feature = str(expr.get("feature", "")).lower()
        cmp = str(expr.get("cmp", "==")).lower()
        asset = expr.get("asset")

        if feature == "projected":
            finite = np.isfinite(self.view.positions[rows]).all(axis=1)
            return finite if cmp in {"finite", "==", "true"} else ~finite

        if feature == "selection":
            values = self.selection_values(str(asset) if asset else None, rows)
            return values if cmp in {"member", "==", "true"} else ~values

        if feature == "cluster":
            values = self.cluster_values(str(asset) if asset else None, rows)
            return self._compare(values, cmp, expr)

        if feature == "density":
            asset_id = str(asset)
            values = self.field_values("density", asset_id, rows)
            if "percentile" in expr:
                # Percentile predicates are properties of the density asset over
                # the whole projected population, not of whichever candidate
                # rows happened to be supplied by a lasso/picker. Cache-backed
                # full point sampling keeps click/lasso/API semantics identical.
                all_rows = self._domain_rows()
                global_values = self.field_values("density", asset_id, all_rows)
                finite = global_values[np.isfinite(global_values)]
                threshold = (
                    float(np.percentile(finite, float(expr["percentile"])))
                    if finite.size
                    else np.nan
                )
                resolved = dict(expr)
                resolved.pop("percentile", None)
                resolved["value"] = threshold
                return self._compare(values, cmp, resolved)
            return self._compare(values, cmp, expr)

        if feature == "segmentation":
            values = self.field_values("segmentation", str(asset), rows)
            return self._compare(values, cmp, expr)

        if feature == "exploration":
            threshold = float(
                expr.get("threshold", self.view.current_exploration_threshold)
            )
            values = self.field_values("exploration", str(asset), rows)
            if cmp == "inside":
                return values >= threshold
            if cmp == "outside":
                return values < threshold
            return self._compare(values, cmp, expr)

        if feature == "timeline":
            if self.view.normalized_timeline is None:
                return np.zeros(len(rows), dtype=bool)

            values = np.asarray(
                self.view.normalized_timeline[rows],
                dtype=np.float32,
            )
            current = float(expr.get("current", self.view.current_timeline))
            if cmp == "observed":
                return values <= current
            if cmp in {"future", "unobserved"}:
                return values > current
            return self._compare(values, cmp, expr)

        if feature == "row":
            return self._compare(rows.astype(np.int64), cmp, expr)

        raise QueryError(f"unsupported point feature: {feature!r}")

    @staticmethod
    def _compare(
        values: np.ndarray,
        cmp: str,
        expr: PointQueryExpression,
    ) -> np.ndarray:
        """Apply one supported PointQuery comparison to a value array."""
        if "percentile" in expr:
            p = float(expr["percentile"])
            finite = np.asarray(values)[np.isfinite(values)]
            value = float(np.percentile(finite, p)) if finite.size else np.nan
        else:
            value = expr.get("value")

        if cmp in {"in", "not in"}:
            vals = np.asarray(
                expr.get("values", value if isinstance(value, list) else [value])
            )
            result = np.isin(values, vals)
            return ~result if cmp == "not in" else result

        if value is None:
            raise QueryError(f"comparison {cmp!r} requires value or percentile")

        if cmp in {"==", "eq"}:
            return values == value
        if cmp in {"!=", "ne"}:
            return values != value
        if cmp in {">", "gt"}:
            return values > value
        if cmp in {">=", "ge"}:
            return values >= value
        if cmp in {"<", "lt"}:
            return values < value
        if cmp in {"<=", "le"}:
            return values <= value

        raise QueryError(f"unsupported comparison: {cmp!r}")

    def selection_values(
        self,
        asset_id: str | None,
        rows: np.ndarray,
    ) -> np.ndarray:
        """Return selection-membership values aligned to ``rows``."""
        if asset_id in (None, "", "active"):
            if self.view.selection_mask is None:
                return np.ones(len(rows), dtype=bool)
            return np.asarray(self.view.selection_mask[rows], dtype=bool)

        spec = self.manifest.selections.get(asset_id)
        if spec is None or spec.domain != self.view.domain_id:
            raise QueryError(f"unknown/incompatible selection {asset_id!r}")

        if spec.kind == "all":
            return np.ones(len(rows), dtype=bool)

        return np.asarray(self.session.array(spec.mask)[rows], dtype=bool)

    def cluster_values(
        self,
        asset_id: str | None,
        rows: np.ndarray,
    ) -> np.ndarray:
        """Return clustering labels aligned to ``rows``."""
        if asset_id in (None, "", "active"):
            if self.view.cluster is None:
                raise QueryError("no active clustering")
            return np.asarray(self.view.cluster[rows])

        spec = self.manifest.clusterings.get(asset_id)
        if spec is None or spec.domain != self.view.domain_id:
            raise QueryError(f"unknown/incompatible clustering {asset_id!r}")

        if spec.projection and spec.projection != self.view.projection_id:
            raise QueryError(f"clustering {asset_id!r} belongs to another projection")

        return np.asarray(self.session.array(spec.labels)[rows])

    def field_values(
        self,
        kind: str,
        asset_id: str,
        rows: np.ndarray,
    ) -> np.ndarray:
        """Return sampled density, segmentation, or exploration values."""
        if not asset_id:
            raise QueryError(f"{kind} predicate requires asset")

        if kind == "density":
            spec = self.manifest.densities.get(asset_id)
            if spec is None or spec.projection != self.view.projection_id:
                raise QueryError(f"unknown/incompatible density {asset_id!r}")
            grid = self.session.array(spec.field)
            return self._sample_grid(
                asset_id,
                grid,
                rows,
                frame=-1,
            ).astype(np.float32, copy=False)

        if kind == "segmentation":
            spec = self.manifest.segmentations.get(asset_id)
            if spec is None or spec.projection != self.view.projection_id:
                raise QueryError(f"unknown/incompatible segmentation {asset_id!r}")
            grid = self.session.array(spec.labels)
            return self._sample_grid(asset_id, grid, rows, frame=-1)

        if kind == "exploration":
            spec = self.manifest.explorations.get(asset_id)
            if spec is None or spec.projection != self.view.projection_id:
                raise QueryError(f"unknown/incompatible exploration {asset_id!r}")

            if spec.timeline is not None and spec.timeline != self.view.spec.timeline:
                raise QueryError(
                    f"exploration {asset_id!r} uses timeline {spec.timeline!r}; "
                    f"view uses {self.view.spec.timeline!r}"
                )

            frames = self.session.array(spec.frames)
            if frames.ndim == 2:
                grid = frames
                frame = 0
            else:
                progress = self.view.exploration_progress_for(
                    spec,
                    self.view.current_timeline,
                )
                frame = int(
                    np.clip(
                        round(progress * (frames.shape[0] - 1)),
                        0,
                        frames.shape[0] - 1,
                    )
                )
                grid = frames[frame]

            return self._sample_grid(
                asset_id,
                grid,
                rows,
                frame=frame,
            ).astype(np.float32, copy=False)

        raise QueryError(kind)

    def _sample_grid(
        self,
        asset_id: str,
        grid: np.ndarray,
        rows: np.ndarray,
        *,
        frame: int,
    ) -> np.ndarray:
        """Sample a raster at point positions, preserving historical caching."""
        # Keep the historical cache key exactly as-is. It is an implementation
        # detail, but changing it is outside the scope of a behavior-only refactor.
        key = (asset_id, str(grid.dtype), float(frame))
        full_domain = self._is_full_domain_rows(rows)

        if full_domain:
            hit = self._point_feature_cache.get(key)
            if hit is not None:
                return hit

        iy, ix, valid = self.view.grid_sample_safe(grid, rows)

        if np.issubdtype(grid.dtype, np.floating):
            out = np.full(len(rows), np.nan, dtype=grid.dtype)
        else:
            out = np.zeros(len(rows), dtype=grid.dtype)

        out[valid] = np.asarray(grid[iy[valid], ix[valid]])

        if full_domain:
            self._point_feature_cache[key] = out

        return out

    def resolve_rows(
        self,
        *,
        rows: Iterable[int] | None = None,
        item_ids: Iterable[str] | None = None,
    ) -> np.ndarray:
        """Resolve row numbers and/or item IDs while preserving input order.

        Args:
            rows: Domain-row numbers.
            item_ids: Stable item IDs to resolve by scanning the domain ID array.

        Returns:
            Deduplicated ``uint32`` rows in first-occurrence order.

        Raises:
            QueryError: If a row is outside the domain or an item ID is unknown.
        """
        pieces: list[np.ndarray] = []

        if rows is not None:
            arr = np.asarray(list(rows), dtype=np.int64)
            if np.any((arr < 0) | (arr >= self.view.n)):
                raise QueryError("row outside domain")
            pieces.append(arr.astype(np.uint32))

        if item_ids is not None:
            requested_ids = [str(x) for x in item_ids]
            wanted = set(requested_ids)
            found: dict[str, int] = {}

            # Avoid materializing an 8M-entry Python dict merely to resolve a
            # small external result set. Scan the mmap in chunks and stop once
            # every requested ID is found. API clients should retain domain rows
            # when possible for O(k) round-trips.
            ids = self.view.item_ids
            chunk = 500_000
            for lo in range(0, self.view.n, chunk):
                hi = min(self.view.n, lo + chunk)
                block = ids[lo:hi]
                for off, value in enumerate(block):
                    key = value.item() if isinstance(value, np.generic) else str(value)
                    if key in wanted and key not in found:
                        found[key] = lo + off
                if len(found) == len(wanted):
                    break

            missing = wanted.difference(found)
            if missing:
                sample = next(iter(missing))
                raise QueryError(f"unknown item_id {sample!r}")

            pieces.append(
                np.asarray([found[x] for x in requested_ids], dtype=np.uint32)
            )

        if not pieces:
            return np.empty(0, dtype=np.uint32)

        combined = np.concatenate(pieces).astype(np.uint32, copy=False)

        # Preserve external ordering: ordered result sets are a core API contract.
        # Deduplicate only later repeats, without np.unique()'s row sorting.
        _, first = np.unique(combined, return_index=True)
        return combined[np.sort(first)].astype(np.uint32, copy=False)

    def _domain_rows(self) -> np.ndarray:
        """Return a lazily cached ``0..N-1`` domain-row vector."""
        if self._domain_rows_cache is None:
            self._domain_rows_cache = np.arange(self.view.n, dtype=np.uint32)
        return self._domain_rows_cache

    def _is_full_domain_rows(self, rows: np.ndarray) -> bool:
        """Return whether ``rows`` exactly matches the full domain in order."""
        return len(rows) == self.view.n and np.array_equal(rows, self._domain_rows())
