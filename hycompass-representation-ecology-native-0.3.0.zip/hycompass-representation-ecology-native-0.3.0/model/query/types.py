"""Shared public types for the PointQuery subsystem."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, TypeAlias

import numpy as np


PointQueryExpression: TypeAlias = dict[str, Any]
"""JSON-friendly PointQuery expression object."""


class QueryError(ValueError):
    """Raised when a PointQuery or requested feature cannot be resolved."""


@dataclass(frozen=True)
class FeatureColumn:
    """Named NumPy-backed feature column.

    Attributes:
        name: Public feature name.
        values: Values aligned to the requested domain rows.
    """

    name: str
    values: np.ndarray
