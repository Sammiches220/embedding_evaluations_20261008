"""Documentation-facing names for the PointQuery and FeatureProvider languages.

The runtime deliberately continues to accept ordinary dictionaries and strings;
these constants exist only to keep documentation terminology centralized without
introducing a second parser or changing the wire representation.
"""

from __future__ import annotations


POINT_QUERY_GUIDE = "project/POINT_QUERIES.md#pointquery-language"
"""MkDocs source/anchor for the PointQuery JSON language reference."""

FEATURE_PROVIDER_GUIDE = "project/POINT_QUERIES.md#featureprovider-language"
"""MkDocs source/anchor for the FeatureProvider feature-name reference."""
