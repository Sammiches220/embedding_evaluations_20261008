"""Point-query evaluation and feature extraction.

The public API intentionally remains compatible with the former single
``model.query`` module. Existing imports continue to work::

    from model.query import FeatureProvider, PointQueryEngine, QueryError

Implementation details are split across focused modules so the query language,
evaluator, and feature-record provider can be documented independently without
changing the JSON wire language or runtime results.
"""

from __future__ import annotations

from .engine import PointQueryEngine
from .features import FeatureProvider
from .types import FeatureColumn, PointQueryExpression, QueryError

# Preserve the historical public module identity for introspection and pickling
# even though the implementations now live in submodules.
for _public_type in (QueryError, FeatureColumn, PointQueryEngine, FeatureProvider):
    _public_type.__module__ = __name__
    for _member in vars(_public_type).values():
        if callable(_member) and hasattr(_member, "__module__"):
            try:
                _member.__module__ = __name__
            except (AttributeError, TypeError):
                pass

del _member, _public_type

__all__ = [
    "FeatureColumn",
    "FeatureProvider",
    "PointQueryEngine",
    "PointQueryExpression",
    "QueryError",
]
