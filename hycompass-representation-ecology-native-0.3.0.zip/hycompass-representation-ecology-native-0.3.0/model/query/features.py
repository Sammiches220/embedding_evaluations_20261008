"""FeatureProvider implementation for API/external post-processing records."""

from __future__ import annotations

from typing import Any

import numpy as np

from .engine import PointQueryEngine
from .types import QueryError


_BUILTIN_FEATURES = frozenset({"position", "x", "y", "timeline", "row", "item_id"})
_FIELD_FEATURE_KINDS = frozenset({"density", "segmentation", "exploration"})


class FeatureProvider:
    """Expose Latent Observer-native features for external post-processing.

    Feature names retain the historical string language. Built-ins are
    ``position``, ``x``, ``y``, ``timeline``, ``row``, and ``item_id``. Asset
    features use ``kind:asset`` names such as ``cluster:hdbscan`` or
    ``density:global``.

    The public record shape is unchanged: every record always contains ``row``
    and ``item_id``; positional requests emit ``x`` and ``y``; timeline requests
    emit ``timestamp`` and ``observed_now``; asset-backed values are emitted
    under the exact requested feature string.

    Args:
        view: Loaded view/data object used to resolve rows and feature assets.
    """

    def __init__(self, view) -> None:
        self.view = view
        self.query_engine = PointQueryEngine(view)

    def records(
        self,
        rows: np.ndarray,
        features: list[str],
    ) -> list[dict[str, Any]]:
        """Build JSON-friendly feature records for domain rows.

        Args:
            rows: Domain rows to serialize.
            features: Requested feature names in the FeatureProvider feature
                language.

        Returns:
            Record dictionaries in the same order as ``rows``.

        Raises:
            QueryError: If a feature name is malformed, unsupported, or refers
                to an incompatible asset.
        """
        rows = np.asarray(rows, dtype=np.uint32)
        columns = self._resolve_columns(rows, features)

        include_position = any(
            feature in features for feature in ("position", "x", "y")
        )
        include_timeline = "timeline" in features

        records: list[dict[str, Any]] = []
        for i, row in enumerate(rows):
            r = int(row)
            rec: dict[str, Any] = {
                "row": r,
                "item_id": self.view.item_id(r),
            }

            if include_position:
                x = float(self.view.positions[r, 0])
                y = float(self.view.positions[r, 1])
                rec["x"] = x if np.isfinite(x) else None
                rec["y"] = y if np.isfinite(y) else None

            if include_timeline:
                rec["timestamp"] = self.view.row_timestamp(r)
                rec["observed_now"] = self.view.row_observed(
                    r,
                    self.view.current_timeline,
                )

            for name, column in columns.items():
                value = column[i]
                value = value.item() if isinstance(value, np.generic) else value
                if isinstance(value, float) and not np.isfinite(value):
                    value = None
                rec[name] = value

            records.append(rec)

        return records

    def _resolve_columns(
        self,
        rows: np.ndarray,
        features: list[str],
    ) -> dict[str, np.ndarray]:
        """Resolve non-built-in requested features into row-aligned arrays."""
        columns: dict[str, np.ndarray] = {}

        for feature in features:
            if feature in _BUILTIN_FEATURES:
                continue

            if ":" not in feature:
                raise QueryError(f"feature {feature!r} needs kind:asset")

            kind, asset = feature.split(":", 1)
            if kind == "source":
                from ecology.catalog import Catalog
                c=Catalog(self.view.session.manifest.root)
                domain=c.raw["domains"].get(self.view.domain_id)
                if domain is None or c.raw["features"].get(asset,{}).get("collection")!=domain["collection"]:raise QueryError("Source feature collection mismatch")
                canonical=c.maps(self.view.domain_id)[0][rows]
                values,known=c.feature(asset,canonical)
                column=values.astype(object);column[~known]=None;columns[feature]=column
            elif kind == "selection":
                columns[feature] = self.query_engine.selection_values(asset, rows)
            elif kind == "cluster":
                columns[feature] = self.query_engine.cluster_values(asset, rows)
            elif kind in _FIELD_FEATURE_KINDS:
                columns[feature] = self.query_engine.field_values(kind, asset, rows)
            else:
                raise QueryError(f"unsupported feature {feature!r}")

        return columns
