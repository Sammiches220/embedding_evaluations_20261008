"""Small FastAPI dependencies and context helpers."""

################################################################################
# MAIN
################################################################################

##### External Imports #####
from __future__ import annotations

from typing import Any

from fastapi import HTTPException, Request

from model.workspace import ViewSpec

##### Internal Imports #####
from .schemas.context import ApiContext


################################################################################
# FUNCTIONS
################################################################################
def get_session(request: Request) -> Any:
    """Return the workspace session attached to the application.

    Raises:
        HTTPException: If a data-dependent endpoint is called on a schema-only app.
    """
    session = getattr(request.app.state, "session", None)
    if session is None:
        raise HTTPException(503, "workspace session is not attached")
    return session


def get_runtime(request: Request) -> Any:
    """Return shared runtime state attached to the application.

    Raises:
        HTTPException: If a runtime-dependent endpoint is called on a schema-only app.
    """
    runtime = getattr(request.app.state, "runtime", None)
    if runtime is None:
        raise HTTPException(503, "runtime state is not attached")
    return runtime


def resolve_view(view_id: str, session: Any, runtime: Any) -> Any:
    """Build the live model view corresponding to a runtime view ID."""
    try:
        spec = runtime.spec(view_id)
    except KeyError:
        raise HTTPException(404, f"unknown runtime view {view_id!r}")
    try:
        view = session.build_view(spec)
        view.current_timeline = runtime.timelines.get(view_id, 0.5)
        return view
    except Exception as exc:
        raise HTTPException(400, f"unable to resolve view: {exc}") from exc


def resolve_api_context(payload: ApiContext, session: Any, runtime: Any) -> Any:
    """Resolve a live view or an ad-hoc domain/projection context.

    This preserves the original API behavior: a truthy ``view`` takes precedence;
    otherwise both ``domain`` and ``projection`` are required.
    """
    if payload.view:
        view = resolve_view(str(payload.view), session, runtime)
        if payload.timeline_progress is not None:
            view.current_timeline = float(payload.timeline_progress)
        return view

    domain = str(payload.domain or "")
    projection = str(payload.projection or "")
    if not domain or not projection:
        raise HTTPException(400, "provide either 'view' or both 'domain' and 'projection'")

    spec = ViewSpec(
        id="__api_context__",
        title="API context",
        domain=domain,
        projection=projection,
        selection=payload.selection,
        timeline=payload.timeline,
        playback_start=payload.playback_start,
        playback_end=payload.playback_end,
    )
    try:
        view = session.build_view(spec)
    except Exception as exc:
        raise HTTPException(400, f"unable to resolve API context: {exc}") from exc
    view.current_timeline = float(payload.timeline_progress if payload.timeline_progress is not None else 0.5)
    return view


def compatible_catalog(view: Any, session: Any) -> dict[str, Any]:
    """Return workspace assets compatible with an already-resolved model view."""
    manifest = session.manifest
    from ecology.catalog import Catalog
    c=Catalog(session.manifest.root); domain=c.raw["domains"].get(view.domain_id)
    return {
        "source_features": [k for k,f in c.raw["features"].items() if domain and f["collection"]==domain["collection"]],
        "domain": view.domain_id,
        "projection": view.projection_id,
        "timeline": view.spec.timeline,
        "selections": [x.id for x in manifest.compatible_selections(view.domain_id)],
        "clusterings": [x.id for x in manifest.compatible_clusterings(view.domain_id, view.projection_id)],
        "densities": [x.id for x in manifest.compatible_densities(view.projection_id)],
        "segmentations": [x.id for x in manifest.compatible_segmentations(view.projection_id)],
        "explorations": [x.id for x in manifest.compatible_explorations(view.projection_id, view.spec.timeline)],
        "builtins": ["position", "timeline", "row", "item_id"],
    }


################################################################################
if __name__=="__main__":
    pass
