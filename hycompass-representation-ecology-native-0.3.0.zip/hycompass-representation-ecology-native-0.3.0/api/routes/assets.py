"""Asset catalog, contracts and registration routes."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from typing import Any, Callable
from textwrap import dedent

from fastapi import APIRouter, Depends, HTTPException

##### Internal Imports #####
from model.workspace import (
    RegistrationError,
    register_clustering,
    register_density,
    register_domain,
    register_exploration,
    register_projection,
    register_segmentation,
    register_selection,
    register_timeline,
    spec_dict,
)

from ..dependencies import get_runtime, get_session
from ..schemas.assets import (
    AssetCatalogResponse,
    AssetRegistrationResponse,
    ClusteringRegistrationRequest,
    DensityRegistrationRequest,
    DomainRegistrationRequest,
    ExplorationRegistrationRequest,
    ProjectionRegistrationRequest,
    SegmentationRegistrationRequest,
    SelectionRegistrationRequest,
    TimelineRegistrationRequest,
)
from ..schemas.common import ErrorBody

##### Global Variables #####
router = APIRouter()

REGISTRATION_RESPONSES = {
    400: {"model": ErrorBody, "description": "Invalid registration request or asset contract violation."},
    409: {"model": ErrorBody, "description": "Asset already exists and replacement was not requested."},
}

################################################################################
# FUNCTIONS
################################################################################
def _registration_response(
    callable_: Callable[..., Any],
    *,
    session: Any,
    runtime: Any,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run one existing workspace registration function and emit its runtime event."""
    try:
        replacing = bool(kwargs.get("replace", False))
        spec = callable_(session.manifest, **kwargs)
        session.reload_manifest(clear_arrays=True)
        runtime.enqueue("reload", "*")
        asset_type = callable_.__name__.removeprefix("register_")
        projection_id = getattr(spec, "projection", None)
        domain_id = getattr(spec, "domain", None)
        if asset_type == "domain":
            domain_id = getattr(spec, "id", None)
        if domain_id is None and projection_id in session.manifest.projections:
            domain_id = session.manifest.projections[projection_id].domain
        runtime.workspace_changed(
            "asset.registered",
            {
                "asset_type": asset_type,
                "asset_id": getattr(spec, "id", None),
                "replace": replacing,
            },
            domain=domain_id,
            projection=projection_id,
        )
        return {"ok": True, "asset": spec_dict(spec)}
    except RegistrationError as exc:
        message = str(exc)
        status = 409 if "already exists" in message else 400
        raise HTTPException(status, message) from exc
    except (FileNotFoundError, OSError, ValueError) as exc:
        raise HTTPException(400, str(exc)) from exc


################################################################################
# API ROUTES
################################################################################
@router.get(
    "/assets/contracts",
    tags=["Assets"],
    response_model=dict[str, Any],
    summary="Get non-HTTP asset contracts",
    description=dedent(
        """
        Returns the canonical external-file contract summary, including NumPy
        shape, dtype, alignment, and storage rules used by external assets.

        External producers should use this endpoint when possible rather than
        hard-coding assumptions indefinitely.
        """
    ).strip(),
    operation_id="get_asset_contracts",
)
def get_asset_contracts() -> dict[str, Any]:
    """Return NumPy shape, dtype, alignment, and storage contracts."""
    return {
        "domain": {
            "files": {
                "embeddings": "real numeric [N,D] .npy",
                "item_ids": "non-object [N] .npy",
            },
            "alignment": "row i identifies the same item across every domain-aligned asset",
            "default_storage": "reference",
        },
        "projection": {
            "positions": "float32 [N,2] .npy; finite pair for projected rows, NaN pair for out-of-scope rows",
            "optional": ["selection", "world_bounds", "x_order/x_sorted"],
            "derived_when_omitted": ["world_bounds", "x_order/x_sorted spatial index"],
        },
        "clustering": {"labels": "non-negative integer [N] .npy"},
        "density": {
            "field": "real finite [H,W] .npy",
            "recommended_range": "[0,1]",
            "alignment": "projection world_bounds -> raster extent",
        },
        "segmentation": {
            "labels": "non-negative integer [H,W] .npy; 0 is background",
            "optional": ["stats JSON", "density", "selection"],
            "derived_when_omitted": ["basic stats/anchors/populations"],
            "alignment": "projection world_bounds -> raster extent",
        },
        "exploration": {
            "field": "real finite [H,W] (static) or [T,H,W] (temporal) .npy",
            "recommended_range": "[0,1]",
            "requires": ["projection", "selection"],
            "temporal_requires": "timeline",
        },
        "selection": {"mask": "bool/integer [N] .npy"},
        "timeline": {"timestamps": "integer UNIX seconds [N] .npy", "default_missing": -1},
        "registration_storage": {
            "copy": "validate and copy/cast into workspace-owned files",
            "reference": "validate and retain the supplied server-local file path",
        },
    }


@router.get(
    "/assets/catalog",
    tags=["Assets"],
    response_model=AssetCatalogResponse,
    summary="Get the asset catalog",
    operation_id="get_asset_catalog",
)
def asset_catalog(session=Depends(get_session)):
    """Return manifest specs grouped by asset type."""
    manifest = session.manifest
    return {
        "domains": {k: spec_dict(v) for k, v in manifest.domains.items()},
        "projections": {k: spec_dict(v) for k, v in manifest.projections.items()},
        "selections": {k: spec_dict(v) for k, v in manifest.selections.items()},
        "timelines": {k: spec_dict(v) for k, v in manifest.timelines.items()},
        "clusterings": {k: spec_dict(v) for k, v in manifest.clusterings.items()},
        "densities": {k: spec_dict(v) for k, v in manifest.densities.items()},
        "segmentations": {k: spec_dict(v) for k, v in manifest.segmentations.items()},
        "explorations": {k: spec_dict(v) for k, v in manifest.explorations.items()},
        "themes": {k: spec_dict(v) for k, v in manifest.themes.items()},
    }


@router.post(
    "/assets/domains/register",
    tags=["Assets"],
    response_model=AssetRegistrationResponse,
    summary="Register a domain",
    operation_id="register_domain_asset",
    responses=REGISTRATION_RESPONSES,
)
def register_external_domain(
    payload: DomainRegistrationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Register externally prepared domain embeddings and item IDs."""
    return _registration_response(
        register_domain,
        session=session,
        runtime=runtime,
        asset_id=str(payload.id or ""),
        embeddings_path=payload.embeddings_path or "",
        item_ids_path=payload.item_ids_path or "",
        version=int(payload.version),
        storage=str(payload.storage),
        replace=bool(payload.replace),
        metadata=dict(payload.metadata or {}),
        chunk_size=payload.normalized_chunk_size(),
    )


@router.post(
    "/assets/projections/register",
    tags=["Assets"],
    response_model=AssetRegistrationResponse,
    summary="Register a projection",
    operation_id="register_projection_asset",
    responses=REGISTRATION_RESPONSES,
)
def register_external_projection(
    payload: ProjectionRegistrationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Register a projection and optional prebuilt spatial-index assets."""
    return _registration_response(
        register_projection,
        session=session,
        runtime=runtime,
        asset_id=str(payload.id or ""),
        domain_id=str(payload.domain or ""),
        positions_path=payload.positions_path or "",
        selection_id=payload.selection,
        x_order_path=payload.x_order_path,
        x_sorted_path=payload.x_sorted_path,
        build_spatial_index=bool(payload.build_spatial_index),
        world_bounds=payload.world_bounds,
        method=str(payload.method),
        storage=str(payload.storage),
        replace=bool(payload.replace),
        metadata=dict(payload.metadata or {}),
        chunk_size=payload.normalized_chunk_size(),
    )


@router.post(
    "/assets/clusterings/register",
    tags=["Assets"],
    response_model=AssetRegistrationResponse,
    summary="Register a clustering",
    operation_id="register_clustering_asset",
    responses=REGISTRATION_RESPONSES,
)
def register_external_clustering(
    payload: ClusteringRegistrationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Register domain-aligned cluster labels."""
    return _registration_response(
        register_clustering,
        session=session,
        runtime=runtime,
        asset_id=str(payload.id or ""),
        domain_id=str(payload.domain or ""),
        labels_path=payload.labels_path or "",
        projection_id=payload.projection,
        selection_id=payload.selection,
        method=str(payload.method),
        storage=str(payload.storage),
        replace=bool(payload.replace),
        metadata=dict(payload.metadata or {}),
        chunk_size=payload.normalized_chunk_size(),
    )


@router.post(
    "/assets/densities/register",
    tags=["Assets"],
    response_model=AssetRegistrationResponse,
    summary="Register a density raster",
    operation_id="register_density_asset",
    responses=REGISTRATION_RESPONSES,
)
def register_external_density(
    payload: DensityRegistrationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Register a projection-aligned density field."""
    return _registration_response(
        register_density,
        session=session,
        runtime=runtime,
        asset_id=str(payload.id or ""),
        projection_id=str(payload.projection or ""),
        field_path=payload.field_path or "",
        selection_id=payload.selection,
        method=str(payload.method),
        storage=str(payload.storage),
        value_range=str(payload.value_range),
        replace=bool(payload.replace),
        metadata=dict(payload.metadata or {}),
        chunk_size=payload.normalized_chunk_size(),
    )


@router.post(
    "/assets/segmentations/register",
    tags=["Assets"],
    response_model=AssetRegistrationResponse,
    summary="Register a segmentation raster",
    operation_id="register_segmentation_asset",
    responses=REGISTRATION_RESPONSES,
)
def register_external_segmentation(
    payload: SegmentationRegistrationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Register a projection-aligned segmentation and optional stats."""
    return _registration_response(
        register_segmentation,
        session=session,
        runtime=runtime,
        asset_id=str(payload.id or ""),
        projection_id=str(payload.projection or ""),
        labels_path=payload.labels_path or "",
        stats_path=payload.stats_path,
        density_id=payload.density,
        selection_id=payload.selection,
        method=str(payload.method),
        storage=str(payload.storage),
        replace=bool(payload.replace),
        metadata=dict(payload.metadata or {}),
        chunk_size=payload.normalized_chunk_size(),
    )


@router.post(
    "/assets/explorations/register",
    tags=["Assets"],
    response_model=AssetRegistrationResponse,
    summary="Register an exploration field",
    operation_id="register_exploration_asset",
    responses=REGISTRATION_RESPONSES,
)
def register_external_exploration(
    payload: ExplorationRegistrationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Register a static or temporal projection-aligned exploration field."""
    return _registration_response(
        register_exploration,
        session=session,
        runtime=runtime,
        asset_id=str(payload.id or ""),
        projection_id=str(payload.projection or ""),
        selection_id=str(payload.selection or ""),
        frames_path=payload.frames_path or "",
        timeline_id=payload.timeline,
        timeline_start=payload.timeline_start,
        timeline_end=payload.timeline_end,
        method=str(payload.method),
        storage=str(payload.storage),
        value_range=str(payload.value_range),
        replace=bool(payload.replace),
        metadata=dict(payload.metadata or {}),
        chunk_size=payload.normalized_chunk_size(),
    )


@router.post(
    "/assets/selections/register",
    tags=["Assets"],
    response_model=AssetRegistrationResponse,
    summary="Register a selection mask",
    operation_id="register_selection_asset",
    responses=REGISTRATION_RESPONSES,
)
def register_external_selection(
    payload: SelectionRegistrationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Register a domain-aligned selection mask."""
    return _registration_response(
        register_selection,
        session=session,
        runtime=runtime,
        asset_id=str(payload.id or ""),
        domain_id=str(payload.domain or ""),
        mask_path=payload.mask_path or "",
        source=payload.source,
        storage=str(payload.storage),
        replace=bool(payload.replace),
        metadata=dict(payload.metadata or {}),
        chunk_size=payload.normalized_chunk_size(),
    )


@router.post(
    "/assets/timelines/register",
    tags=["Assets"],
    response_model=AssetRegistrationResponse,
    summary="Register a timeline",
    operation_id="register_timeline_asset",
    responses=REGISTRATION_RESPONSES,
)
def register_external_timeline(
    payload: TimelineRegistrationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Register domain-aligned UNIX timestamps."""
    return _registration_response(
        register_timeline,
        session=session,
        runtime=runtime,
        asset_id=str(payload.id or ""),
        domain_id=str(payload.domain or ""),
        timestamps_path=payload.timestamps_path or "",
        missing_value=int(payload.missing_value),
        storage=str(payload.storage),
        replace=bool(payload.replace),
        metadata=dict(payload.metadata or {}),
        chunk_size=payload.normalized_chunk_size(),
    )


################################################################################
if __name__=="__main__":
    pass
