"""Canonical correspondence and saved-exploration endpoints. Computation uses CLI/GUI worker."""
from typing import Literal
import numpy as np
from fastapi import APIRouter,Depends,HTTPException
from pydantic import BaseModel,Field,ConfigDict
from ..dependencies import get_session
from ecology.catalog import Catalog,clean
from ecology.store import Store
from ecology.instruments import plan
from ecology.comparison import compare

router=APIRouter(prefix='/ecology',tags=['Representation ecology'])

class CorrespondenceRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    source_domain:str
    target_domain:str
    rows:list[int]=Field(max_length=100000)

class DefineRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    title:str
    domain:str
    collection_rows:list[int]=Field(min_length=1,max_length=100000)
    settings:dict=Field(default_factory=dict)

class FeatureRequest(BaseModel):
    collection:str
    collection_rows:list[int]=Field(max_length=10000)
    features:list[str]=Field(max_length=16)

@router.get('/catalog')
def catalog(session=Depends(get_session)):
    c=Catalog(session.manifest.root)
    return c.raw

@router.post('/correspondence')
def correspondence(payload:CorrespondenceRequest,session=Depends(get_session)):
    c=Catalog(session.manifest.root)
    try:
        if c.raw['domains'][payload.source_domain]['collection']!=c.raw['domains'][payload.target_domain]['collection']:raise ValueError('Domains belong to different collections')
        canonical=c.to_collection(payload.source_domain,np.asarray(payload.rows,dtype=np.int64));present,rows=c.to_domain(payload.target_domain,canonical)
        ids=c.load(c.collection(c.raw['domains'][payload.source_domain]['collection'])['item_ids'])[present]
        return clean(dict(collection_rows=present,domain_rows=rows,item_ids=ids,missing=len(canonical)-len(present)))
    except (KeyError,ValueError) as exc:raise HTTPException(400,str(exc))

@router.post('/features')
def features(payload:FeatureRequest,session=Depends(get_session)):
    from ecology.catalog import rows_checked
    c=Catalog(session.manifest.root)
    try:
        rows=rows_checked(np.asarray(payload.collection_rows,np.int64),c.n(payload.collection));ids=c.load(c.collection(payload.collection)['item_ids'])[rows];columns={}
        for f in payload.features:
            if c.raw['features'][f]['collection']!=payload.collection:raise ValueError('Feature collection mismatch')
            v,known=c.feature(f,rows);columns[f]=[x.item() if k else None for x,k in zip(v,known)]
        return clean(dict(collection_rows=rows,item_ids=ids,columns=columns))
    except (KeyError,ValueError) as exc:raise HTTPException(400,str(exc))

@router.get('/explorations')
def explorations(session=Depends(get_session)):
    return Store(session.manifest.root).definitions()

@router.post('/explorations')
def define(payload:DefineRequest,session=Depends(get_session)):
    try:return Store(session.manifest.root).create(payload.title,payload.domain,np.asarray(payload.collection_rows,np.int64),payload.settings)
    except (KeyError,ValueError) as exc:raise HTTPException(400,str(exc))

@router.get('/explorations/{key}')
def status(key:str,session=Depends(get_session)):
    try:
        store=Store(session.manifest.root);return dict(definition=store.validate(key),instruments=store.status(key),disk_bytes=store.disk_bytes(key))
    except (KeyError,ValueError,FileNotFoundError) as exc:raise HTTPException(400,str(exc))

@router.get('/explorations/{key}/plan')
def estimate(key:str,instrument:str='geometry',session=Depends(get_session)):
    try:return plan(Store(session.manifest.root),key,[instrument])
    except (KeyError,ValueError,FileNotFoundError) as exc:raise HTTPException(400,str(exc))

@router.get('/compare')
def comparison(a:str,b:str,instrument:str='geometry',session=Depends(get_session)):
    try:return clean(compare(Store(session.manifest.root),a,b,instrument))
    except (KeyError,ValueError,FileNotFoundError) as exc:raise HTTPException(400,str(exc))
