"""Saved-query, saved-view and workspace-reload routes."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations
from typing_extensions import runtime

from fastapi import APIRouter, Depends, HTTPException
from requests import session

from textwrap import dedent

##### Internal Imports #####
from model.workspace import SavedQuerySpec

from ..dependencies import get_runtime, get_session
from ..schemas.common import ErrorBody, OkResponse
from ..schemas.saved import (
    IdResponse,
    SavedQueryCreate,
    SavedQueryResponse,
    SavedViewResponse,
)
from ..schemas.views import OkRevisionResponse

##### Global Variables #####
router = APIRouter()


################################################################################
# API ROUTES
################################################################################
@router.get(
    "/saved-queries",
    tags=["Saved Queries"],
    response_model=list[SavedQueryResponse],
    summary="List saved queries",
    operation_id="list_saved_queries",
)
def saved_queries(session=Depends(get_session)):
    """Return saved query definitions from the manifest."""
    return [
        {
            "id": query.id,
            "title": query.title or query.id,
            "folder": query.folder,
            "domain": query.domain,
            "projection": query.projection,
            "query": query.query,
        }
        for query in session.manifest.saved_queries.values()
    ]


@router.post(
    "/saved-queries",
    tags=["Saved Queries"],
    response_model=IdResponse,
    summary="Save or replace a query",
    operation_id="save_query",
    responses={400: {"model": ErrorBody, "description": "Missing ID or invalid domain."}},
)
def save_query(
    payload: SavedQueryCreate,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Save a query using the same overwrite behavior as the current manifest API."""
    query_id = str(payload.id or "")
    domain = str(payload.domain or "")
    projection = payload.projection
    if not query_id or domain not in session.manifest.domains:
        raise HTTPException(400, "id and valid domain required")
    session.manifest.saved_queries[query_id] = SavedQuerySpec(
        id=query_id,
        title=payload.title or query_id,
        folder=str(payload.folder or ""),
        domain=domain,
        projection=projection,
        query=dict(payload.query or {}),
        metadata=dict(payload.metadata or {}),
    )
    session.manifest.save()
    session.reload_manifest()
    runtime.workspace_changed(
        "saved_query.changed",
        {"action": "saved", "query_id": query_id},
        domain=domain,
        projection=projection,
    )
    return {"id": query_id}


@router.delete(
    "/saved-queries/{query_id}",
    tags=["Saved Queries"],
    response_model=OkResponse,
    summary="Delete a saved query",
    operation_id="delete_saved_query",
    responses={404: {"model": ErrorBody, "description": "Saved query not found."}},
)
def delete_saved_query(
    query_id: str,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Delete a saved query and publish the manifest change."""
    if not session.manifest.delete_saved_query(query_id):
        raise HTTPException(404, "unknown saved query")
    session.manifest.save()
    session.reload_manifest()
    runtime.workspace_changed("saved_query.changed", {"action": "deleted", "query_id": query_id})
    return {"ok": True}


@router.get(
    "/saved-views",
    tags=["Saved Views"],
    response_model=list[SavedViewResponse],
    summary="List saved views",
    operation_id="list_saved_views",
)
def saved_views(session=Depends(get_session)):
    """Return the stable public fields of saved view specs."""
    return [
        {
            "id": view.id,
            "title": view.title,
            "folder": view.folder,
            "domain": view.domain,
            "projection": view.projection,
        }
        for view in session.manifest.views
    ]


@router.delete(
    "/saved-views/{view_id}",
    tags=["Saved Views"],
    response_model=OkResponse,
    summary="Delete a saved view",
    operation_id="delete_saved_view",
    responses={404: {"model": ErrorBody, "description": "Saved view not found."}},
)
def delete_saved_view(
    view_id: str,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Delete a saved view and publish the manifest change."""
    if not session.manifest.delete_view(view_id):
        raise HTTPException(404, "unknown saved view")
    session.manifest.save()
    runtime.workspace_changed("saved_view.changed", {"action": "deleted", "view_id": view_id})
    return {"ok": True}


@router.post(
    "/workspace/reload",
    tags=["Workspace"],
    response_model=OkRevisionResponse,
    summary="Reload the workspace manifest",
    description=dedent(
        """
        Reloads manifest-backed assets, requests a GUI reload, and publishes a
        workspace revision.

        Use this endpoint after externally modifying already registered files
        or catalog state outside the registration endpoints.

        Registration endpoints already trigger a reload automatically.

        The runtime versions shared GPU resource cache keys using file size and
        modification time. Therefore, an explicit reload does not intentionally
        reuse stale buffers or textures merely because the file path is unchanged.
        """
    ).strip(),
    operation_id="reload_workspace",
)
def reload_workspace(
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Reload the workspace and notify the runtime of the change."""
    session.reload_manifest(clear_arrays=True)
    runtime.enqueue("reload", "*")
    revision = runtime.workspace_changed("workspace.reloaded", {"cause": "api"})
    return {"ok": True, "revision": revision}


################################################################################
if __name__=="__main__":
    pass
