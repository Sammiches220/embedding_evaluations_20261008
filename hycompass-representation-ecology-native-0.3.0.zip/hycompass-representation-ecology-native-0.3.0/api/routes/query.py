"""Point query and feature routes."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

##### Internal Imports #####
from model.query.engine import PointQueryEngine
from model.query.types import QueryError
from model.query.features import FeatureProvider

from ..dependencies import (
    compatible_catalog,
    get_runtime,
    get_session,
    resolve_api_context,
)
from ..schemas.common import ErrorBody
from ..schemas.query import (
    FeatureCatalogRequest,
    FeatureCatalogResponse,
    FeatureRecordEnvelope,
    ItemFeaturesRequest,
    QueryFeaturesRequest,
    QueryFeaturesResponse,
    QueryRequest,
    QueryResponse,
)

##### Global Variables #####
router = APIRouter(
    responses={400: {"model": ErrorBody, "description": "Invalid API context, query, item selector, or typed request body."}}
)

################################################################################
# API ROUTES
################################################################################
@router.post(
    "/query",
    tags=["Query"],
    response_model=QueryResponse,
    summary="Query point rows",
    operation_id="query_points",
)
def query_points(
    payload: QueryRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Execute a structured point query and return a paginated row snapshot."""
    view = resolve_api_context(payload, session, runtime)
    try:
        rows = PointQueryEngine(view).query(payload.where)
    except QueryError as exc:
        raise HTTPException(400, str(exc)) from exc
    offset, limit = payload.normalized_page()
    page = rows[offset:offset + limit]
    return {
        "total": int(len(rows)),
        "offset": offset,
        "rows": [int(x) for x in page],
        "item_ids": [view.item_id(int(x)) for x in page],
        "next_offset": offset + len(page) if offset + len(page) < len(rows) else None,
    }


@router.post(
    "/items/features",
    tags=["Features"],
    response_model=FeatureRecordEnvelope,
    summary="Get features for selected items",
    operation_id="get_item_features",
)
def item_features(
    payload: ItemFeaturesRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Return dynamic FeatureProvider records while preserving the current wire shape."""
    view = resolve_api_context(payload, session, runtime)
    engine = PointQueryEngine(view)
    try:
        if payload.where is not None and payload.rows is None and payload.item_ids is None:
            rows = engine.query(payload.where)
            offset, limit = payload.normalized_page()
            rows = rows[offset:offset + limit]
        else:
            rows = engine.resolve_rows(rows=payload.rows, item_ids=payload.item_ids)
        if len(rows) > 10_000:
            raise QueryError("features endpoint is limited to 10,000 items per request")
        return {"items": FeatureProvider(view).records(rows, payload.requested_features())}
    except QueryError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.post(
    "/features/catalog",
    tags=["Features"],
    response_model=FeatureCatalogResponse,
    summary="Get compatible feature catalog",
    operation_id="get_feature_catalog",
)
def feature_catalog(
    payload: FeatureCatalogRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Return built-in and workspace-backed features compatible with a context."""
    return compatible_catalog(resolve_api_context(payload, session, runtime), session)


@router.post(
    "/query/features",
    tags=["Query", "Features"],
    response_model=QueryFeaturesResponse,
    summary="Query points and return features",
    operation_id="query_features",
)
def query_features(
    payload: QueryFeaturesRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Execute a point query and return paginated dynamic feature records."""
    view = resolve_api_context(payload, session, runtime)
    engine = PointQueryEngine(view)
    try:
        rows = engine.query(payload.where)
        total = int(len(rows))
        offset, limit = payload.normalized_page()
        page = rows[offset:offset + limit]
        items = FeatureProvider(view).records(page, payload.requested_features())
    except QueryError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {
        "total": total,
        "offset": offset,
        "items": items,
        "next_offset": offset + len(page) if offset + len(page) < total else None,
    }

################################################################################
if __name__=="__main__":
    pass