"""System and workspace routes."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from fastapi import APIRouter, Depends

##### Internal Imports #####
from ..dependencies import get_runtime, get_session
from ..schemas.system import HealthResponse, WorkspaceResponse
from ..schemas.views import GlobalStateResponse

##### Global Variables #####
router = APIRouter()


################################################################################
# API ROUTES
################################################################################
@router.get(
    "/health",
    tags=["System"],
    response_model=HealthResponse,
    summary="Health check",
    operation_id="get_health",
)
def health() -> dict[str, object]:
    """Return API health and the public API version."""
    return {"ok": True, "version": "0.5.4"}


@router.get(
    "/state",
    tags=["System"],
    response_model=GlobalStateResponse,
    summary="Get global runtime state",
    operation_id="get_runtime_state",
)
def runtime_state(runtime=Depends(get_runtime)):
    """Return the cheap global runtime snapshot."""
    return runtime.global_state()


@router.get(
    "/workspace",
    tags=["Workspace"],
    response_model=WorkspaceResponse,
    summary="List workspace asset identifiers",
    operation_id="get_workspace",
)
def workspace(session=Depends(get_session)) -> dict[str, list[str]]:
    """Return top-level identifiers currently present in the workspace manifest."""
    manifest = session.manifest
    return {
        "domains": list(manifest.domains),
        "projections": list(manifest.projections),
        "selections": list(manifest.selections),
        "timelines": list(manifest.timelines),
        "clusterings": list(manifest.clusterings),
        "densities": list(manifest.densities),
        "segmentations": list(manifest.segmentations),
        "explorations": list(manifest.explorations),
        "saved_queries": list(manifest.saved_queries),
        "themes": list(manifest.themes),
    }


################################################################################
if __name__=="__main__":
    pass
