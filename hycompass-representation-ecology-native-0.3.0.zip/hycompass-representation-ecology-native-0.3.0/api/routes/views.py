"""Runtime view state, selections, highlights, focus, fit and visibility routes."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import numpy as np
from fastapi import APIRouter, Depends, HTTPException, Query

from textwrap import dedent

##### Internal Imports #####
from model.query.engine import PointQueryEngine
from model.query.types import QueryError
from model.query.features import FeatureProvider

from ..dependencies import get_runtime, get_session, resolve_view
from ..runtime import ResultSet
from ..schemas.common import CountResponse, CountRevisionResponse
from ..schemas.views import (
    ActiveViewStateResponse,
    FocusRequest,
    FocusResponse,
    OkRevisionResponse,
    PredicateStateResponse,
    ResultSetRequest,
    ResultSetResponse,
    RuntimeViewSummary,
    SelectionMutationRequest,
    ViewStateResponse,
    VisibilityRequest,
    VisibilityResponse,
    WorkingSelectionDeltaResponse,
    WorkingSelectionFeaturesRequest,
    WorkingSelectionFeaturesResponse,
    WorkingSelectionPage,
    WorkingSelectionStateResponse,
)

##### Global Variables #####
router = APIRouter()


################################################################################
# FUNCTIONS
################################################################################
def _combine(current: np.ndarray, incoming: np.ndarray, mode: str) -> np.ndarray:
    """Combine row arrays with the exact legacy mutation semantics."""
    current = np.asarray(current, dtype=np.uint32)
    incoming = np.asarray(incoming, dtype=np.uint32)
    if mode == "add":
        return np.union1d(current, incoming).astype(np.uint32)
    if mode == "subtract":
        return np.setdiff1d(current, incoming, assume_unique=False).astype(np.uint32)
    if mode == "intersect":
        return np.intersect1d(current, incoming, assume_unique=False).astype(np.uint32)
    return np.unique(incoming).astype(np.uint32)


################################################################################
# API ROUTES
################################################################################
@router.get(
    "/active-view/state",
    tags=["Views"],
    response_model=ActiveViewStateResponse,
    summary="Get active view state",
    operation_id="get_active_view_state",
)
def active_view_state(runtime=Depends(get_runtime)):
    """Return active-view identity plus the active-view/event revisions."""
    state = runtime.global_state()
    return {
        "revision": state["active_view_revision"],
        "active_view": state["active_view"],
        "head_event_id": state["head_event_id"],
    }


@router.get(
    "/views",
    tags=["Views"],
    response_model=list[RuntimeViewSummary],
    summary="List runtime views",
    operation_id="list_runtime_views",
)
def views(runtime=Depends(get_runtime)):
    """List views currently registered with the shared runtime."""
    with runtime.lock:
        return [
            {"id": spec.id, "title": spec.title, "domain": spec.domain, "projection": spec.projection}
            for spec in runtime.views.values()
        ]


@router.get(
    "/views/{view_id}/state",
    tags=["Views"],
    response_model=ViewStateResponse,
    summary="Get runtime view state",
    operation_id="get_view_state",
)
def view_state(view_id: str, runtime=Depends(get_runtime)):
    """Return a cheap revision/count snapshot for one runtime view."""
    try:
        return runtime.view_state(view_id)
    except KeyError as exc:
        raise HTTPException(404, f"unknown runtime view {view_id!r}") from exc


@router.get(
    "/views/{view_id}/working-selection/state",
    tags=["Views"],
    response_model=WorkingSelectionStateResponse,
    summary="Get working-selection state",
    operation_id="get_working_selection_state",
)
def working_selection_state(view_id: str, runtime=Depends(get_runtime)):
    """Return revision metadata for the working selection without returning rows."""
    try:
        runtime.spec(view_id)
    except KeyError as exc:
        raise HTTPException(404, f"unknown runtime view {view_id!r}") from exc
    return runtime.working_state(view_id)


@router.get(
    "/views/{view_id}/working-selection/delta",
    tags=["Views"],
    response_model=WorkingSelectionDeltaResponse,
    response_model_exclude_none=True,
    summary="Get a working-selection delta",
    operation_id="get_working_selection_delta",
)
def working_selection_delta(
    view_id: str,
    since_revision: int = Query(..., ge=0),
    max_items: int = Query(10_000, ge=1, le=10_000),
    include_item_ids: bool = Query(False),
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Return a composed delta when history is available, otherwise request a snapshot."""
    try:
        runtime.spec(view_id)
    except KeyError as exc:
        raise HTTPException(404, f"unknown runtime view {view_id!r}") from exc
    result = runtime.working_delta(view_id, since_revision, max_items=max_items)
    if include_item_ids and not result.get("snapshot_required"):
        view = resolve_view(view_id, session, runtime)
        result["added_item_ids"] = [view.item_id(int(x)) for x in result.get("added_rows", [])]
        result["removed_item_ids"] = [view.item_id(int(x)) for x in result.get("removed_rows", [])]
    return result


@router.get(
    "/views/{view_id}/predicate/state",
    tags=["Views"],
    response_model=PredicateStateResponse,
    summary="Get point-predicate state",
    operation_id="get_predicate_state",
)
def predicate_state(view_id: str, runtime=Depends(get_runtime)):
    """Return the current point predicate and its source metadata."""
    try:
        runtime.spec(view_id)
    except KeyError as exc:
        raise HTTPException(404, f"unknown runtime view {view_id!r}") from exc
    return runtime.predicate_state(view_id)


@router.get(
    "/views/{view_id}/working-selection",
    tags=["Views"],
    response_model=WorkingSelectionPage,
    summary="Page through a working-selection snapshot",
    operation_id="get_working_selection",
)
def working_selection(
    view_id: str,
    offset: int = Query(0, ge=0),
    limit: int = Query(1000, ge=1, le=10_000),
    revision: int | None = Query(None, ge=0),
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Return one stable page of working-selection rows and item IDs."""
    view = resolve_view(view_id, session, runtime)
    with runtime.lock:
        runtime._ensure_view_state_locked(view_id)
        current_revision = runtime._revisions[view_id]["working_selection"]
        if revision is not None and int(revision) != current_revision:
            raise HTTPException(
                409,
                detail={
                    "message": "working selection changed; restart snapshot",
                    "requested_revision": int(revision),
                    "current_revision": current_revision,
                },
            )
        rows = runtime.working.get(view_id, np.empty(0, np.uint32)).copy()
    page = rows[offset:offset + limit]
    return {
        "revision": current_revision,
        "total": int(len(rows)),
        "offset": offset,
        "rows": [int(x) for x in page],
        "item_ids": [view.item_id(int(x)) for x in page],
        "next_offset": offset + len(page) if offset + len(page) < len(rows) else None,
    }


@router.post(
    "/views/{view_id}/working-selection/features",
    tags=["Views", "Features"],
    response_model=WorkingSelectionFeaturesResponse,
    summary="Get features for a working-selection snapshot",
    operation_id="get_working_selection_features",
)
def working_selection_features(
    view_id: str,
    payload: WorkingSelectionFeaturesRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Return feature records from a revision-checked working-selection snapshot."""
    view = resolve_view(view_id, session, runtime)
    with runtime.lock:
        runtime._ensure_view_state_locked(view_id)
        selection_revision = runtime._revisions[view_id]["working_selection"]
        if payload.revision is not None and int(payload.revision) != selection_revision:
            raise HTTPException(
                409,
                detail={
                    "message": "working selection changed; restart feature snapshot",
                    "requested_revision": int(payload.revision),
                    "current_revision": selection_revision,
                },
            )
        rows = runtime.working.get(view_id, np.empty(0, np.uint32)).copy()
    offset, limit = payload.normalized_page()
    page = rows[offset:offset + limit]
    try:
        items = FeatureProvider(view).records(page, payload.requested_features())
    except QueryError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {
        "revision": selection_revision,
        "total": int(len(rows)),
        "offset": offset,
        "items": items,
        "next_offset": offset + len(page) if offset + len(page) < len(rows) else None,
    }


@router.post(
    "/views/{view_id}/working-selection",
    tags=["Views"],
    response_model=CountRevisionResponse,
    summary="Mutate the working selection",
    operation_id="set_working_selection",
)
def set_working_selection(
    view_id: str,
    payload: SelectionMutationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Resolve incoming items, combine them with the working selection and notify the GUI."""
    view = resolve_view(view_id, session, runtime)
    engine = PointQueryEngine(view)
    try:
        incoming = engine.resolve_rows(rows=payload.rows, item_ids=payload.item_ids)
    except QueryError as exc:
        raise HTTPException(400, str(exc)) from exc
    with runtime.lock:
        current = runtime.working.get(view_id, np.empty(0, np.uint32))
    rows = _combine(current, incoming, str(payload.mode))
    revision = runtime.set_working(view_id, rows, cause="api")
    runtime.enqueue("working", view_id, rows=rows)
    return {"count": int(len(rows)), "revision": revision}


@router.delete(
    "/views/{view_id}/working-selection",
    tags=["Views"],
    response_model=CountRevisionResponse,
    summary="Clear the working selection",
    operation_id="clear_working_selection",
)
def clear_working_selection(
    view_id: str,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Clear the working selection and enqueue the corresponding GUI action."""
    resolve_view(view_id, session, runtime)
    rows = np.empty(0, np.uint32)
    revision = runtime.set_working(view_id, rows, cause="api_clear")
    runtime.enqueue("working", view_id, rows=rows)
    return {"count": 0, "revision": revision}


@router.post(
    "/views/{view_id}/highlights",
    tags=["Views"],
    response_model=CountRevisionResponse,
    summary="Set highlighted items",
    operation_id="set_highlights",
)
def set_highlights(
    view_id: str,
    payload: SelectionMutationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Resolve rows/item IDs and replace the highlighted-row set."""
    view = resolve_view(view_id, session, runtime)
    engine = PointQueryEngine(view)
    try:
        rows = engine.resolve_rows(rows=payload.rows, item_ids=payload.item_ids)
    except QueryError as exc:
        raise HTTPException(400, str(exc)) from exc
    revision = runtime.set_highlights(view_id, rows, cause="api")
    runtime.enqueue("highlights", view_id, rows=rows)
    return {"count": int(len(rows)), "revision": revision}


@router.delete(
    "/views/{view_id}/highlights",
    tags=["Views"],
    response_model=CountRevisionResponse,
    summary="Clear highlighted items",
    operation_id="clear_highlights",
)
def clear_highlights(
    view_id: str,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Clear highlights and notify the GUI bridge."""
    resolve_view(view_id, session, runtime)
    rows = np.empty(0, np.uint32)
    revision = runtime.set_highlights(view_id, rows, cause="api_clear")
    runtime.enqueue("highlights", view_id, rows=rows)
    return {"count": 0, "revision": revision}


@router.post(
    "/views/{view_id}/result-sets/{result_id}",
    tags=["Views"],
    response_model=ResultSetResponse,
    summary="Store a result set",
    description=dedent(
        """
        Stores a revisioned result set for the specified view and optionally
        highlights its rows.

        Result-set order is preserved, making result sets suitable for ranked
        or otherwise ordered query results. Optional scores, labels, and
        metadata are stored alongside the resolved rows.

        Rows may be specified directly by row index or resolved from item IDs.

        If `highlight=true`, the resolved rows are also applied as the current
        highlights for the view.

        `WorkingSelection` is set-like and does not preserve ranking order.
        Use a result set instead when ordering is significant.

        Ranking order belongs to the external client. Register rows/item IDs in 
        the desired order, then focus by index. WorkingSelection remains set-like 
        and should not be used to preserve external ranking order.

        This lets an external tool reproduce the useful “click row in 
        ranking table → camera moves there” interaction without HyCompass 
        maintaining the ranking technique.
        """
    ).strip(),
    operation_id="set_result_set",
)
def result_set(
    view_id: str,
    result_id: str,
    payload: ResultSetRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Store a revisioned result set for a view."""
    view = resolve_view(view_id, session, runtime)

    engine = PointQueryEngine(view)
    try:
        rows = engine.resolve_rows(
            rows=payload.rows,
            item_ids=payload.item_ids,
        )
    except QueryError as exc:
        raise HTTPException(400, str(exc)) from exc

    stored = ResultSet(
        result_id,
        rows,
        list(payload.scores) if payload.scores is not None else None,
        list(payload.labels) if payload.labels is not None else None,
        dict(payload.metadata or {}),
    )

    revision = runtime.set_result_set(
        view_id,
        stored,
        cause="api",
    )

    if bool(payload.highlight):
        runtime.set_highlights(
            view_id,
            rows,
            cause="result_set",
        )
        runtime.enqueue(
            "highlights",
            view_id,
            rows=rows,
        )

    return {
        "id": result_id,
        "count": int(len(rows)),
        "revision": revision,
    }


@router.post(
    "/views/{view_id}/focus",
    tags=["Views"],
    response_model=FocusResponse,
    summary="Focus one item",
    operation_id="focus_item",
)
def focus(
    view_id: str,
    payload: FocusRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Focus one row directly or by stored result-set index."""
    view = resolve_view(view_id, session, runtime)
    engine = PointQueryEngine(view)
    if payload.result_set is not None:
        key = (view_id, str(payload.result_set))
        idx = int(payload.index)
        with runtime.lock:
            stored = runtime.result_sets.get(key)
        if stored is None or idx < 0 or idx >= len(stored.rows):
            raise HTTPException(404, "unknown result set/index")
        row = int(stored.rows[idx])
    else:
        rows_arg = payload.rows
        item_ids_arg = payload.item_ids
        if rows_arg is None and "row" in payload.model_fields_set:
            rows_arg = [payload.row]
        if item_ids_arg is None and "item_id" in payload.model_fields_set:
            item_ids_arg = [payload.item_id]
        try:
            resolved = engine.resolve_rows(rows=rows_arg, item_ids=item_ids_arg)
        except QueryError as exc:
            raise HTTPException(400, str(exc)) from exc
        if len(resolved) != 1:
            raise HTTPException(400, "focus requires exactly one item")
        row = int(resolved[0])
    revision = runtime.set_focus(view_id, row, cause="api")
    runtime.enqueue("focus", view_id, row=row)
    return {"row": row, "item_id": view.item_id(row), "revision": revision}


@router.post(
    "/views/{view_id}/fit",
    tags=["Views"],
    response_model=CountResponse,
    summary="Request camera fit",
    operation_id="fit_camera",
)
def fit(
    view_id: str,
    payload: SelectionMutationRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Request a GUI camera fit around resolved rows and publish the request event."""
    view = resolve_view(view_id, session, runtime)
    engine = PointQueryEngine(view)
    try:
        rows = engine.resolve_rows(rows=payload.rows, item_ids=payload.item_ids)
    except QueryError as exc:
        raise HTTPException(400, str(exc)) from exc
    runtime.enqueue("fit", view_id, rows=rows)
    with runtime.lock:
        spec = runtime.views.get(view_id)
        revision = runtime._revisions.get(view_id, {}).get("view", 0)
    runtime.events.publish(
        "camera.fit_requested",
        revision=revision,
        view=view_id,
        domain=spec.domain if spec else None,
        projection=spec.projection if spec else None,
        data={"count": int(len(rows))},
    )
    return {"count": int(len(rows))}


@router.post(
    "/views/{view_id}/visibility/query",
    tags=["Views", "Query"],
    response_model=VisibilityResponse,
    summary="Set visibility from a query",
    operation_id="set_visibility_query",
)
def visibility(
    view_id: str,
    payload: VisibilityRequest,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Evaluate a visibility predicate, enqueue the mask and update runtime state."""
    view = resolve_view(view_id, session, runtime)
    where = payload.where or {"op": "all"}
    try:
        rows = PointQueryEngine(view).query(where)
    except QueryError as exc:
        raise HTTPException(400, str(exc)) from exc
    mask = np.zeros(view.n, dtype=np.uint8)
    mask[rows] = 1
    revision = runtime.set_visibility(view_id, where, visible_count=len(rows), cause="api")
    runtime.enqueue("visibility", view_id, mask=mask, query=where)
    return {"visible": int(len(rows)), "total": view.n, "revision": revision}


@router.delete(
    "/views/{view_id}/visibility",
    tags=["Views"],
    response_model=OkRevisionResponse,
    summary="Clear visibility filtering",
    operation_id="clear_visibility",
)
def clear_visibility(
    view_id: str,
    session=Depends(get_session),
    runtime=Depends(get_runtime),
):
    """Restore unfiltered visibility and notify the GUI bridge."""
    view = resolve_view(view_id, session, runtime)
    revision = runtime.set_visibility(
        view_id,
        None,
        visible_count=view.projected_count,
        cause="api_clear",
    )
    runtime.enqueue("visibility", view_id, mask=None, query=None)
    return {"ok": True, "revision": revision}


################################################################################
if __name__=="__main__":
    pass
