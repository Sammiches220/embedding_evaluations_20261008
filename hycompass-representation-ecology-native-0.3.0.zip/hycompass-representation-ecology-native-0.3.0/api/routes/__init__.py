"""FastAPI routers grouped by public API subsystem."""
