"""Server-Sent Events route."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import json
from queue import Empty
from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from fastapi.responses import StreamingResponse

##### Internal Imports #####
from ..dependencies import get_runtime

##### Global Variables #####
router = APIRouter()


################################################################################
# FUNCTIONS
################################################################################
def _sse(event: dict[str, Any]) -> str:
    """Serialize one event dictionary as an SSE frame."""
    event_id = event.get("event_id")
    prefix = f"id: {int(event_id)}\n" if event_id is not None else ""
    event_type = str(event.get("type") or "message")
    data = json.dumps(event, separators=(",", ":"), ensure_ascii=False)
    return f"{prefix}event: {event_type}\ndata: {data}\n\n"


################################################################################
# API ROUTES
################################################################################
@router.get(
    "/events",
    tags=["Events"],
    summary="Subscribe to runtime events",
    description=(
        "Server-Sent Events stream. The first frame is `stream.ready`. Replay is supported "
        "through `since_event_id` or the `Last-Event-ID` header. If history has expired or a "
        "subscriber queue overflows, clients receive `stream.resync_required` and should recover "
        "through revisioned REST snapshots."
    ),
    operation_id="stream_events",
    response_model=None,
    response_class=StreamingResponse,
    responses={
        200: {
            "description": "SSE stream",
            "content": {"text/event-stream": {"schema": {"type": "string"}}},
        },
        400: {"description": "Invalid Last-Event-ID header"},
    },
)
def event_stream(
    types: str | None = Query(None, description="Comma-separated exact event types; suffix * matches a prefix."),
    view: str | None = Query(None),
    domain: str | None = Query(None),
    since_event_id: int | None = Query(None, ge=0),
    heartbeat: float = Query(15.0, ge=2.0, le=60.0),
    last_event_id: str | None = Header(None, alias="Last-Event-ID"),
    runtime=Depends(get_runtime),
):
    """Open the event stream without blocking runtime producers."""
    since = since_event_id
    if since is None and last_event_id:
        try:
            since = max(0, int(last_event_id))
        except ValueError as exc:
            raise HTTPException(400, "Last-Event-ID must be an integer") from exc

    wanted = {x.strip() for x in (types or "").split(",") if x.strip()} or None
    sub, replay, resync, head = runtime.events.subscribe(
        since_event_id=since,
        types=wanted,
        view=view,
        domain=domain,
    )

    def generate():
        try:
            yield _sse({
                "type": "stream.ready",
                "revision": 0,
                "time": None,
                "view": view,
                "domain": domain,
                "projection": None,
                "data": {"version": "0.5.4", "head_event_id": head, "replay_count": len(replay)},
            })
            if resync:
                yield _sse({
                    "event_id": head,
                    "type": "stream.resync_required",
                    "revision": 0,
                    "time": None,
                    "view": view,
                    "domain": domain,
                    "projection": None,
                    "data": {"reason": "event_history_expired", "head_event_id": head},
                })
            else:
                for event in replay:
                    yield _sse(event)

            while True:
                try:
                    event = sub.queue.get(timeout=float(heartbeat))
                except Empty:
                    yield f": keepalive head={runtime.events.head}\n\n"
                else:
                    yield _sse(event)
        finally:
            runtime.events.unsubscribe(sub.token)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )


################################################################################
if __name__=="__main__":
    pass
