"""Pydantic models used only at the HyCompass HTTP boundary."""
