"""Reusable HTTP schemas shared by multiple route groups."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from typing import Any

from pydantic import Field

##### Internal Imports #####
from .base import ApiModel
from .descriptions import FEATURE_SELECTION_DESCRIPTION

##### Global Variables #####
JsonObject = dict[str, Any]


################################################################################
# CLASSES
################################################################################
class OkResponse(ApiModel):
    """Simple success response."""

    ok: bool = True


class RevisionResponse(ApiModel):
    """A response carrying a runtime revision."""

    revision: int


class CountResponse(ApiModel):
    """Count returned after a mutation."""

    count: int


class CountRevisionResponse(CountResponse, RevisionResponse):
    """Count and resulting runtime revision."""


class PageInfo(ApiModel):
    """Common pagination metadata."""

    total: int
    offset: int
    next_offset: int | None = None


class RowsPage(PageInfo):
    """A paged row/item-id result."""

    rows: list[int]
    item_ids: list[str]


class ErrorBody(ApiModel):
    """Common string error body used by FastAPI HTTP exceptions."""

    detail: str | JsonObject | list[JsonObject]


class ItemSelector(ApiModel):
    """Rows and/or stable item IDs resolved by ``PointQueryEngine``."""

    rows: list[int] | None = None
    item_ids: list[str] | None = None


class FeatureSelection(ApiModel):
    """Requested feature names.

    Feature names are intentionally strings because the available feature set is
    workspace-dependent. The default matches the existing API.
    """

    features: list[str] | None = Field(
        default=None,
        description=FEATURE_SELECTION_DESCRIPTION,
    )

    def requested_features(self) -> list[str]:
        """Return the effective feature list used by the legacy API."""
        return list(self.features or ["position"])


################################################################################
if __name__=="__main__":
    pass
