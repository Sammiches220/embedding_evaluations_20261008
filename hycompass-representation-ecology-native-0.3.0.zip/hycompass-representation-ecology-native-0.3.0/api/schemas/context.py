"""Schemas for selecting a live view or ad-hoc API context."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from pydantic import Field

##### Internal Imports #####
from .base import ApiModel


################################################################################
# CLASSES
################################################################################
class ApiContext(ApiModel):
    """Context used by query and feature endpoints.

    Supply ``view`` to use a live runtime view, or supply both ``domain`` and
    ``projection`` for an ad-hoc context. The route layer preserves the existing
    400 error when neither form is complete.
    """

    view: str | None = None
    domain: str | None = None
    projection: str | None = None
    selection: str | None = None
    timeline: str | None = None
    playback_start: float | None = None
    playback_end: float | None = None
    timeline_progress: float | None = Field(
        default=None,
        description="Override timeline progress for this request; defaults to 0.5 for ad-hoc contexts.",
    )


################################################################################
if __name__=="__main__":
    pass
