"""Schemas for saved query/view endpoints."""

################################################################################
# MAIN
################################################################################

##### External Imports #####
from __future__ import annotations

from typing import Any

from pydantic import Field

##### Internal Imports #####
from .base import ApiModel
from .compat import FalsyEmptyString, LegacyDict
from .descriptions import SAVED_POINT_QUERY_DESCRIPTION


################################################################################
# CLASSES
################################################################################
class SavedQueryResponse(ApiModel):
    id: str
    title: str
    folder: str
    domain: str
    projection: str | None
    query: dict[str, Any] = Field(description=SAVED_POINT_QUERY_DESCRIPTION)


class SavedQueryCreate(ApiModel):
    id: FalsyEmptyString = ""
    title: str | None = None
    folder: FalsyEmptyString = ""
    domain: FalsyEmptyString = ""
    projection: str | None = None
    query: LegacyDict | None = Field(default=None, description=SAVED_POINT_QUERY_DESCRIPTION)
    metadata: LegacyDict | None = None


class IdResponse(ApiModel):
    id: str


class SavedViewResponse(ApiModel):
    id: str
    title: str
    folder: str
    domain: str
    projection: str


################################################################################
if __name__=="__main__":
    pass
