"""Compatibility-oriented scalar types for the legacy dictionary API.

The original routes frequently normalized JSON values with ``str()``, ``int()``,
``bool()`` and ``dict()``. These annotated Pydantic types preserve those useful
coercions while still publishing concrete OpenAPI types.
"""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from typing import Annotated, Any

from pydantic import BeforeValidator


################################################################################
# FUNCTIONS
################################################################################
def _as_bool(value: Any) -> bool:
    return bool(value)


def _as_int(value: Any) -> int:
    return int(value)


def _as_string(value: Any) -> str:
    return str(value)


def _as_falsy_empty_string(value: Any) -> str:
    return str(value or "")


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value or {})

##### Global Variables #####
LegacyBool = Annotated[bool, BeforeValidator(_as_bool)]
LegacyInt = Annotated[int, BeforeValidator(_as_int)]
Stringified = Annotated[str, BeforeValidator(_as_string)]
FalsyEmptyString = Annotated[str, BeforeValidator(_as_falsy_empty_string)]
LegacyDict = Annotated[dict[str, Any], BeforeValidator(_as_dict)]


################################################################################
if __name__=="__main__":
    pass
