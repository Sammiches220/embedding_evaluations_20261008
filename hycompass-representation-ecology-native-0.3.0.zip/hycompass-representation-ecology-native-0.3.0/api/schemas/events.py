"""Schemas describing HyCompass SSE event metadata."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from typing import Any

##### Internal Imports #####
from .base import ApiModel


################################################################################
# CLASSES
################################################################################
class EventEnvelope(ApiModel):
    """Stable envelope published by the in-process event hub."""

    event_id: int | None = None
    type: str
    revision: int
    time: str | None
    view: str | None = None
    domain: str | None = None
    projection: str | None = None
    data: dict[str, Any]


class StreamReadyData(ApiModel):
    """Payload of the initial ``stream.ready`` event."""

    version: str
    head_event_id: int
    replay_count: int


class ResyncRequiredData(ApiModel):
    """Payload instructing a client to recover from revisioned snapshots."""

    reason: str
    head_event_id: int


################################################################################
if __name__=="__main__":
    pass
