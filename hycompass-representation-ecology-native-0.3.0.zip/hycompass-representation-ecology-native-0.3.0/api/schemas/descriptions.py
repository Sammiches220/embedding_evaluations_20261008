"""Reusable OpenAPI descriptions."""

################################################################################
# DESCRIPTIONS
################################################################################

DOMAIN = "unique Domain ID"

## Query-language fields
POINT_QUERY_DESCRIPTION = (
    "PointQuery JSON expression. See the "
    "[PointQuery language](../../../project/POINT_QUERIES.html#pointquery-language) "
    "reference in the combined MkDocs documentation."
)

FEATURE_SELECTION_DESCRIPTION = (
    "FeatureProvider feature names to return. See the "
    "[FeatureProvider language](../../../project/POINT_QUERIES.html#featureprovider-language) "
    "reference in the combined MkDocs documentation. Omitted or empty lists "
    "default to ['position'] at the REST API boundary."
)

SAVED_POINT_QUERY_DESCRIPTION = (
    "Stored PointQuery JSON expression. See the "
    "[PointQuery language](../../../project/POINT_QUERIES.html#pointquery-language) "
    "reference in the combined MkDocs documentation."
)

FEATURE_RECORDS_DESCRIPTION = (
    "Dynamic records produced by FeatureProvider. See the "
    "[FeatureProvider language](../../../project/POINT_QUERIES.html#featureprovider-language) "
    "reference for built-ins, kind:asset names, and exact record-shape behavior."
)


################################################################################
if __name__=="__main__":
    pass
