"""Shared configuration for API request and response models."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from pydantic import BaseModel, ConfigDict


################################################################################
# CLASSES
################################################################################
class ApiModel(BaseModel):
    """Base model for HyCompass HTTP DTOs.

    Unknown fields are ignored to preserve the existing API's permissive request
    behavior. Numeric values may be coerced to strings where a public identifier
    is represented as a string, matching the old ``str(payload.get(...))`` style.
    """

    model_config = ConfigDict(extra="ignore", coerce_numbers_to_str=True)


################################################################################
if __name__=="__main__":
    pass
