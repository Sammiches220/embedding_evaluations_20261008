"""Schemas for runtime views and view mutations."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

from typing import Any

from pydantic import Field

##### Internal Imports #####
from .base import ApiModel
from .common import FeatureSelection, ItemSelector, JsonObject, PageInfo
from .descriptions import FEATURE_RECORDS_DESCRIPTION, POINT_QUERY_DESCRIPTION
from .compat import LegacyBool, LegacyDict, LegacyInt, Stringified


################################################################################
# CLASSES
################################################################################
class RuntimeViewSummary(ApiModel):
    id: str
    title: str
    domain: str
    projection: str


class ActiveViewSummary(ApiModel):
    view: str
    title: str
    domain: str
    projection: str


class GlobalStateResponse(ApiModel):
    version: str
    head_event_id: int
    workspace_revision: int
    active_view_revision: int
    active_view: ActiveViewSummary | None
    runtime_view_count: int


class ActiveViewStateResponse(ApiModel):
    revision: int
    active_view: ActiveViewSummary | None
    head_event_id: int


class ViewCounts(ApiModel):
    working_selection: int
    highlights: int
    visible: int | None


class ViewStateResponse(ApiModel):
    view: str
    domain: str
    projection: str
    title: str
    active: bool
    revisions: dict[str, int]
    counts: ViewCounts
    timeline_progress: float
    predicate_source: dict[str, Any]
    predicate_query_hash: str | None
    visibility_query_hash: str | None
    focused_row: int | None
    head_event_id: int


class WorkingSelectionStateResponse(ApiModel):
    type: str
    view: str
    domain: str | None
    projection: str | None
    revision: int
    count: int
    updated_at: str
    head_event_id: int


class WorkingSelectionDeltaResponse(ApiModel):
    from_revision: int
    to_revision: int
    snapshot_required: bool
    count: int
    added_rows: list[int] | None = None
    removed_rows: list[int] | None = None
    added_item_ids: list[str] | None = None
    removed_item_ids: list[str] | None = None


class PredicateStateResponse(ApiModel):
    type: str
    view: str
    domain: str | None
    projection: str | None
    revision: int
    updated_at: str
    query_hash: str | None
    query: JsonObject = Field(description=POINT_QUERY_DESCRIPTION)
    source: str
    saved_query_id: str | None
    saved_query_name: str | None


class WorkingSelectionPage(PageInfo):
    revision: int
    rows: list[int]
    item_ids: list[str]


class WorkingSelectionFeaturesRequest(FeatureSelection):
    revision: LegacyInt | None = None
    offset: LegacyInt = 0
    limit: LegacyInt = 1000

    def normalized_page(self) -> tuple[int, int]:
        return max(0, int(self.offset)), min(10_000, max(1, int(self.limit)))


class WorkingSelectionFeaturesResponse(PageInfo):
    revision: int
    items: list[dict[str, Any]] = Field(description=FEATURE_RECORDS_DESCRIPTION)


class SelectionMutationRequest(ItemSelector):
    mode: Stringified = Field(
        default="replace",
        description=(
            "Combination mode. Existing behavior recognizes add, subtract and intersect; "
            "all other values use replace semantics for compatibility."
        ),
    )


class ResultSetRequest(ItemSelector):
    scores: list[float] | None = None
    labels: list[str] | None = None
    metadata: LegacyDict | None = None
    highlight: LegacyBool = True


class ResultSetResponse(ApiModel):
    id: str
    count: int
    revision: int


class FocusRequest(ItemSelector):
    row: int | None = None
    item_id: str | None = None
    result_set: str | None = None
    index: LegacyInt = 0


class FocusResponse(ApiModel):
    row: int
    item_id: str
    revision: int


class VisibilityRequest(ApiModel):
    where: JsonObject | None = Field(default=None, description=POINT_QUERY_DESCRIPTION)


class VisibilityResponse(ApiModel):
    visible: int
    total: int
    revision: int


class OkRevisionResponse(ApiModel):
    ok: bool = True
    revision: int


################################################################################
if __name__=="__main__":
    pass
