"""FastAPI application factory for the HyCompass REST API."""

################################################################################
# CONFIGURATION
################################################################################

##### External Imports #####
from __future__ import annotations

import threading
from typing import Any
from textwrap import dedent

from fastapi import FastAPI, Request
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

##### Internal Imports #####
from .routes import assets, events, query, saved, system, views, ecology

##### Global Variables #####
API_VERSION = "0.6.0"

OPENAPI_TAGS = [
    {"name": "System", "description": "Health and global runtime state."},
    {"name": "Events", "description": "Revisioned Server-Sent Events and replay/resync semantics."},
    {"name": "Workspace", "description": "Workspace manifest inspection and reload operations."},
    {"name": "Views", "description": "Runtime view state and interactive view mutations."},
    {
        "name": "Query", 
        "description": dedent(
            """
            Structured point-query execution.

            Data queries do **not** require an open GUI View.

            A request may use either a View:

            ```json
            {
            "view": "default"
            }
            ```

            or an ad-hoc context:

            ```json
            {
            "domain": "swinv2-v3",
            "projection": "external-umap",
            "timeline": "archive-time",
            "timeline_progress": 0.65
            }
            ```

            The latter is important for automation: 
            a client can query any compatible assets without creating or opening a GUI View. 
            PointQuery expressions may combine arbitrary compatible assets, 
            including multiple clusterings, segmentations, density fields, selections, and exploration fields.

            Supported ad-hoc context fields:

            ```text
            domain
            projection
            selection          optional active Selection
            timeline           optional active Timeline
            timeline_progress  optional normalized 0..1, default 0.5
            playback_start     optional UNIX seconds
            playback_end       optional UNIX seconds
            ```

            GUI-control operations such as camera focus/highlights still require a View.

            Discover the available IDs first through the feature catalog, then query and retrieve features together.
            """
        ).strip(),
    },
    {
        "name": "Features", 
        "description": dedent(
            """
            Dynamic item features and compatible feature catalogs.

            Before constructing queries, discover compatible assets in the catalog.

            Example:

            ```json
            {
            "domain": "swinv2-v3",
            "projection": "external-umap",
            "timeline": "archive-time"
            }
            ```

            Response shape:

            ```json
            {
            "domain": "swinv2-v3",
            "projection": "external-umap",
            "timeline": "archive-time",
            "selections": ["swinv2-v3-all", "favorites"],
            "clusterings": ["hdbscan-v4", "kmeans-v2"],
            "densities": ["adaptive-kde"],
            "segmentations": ["external-regions"],
            "explorations": ["favorites-coverage", "favorites-history"],
            "builtins": ["position", "timeline", "row", "item_id"]
            }
            ```

            PointQuery expressions may reference compatible assets even if those assets are not currently displayed by a GUI View.
            """
        ).strip(),
    },
    {
        "name": "Assets",
        "description": dedent(
            """
            Asset contracts, catalog inspection, and registration.

            **Typical errors:**

            - HTTP `400` — Invalid shape, dtype, path, dependency, range, or request.
            - HTTP `409` — An asset ID already exists and `replace=true` was not requested.

            After successful REST registration, the workspace/session is reloaded
            automatically.

            For externally edited files that are not re-registered, use
            `POST /workspace/reload`.
            """
        ).strip(),
    },
    {"name": "Saved Queries", "description": "Persistent saved-query definitions."},
    {"name": "Saved Views", "description": "Persistent saved-view definitions."},
]


################################################################################
# FUNCTIONS
################################################################################
def create_app(session: Any | None = None, runtime: Any | None = None) -> FastAPI:
    """Create the HyCompass REST application.

    The factory is safe to call without a loaded workspace or runtime. This is
    intentional: documentation tooling can call ``create_app().openapi()`` while
    data-dependent endpoints fail with 503 only if they are actually invoked.

    Args:
        session: Optional live workspace/session object.
        runtime: Optional shared ``RuntimeState`` instance.

    Returns:
        Configured FastAPI application.
    """
    app = FastAPI(
        title="Latent Observer API",
        version=API_VERSION,
        description=(
            "Code-first REST and SSE interface for HyCompass runtime views, queries, "
            "features, assets and saved workspace state."
        ),
        openapi_tags=OPENAPI_TAGS,
    )
    app.state.session = session
    app.state.runtime = runtime

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        """Keep query/path FastAPI validation while treating typed body fields as API 400s.

        The old implementation manually parsed most JSON-body fields and commonly
        surfaced malformed values as request errors. Missing/malformed JSON bodies
        retain FastAPI's ordinary 422 behavior; field-level DTO validation is mapped
        to 400 so the typed refactor does not broadly turn domain-style request
        errors into 422 responses.
        """
        errors = exc.errors()
        body_field_errors = bool(errors) and all(
            error.get("loc")
            and error["loc"][0] == "body"
            and error.get("type") not in {"missing", "json_invalid"}
            for error in errors
        )
        if body_field_errors:
            return JSONResponse(status_code=400, content={"detail": errors})
        return await request_validation_exception_handler(request, exc)

    app.include_router(system.router)
    app.include_router(events.router)
    app.include_router(query.router)
    app.include_router(views.router)
    app.include_router(assets.router)
    app.include_router(saved.router)
    app.include_router(ecology.router)
    return app


def start_api_server(session: Any, runtime: Any, host: str, port: int) -> threading.Thread:
    """Start Uvicorn in the same daemon-thread pattern as the existing API."""

    def run() -> None:
        try:
            import uvicorn
        except ImportError as exc:
            raise RuntimeError("REST API requires uvicorn; install requirements.txt") from exc
        uvicorn.run(create_app(session, runtime), host=host, port=int(port), log_level="info")

    thread = threading.Thread(target=run, name="latent-observer-api", daemon=True)
    thread.start()
    return thread


################################################################################
if __name__=="__main__":
    pass
