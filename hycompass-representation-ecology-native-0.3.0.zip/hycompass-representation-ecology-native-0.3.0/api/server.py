"""Backward-compatible imports for the refactored API factory.

Existing callers may continue importing ``create_app`` and ``start_api_server``
from ``api.server`` while route implementation lives in focused modules.
"""

################################################################################
# CONFIGURATION
################################################################################

##### Internal Imports #####
from .app import create_app, start_api_server
from .routes.views import _combine

##### Global Variables #####
__all__ = ["create_app", "start_api_server", "_combine"]


################################################################################
if __name__=="__main__":
    pass
